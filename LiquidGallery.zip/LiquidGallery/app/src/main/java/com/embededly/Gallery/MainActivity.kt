package com.embededly.Gallery

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

data class LaunchInfo(val viewUri: Uri?, val pick: Boolean, val onPick: (Uri) -> Unit)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val act = intent?.action
        val info = LaunchInfo(
            viewUri = if (act == Intent.ACTION_VIEW) intent.data else null,
            pick = act == Intent.ACTION_GET_CONTENT || act == Intent.ACTION_PICK,
            onPick = { uri ->
                setResult(RESULT_OK, Intent().setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                finish()
            }
        )
        setContent {
            val prefs = remember { Prefs(applicationContext) }
            val sysDark = isSystemInDarkTheme()
            val dark = when (prefs.theme.value) { "light" -> false; "system" -> sysDark; else -> true }
            val pal = Pal(
                bg = if (dark) (if (prefs.amoled.value) Color.Black else Color(0xFF121214)) else Color(0xFFF2F2F7),
                fg = if (dark) Color.White else Color.Black,
                sub = if (dark) Color(0xFF9A9AA0) else Color(0xFF6C6C70),
                glass = if (dark) Color(0xFF1E1E22) else Color.White,
                accent = ACCENTS[prefs.accent.value.coerceIn(ACCENTS.indices)],
                dark = dark
            )
            LaunchedEffect(dark) {
                val s = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
                enableEdgeToEdge(statusBarStyle = s, navigationBarStyle = s)
            }
            val touch = remember { mutableStateOf(Offset.Unspecified) }
            CompositionLocalProvider(LocalPrefs provides prefs, LocalPal provides pal, LocalTouch provides touch) {
                MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                    // запоминаем точку касания (ничего не перехватывая): из неё «вываливаются» окна
                    Box(Modifier.fillMaxSize().pointerInput(Unit) {
                        awaitPointerEventScope {
                            while (true) {
                                val c = awaitPointerEvent(PointerEventPass.Initial).changes.firstOrNull()
                                if (c != null && c.pressed && !c.previousPressed) touch.value = c.position
                            }
                        }
                    }) { Root(info) }
                }
            }
        }
    }
}

@Composable
private fun Root(info: LaunchInfo) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    var granted by remember {
        mutableStateOf(perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED })
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r.values.all { it }
    }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(perms) }
    if (granted) GalleryScreen(info) else {
        Box(Modifier.fillMaxSize().background(pal.bg), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(t(R.string.s_024), color = pal.fg)
                GlassButton(t(R.string.s_025)) { launcher.launch(perms) }
            }
        }
    }
}
