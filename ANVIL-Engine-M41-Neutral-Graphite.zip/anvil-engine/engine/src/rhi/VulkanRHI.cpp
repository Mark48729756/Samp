// ANVIL RHI - Vulkan backend (M34).
//
// Tiers: Backend::Vulkan14 requires a Vulkan 1.4 instance + device; Backend::Vulkan12 runs on 1.2+ devices using
// VK_KHR_dynamic_rendering / VK_KHR_synchronization2. Both share one code path (entry points are resolved with
// vkGetDeviceProcAddr, core name first, KHR name second).
//
// Design notes
//  * Dynamic rendering only (no VkRenderPass / VkFramebuffer). Sync2 barriers, timeline semaphore for frame pacing.
//  * Image layouts are tracked per texture inside the backend and barriers are emitted automatically, in RECORD order.
//    Command lists must therefore be submitted in the order they were recorded.
//  * Descriptors: set 0 = 4 uniform buffers, set 1 = 16 combined image samplers. Sets are allocated from per-frame
//    pools (reset in beginFrame). Unbound slots point at a fallback buffer / 1x1 white texture.
//  * One fixed pipeline layout (set 0, set 1, 128 bytes of push constants), so descriptor sets survive pipeline changes.
//  * Viewport is flipped (negative height) so GL-style clip space and winding work unchanged. Texture origin is
//    top-left (Vulkan convention).
//  * `dynamic` buffers keep one copy per frame in flight (+ a CPU shadow): update() is safe while the GPU still
//    reads the previous frame. Static buffers are updated through a staging copy that waits for the queue (slow path).
//  * Resource destruction is deferred until the GPU has finished the last submit made before the destruction.
//  * Single-threaded: create resources, record and submit from one thread.
//  * Only one command list per frame may render to the swapchain backbuffer.
#include "anvil/rhi/RHI.h"
#include "anvil/Core.h"

#include <vulkan/vulkan.h>
#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#if defined(_MSC_VER)
#pragma warning(push, 0)
#endif
#define VMA_VULKAN_VERSION 1003000
#define VMA_STATIC_VULKAN_FUNCTIONS 1
#define VMA_DYNAMIC_VULKAN_FUNCTIONS 0
#define VMA_IMPLEMENTATION
#include <vk_mem_alloc.h>
#if defined(_MSC_VER)
#pragma warning(pop)
#endif

#include <algorithm>
#include <array>
#include <cstring>
#include <deque>
#include <functional>
#include <limits>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

#ifndef VK_API_VERSION_1_4
#define VK_API_VERSION_1_4 VK_MAKE_API_VERSION(0, 1, 4, 0)
#endif

namespace anvil::rhi::vk {
namespace {

constexpr std::uint32_t kFrames = 2;
constexpr VkDeviceSize kFallbackUboSize = 16384;

std::string vkErr(VkResult r) {
    switch (r) {
        case VK_ERROR_OUT_OF_HOST_MEMORY: return "VK_ERROR_OUT_OF_HOST_MEMORY";
        case VK_ERROR_OUT_OF_DEVICE_MEMORY: return "VK_ERROR_OUT_OF_DEVICE_MEMORY";
        case VK_ERROR_INITIALIZATION_FAILED: return "VK_ERROR_INITIALIZATION_FAILED";
        case VK_ERROR_DEVICE_LOST: return "VK_ERROR_DEVICE_LOST";
        case VK_ERROR_LAYER_NOT_PRESENT: return "VK_ERROR_LAYER_NOT_PRESENT";
        case VK_ERROR_EXTENSION_NOT_PRESENT: return "VK_ERROR_EXTENSION_NOT_PRESENT";
        case VK_ERROR_FEATURE_NOT_PRESENT: return "VK_ERROR_FEATURE_NOT_PRESENT";
        case VK_ERROR_INCOMPATIBLE_DRIVER: return "VK_ERROR_INCOMPATIBLE_DRIVER";
        case VK_ERROR_SURFACE_LOST_KHR: return "VK_ERROR_SURFACE_LOST_KHR";
        case VK_ERROR_OUT_OF_DATE_KHR: return "VK_ERROR_OUT_OF_DATE_KHR";
        default: return "VkResult(" + std::to_string(static_cast<int>(r)) + ")";
    }
}
#define VK_CHECK(x) do { const VkResult vkr_ = (x); if (vkr_ != VK_SUCCESS) \
    throw std::runtime_error(std::string("Vulkan call failed: " #x " -> ") + ::anvil::rhi::vk::vkErr(vkr_)); } while (0)

// ---------------------------------------------------------------------------------------------------------------------
// format helpers
bool isDepthFormat(TextureFormat f) { return f == TextureFormat::Depth24 || f == TextureFormat::Depth32F || f == TextureFormat::Depth24Stencil8; }
bool hasStencil(TextureFormat f) { return f == TextureFormat::Depth24Stencil8; }
std::uint32_t bytesPerPixel(TextureFormat f) {
    switch (f) {
        case TextureFormat::R8: return 1;
        case TextureFormat::RG8: case TextureFormat::R16F: return 2;
        case TextureFormat::RGB8: return 3;   // expanded to RGBA8 on upload
        case TextureFormat::RGBA16F: return 8;
        case TextureFormat::Undefined: return 0;
        default: return 4;
    }
}
VkImageAspectFlags attachAspect(TextureFormat f) {
    if (!isDepthFormat(f)) return VK_IMAGE_ASPECT_COLOR_BIT;
    return VK_IMAGE_ASPECT_DEPTH_BIT | (hasStencil(f) ? VK_IMAGE_ASPECT_STENCIL_BIT : 0);
}
VkImageAspectFlags sampleAspect(TextureFormat f) { return isDepthFormat(f) ? VK_IMAGE_ASPECT_DEPTH_BIT : VK_IMAGE_ASPECT_COLOR_BIT; }
VkImageLayout readLayout(TextureFormat f) { return isDepthFormat(f) ? VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL : VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL; }

VkCompareOp toVk(CompareOp o) {
    switch (o) {
        case CompareOp::Never: return VK_COMPARE_OP_NEVER; case CompareOp::Less: return VK_COMPARE_OP_LESS;
        case CompareOp::Equal: return VK_COMPARE_OP_EQUAL; case CompareOp::LessEqual: return VK_COMPARE_OP_LESS_OR_EQUAL;
        case CompareOp::Greater: return VK_COMPARE_OP_GREATER; case CompareOp::NotEqual: return VK_COMPARE_OP_NOT_EQUAL;
        case CompareOp::GreaterEqual: return VK_COMPARE_OP_GREATER_OR_EQUAL; case CompareOp::Always: return VK_COMPARE_OP_ALWAYS;
    }
    return VK_COMPARE_OP_ALWAYS;
}
VkSamplerAddressMode toVk(TextureWrap w) {
    switch (w) {
        case TextureWrap::Repeat: return VK_SAMPLER_ADDRESS_MODE_REPEAT;
        case TextureWrap::ClampToEdge: return VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
        case TextureWrap::MirroredRepeat: return VK_SAMPLER_ADDRESS_MODE_MIRRORED_REPEAT;
        case TextureWrap::ClampToBorder: return VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_BORDER;
    }
    return VK_SAMPLER_ADDRESS_MODE_REPEAT;
}
VkFormat toVk(VertexFormat f) {
    switch (f) {
        case VertexFormat::Float: return VK_FORMAT_R32_SFLOAT; case VertexFormat::Float2: return VK_FORMAT_R32G32_SFLOAT;
        case VertexFormat::Float3: return VK_FORMAT_R32G32B32_SFLOAT; case VertexFormat::Float4: return VK_FORMAT_R32G32B32A32_SFLOAT;
        case VertexFormat::UByte4Norm: return VK_FORMAT_R8G8B8A8_UNORM; case VertexFormat::UInt: return VK_FORMAT_R32_UINT;
    }
    return VK_FORMAT_R32G32B32_SFLOAT;
}
VkPrimitiveTopology toVk(PrimitiveTopology t) {
    switch (t) {
        case PrimitiveTopology::TriangleList: return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
        case PrimitiveTopology::TriangleStrip: return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_STRIP;
        case PrimitiveTopology::LineList: return VK_PRIMITIVE_TOPOLOGY_LINE_LIST;
        case PrimitiveTopology::PointList: return VK_PRIMITIVE_TOPOLOGY_POINT_LIST;
    }
    return VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
}
TextureFormat fromVkSurfaceFormat(VkFormat f) {
    switch (f) {
        case VK_FORMAT_B8G8R8A8_UNORM: return TextureFormat::BGRA8;
        case VK_FORMAT_B8G8R8A8_SRGB: return TextureFormat::SBGRA8;
        case VK_FORMAT_R8G8B8A8_UNORM: return TextureFormat::RGBA8;
        case VK_FORMAT_R8G8B8A8_SRGB: return TextureFormat::SRGBA8;
        case VK_FORMAT_A2B10G10R10_UNORM_PACK32: return TextureFormat::RGB10A2;
        default: return TextureFormat::BGRA8;
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// barrier helpers (sync2)
struct Scope { VkPipelineStageFlags2 stage; VkAccessFlags2 access; };
Scope scopeFor(VkImageLayout l) {
    switch (l) {
        case VK_IMAGE_LAYOUT_UNDEFINED: return {VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT, 0};
        case VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
            return {VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT, VK_ACCESS_2_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_2_COLOR_ATTACHMENT_WRITE_BIT};
        case VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:
            return {VK_PIPELINE_STAGE_2_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_2_LATE_FRAGMENT_TESTS_BIT,
                    VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_READ_BIT | VK_ACCESS_2_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT};
        case VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:
        case VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL:
            return {VK_PIPELINE_STAGE_2_VERTEX_SHADER_BIT | VK_PIPELINE_STAGE_2_FRAGMENT_SHADER_BIT, VK_ACCESS_2_SHADER_SAMPLED_READ_BIT};
        case VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL: return {VK_PIPELINE_STAGE_2_ALL_TRANSFER_BIT, VK_ACCESS_2_TRANSFER_READ_BIT};
        case VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL: return {VK_PIPELINE_STAGE_2_ALL_TRANSFER_BIT, VK_ACCESS_2_TRANSFER_WRITE_BIT};
        case VK_IMAGE_LAYOUT_PRESENT_SRC_KHR: return {VK_PIPELINE_STAGE_2_NONE, 0};
        default: return {VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT, VK_ACCESS_2_MEMORY_READ_BIT | VK_ACCESS_2_MEMORY_WRITE_BIT};
    }
}
VkImageMemoryBarrier2 makeBarrier(VkImage img, VkImageAspectFlags aspect, std::uint32_t baseMip, std::uint32_t mips,
                                  VkImageLayout oldL, VkImageLayout newL, Scope src, Scope dst) {
    VkImageMemoryBarrier2 b{};
    b.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER_2;
    b.srcStageMask = src.stage; b.srcAccessMask = src.access;
    b.dstStageMask = dst.stage; b.dstAccessMask = dst.access;
    b.oldLayout = oldL; b.newLayout = newL;
    b.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    b.image = img;
    b.subresourceRange = {aspect, baseMip, mips, 0, 1};
    return b;
}

// ---------------------------------------------------------------------------------------------------------------------
VKAPI_ATTR VkBool32 VKAPI_CALL debugCallback(VkDebugUtilsMessageSeverityFlagBitsEXT sev, VkDebugUtilsMessageTypeFlagsEXT,
                                             const VkDebugUtilsMessengerCallbackDataEXT* d, void*) {
    if (sev >= VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT)
        ANVIL_LOG("Vulkan %s: %s", sev >= VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT ? "ERROR" : "warning", d->pMessage);
    return VK_FALSE;
}

std::uint64_t alignUp(std::uint64_t v, std::uint64_t a) { return (v + a - 1) / a * a; }

} // namespace

class Swapchain;

// ---------------------------------------------------------------------------------------------------------------------
// Core: instance, device, allocator, frame timeline, descriptor pools, deferred destruction. Shared by every resource so
// that resources can safely outlive the Device object.
struct Core {
    VkInstance instance = VK_NULL_HANDLE;
    VkDebugUtilsMessengerEXT messenger = VK_NULL_HANDLE;
    VkSurfaceKHR surface = VK_NULL_HANDLE;
    VkPhysicalDevice phys = VK_NULL_HANDLE;
    VkDevice device = VK_NULL_HANDLE;
    VkQueue queue = VK_NULL_HANDLE;
    std::uint32_t queueFamily = 0;
    VmaAllocator vma = nullptr;
    Backend tier = Backend::Vulkan14;
    std::uint32_t deviceApi = 0;
    VkPhysicalDeviceProperties props{};
    DeviceCapabilities caps;
    bool anisotropy = false;

    PFN_vkCmdBeginRenderingKHR cmdBeginRendering = nullptr;
    PFN_vkCmdEndRenderingKHR cmdEndRendering = nullptr;
    PFN_vkCmdPipelineBarrier2KHR cmdBarrier2 = nullptr;
    PFN_vkQueueSubmit2KHR queueSubmit2 = nullptr;
    PFN_vkCmdBeginDebugUtilsLabelEXT cmdBeginLabel = nullptr;
    PFN_vkCmdEndDebugUtilsLabelEXT cmdEndLabel = nullptr;
    PFN_vkDestroyDebugUtilsMessengerEXT destroyMessenger = nullptr;

    VkSemaphore timeline = VK_NULL_HANDLE;
    std::uint64_t submitted = 0;
    std::uint64_t frameValue[kFrames] = {};
    std::uint32_t frame = 0;

    VkDescriptorSetLayout uboLayout = VK_NULL_HANDLE, texLayout = VK_NULL_HANDLE;
    VkPipelineLayout pipelineLayout = VK_NULL_HANDLE;
    VkSampler defaultSampler = VK_NULL_HANDLE;
    VkCommandPool immPool = VK_NULL_HANDLE;

    VkImage fbImage = VK_NULL_HANDLE; VkImageView fbView = VK_NULL_HANDLE; VmaAllocation fbAlloc = nullptr;
    VkBuffer fbBuffer = VK_NULL_HANDLE; VmaAllocation fbBufAlloc = nullptr;

    std::vector<VkDescriptorPool> pools[kFrames];
    std::uint32_t poolIndex[kFrames] = {};

    VkFormat d24 = VK_FORMAT_D32_SFLOAT, d24s8 = VK_FORMAT_D32_SFLOAT_S8_UINT;

    struct Retired { std::uint64_t value; std::function<void()> fn; };
    std::deque<Retired> retired;
    std::mutex mu;

    Core() = default;
    Core(const Core&) = delete;
    Core& operator=(const Core&) = delete;
    ~Core();

    void init(const DeviceCreateInfo& info, Backend tierIn);
    VkFormat vkFormat(TextureFormat f) const;
    void retire(std::function<void()> fn);
    void collect(bool all = false);
    void beginFrame();
    VkDescriptorSet allocSet(VkDescriptorSetLayout layout);
    VkDescriptorPool makePool();

    template <class F> void immediate(F&& f) {
        VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        ai.commandPool = immPool; ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; ai.commandBufferCount = 1;
        VkCommandBuffer cmd{};
        VK_CHECK(vkAllocateCommandBuffers(device, &ai, &cmd));
        VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        VK_CHECK(vkBeginCommandBuffer(cmd, &bi));
        f(cmd);
        VK_CHECK(vkEndCommandBuffer(cmd));
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1; si.pCommandBuffers = &cmd;
        VK_CHECK(vkQueueSubmit(queue, 1, &si, VK_NULL_HANDLE));
        VK_CHECK(vkQueueWaitIdle(queue));
        vkFreeCommandBuffers(device, immPool, 1, &cmd);
    }

    struct Staging { VkBuffer buf = VK_NULL_HANDLE; VmaAllocation alloc = nullptr; };
    Staging makeStaging(const void* data, std::size_t bytes) {
        VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bi.size = bytes; bi.usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        VmaAllocationCreateInfo ai{};
        ai.usage = VMA_MEMORY_USAGE_AUTO;
        ai.flags = VMA_ALLOCATION_CREATE_HOST_ACCESS_SEQUENTIAL_WRITE_BIT | VMA_ALLOCATION_CREATE_MAPPED_BIT;
        Staging s; VmaAllocationInfo info{};
        VK_CHECK(vmaCreateBuffer(vma, &bi, &ai, &s.buf, &s.alloc, &info));
        std::memcpy(info.pMappedData, data, bytes);
        vmaFlushAllocation(vma, s.alloc, 0, VK_WHOLE_SIZE);
        return s;
    }
    void destroyStaging(Staging& s) { if (s.buf) vmaDestroyBuffer(vma, s.buf, s.alloc); s = {}; }

    void uploadBuffer(VkBuffer dst, VkDeviceSize offset, const void* data, std::size_t bytes) {
        Staging s = makeStaging(data, bytes);
        immediate([&](VkCommandBuffer cmd) { VkBufferCopy r{0, offset, bytes}; vkCmdCopyBuffer(cmd, s.buf, dst, 1, &r); });
        destroyStaging(s);
    }

    void barriers(VkCommandBuffer cmd, const VkImageMemoryBarrier2* b, std::uint32_t n) {
        VkDependencyInfo dep{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
        dep.imageMemoryBarrierCount = n; dep.pImageMemoryBarriers = b;
        cmdBarrier2(cmd, &dep);
    }
    void recordMips(VkCommandBuffer cmd, VkImage img, int w, int h, int levels, VkImageLayout level0Old) {
        const auto A = VK_IMAGE_ASPECT_COLOR_BIT;
        {
            VkImageMemoryBarrier2 b[2] = {
                makeBarrier(img, A, 0, 1, level0Old, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, scopeFor(level0Old), scopeFor(VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL)),
                makeBarrier(img, A, 1, static_cast<std::uint32_t>(levels - 1), VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                            scopeFor(VK_IMAGE_LAYOUT_UNDEFINED), scopeFor(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL))};
            barriers(cmd, b, 2);
        }
        int mw = w, mh = h;
        for (int i = 1; i < levels; ++i) {
            const int nw = std::max(1, mw / 2), nh = std::max(1, mh / 2);
            VkImageBlit blit{};
            blit.srcSubresource = {A, static_cast<std::uint32_t>(i - 1), 0, 1};
            blit.srcOffsets[1] = {mw, mh, 1};
            blit.dstSubresource = {A, static_cast<std::uint32_t>(i), 0, 1};
            blit.dstOffsets[1] = {nw, nh, 1};
            vkCmdBlitImage(cmd, img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &blit, VK_FILTER_LINEAR);
            VkImageMemoryBarrier2 b = makeBarrier(img, A, static_cast<std::uint32_t>(i), 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, scopeFor(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL), scopeFor(VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL));
            barriers(cmd, &b, 1);
            mw = nw; mh = nh;
        }
        VkImageMemoryBarrier2 b = makeBarrier(img, A, 0, static_cast<std::uint32_t>(levels), VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
            VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, scopeFor(VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL), scopeFor(VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL));
        barriers(cmd, &b, 1);
    }
};

VkFormat Core::vkFormat(TextureFormat f) const {
    switch (f) {
        case TextureFormat::R8: return VK_FORMAT_R8_UNORM;
        case TextureFormat::RG8: return VK_FORMAT_R8G8_UNORM;
        case TextureFormat::RGB8: case TextureFormat::RGBA8: return VK_FORMAT_R8G8B8A8_UNORM;
        case TextureFormat::SRGBA8: return VK_FORMAT_R8G8B8A8_SRGB;
        case TextureFormat::R16F: return VK_FORMAT_R16_SFLOAT;
        case TextureFormat::RG16F: return VK_FORMAT_R16G16_SFLOAT;
        case TextureFormat::RGBA16F: return VK_FORMAT_R16G16B16A16_SFLOAT;
        case TextureFormat::R32F: return VK_FORMAT_R32_SFLOAT;
        case TextureFormat::Depth24: return d24;
        case TextureFormat::Depth32F: return VK_FORMAT_D32_SFLOAT;
        case TextureFormat::BGRA8: return VK_FORMAT_B8G8R8A8_UNORM;
        case TextureFormat::SBGRA8: return VK_FORMAT_B8G8R8A8_SRGB;
        case TextureFormat::RGB10A2: return VK_FORMAT_A2B10G10R10_UNORM_PACK32;
        case TextureFormat::R11G11B10F: return VK_FORMAT_B10G11R11_UFLOAT_PACK32;
        case TextureFormat::Depth24Stencil8: return d24s8;
        case TextureFormat::Undefined: break;
    }
    return VK_FORMAT_UNDEFINED;
}

void Core::retire(std::function<void()> fn) {
    std::lock_guard<std::mutex> l(mu);
    retired.push_back({submitted, std::move(fn)});
}
void Core::collect(bool all) {
    std::uint64_t done = 0;
    if (!all && device) vkGetSemaphoreCounterValue(device, timeline, &done);
    std::vector<std::function<void()>> run;
    {
        std::lock_guard<std::mutex> l(mu);
        while (!retired.empty() && (all || retired.front().value <= done)) { run.push_back(std::move(retired.front().fn)); retired.pop_front(); }
    }
    for (auto& f : run) f();
}
VkDescriptorPool Core::makePool() {
    const VkDescriptorPoolSize sizes[2] = {{VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 4096 * kMaxUniformSlots},
                                           {VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 4096 * kMaxTextureSlots}};
    VkDescriptorPoolCreateInfo ci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    ci.maxSets = 4096; ci.poolSizeCount = 2; ci.pPoolSizes = sizes;
    VkDescriptorPool p{};
    VK_CHECK(vkCreateDescriptorPool(device, &ci, nullptr, &p));
    return p;
}
VkDescriptorSet Core::allocSet(VkDescriptorSetLayout layout) {
    auto& v = pools[frame];
    for (int attempt = 0; attempt < 2; ++attempt) {
        if (poolIndex[frame] >= v.size()) v.push_back(makePool());
        VkDescriptorSetAllocateInfo ai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
        ai.descriptorPool = v[poolIndex[frame]]; ai.descriptorSetCount = 1; ai.pSetLayouts = &layout;
        VkDescriptorSet s{};
        const VkResult r = vkAllocateDescriptorSets(device, &ai, &s);
        if (r == VK_SUCCESS) return s;
        if (r == VK_ERROR_OUT_OF_POOL_MEMORY || r == VK_ERROR_FRAGMENTED_POOL) { ++poolIndex[frame]; continue; }
        VK_CHECK(r);
    }
    throw std::runtime_error("Vulkan: cannot allocate descriptor set");
}
void Core::beginFrame() {
    frame = (frame + 1) % kFrames;
    std::uint64_t v = frameValue[frame];
    if (v) {
        VkSemaphoreWaitInfo wi{VK_STRUCTURE_TYPE_SEMAPHORE_WAIT_INFO};
        wi.semaphoreCount = 1; wi.pSemaphores = &timeline; wi.pValues = &v;
        VK_CHECK(vkWaitSemaphores(device, &wi, UINT64_MAX));
    }
    for (auto p : pools[frame]) vkResetDescriptorPool(device, p, 0);
    poolIndex[frame] = 0;
    collect();
}

Core::~Core() {
    if (device) {
        vkDeviceWaitIdle(device);
        collect(true);
        if (fbView) vkDestroyImageView(device, fbView, nullptr);
        if (fbImage) vmaDestroyImage(vma, fbImage, fbAlloc);
        if (fbBuffer) vmaDestroyBuffer(vma, fbBuffer, fbBufAlloc);
        if (defaultSampler) vkDestroySampler(device, defaultSampler, nullptr);
        for (auto& v : pools) for (auto p : v) vkDestroyDescriptorPool(device, p, nullptr);
        if (immPool) vkDestroyCommandPool(device, immPool, nullptr);
        if (pipelineLayout) vkDestroyPipelineLayout(device, pipelineLayout, nullptr);
        if (uboLayout) vkDestroyDescriptorSetLayout(device, uboLayout, nullptr);
        if (texLayout) vkDestroyDescriptorSetLayout(device, texLayout, nullptr);
        if (timeline) vkDestroySemaphore(device, timeline, nullptr);
        if (vma) vmaDestroyAllocator(vma);
        vkDestroyDevice(device, nullptr);
    }
    if (instance) {
        if (messenger && destroyMessenger) destroyMessenger(instance, messenger, nullptr);
        if (surface) vkDestroySurfaceKHR(instance, surface, nullptr);
        vkDestroyInstance(instance, nullptr);
    }
}

void Core::init(const DeviceCreateInfo& info, Backend tierIn) {
    tier = tierIn;
    const bool want14 = tier == Backend::Vulkan14;
    const std::uint32_t needApi = want14 ? VK_API_VERSION_1_4 : VK_API_VERSION_1_2;

    // ---- instance
    std::uint32_t instVersion = VK_API_VERSION_1_0;
    vkEnumerateInstanceVersion(&instVersion);
    if (instVersion < needApi)
        throw std::runtime_error(want14 ? "Vulkan 1.4 runtime not found (loader reports an older version). Update the Vulkan SDK/driver or use ANVIL_BACKEND=vulkan12"
                                        : "Vulkan 1.2 runtime not found");
    std::uint32_t n = 0;
    vkEnumerateInstanceExtensionProperties(nullptr, &n, nullptr);
    std::vector<VkExtensionProperties> instExt(n);
    vkEnumerateInstanceExtensionProperties(nullptr, &n, instExt.data());
    auto hasInstExt = [&](const char* name) { for (auto& e : instExt) if (!std::strcmp(e.extensionName, name)) return true; return false; };

    std::vector<const char*> extensions;
    if (info.nativeWindow) {
        std::uint32_t gc = 0;
        const char** ge = glfwGetRequiredInstanceExtensions(&gc);
        if (!ge) throw std::runtime_error("GLFW reports no Vulkan support (Vulkan loader missing?)");
        for (std::uint32_t i = 0; i < gc; ++i) extensions.push_back(ge[i]);
    }
    if (hasInstExt("VK_EXT_swapchain_colorspace")) extensions.push_back("VK_EXT_swapchain_colorspace");

    std::vector<const char*> layers;
    bool debugUtils = false;
    if (info.validation) {
        std::uint32_t lc = 0;
        vkEnumerateInstanceLayerProperties(&lc, nullptr);
        std::vector<VkLayerProperties> lp(lc);
        vkEnumerateInstanceLayerProperties(&lc, lp.data());
        for (auto& l : lp) if (!std::strcmp(l.layerName, "VK_LAYER_KHRONOS_validation")) { layers.push_back("VK_LAYER_KHRONOS_validation"); break; }
        if (layers.empty()) ANVIL_LOG("Vulkan: validation requested but VK_LAYER_KHRONOS_validation is not installed");
    }
    if (hasInstExt(VK_EXT_DEBUG_UTILS_EXTENSION_NAME)) { extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME); debugUtils = true; }

    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = info.appName.c_str(); app.pEngineName = "ANVIL"; app.engineVersion = 1;
    app.apiVersion = needApi;
    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &app;
    ici.enabledExtensionCount = static_cast<std::uint32_t>(extensions.size()); ici.ppEnabledExtensionNames = extensions.data();
    ici.enabledLayerCount = static_cast<std::uint32_t>(layers.size()); ici.ppEnabledLayerNames = layers.data();
    VK_CHECK(vkCreateInstance(&ici, nullptr, &instance));

    if (debugUtils && !layers.empty()) {
        auto create = reinterpret_cast<PFN_vkCreateDebugUtilsMessengerEXT>(vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT"));
        destroyMessenger = reinterpret_cast<PFN_vkDestroyDebugUtilsMessengerEXT>(vkGetInstanceProcAddr(instance, "vkDestroyDebugUtilsMessengerEXT"));
        if (create) {
            VkDebugUtilsMessengerCreateInfoEXT mi{VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT};
            mi.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
            mi.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT | VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
            mi.pfnUserCallback = debugCallback;
            create(instance, &mi, nullptr, &messenger);
        }
    }
    caps.validationEnabled = !layers.empty();

    if (info.nativeWindow)
        VK_CHECK(glfwCreateWindowSurface(instance, static_cast<GLFWwindow*>(info.nativeWindow), nullptr, &surface));

    // ---- physical device
    std::uint32_t pc = 0;
    vkEnumeratePhysicalDevices(instance, &pc, nullptr);
    std::vector<VkPhysicalDevice> devs(pc);
    vkEnumeratePhysicalDevices(instance, &pc, devs.data());
    if (devs.empty()) throw std::runtime_error("Vulkan: no physical devices found");

    struct Cand { VkPhysicalDevice pd; std::uint32_t family; long long score; int index; };
    std::vector<Cand> cands;
    std::string rejected;
    for (std::size_t i = 0; i < devs.size(); ++i) {
        VkPhysicalDeviceProperties p{};
        vkGetPhysicalDeviceProperties(devs[i], &p);
        auto reject = [&](const char* why) { rejected += std::string("\n  ") + p.deviceName + ": " + why; };
        if (p.apiVersion < needApi) { reject(want14 ? "no Vulkan 1.4 driver" : "no Vulkan 1.2 driver"); continue; }
        const bool software = p.deviceType == VK_PHYSICAL_DEVICE_TYPE_CPU;
        if (software && !info.allowSoftwareAdapter) { reject("software adapter"); continue; }

        std::uint32_t ec = 0;
        vkEnumerateDeviceExtensionProperties(devs[i], nullptr, &ec, nullptr);
        std::vector<VkExtensionProperties> ext(ec);
        vkEnumerateDeviceExtensionProperties(devs[i], nullptr, &ec, ext.data());
        auto hasExt = [&](const char* name) { for (auto& e : ext) if (!std::strcmp(e.extensionName, name)) return true; return false; };
        if (surface && !hasExt(VK_KHR_SWAPCHAIN_EXTENSION_NAME)) { reject("no VK_KHR_swapchain"); continue; }
        if (p.apiVersion < VK_API_VERSION_1_3 &&
            !(hasExt(VK_KHR_DYNAMIC_RENDERING_EXTENSION_NAME) && hasExt(VK_KHR_SYNCHRONIZATION_2_EXTENSION_NAME))) { reject("no dynamic rendering / synchronization2"); continue; }

        VkPhysicalDeviceVulkan12Features q12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};
        VkPhysicalDeviceFeatures2 q2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
        q2.pNext = &q12;
        vkGetPhysicalDeviceFeatures2(devs[i], &q2);
        if (!q12.timelineSemaphore) { reject("no timeline semaphores"); continue; }

        std::uint32_t qc = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(devs[i], &qc, nullptr);
        std::vector<VkQueueFamilyProperties> qf(qc);
        vkGetPhysicalDeviceQueueFamilyProperties(devs[i], &qc, qf.data());
        int family = -1;
        for (std::uint32_t q = 0; q < qc; ++q) {
            if (!(qf[q].queueFlags & VK_QUEUE_GRAPHICS_BIT)) continue;
            if (surface) {
                VkBool32 ok = VK_FALSE;
                vkGetPhysicalDeviceSurfaceSupportKHR(devs[i], q, surface, &ok);
                if (!ok) continue;
            }
            family = static_cast<int>(q); break;
        }
        if (family < 0) { reject("no graphics+present queue"); continue; }

        VkPhysicalDeviceMemoryProperties mp{};
        vkGetPhysicalDeviceMemoryProperties(devs[i], &mp);
        std::uint64_t vram = 0;
        for (std::uint32_t h = 0; h < mp.memoryHeapCount; ++h) if (mp.memoryHeaps[h].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) vram += mp.memoryHeaps[h].size;
        long long score = static_cast<long long>(vram >> 20);
        if (p.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) score += 1000000;
        else if (p.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU) score += 100000;
        cands.push_back({devs[i], static_cast<std::uint32_t>(family), score, static_cast<int>(i)});
    }
    if (cands.empty()) throw std::runtime_error("Vulkan: no suitable GPU found:" + rejected);
    const Cand* pick = nullptr;
    if (info.preferredAdapter >= 0) {
        for (auto& c : cands) if (c.index == info.preferredAdapter) pick = &c;
        if (!pick) throw std::runtime_error("Vulkan: preferred adapter " + std::to_string(info.preferredAdapter) + " is not suitable:" + rejected);
    } else {
        pick = &cands[0];
        for (auto& c : cands) if (c.score > pick->score) pick = &c;
    }
    phys = pick->pd; queueFamily = pick->family;
    vkGetPhysicalDeviceProperties(phys, &props);
    deviceApi = props.apiVersion;

    // ---- logical device
    std::vector<const char*> devExt;
    if (surface) devExt.push_back(VK_KHR_SWAPCHAIN_EXTENSION_NAME);
    if (deviceApi < VK_API_VERSION_1_3) { devExt.push_back(VK_KHR_DYNAMIC_RENDERING_EXTENSION_NAME); devExt.push_back(VK_KHR_SYNCHRONIZATION_2_EXTENSION_NAME); }

    VkPhysicalDeviceFeatures supported{};
    vkGetPhysicalDeviceFeatures(phys, &supported);
    anisotropy = supported.samplerAnisotropy == VK_TRUE;

    VkPhysicalDeviceVulkan13Features f13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};
    f13.dynamicRendering = VK_TRUE; f13.synchronization2 = VK_TRUE;
    VkPhysicalDeviceDynamicRenderingFeaturesKHR dr{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DYNAMIC_RENDERING_FEATURES_KHR};
    dr.dynamicRendering = VK_TRUE;
    VkPhysicalDeviceSynchronization2FeaturesKHR s2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SYNCHRONIZATION_2_FEATURES_KHR};
    s2.synchronization2 = VK_TRUE;
    VkPhysicalDeviceVulkan12Features f12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};
    f12.timelineSemaphore = VK_TRUE;
    if (deviceApi >= VK_API_VERSION_1_3) f12.pNext = &f13;
    else { f12.pNext = &dr; dr.pNext = &s2; }
    VkPhysicalDeviceFeatures2 f2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
    f2.pNext = &f12;
    f2.features.samplerAnisotropy = anisotropy ? VK_TRUE : VK_FALSE;

    const float prio = 1.0f;
    VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
    qci.queueFamilyIndex = queueFamily; qci.queueCount = 1; qci.pQueuePriorities = &prio;
    VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
    dci.pNext = &f2;
    dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qci;
    dci.enabledExtensionCount = static_cast<std::uint32_t>(devExt.size()); dci.ppEnabledExtensionNames = devExt.data();
    VK_CHECK(vkCreateDevice(phys, &dci, nullptr, &device));
    vkGetDeviceQueue(device, queueFamily, 0, &queue);

    auto load = [&](const char* core, const char* khr) -> PFN_vkVoidFunction {
        PFN_vkVoidFunction f = vkGetDeviceProcAddr(device, core);
        return f ? f : vkGetDeviceProcAddr(device, khr);
    };
    cmdBeginRendering = reinterpret_cast<PFN_vkCmdBeginRenderingKHR>(load("vkCmdBeginRendering", "vkCmdBeginRenderingKHR"));
    cmdEndRendering = reinterpret_cast<PFN_vkCmdEndRenderingKHR>(load("vkCmdEndRendering", "vkCmdEndRenderingKHR"));
    cmdBarrier2 = reinterpret_cast<PFN_vkCmdPipelineBarrier2KHR>(load("vkCmdPipelineBarrier2", "vkCmdPipelineBarrier2KHR"));
    queueSubmit2 = reinterpret_cast<PFN_vkQueueSubmit2KHR>(load("vkQueueSubmit2", "vkQueueSubmit2KHR"));
    if (!cmdBeginRendering || !cmdEndRendering || !cmdBarrier2 || !queueSubmit2) throw std::runtime_error("Vulkan: dynamic rendering / synchronization2 entry points missing");
    cmdBeginLabel = reinterpret_cast<PFN_vkCmdBeginDebugUtilsLabelEXT>(vkGetInstanceProcAddr(instance, "vkCmdBeginDebugUtilsLabelEXT"));
    cmdEndLabel = reinterpret_cast<PFN_vkCmdEndDebugUtilsLabelEXT>(vkGetInstanceProcAddr(instance, "vkCmdEndDebugUtilsLabelEXT"));

    // ---- allocator
    VmaAllocatorCreateInfo vci{};
    vci.instance = instance; vci.physicalDevice = phys; vci.device = device;
    vci.vulkanApiVersion = deviceApi >= VK_API_VERSION_1_3 ? VK_API_VERSION_1_3 : VK_API_VERSION_1_2;
    VK_CHECK(vmaCreateAllocator(&vci, &vma));

    // ---- timeline + layouts
    VkSemaphoreTypeCreateInfo tci{VK_STRUCTURE_TYPE_SEMAPHORE_TYPE_CREATE_INFO};
    tci.semaphoreType = VK_SEMAPHORE_TYPE_TIMELINE; tci.initialValue = 0;
    VkSemaphoreCreateInfo sci{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
    sci.pNext = &tci;
    VK_CHECK(vkCreateSemaphore(device, &sci, nullptr, &timeline));

    {
        VkDescriptorSetLayoutBinding b[kMaxTextureSlots]{};
        for (unsigned i = 0; i < kMaxUniformSlots; ++i) b[i] = {i, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 1, VK_SHADER_STAGE_ALL_GRAPHICS, nullptr};
        VkDescriptorSetLayoutCreateInfo li{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
        li.bindingCount = kMaxUniformSlots; li.pBindings = b;
        VK_CHECK(vkCreateDescriptorSetLayout(device, &li, nullptr, &uboLayout));
        for (unsigned i = 0; i < kMaxTextureSlots; ++i) b[i] = {i, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1, VK_SHADER_STAGE_ALL_GRAPHICS, nullptr};
        li.bindingCount = kMaxTextureSlots;
        VK_CHECK(vkCreateDescriptorSetLayout(device, &li, nullptr, &texLayout));
        const VkDescriptorSetLayout sets[2] = {uboLayout, texLayout};
        const VkPushConstantRange pcr{VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, 0, kMaxPushConstantBytes};
        VkPipelineLayoutCreateInfo pli{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
        pli.setLayoutCount = 2; pli.pSetLayouts = sets; pli.pushConstantRangeCount = 1; pli.pPushConstantRanges = &pcr;
        VK_CHECK(vkCreatePipelineLayout(device, &pli, nullptr, &pipelineLayout));
    }
    {
        VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        pi.flags = VK_COMMAND_POOL_CREATE_TRANSIENT_BIT | VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT; pi.queueFamilyIndex = queueFamily;
        VK_CHECK(vkCreateCommandPool(device, &pi, nullptr, &immPool));
    }
    {
        VkSamplerCreateInfo si{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
        si.magFilter = si.minFilter = VK_FILTER_LINEAR; si.mipmapMode = VK_SAMPLER_MIPMAP_MODE_LINEAR;
        si.addressModeU = si.addressModeV = si.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT;
        si.maxLod = VK_LOD_CLAMP_NONE;
        VK_CHECK(vkCreateSampler(device, &si, nullptr, &defaultSampler));
    }

    // ---- depth format fallbacks
    auto supportsDepth = [&](VkFormat f) {
        VkFormatProperties fp{}; vkGetPhysicalDeviceFormatProperties(phys, f, &fp);
        return (fp.optimalTilingFeatures & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) != 0;
    };
    d24 = supportsDepth(VK_FORMAT_X8_D24_UNORM_PACK32) ? VK_FORMAT_X8_D24_UNORM_PACK32 : VK_FORMAT_D32_SFLOAT;
    d24s8 = supportsDepth(VK_FORMAT_D24_UNORM_S8_UINT) ? VK_FORMAT_D24_UNORM_S8_UINT : VK_FORMAT_D32_SFLOAT_S8_UINT;

    // ---- fallback resources for unbound descriptor slots
    {
        VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
        ii.imageType = VK_IMAGE_TYPE_2D; ii.format = VK_FORMAT_R8G8B8A8_UNORM; ii.extent = {1, 1, 1}; ii.mipLevels = 1; ii.arrayLayers = 1;
        ii.samples = VK_SAMPLE_COUNT_1_BIT; ii.tiling = VK_IMAGE_TILING_OPTIMAL;
        ii.usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT; ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        VmaAllocationCreateInfo ai{}; ai.usage = VMA_MEMORY_USAGE_AUTO;
        VK_CHECK(vmaCreateImage(vma, &ii, &ai, &fbImage, &fbAlloc, nullptr));
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = fbImage; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = ii.format; vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VK_CHECK(vkCreateImageView(device, &vi, nullptr, &fbView));
        const std::uint8_t white[4] = {255, 255, 255, 255};
        Staging st = makeStaging(white, 4);
        immediate([&](VkCommandBuffer cmd) {
            VkImageMemoryBarrier2 b = makeBarrier(fbImage, VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                scopeFor(VK_IMAGE_LAYOUT_UNDEFINED), scopeFor(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL));
            barriers(cmd, &b, 1);
            VkBufferImageCopy rg{}; rg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1}; rg.imageExtent = {1, 1, 1};
            vkCmdCopyBufferToImage(cmd, st.buf, fbImage, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &rg);
            b = makeBarrier(fbImage, VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
                scopeFor(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL), scopeFor(VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL));
            barriers(cmd, &b, 1);
        });
        destroyStaging(st);

        VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bi.size = kFallbackUboSize; bi.usage = VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        VmaAllocationCreateInfo bai{}; bai.usage = VMA_MEMORY_USAGE_AUTO;
        VK_CHECK(vmaCreateBuffer(vma, &bi, &bai, &fbBuffer, &fbBufAlloc, nullptr));
        immediate([&](VkCommandBuffer cmd) { vkCmdFillBuffer(cmd, fbBuffer, 0, VK_WHOLE_SIZE, 0); });
    }

    // ---- capabilities
    caps.backend = tier;
    caps.deviceName = props.deviceName;
    caps.apiVersion = std::to_string(VK_API_VERSION_MAJOR(deviceApi)) + "." + std::to_string(VK_API_VERSION_MINOR(deviceApi)) + "." + std::to_string(VK_API_VERSION_PATCH(deviceApi));
    caps.maxTextureSize = static_cast<int>(props.limits.maxImageDimension2D);
    {
        const VkSampleCountFlags sc = props.limits.framebufferColorSampleCounts & props.limits.framebufferDepthSampleCounts;
        int s = 1;
        for (int c = 2; c <= 64; c *= 2) if (sc & static_cast<VkSampleCountFlags>(c)) s = c;
        caps.maxSamples = s;
    }
    caps.debugOutput = messenger != VK_NULL_HANDLE;
    caps.directStateAccess = false;
    caps.framesInFlight = kFrames;
    caps.discreteGpu = props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU;
    caps.maxAnisotropy = anisotropy ? props.limits.maxSamplerAnisotropy : 1.0f;
    {
        VkPhysicalDeviceMemoryProperties mp{};
        vkGetPhysicalDeviceMemoryProperties(phys, &mp);
        for (std::uint32_t h = 0; h < mp.memoryHeapCount; ++h) if (mp.memoryHeaps[h].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) caps.dedicatedVideoMemory += mp.memoryHeaps[h].size;
    }
    ANVIL_LOG("Vulkan %s | %s%s", caps.apiVersion.c_str(), props.deviceName, caps.validationEnabled ? " | validation ON" : "");
}

// ---------------------------------------------------------------------------------------------------------------------
class Buffer final : public rhi::Buffer {
public:
    Buffer(std::shared_ptr<Core> core, const BufferDesc& d, const void* init) : core_(std::move(core)), size_(d.size) {
        if (size_ == 0) throw std::invalid_argument("Vulkan: zero-sized buffer");
        VkBufferUsageFlags u = 0;
        switch (d.usage) {
            case BufferUsage::Vertex: u = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT; break;
            case BufferUsage::Index: u = VK_BUFFER_USAGE_INDEX_BUFFER_BIT; break;
            case BufferUsage::Uniform: u = VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT; break;
            case BufferUsage::Storage: u = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT; break;
            case BufferUsage::Readback: u = VK_BUFFER_USAGE_TRANSFER_DST_BIT; break;
        }
        readback_ = d.usage == BufferUsage::Readback;
        ring_ = d.dynamic && !readback_;
        host_ = d.dynamic || readback_;
        stride_ = ring_ ? alignUp(size_, 256) : size_;
        VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bi.size = ring_ ? stride_ * kFrames : size_;
        bi.usage = u | VK_BUFFER_USAGE_TRANSFER_DST_BIT; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        VmaAllocationCreateInfo ai{};
        ai.usage = VMA_MEMORY_USAGE_AUTO;
        if (host_) ai.flags = (readback_ ? VMA_ALLOCATION_CREATE_HOST_ACCESS_RANDOM_BIT : VMA_ALLOCATION_CREATE_HOST_ACCESS_SEQUENTIAL_WRITE_BIT) | VMA_ALLOCATION_CREATE_MAPPED_BIT;
        VmaAllocationInfo info{};
        VK_CHECK(vmaCreateBuffer(core_->vma, &bi, &ai, &buf_, &alloc_, &info));
        mapped_ = static_cast<std::uint8_t*>(info.pMappedData);
        if (ring_) {
            shadow_.assign(size_, 0);
            if (init) std::memcpy(shadow_.data(), init, size_);
            version_ = 1; slotVersion_.fill(0);
            sync();
        } else if (host_) {
            if (init) { std::memcpy(mapped_, init, size_); vmaFlushAllocation(core_->vma, alloc_, 0, VK_WHOLE_SIZE); }
        } else if (init) {
            core_->uploadBuffer(buf_, 0, init, size_);
        }
    }
    ~Buffer() override {
        Core* c = core_.get(); VkBuffer b = buf_; VmaAllocation a = alloc_;
        c->retire([c, b, a] { vmaDestroyBuffer(c->vma, b, a); });
    }
    std::size_t size() const noexcept override { return size_; }
    void update(std::size_t offset, const void* data, std::size_t bytes) override {
        if (offset + bytes > size_) throw std::out_of_range("Vulkan: Buffer::update out of range");
        if (bytes == 0) return;
        if (ring_) { std::memcpy(shadow_.data() + offset, data, bytes); ++version_; sync(); }
        else if (host_) { std::memcpy(mapped_ + offset, data, bytes); vmaFlushAllocation(core_->vma, alloc_, offset, bytes); }
        else core_->uploadBuffer(buf_, offset, data, bytes);
    }
    // Brings this frame's slot of a `dynamic` buffer up to date (cheap no-op otherwise).
    void sync() {
        if (!ring_) return;
        const std::uint32_t f = core_->frame;
        if (slotVersion_[f] == version_) return;
        std::memcpy(mapped_ + f * stride_, shadow_.data(), size_);
        vmaFlushAllocation(core_->vma, alloc_, f * stride_, size_);
        slotVersion_[f] = version_;
    }
    VkBuffer handle() const noexcept { return buf_; }
    VkDeviceSize slotOffset() const noexcept { return ring_ ? core_->frame * stride_ : 0; }

private:
    std::shared_ptr<Core> core_;
    VkBuffer buf_ = VK_NULL_HANDLE; VmaAllocation alloc_ = nullptr;
    std::size_t size_ = 0; VkDeviceSize stride_ = 0;
    bool ring_ = false, host_ = false, readback_ = false;
    std::uint8_t* mapped_ = nullptr;
    std::vector<std::uint8_t> shadow_;
    std::uint64_t version_ = 0; std::array<std::uint64_t, kFrames> slotVersion_{};
};

class Texture final : public rhi::Texture {
public:
    // Owned image created through VMA.
    Texture(std::shared_ptr<Core> core, const TextureDesc& d, const void* init) : core_(std::move(core)) {
        if (d.width <= 0 || d.height <= 0) throw std::invalid_argument("Vulkan: invalid texture size");
        fmt_ = d.format; w_ = d.width; h_ = d.height;
        vkFmt_ = core_->vkFormat(fmt_);
        if (vkFmt_ == VK_FORMAT_UNDEFINED) throw std::invalid_argument("Vulkan: undefined texture format");
        int maxLevels = 1;
        for (int m = std::max(w_, h_); m > 1; m >>= 1) ++maxLevels;
        levels_ = std::clamp(d.levels, 1, maxLevels);
        const bool depth = isDepthFormat(fmt_);
        VkImageUsageFlags u = 0;
        if (hasUsage(d.usage, TextureUsage::Sampled)) u |= VK_IMAGE_USAGE_SAMPLED_BIT;
        if (hasUsage(d.usage, TextureUsage::RenderTarget) || hasUsage(d.usage, TextureUsage::DepthStencil))
            u |= depth ? VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT : VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
        if (hasUsage(d.usage, TextureUsage::Storage)) u |= VK_IMAGE_USAGE_STORAGE_BIT;
        if (hasUsage(d.usage, TextureUsage::TransferSrc)) u |= VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
        if (hasUsage(d.usage, TextureUsage::TransferDst) || init) u |= VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        if (levels_ > 1) u |= VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        if (u == 0) u = VK_IMAGE_USAGE_SAMPLED_BIT;

        VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO};
        ii.imageType = VK_IMAGE_TYPE_2D; ii.format = vkFmt_;
        ii.extent = {static_cast<std::uint32_t>(w_), static_cast<std::uint32_t>(h_), 1};
        ii.mipLevels = static_cast<std::uint32_t>(levels_); ii.arrayLayers = 1;
        ii.samples = static_cast<VkSampleCountFlagBits>(std::max(1, d.samples));
        ii.tiling = VK_IMAGE_TILING_OPTIMAL; ii.usage = u; ii.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        VmaAllocationCreateInfo ai{};
        ai.usage = VMA_MEMORY_USAGE_AUTO;
        if (u & (VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT)) ai.flags = VMA_ALLOCATION_CREATE_DEDICATED_MEMORY_BIT;
        VK_CHECK(vmaCreateImage(core_->vma, &ii, &ai, &image_, &alloc_, nullptr));
        createViews();

        if (init) {
            if (depth) throw std::invalid_argument("Vulkan: initial data for depth textures is not supported");
            std::vector<std::uint8_t> expanded;
            const void* src = init; std::size_t bytes = static_cast<std::size_t>(w_) * h_ * bytesPerPixel(fmt_);
            if (fmt_ == TextureFormat::RGB8) {
                expanded.resize(static_cast<std::size_t>(w_) * h_ * 4);
                const auto* s = static_cast<const std::uint8_t*>(init);
                for (std::size_t i = 0, n = static_cast<std::size_t>(w_) * h_; i < n; ++i) {
                    expanded[i * 4 + 0] = s[i * 3 + 0]; expanded[i * 4 + 1] = s[i * 3 + 1]; expanded[i * 4 + 2] = s[i * 3 + 2]; expanded[i * 4 + 3] = 255;
                }
                src = expanded.data(); bytes = expanded.size();
            }
            Core::Staging st = core_->makeStaging(src, bytes);
            core_->immediate([&](VkCommandBuffer cmd) {
                VkImageMemoryBarrier2 b = makeBarrier(image_, VK_IMAGE_ASPECT_COLOR_BIT, 0, VK_REMAINING_MIP_LEVELS, VK_IMAGE_LAYOUT_UNDEFINED,
                    VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, scopeFor(VK_IMAGE_LAYOUT_UNDEFINED), scopeFor(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL));
                core_->barriers(cmd, &b, 1);
                VkBufferImageCopy rg{};
                rg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
                rg.imageExtent = {static_cast<std::uint32_t>(w_), static_cast<std::uint32_t>(h_), 1};
                vkCmdCopyBufferToImage(cmd, st.buf, image_, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &rg);
                if (levels_ > 1) core_->recordMips(cmd, image_, w_, h_, levels_, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);
                else {
                    b = makeBarrier(image_, VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL,
                        scopeFor(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL), scopeFor(VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL));
                    core_->barriers(cmd, &b, 1);
                }
            });
            core_->destroyStaging(st);
            layout_ = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        }
    }
    // Swapchain backbuffer wrapper (image owned by the swapchain).
    Texture(std::shared_ptr<Core> core, VkImage image, VkFormat vkFormat, TextureFormat format, int w, int h, Swapchain* owner)
        : core_(std::move(core)), image_(image), vkFmt_(vkFormat), fmt_(format), w_(w), h_(h), owner_(owner) {
        createViews();
    }
    ~Texture() override {
        Core* c = core_.get();
        std::vector<VkImageView> views;
        if (view_) views.push_back(view_);
        if (sampleView_ && sampleView_ != view_) views.push_back(sampleView_);
        for (auto& kv : mipViews_) views.push_back(kv.second);
        VkImage img = owner_ ? VK_NULL_HANDLE : image_; VmaAllocation a = alloc_;
        c->retire([c, views, img, a] {
            for (auto v : views) vkDestroyImageView(c->device, v, nullptr);
            if (img) vmaDestroyImage(c->vma, img, a);
        });
    }
    int width() const noexcept override { return w_; }
    int height() const noexcept override { return h_; }
    TextureFormat format() const noexcept override { return fmt_; }
    std::uintptr_t nativeHandle() const noexcept override { return reinterpret_cast<std::uintptr_t>(sampleView_); }

    VkImageView mipView(std::uint32_t mip) {
        if (mip == 0) return view_;
        auto it = mipViews_.find(mip);
        if (it != mipViews_.end()) return it->second;
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = image_; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = vkFmt_;
        vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, mip, 1, 0, 1};
        VkImageView v{};
        VK_CHECK(vkCreateImageView(core_->device, &vi, nullptr, &v));
        mipViews_[mip] = v;
        return v;
    }

    std::shared_ptr<Core> core_;
    VkImage image_ = VK_NULL_HANDLE; VmaAllocation alloc_ = nullptr;
    VkImageView view_ = VK_NULL_HANDLE, sampleView_ = VK_NULL_HANDLE;
    VkFormat vkFmt_ = VK_FORMAT_UNDEFINED; TextureFormat fmt_ = TextureFormat::RGBA8;
    int w_ = 1, h_ = 1, levels_ = 1;
    VkImageLayout layout_ = VK_IMAGE_LAYOUT_UNDEFINED;
    Swapchain* owner_ = nullptr;
    std::unordered_map<std::uint32_t, VkImageView> mipViews_;

private:
    void createViews() {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO};
        vi.image = image_; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = vkFmt_;
        vi.subresourceRange = {attachAspect(fmt_), 0, VK_REMAINING_MIP_LEVELS, 0, 1};
        VK_CHECK(vkCreateImageView(core_->device, &vi, nullptr, &view_));
        if (sampleAspect(fmt_) == attachAspect(fmt_)) sampleView_ = view_;
        else {
            vi.subresourceRange.aspectMask = sampleAspect(fmt_);
            VK_CHECK(vkCreateImageView(core_->device, &vi, nullptr, &sampleView_));
        }
    }
};

class Sampler final : public rhi::Sampler {
public:
    Sampler(std::shared_ptr<Core> core, const SamplerDesc& d) : core_(std::move(core)) {
        VkSamplerCreateInfo si{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
        const bool mip = d.minFilter == TextureFilter::LinearMipmapLinear;
        si.minFilter = d.minFilter == TextureFilter::Nearest ? VK_FILTER_NEAREST : VK_FILTER_LINEAR;
        si.magFilter = d.magFilter == TextureFilter::Nearest ? VK_FILTER_NEAREST : VK_FILTER_LINEAR;
        si.mipmapMode = mip ? VK_SAMPLER_MIPMAP_MODE_LINEAR : VK_SAMPLER_MIPMAP_MODE_NEAREST;
        si.addressModeU = toVk(d.wrapU); si.addressModeV = toVk(d.wrapV); si.addressModeW = VK_SAMPLER_ADDRESS_MODE_REPEAT;
        si.anisotropyEnable = (core_->anisotropy && d.maxAnisotropy > 1.0f) ? VK_TRUE : VK_FALSE;
        si.maxAnisotropy = std::min(d.maxAnisotropy, core_->props.limits.maxSamplerAnisotropy);
        si.compareEnable = d.compare ? VK_TRUE : VK_FALSE; si.compareOp = toVk(d.compareOp);
        si.minLod = 0.0f; si.maxLod = mip ? VK_LOD_CLAMP_NONE : 0.0f;
        si.borderColor = d.whiteBorder ? VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE : VK_BORDER_COLOR_FLOAT_TRANSPARENT_BLACK;
        VK_CHECK(vkCreateSampler(core_->device, &si, nullptr, &sampler_));
    }
    ~Sampler() override { Core* c = core_.get(); VkSampler s = sampler_; c->retire([c, s] { vkDestroySampler(c->device, s, nullptr); }); }
    VkSampler handle() const noexcept { return sampler_; }
private:
    std::shared_ptr<Core> core_;
    VkSampler sampler_ = VK_NULL_HANDLE;
};

class Shader final : public rhi::Shader {
public:
    Shader(std::shared_ptr<Core> core, const ShaderDesc& d) : core_(std::move(core)) {
        if (d.vertexSpirv.empty() || d.fragmentSpirv.empty())
            throw std::runtime_error("Vulkan: ShaderDesc needs vertexSpirv + fragmentSpirv (load them with rhi::loadShaderDesc)");
        vert_ = make(d.vertexSpirv); frag_ = make(d.fragmentSpirv);
    }
    ~Shader() override {
        Core* c = core_.get(); VkShaderModule v = vert_, f = frag_;
        c->retire([c, v, f] { vkDestroyShaderModule(c->device, v, nullptr); vkDestroyShaderModule(c->device, f, nullptr); });
    }
    VkShaderModule vert() const noexcept { return vert_; }
    VkShaderModule frag() const noexcept { return frag_; }
private:
    VkShaderModule make(const std::vector<std::uint32_t>& code) {
        VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
        ci.codeSize = code.size() * sizeof(std::uint32_t); ci.pCode = code.data();
        VkShaderModule m{};
        VK_CHECK(vkCreateShaderModule(core_->device, &ci, nullptr, &m));
        return m;
    }
    std::shared_ptr<Core> core_;
    VkShaderModule vert_ = VK_NULL_HANDLE, frag_ = VK_NULL_HANDLE;
};

class Pipeline final : public rhi::Pipeline {
public:
    Pipeline(std::shared_ptr<Core> core, const std::shared_ptr<rhi::Shader>& shader, const PipelineDesc& d)
        : core_(std::move(core)), shader_(std::static_pointer_cast<Shader>(shader)), desc_(d) {
        if (!shader_) throw std::invalid_argument("Vulkan: createPipeline without shader");
        if (d.pushConstantBytes > kMaxPushConstantBytes) throw std::invalid_argument("Vulkan: pushConstantBytes exceeds kMaxPushConstantBytes");

        VkPipelineShaderStageCreateInfo stages[2]{};
        stages[0] = {VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0, VK_SHADER_STAGE_VERTEX_BIT, shader_->vert(), "main", nullptr};
        stages[1] = {VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0, VK_SHADER_STAGE_FRAGMENT_BIT, shader_->frag(), "main", nullptr};

        std::vector<VkVertexInputBindingDescription> binds;
        for (auto& b : d.vertexLayout.bindings) binds.push_back({b.binding, b.stride, b.perInstance ? VK_VERTEX_INPUT_RATE_INSTANCE : VK_VERTEX_INPUT_RATE_VERTEX});
        std::vector<VkVertexInputAttributeDescription> attrs;
        for (auto& a : d.vertexLayout.attributes) attrs.push_back({a.location, a.binding, toVk(a.format), a.offset});
        VkPipelineVertexInputStateCreateInfo vi{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
        vi.vertexBindingDescriptionCount = static_cast<std::uint32_t>(binds.size()); vi.pVertexBindingDescriptions = binds.data();
        vi.vertexAttributeDescriptionCount = static_cast<std::uint32_t>(attrs.size()); vi.pVertexAttributeDescriptions = attrs.data();

        VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO};
        ia.topology = toVk(d.topology);

        VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO};
        vp.viewportCount = 1; vp.scissorCount = 1;

        VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO};
        rs.polygonMode = VK_POLYGON_MODE_FILL; rs.lineWidth = 1.0f;
        const CullMode cm = d.cull ? d.cullMode : CullMode::None;
        rs.cullMode = cm == CullMode::Back ? VK_CULL_MODE_BACK_BIT : cm == CullMode::Front ? VK_CULL_MODE_FRONT_BIT : VK_CULL_MODE_NONE;
        rs.frontFace = d.frontFaceCCW ? VK_FRONT_FACE_COUNTER_CLOCKWISE : VK_FRONT_FACE_CLOCKWISE;
        if (d.depthBiasConstant != 0.0f || d.depthBiasSlope != 0.0f) {
            rs.depthBiasEnable = VK_TRUE; rs.depthBiasConstantFactor = d.depthBiasConstant; rs.depthBiasSlopeFactor = d.depthBiasSlope;
        }

        VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO};
        ms.rasterizationSamples = static_cast<VkSampleCountFlagBits>(std::max(1, d.samples));

        const bool hasDepth = d.depthFormat != TextureFormat::Undefined;
        VkPipelineDepthStencilStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO};
        ds.depthTestEnable = (hasDepth && d.depthTest) ? VK_TRUE : VK_FALSE;
        ds.depthWriteEnable = (hasDepth && d.depthTest && d.depthWrite) ? VK_TRUE : VK_FALSE;
        ds.depthCompareOp = toVk(d.depthCompare);

        VkPipelineColorBlendAttachmentState att{};
        att.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
        if (d.blend) {
            att.blendEnable = VK_TRUE;
            att.colorBlendOp = att.alphaBlendOp = VK_BLEND_OP_ADD;
            switch (d.blendMode) {
                case BlendMode::Alpha:
                    att.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA; att.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
                    att.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE; att.dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA; break;
                case BlendMode::Additive:
                    att.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA; att.dstColorBlendFactor = VK_BLEND_FACTOR_ONE;
                    att.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE; att.dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE; break;
                case BlendMode::Premultiplied:
                    att.srcColorBlendFactor = VK_BLEND_FACTOR_ONE; att.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
                    att.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE; att.dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA; break;
            }
        }
        std::vector<VkPipelineColorBlendAttachmentState> atts(d.colorFormats.size(), att);
        VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
        cb.attachmentCount = static_cast<std::uint32_t>(atts.size()); cb.pAttachments = atts.data();

        const VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
        VkPipelineDynamicStateCreateInfo dy{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO};
        dy.dynamicStateCount = 2; dy.pDynamicStates = dyn;

        std::vector<VkFormat> colorFmts;
        for (auto f : d.colorFormats) colorFmts.push_back(core_->vkFormat(f));
        VkPipelineRenderingCreateInfo ri{VK_STRUCTURE_TYPE_PIPELINE_RENDERING_CREATE_INFO};
        ri.colorAttachmentCount = static_cast<std::uint32_t>(colorFmts.size()); ri.pColorAttachmentFormats = colorFmts.data();
        if (hasDepth) {
            ri.depthAttachmentFormat = core_->vkFormat(d.depthFormat);
            if (hasStencil(d.depthFormat)) ri.stencilAttachmentFormat = ri.depthAttachmentFormat;
        }

        VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO};
        pi.pNext = &ri;
        pi.stageCount = 2; pi.pStages = stages;
        pi.pVertexInputState = &vi; pi.pInputAssemblyState = &ia; pi.pViewportState = &vp; pi.pRasterizationState = &rs;
        pi.pMultisampleState = &ms; pi.pDepthStencilState = &ds; pi.pColorBlendState = &cb; pi.pDynamicState = &dy;
        pi.layout = core_->pipelineLayout; pi.renderPass = VK_NULL_HANDLE;
        VK_CHECK(vkCreateGraphicsPipelines(core_->device, VK_NULL_HANDLE, 1, &pi, nullptr, &pipeline_));
    }
    ~Pipeline() override { Core* c = core_.get(); VkPipeline p = pipeline_; c->retire([c, p] { vkDestroyPipeline(c->device, p, nullptr); }); }
    VkPipeline handle() const noexcept { return pipeline_; }
    const PipelineDesc& desc() const noexcept { return desc_; }
private:
    std::shared_ptr<Core> core_;
    std::shared_ptr<Shader> shader_;
    PipelineDesc desc_;
    VkPipeline pipeline_ = VK_NULL_HANDLE;
};

// ---------------------------------------------------------------------------------------------------------------------
class Swapchain final : public rhi::Swapchain {
public:
    Swapchain(std::shared_ptr<Core> core, const SwapchainDesc& d) : core_(std::move(core)), desc_(d), wantW_(d.width), wantH_(d.height) {
        if (!core_->surface) throw std::runtime_error("Vulkan: createSwapchain needs DeviceCreateInfo::nativeWindow (GLFWwindow*) at device creation");
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        for (auto& s : acquireSem_) VK_CHECK(vkCreateSemaphore(core_->device, &si, nullptr, &s));
        needRecreate_ = !create();
    }
    ~Swapchain() override {
        vkDeviceWaitIdle(core_->device);
        textures_.clear();
        for (auto s : renderFinished_) vkDestroySemaphore(core_->device, s, nullptr);
        for (auto s : acquireSem_) vkDestroySemaphore(core_->device, s, nullptr);
        if (sc_) vkDestroySwapchainKHR(core_->device, sc_, nullptr);
    }
    void resize(int w, int h) override { wantW_ = w; wantH_ = h; needRecreate_ = true; }
    TextureFormat format() const noexcept override { return fmt_; }
    int width() const noexcept override { return static_cast<int>(extent_.width); }
    int height() const noexcept override { return static_cast<int>(extent_.height); }

    std::shared_ptr<rhi::Texture> acquire() override {
        if (needRecreate_) { if (!create()) return {}; needRecreate_ = false; }
        if (extent_.width == 0 || extent_.height == 0) { needRecreate_ = true; return {}; }
        const VkResult r = vkAcquireNextImageKHR(core_->device, sc_, UINT64_MAX, acquireSem_[core_->frame], VK_NULL_HANDLE, &imageIndex_);
        if (r == VK_ERROR_OUT_OF_DATE_KHR) { needRecreate_ = true; return {}; }
        if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) VK_CHECK(r);
        if (r == VK_SUBOPTIMAL_KHR) needRecreate_ = true;   // keep rendering this frame, rebuild next time
        acquirePending_ = true; presentSignaled_ = false;
        textures_[imageIndex_]->layout_ = VK_IMAGE_LAYOUT_UNDEFINED;
        return textures_[imageIndex_];
    }
    void present() override {
        if (!acquirePending_ && !presentSignaled_) return;   // nothing acquired
        if (!presentSignaled_) { needRecreate_ = true; return; }   // acquired but never rendered/submitted
        VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR};
        pi.waitSemaphoreCount = 1; pi.pWaitSemaphores = &renderFinished_[imageIndex_];
        pi.swapchainCount = 1; pi.pSwapchains = &sc_; pi.pImageIndices = &imageIndex_;
        const VkResult r = vkQueuePresentKHR(core_->queue, &pi);
        presentSignaled_ = false; acquirePending_ = false;
        if (r == VK_ERROR_OUT_OF_DATE_KHR || r == VK_SUBOPTIMAL_KHR) needRecreate_ = true;
        else VK_CHECK(r);
    }

    // Used by Device::submit.
    bool consumeAcquire(VkSemaphore& s) { if (!acquirePending_) return false; acquirePending_ = false; s = acquireSem_[core_->frame]; return true; }
    bool consumeRenderFinished(VkSemaphore& s) { if (presentSignaled_) return false; presentSignaled_ = true; s = renderFinished_[imageIndex_]; return true; }

private:
    // Returns false while the surface has zero size (minimised); keeps the old swapchain in that case.
    bool create() {
        VkSurfaceCapabilitiesKHR caps{};
        VK_CHECK(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(core_->phys, core_->surface, &caps));
        VkExtent2D ext = caps.currentExtent;
        if (ext.width == UINT32_MAX) {
            ext.width = std::clamp(static_cast<std::uint32_t>(std::max(0, wantW_)), caps.minImageExtent.width, caps.maxImageExtent.width);
            ext.height = std::clamp(static_cast<std::uint32_t>(std::max(0, wantH_)), caps.minImageExtent.height, caps.maxImageExtent.height);
        }
        if (ext.width == 0 || ext.height == 0) { extent_ = ext; return false; }

        std::uint32_t n = 0;
        vkGetPhysicalDeviceSurfaceFormatsKHR(core_->phys, core_->surface, &n, nullptr);
        std::vector<VkSurfaceFormatKHR> formats(n);
        vkGetPhysicalDeviceSurfaceFormatsKHR(core_->phys, core_->surface, &n, formats.data());
        if (formats.empty()) throw std::runtime_error("Vulkan: surface has no formats");
        VkSurfaceFormatKHR chosen = formats[0];
        bool found = false;
        if (desc_.hdr10)
            for (auto& f : formats) if (f.format == VK_FORMAT_A2B10G10R10_UNORM_PACK32 && f.colorSpace == VK_COLOR_SPACE_HDR10_ST2084_EXT) { chosen = f; found = true; break; }
        if (!found)
            for (auto& f : formats) if (f.format == VK_FORMAT_B8G8R8A8_UNORM && f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) { chosen = f; found = true; break; }
        if (!found)
            for (auto& f : formats) if (f.format == VK_FORMAT_R8G8B8A8_UNORM && f.colorSpace == VK_COLOR_SPACE_SRGB_NONLINEAR_KHR) { chosen = f; break; }

        vkGetPhysicalDeviceSurfacePresentModesKHR(core_->phys, core_->surface, &n, nullptr);
        std::vector<VkPresentModeKHR> modes(n);
        vkGetPhysicalDeviceSurfacePresentModesKHR(core_->phys, core_->surface, &n, modes.data());
        VkPresentModeKHR mode = VK_PRESENT_MODE_FIFO_KHR;
        if (!desc_.vsync) {
            for (auto m : modes) if (m == VK_PRESENT_MODE_MAILBOX_KHR) mode = m;
            if (mode == VK_PRESENT_MODE_FIFO_KHR) for (auto m : modes) if (m == VK_PRESENT_MODE_IMMEDIATE_KHR) mode = m;
        }

        std::uint32_t count = std::max(desc_.imageCount, caps.minImageCount);
        if (caps.maxImageCount > 0) count = std::min(count, caps.maxImageCount);

        VkSwapchainCreateInfoKHR ci{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR};
        ci.surface = core_->surface; ci.minImageCount = count;
        ci.imageFormat = chosen.format; ci.imageColorSpace = chosen.colorSpace; ci.imageExtent = ext; ci.imageArrayLayers = 1;
        ci.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT |
                        (caps.supportedUsageFlags & VK_IMAGE_USAGE_TRANSFER_SRC_BIT);
        ci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE; ci.preTransform = caps.currentTransform;
        ci.compositeAlpha = (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR) ? VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR : VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;
        ci.presentMode = mode; ci.clipped = VK_TRUE; ci.oldSwapchain = sc_;

        vkDeviceWaitIdle(core_->device);
        VkSwapchainKHR fresh{};
        VK_CHECK(vkCreateSwapchainKHR(core_->device, &ci, nullptr, &fresh));
        textures_.clear();
        for (auto s : renderFinished_) vkDestroySemaphore(core_->device, s, nullptr);
        renderFinished_.clear();
        if (sc_) vkDestroySwapchainKHR(core_->device, sc_, nullptr);
        sc_ = fresh;

        vkGetSwapchainImagesKHR(core_->device, sc_, &n, nullptr);
        std::vector<VkImage> images(n);
        vkGetSwapchainImagesKHR(core_->device, sc_, &n, images.data());
        extent_ = ext; fmt_ = fromVkSurfaceFormat(chosen.format);
        VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};
        for (auto img : images) {
            textures_.push_back(std::make_shared<Texture>(core_, img, chosen.format, fmt_, static_cast<int>(ext.width), static_cast<int>(ext.height), this));
            VkSemaphore s{};
            VK_CHECK(vkCreateSemaphore(core_->device, &si, nullptr, &s));
            renderFinished_.push_back(s);
        }
        acquirePending_ = false; presentSignaled_ = false;
        return true;
    }

    std::shared_ptr<Core> core_;
    SwapchainDesc desc_;
    int wantW_ = 0, wantH_ = 0;
    VkSwapchainKHR sc_ = VK_NULL_HANDLE;
    VkExtent2D extent_{0, 0};
    TextureFormat fmt_ = TextureFormat::BGRA8;
    std::vector<std::shared_ptr<Texture>> textures_;
    std::vector<VkSemaphore> renderFinished_;
    VkSemaphore acquireSem_[kFrames] = {};
    std::uint32_t imageIndex_ = 0;
    bool acquirePending_ = false, presentSignaled_ = false, needRecreate_ = false;
};

// ---------------------------------------------------------------------------------------------------------------------
class CommandList final : public rhi::CommandList {
public:
    explicit CommandList(std::shared_ptr<Core> core) : core_(std::move(core)) {
        for (std::uint32_t i = 0; i < kFrames; ++i) {
            VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
            pi.queueFamilyIndex = core_->queueFamily;
            VK_CHECK(vkCreateCommandPool(core_->device, &pi, nullptr, &pools_[i]));
            VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
            ai.commandPool = pools_[i]; ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; ai.commandBufferCount = 1;
            VK_CHECK(vkAllocateCommandBuffers(core_->device, &ai, &bufs_[i]));
        }
    }
    ~CommandList() override {
        Core* c = core_.get();
        VkCommandPool p0 = pools_[0], p1 = pools_[1];
        keep_.clear();
        c->retire([c, p0, p1] { vkDestroyCommandPool(c->device, p0, nullptr); vkDestroyCommandPool(c->device, p1, nullptr); });
    }

    void begin() override {
        const std::uint32_t f = core_->frame;
        VK_CHECK(vkResetCommandPool(core_->device, pools_[f], 0));
        cmd_ = bufs_[f];
        VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        VK_CHECK(vkBeginCommandBuffer(cmd_, &bi));
        recording_ = true; inPass_ = false;
        pipeline_.reset(); keep_.clear(); swapTex_.clear(); swapchain_ = nullptr;
        for (auto& b : ubo_) b.reset();
        for (auto& t : tex_) t.reset();
        for (auto& s : smp_) s.reset();
        uboOff_.fill(0); uboRange_.fill(0);
        dirtyUbo_ = dirtyTex_ = true; uboSet_ = texSet_ = VK_NULL_HANDLE;
    }
    void end() override {
        requireRecording();
        if (inPass_) endRenderPass();
        if (!swapTex_.empty()) {
            std::vector<VkImageMemoryBarrier2> bars;
            for (auto& t : swapTex_) {
                bars.push_back(makeBarrier(t->image_, VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, t->layout_, VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
                                           scopeFor(t->layout_), scopeFor(VK_IMAGE_LAYOUT_PRESENT_SRC_KHR)));
                t->layout_ = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
            }
            core_->barriers(cmd_, bars.data(), static_cast<std::uint32_t>(bars.size()));
        }
        VK_CHECK(vkEndCommandBuffer(cmd_));
        recording_ = false;
    }

    void setPipeline(const std::shared_ptr<rhi::Pipeline>& p) override {
        requireRecording();
        pipeline_ = std::static_pointer_cast<Pipeline>(p);
        if (!pipeline_) throw std::invalid_argument("Vulkan: setPipeline(null)");
        vkCmdBindPipeline(cmd_, VK_PIPELINE_BIND_POINT_GRAPHICS, pipeline_->handle());
        keep_.push_back(pipeline_);
    }
    void bindVertexBuffer(const std::shared_ptr<rhi::Buffer>& b, unsigned binding) override {
        requireRecording();
        auto vb = std::static_pointer_cast<Buffer>(b);
        vb->sync();
        const VkBuffer h = vb->handle(); const VkDeviceSize off = vb->slotOffset();
        vkCmdBindVertexBuffers(cmd_, binding, 1, &h, &off);
        keep_.push_back(vb);
    }
    void bindIndexBuffer(const std::shared_ptr<rhi::Buffer>& b) override {
        requireRecording();
        auto ib = std::static_pointer_cast<Buffer>(b);
        ib->sync();
        vkCmdBindIndexBuffer(cmd_, ib->handle(), ib->slotOffset(), VK_INDEX_TYPE_UINT32);
        keep_.push_back(ib);
    }
    void bindTexture(unsigned unit, const std::shared_ptr<rhi::Texture>& t, const std::shared_ptr<rhi::Sampler>& s) override {
        requireRecording();
        if (unit >= kMaxTextureSlots) throw std::out_of_range("Vulkan: texture slot out of range");
        auto vt = std::static_pointer_cast<Texture>(t);
        if (vt) ensureReadable(*vt);
        tex_[unit] = vt; smp_[unit] = std::static_pointer_cast<Sampler>(s);
        if (vt) keep_.push_back(vt);
        if (smp_[unit]) keep_.push_back(smp_[unit]);
        dirtyTex_ = true;
    }
    void draw(std::uint32_t vertexCount, std::uint32_t firstVertex) override { drawInstanced(vertexCount, 1, firstVertex, 0); }
    void drawIndexed(std::uint32_t indexCount, std::uint32_t firstIndex) override { drawIndexedInstanced(indexCount, 1, firstIndex, 0, 0); }

    void beginRenderPass(const RenderPassDesc& d) override {
        requireRecording();
        if (inPass_) throw std::logic_error("Vulkan: beginRenderPass inside a render pass");
        pass_ = d;
        beginRendering(pass_, false);
        dirtyTex_ = true;   // bound textures may have changed layout since the descriptor set was written
        if (!d.label.empty()) pushDebugGroup(d.label.c_str());
        labelDepth_ = !d.label.empty();
    }
    void endRenderPass() override {
        requireRecording();
        if (!inPass_) throw std::logic_error("Vulkan: endRenderPass outside a render pass");
        if (labelDepth_) { popDebugGroup(); labelDepth_ = false; }
        core_->cmdEndRendering(cmd_);
        inPass_ = false;
    }
    void setViewport(float x, float y, float w, float h, float minD, float maxD) override {
        requireRecording();
        const VkViewport vp{x, y + h, w, -h, minD, maxD};   // flipped: GL-style clip space / winding
        vkCmdSetViewport(cmd_, 0, 1, &vp);
    }
    void setScissor(int x, int y, std::uint32_t w, std::uint32_t h) override {
        requireRecording();
        const VkRect2D r{{x, y}, {w, h}};
        vkCmdSetScissor(cmd_, 0, 1, &r);
    }
    void bindUniformBuffer(unsigned slot, const std::shared_ptr<rhi::Buffer>& b, std::size_t offset, std::size_t range) override {
        requireRecording();
        if (slot >= kMaxUniformSlots) throw std::out_of_range("Vulkan: uniform slot out of range");
        if (offset % core_->props.limits.minUniformBufferOffsetAlignment != 0)
            throw std::invalid_argument("Vulkan: uniform buffer offset must be a multiple of minUniformBufferOffsetAlignment");
        ubo_[slot] = std::static_pointer_cast<Buffer>(b);
        uboOff_[slot] = offset; uboRange_[slot] = range;
        if (ubo_[slot]) keep_.push_back(ubo_[slot]);
        dirtyUbo_ = true;
    }
    void pushConstants(const void* data, std::uint32_t size, std::uint32_t offset) override {
        requireRecording();
        if (offset + size > kMaxPushConstantBytes || (size % 4) || (offset % 4)) throw std::invalid_argument("Vulkan: invalid push constant range");
        vkCmdPushConstants(cmd_, core_->pipelineLayout, VK_SHADER_STAGE_VERTEX_BIT | VK_SHADER_STAGE_FRAGMENT_BIT, offset, size, data);
    }
    void drawInstanced(std::uint32_t vertexCount, std::uint32_t instanceCount, std::uint32_t firstVertex, std::uint32_t firstInstance) override {
        prepareDraw();
        vkCmdDraw(cmd_, vertexCount, instanceCount, firstVertex, firstInstance);
    }
    void drawIndexedInstanced(std::uint32_t indexCount, std::uint32_t instanceCount, std::uint32_t firstIndex, std::int32_t baseVertex, std::uint32_t firstInstance) override {
        prepareDraw();
        vkCmdDrawIndexed(cmd_, indexCount, instanceCount, firstIndex, baseVertex, firstInstance);
    }
    void generateMipmaps(const std::shared_ptr<rhi::Texture>& tex) override {
        requireRecording();
        if (inPass_) throw std::logic_error("Vulkan: generateMipmaps inside a render pass");
        auto t = std::static_pointer_cast<Texture>(tex);
        if (!t || t->levels_ <= 1) return;
        if (isDepthFormat(t->fmt_)) throw std::invalid_argument("Vulkan: generateMipmaps on a depth texture");
        core_->recordMips(cmd_, t->image_, t->w_, t->h_, t->levels_, t->layout_);
        t->layout_ = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
        keep_.push_back(t);
    }
    void pushDebugGroup(const char* name) override {
        if (!core_->cmdBeginLabel || !recording_) return;
        VkDebugUtilsLabelEXT l{VK_STRUCTURE_TYPE_DEBUG_UTILS_LABEL_EXT}; l.pLabelName = name;
        core_->cmdBeginLabel(cmd_, &l);
    }
    void popDebugGroup() override { if (core_->cmdEndLabel && recording_) core_->cmdEndLabel(cmd_); }

    VkCommandBuffer handle() const noexcept { return cmd_; }
    Swapchain* swapchain() const noexcept { return swapchain_; }

private:
    void requireRecording() const { if (!recording_) throw std::logic_error("Vulkan: CommandList::begin() was not called"); }

    void transitionNow(Texture& t, VkImageLayout want) {
        VkImageMemoryBarrier2 b = makeBarrier(t.image_, attachAspect(t.fmt_), 0, VK_REMAINING_MIP_LEVELS, t.layout_, want, scopeFor(t.layout_), scopeFor(want));
        core_->barriers(cmd_, &b, 1);
        t.layout_ = want;
    }
    // Puts a texture into its sampled layout. Inside a render pass this splits the pass (end, barrier, resume with Load).
    void ensureReadable(Texture& t) {
        const VkImageLayout want = readLayout(t.fmt_);
        if (t.layout_ == want) return;
        if (inPass_) {
            for (auto& c : pass_.colors) if (c.texture.get() == &t) throw std::logic_error("Vulkan: texture is sampled while it is a render target of the current pass");
            if (pass_.depth.texture.get() == &t) throw std::logic_error("Vulkan: texture is sampled while it is the depth target of the current pass");
            core_->cmdEndRendering(cmd_);
            transitionNow(t, want);
            beginRendering(pass_, true);
        } else {
            transitionNow(t, want);
        }
    }
    void noteSwapchain(const std::shared_ptr<Texture>& t) {
        if (!t->owner_) return;
        swapchain_ = t->owner_;
        for (auto& s : swapTex_) if (s == t) return;
        swapTex_.push_back(t);
    }
    void beginRendering(const RenderPassDesc& d, bool resume) {
        std::vector<VkImageMemoryBarrier2> bars;
        VkRenderingAttachmentInfo colors[kMaxColorAttachments]{};
        std::uint32_t n = 0, w = 0, h = 0;
        for (auto& c : d.colors) {
            if (!c.texture) throw std::invalid_argument("Vulkan: render pass colour attachment without texture");
            if (n >= kMaxColorAttachments) throw std::invalid_argument("Vulkan: too many colour attachments");
            auto t = std::static_pointer_cast<Texture>(c.texture);
            const bool load = resume || c.load == LoadOp::Load;
            bars.push_back(makeBarrier(t->image_, VK_IMAGE_ASPECT_COLOR_BIT, 0, VK_REMAINING_MIP_LEVELS,
                load ? t->layout_ : VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
                scopeFor(t->layout_), scopeFor(VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL)));
            t->layout_ = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            noteSwapchain(t);
            if (!resume) keep_.push_back(t);
            colors[n].sType = VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO;
            colors[n].imageView = t->mipView(c.mip);
            colors[n].imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
            colors[n].loadOp = load ? VK_ATTACHMENT_LOAD_OP_LOAD : (c.load == LoadOp::Clear ? VK_ATTACHMENT_LOAD_OP_CLEAR : VK_ATTACHMENT_LOAD_OP_DONT_CARE);
            colors[n].storeOp = VK_ATTACHMENT_STORE_OP_STORE;   // DontCare is ignored on purpose: passes can be split (see ensureReadable)
            std::memcpy(colors[n].clearValue.color.float32, c.clear, sizeof(float) * 4);
            const std::uint32_t cw = static_cast<std::uint32_t>(std::max(1, t->w_ >> c.mip)), ch = static_cast<std::uint32_t>(std::max(1, t->h_ >> c.mip));
            if (n == 0) { w = cw; h = ch; }
            ++n;
        }
        VkRenderingAttachmentInfo depthInfo{}; bool hasDepth = false, stencil = false;
        if (d.depth.texture) {
            auto t = std::static_pointer_cast<Texture>(d.depth.texture);
            const bool load = resume || d.depth.load == LoadOp::Load;
            bars.push_back(makeBarrier(t->image_, attachAspect(t->fmt_), 0, VK_REMAINING_MIP_LEVELS,
                load ? t->layout_ : VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
                scopeFor(t->layout_), scopeFor(VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL)));
            t->layout_ = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
            if (!resume) keep_.push_back(t);
            depthInfo.sType = VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO;
            depthInfo.imageView = t->view_;
            depthInfo.imageLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL;
            depthInfo.loadOp = load ? VK_ATTACHMENT_LOAD_OP_LOAD : (d.depth.load == LoadOp::Clear ? VK_ATTACHMENT_LOAD_OP_CLEAR : VK_ATTACHMENT_LOAD_OP_DONT_CARE);
            depthInfo.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
            depthInfo.clearValue.depthStencil = {d.depth.clearDepth, 0};
            hasDepth = true; stencil = hasStencil(t->fmt_);
            if (n == 0) { w = static_cast<std::uint32_t>(t->w_); h = static_cast<std::uint32_t>(t->h_); }
        }
        if (n == 0 && !hasDepth) throw std::invalid_argument("Vulkan: render pass without attachments");
        core_->barriers(cmd_, bars.data(), static_cast<std::uint32_t>(bars.size()));

        VkRenderingInfo ri{VK_STRUCTURE_TYPE_RENDERING_INFO};
        ri.renderArea = {{0, 0}, {w, h}}; ri.layerCount = 1;
        ri.colorAttachmentCount = n; ri.pColorAttachments = n ? colors : nullptr;
        ri.pDepthAttachment = hasDepth ? &depthInfo : nullptr;
        ri.pStencilAttachment = stencil ? &depthInfo : nullptr;
        core_->cmdBeginRendering(cmd_, &ri);
        inPass_ = true;
        if (!resume) {
            const VkViewport vp{0.0f, static_cast<float>(h), static_cast<float>(w), -static_cast<float>(h), 0.0f, 1.0f};
            const VkRect2D sc{{0, 0}, {w, h}};
            vkCmdSetViewport(cmd_, 0, 1, &vp);
            vkCmdSetScissor(cmd_, 0, 1, &sc);
        }
    }

    void prepareDraw() {
        requireRecording();
        if (!inPass_) throw std::logic_error("Vulkan: draw outside a render pass");
        if (!pipeline_) throw std::logic_error("Vulkan: draw without a pipeline");
        bool rebind = false;
        if (dirtyTex_) {
            for (auto& t : tex_) if (t) ensureReadable(*t);   // may split the pass
            VkDescriptorSet set = core_->allocSet(core_->texLayout);
            VkDescriptorImageInfo infos[kMaxTextureSlots]; VkWriteDescriptorSet w[kMaxTextureSlots]{};
            for (unsigned i = 0; i < kMaxTextureSlots; ++i) {
                if (tex_[i]) {
                    infos[i] = {smp_[i] ? smp_[i]->handle() : core_->defaultSampler, tex_[i]->sampleView_, readLayout(tex_[i]->fmt_)};
                } else {
                    infos[i] = {core_->defaultSampler, core_->fbView, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
                }
                w[i] = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET, nullptr, set, i, 0, 1, VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, &infos[i], nullptr, nullptr};
            }
            vkUpdateDescriptorSets(core_->device, kMaxTextureSlots, w, 0, nullptr);
            texSet_ = set; dirtyTex_ = false; rebind = true;
        }
        if (dirtyUbo_) {
            VkDescriptorSet set = core_->allocSet(core_->uboLayout);
            VkDescriptorBufferInfo infos[kMaxUniformSlots]; VkWriteDescriptorSet w[kMaxUniformSlots]{};
            for (unsigned i = 0; i < kMaxUniformSlots; ++i) {
                if (ubo_[i]) {
                    ubo_[i]->sync();
                    const VkDeviceSize range = uboRange_[i] ? uboRange_[i] : ubo_[i]->size() - uboOff_[i];
                    infos[i] = {ubo_[i]->handle(), ubo_[i]->slotOffset() + uboOff_[i], range};
                } else {
                    infos[i] = {core_->fbBuffer, 0, kFallbackUboSize};
                }
                w[i] = {VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET, nullptr, set, i, 0, 1, VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, nullptr, &infos[i], nullptr};
            }
            vkUpdateDescriptorSets(core_->device, kMaxUniformSlots, w, 0, nullptr);
            uboSet_ = set; dirtyUbo_ = false; rebind = true;
        }
        if (rebind) {
            const VkDescriptorSet sets[2] = {uboSet_, texSet_};
            vkCmdBindDescriptorSets(cmd_, VK_PIPELINE_BIND_POINT_GRAPHICS, core_->pipelineLayout, 0, 2, sets, 0, nullptr);
        }
    }

    std::shared_ptr<Core> core_;
    VkCommandPool pools_[kFrames] = {};
    VkCommandBuffer bufs_[kFrames] = {};
    VkCommandBuffer cmd_ = VK_NULL_HANDLE;
    bool recording_ = false, inPass_ = false, labelDepth_ = false;
    RenderPassDesc pass_;
    std::shared_ptr<Pipeline> pipeline_;
    std::array<std::shared_ptr<Buffer>, kMaxUniformSlots> ubo_;
    std::array<std::size_t, kMaxUniformSlots> uboOff_{}, uboRange_{};
    std::array<std::shared_ptr<Texture>, kMaxTextureSlots> tex_;
    std::array<std::shared_ptr<Sampler>, kMaxTextureSlots> smp_;
    bool dirtyUbo_ = true, dirtyTex_ = true;
    VkDescriptorSet uboSet_ = VK_NULL_HANDLE, texSet_ = VK_NULL_HANDLE;
    std::vector<std::shared_ptr<void>> keep_;
    std::vector<std::shared_ptr<Texture>> swapTex_;
    Swapchain* swapchain_ = nullptr;
};

// ---------------------------------------------------------------------------------------------------------------------
class Device final : public rhi::Device {
public:
    explicit Device(std::shared_ptr<Core> core) : core_(std::move(core)) {}
    ~Device() override { if (core_ && core_->device) { vkDeviceWaitIdle(core_->device); core_->collect(true); } }
    const DeviceCapabilities& capabilities() const noexcept override { return core_->caps; }
    std::shared_ptr<rhi::Buffer> createBuffer(const BufferDesc& d, const void* init) override { return std::make_shared<Buffer>(core_, d, init); }
    std::shared_ptr<rhi::Texture> createTexture2D(const TextureDesc& d, const void* init) override { return std::make_shared<Texture>(core_, d, init); }
    std::shared_ptr<rhi::Sampler> createSampler(const SamplerDesc& d) override { return std::make_shared<Sampler>(core_, d); }
    std::shared_ptr<rhi::Shader> createShader(const ShaderDesc& d) override { return std::make_shared<Shader>(core_, d); }
    std::shared_ptr<rhi::Pipeline> createPipeline(const std::shared_ptr<rhi::Shader>& s, const PipelineDesc& d) override { return std::make_shared<Pipeline>(core_, s, d); }
    std::unique_ptr<rhi::CommandList> createCommandList() override { return std::make_unique<CommandList>(core_); }
    std::unique_ptr<rhi::Swapchain> createSwapchain(const SwapchainDesc& d) override { return std::make_unique<Swapchain>(core_, d); }

    void beginFrame() override { core_->beginFrame(); }
    void endFrame() override { core_->collect(); }
    void waitIdle() override { vkDeviceWaitIdle(core_->device); core_->collect(); }

    void submit(rhi::CommandList& list) override {
        auto* cl = dynamic_cast<CommandList*>(&list);
        if (!cl) throw std::invalid_argument("Vulkan: submit() got a command list from another backend");
        VkCommandBufferSubmitInfo cbi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_SUBMIT_INFO};
        cbi.commandBuffer = cl->handle();
        VkSemaphoreSubmitInfo waits[1]{}, signals[2]{};
        std::uint32_t nw = 0, ns = 0;
        if (Swapchain* sc = cl->swapchain()) {
            VkSemaphore s{};
            if (sc->consumeAcquire(s)) {
                waits[nw++] = {VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO, nullptr, s, 0,
                               VK_PIPELINE_STAGE_2_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_2_ALL_TRANSFER_BIT, 0};
            }
            if (sc->consumeRenderFinished(s)) signals[ns++] = {VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO, nullptr, s, 0, VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT, 0};
        }
        const std::uint64_t value = ++core_->submitted;
        signals[ns++] = {VK_STRUCTURE_TYPE_SEMAPHORE_SUBMIT_INFO, nullptr, core_->timeline, value, VK_PIPELINE_STAGE_2_ALL_COMMANDS_BIT, 0};
        VkSubmitInfo2 si{VK_STRUCTURE_TYPE_SUBMIT_INFO_2};
        si.waitSemaphoreInfoCount = nw; si.pWaitSemaphoreInfos = waits;
        si.commandBufferInfoCount = 1; si.pCommandBufferInfos = &cbi;
        si.signalSemaphoreInfoCount = ns; si.pSignalSemaphoreInfos = signals;
        VK_CHECK(core_->queueSubmit2(core_->queue, 1, &si, VK_NULL_HANDLE));
        core_->frameValue[core_->frame] = value;
    }

private:
    std::shared_ptr<Core> core_;
};

} // namespace anvil::rhi::vk

namespace anvil::rhi {
std::unique_ptr<Device> createVulkanDevice(const DeviceCreateInfo& info, Backend tier) {
    auto core = std::make_shared<vk::Core>();
    core->init(info, tier);
    return std::make_unique<vk::Device>(std::move(core));
}
} // namespace anvil::rhi
