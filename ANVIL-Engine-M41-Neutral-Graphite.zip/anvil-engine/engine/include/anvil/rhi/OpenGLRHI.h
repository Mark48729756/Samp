#pragma once
#include "anvil/rhi/RHI.h"
#include <glad/gl.h>
#include <array>

namespace anvil::rhi::gl {
class Buffer final : public rhi::Buffer {
public: Buffer(const BufferDesc&, const void*); ~Buffer() override; std::size_t size() const noexcept override { return size_; }
    void update(std::size_t, const void*, std::size_t) override; GLuint id() const noexcept { return id_; }
private: GLuint id_ = 0; std::size_t size_ = 0; GLenum target_ = GL_ARRAY_BUFFER; bool dynamic_ = false;
};
class Texture final : public rhi::Texture {
public: Texture(const TextureDesc&, const void*); ~Texture() override; int width() const noexcept override { return width_; } int height() const noexcept override { return height_; } GLuint id() const noexcept { return id_; }
private: GLuint id_ = 0; int width_ = 1, height_ = 1;
};
class Sampler final : public rhi::Sampler { public: explicit Sampler(const SamplerDesc&); ~Sampler() override; GLuint id() const noexcept { return id_; } private: GLuint id_ = 0; };
class Shader final : public rhi::Shader { public: explicit Shader(const ShaderDesc&); ~Shader() override; GLuint id() const noexcept { return id_; } private: GLuint id_ = 0; };
class Pipeline final : public rhi::Pipeline { public: Pipeline(const std::shared_ptr<rhi::Shader>&, const PipelineDesc&); GLuint program() const noexcept { return program_; } const PipelineDesc& desc() const noexcept { return desc_; } private: std::shared_ptr<rhi::Shader> shader_; GLuint program_ = 0; PipelineDesc desc_{}; };
class CommandList final : public rhi::CommandList {
public: void begin() override; void end() override; void setPipeline(const std::shared_ptr<rhi::Pipeline>&) override;
    void bindVertexBuffer(const std::shared_ptr<rhi::Buffer>&, unsigned) override; void bindIndexBuffer(const std::shared_ptr<rhi::Buffer>&) override;
    void bindTexture(unsigned, const std::shared_ptr<rhi::Texture>&, const std::shared_ptr<rhi::Sampler>&) override;
    void draw(std::uint32_t, std::uint32_t) override; void drawIndexed(std::uint32_t, std::uint32_t) override;
private: std::shared_ptr<Pipeline> pipeline_; bool recording_ = false;
};
class Device final : public rhi::Device {
public: Device(); const DeviceCapabilities& capabilities() const noexcept override { return caps_; }
    std::shared_ptr<rhi::Buffer> createBuffer(const BufferDesc&, const void*) override;
    std::shared_ptr<rhi::Texture> createTexture2D(const TextureDesc&, const void*) override;
    std::shared_ptr<rhi::Sampler> createSampler(const SamplerDesc&) override;
    std::shared_ptr<rhi::Shader> createShader(const ShaderDesc&) override;
    std::shared_ptr<rhi::Pipeline> createPipeline(const std::shared_ptr<rhi::Shader>&, const PipelineDesc&) override;
    std::unique_ptr<rhi::CommandList> createCommandList() override;
private: DeviceCapabilities caps_{};
};
}
