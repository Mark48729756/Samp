#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace anvil::rhi {

// New values are only ever appended, so serialized/stored enum values stay valid.
// Vulkan12 = compatibility tier (1.2 + dynamic rendering/sync2 extensions), Vulkan14 = target tier (core 1.4).
enum class Backend : std::uint8_t { OpenGL45, Vulkan12, Direct3D12, Vulkan14 };
enum class BufferUsage : std::uint8_t { Vertex, Index, Uniform, Storage, Readback };
enum class TextureFormat : std::uint8_t {
    R8, RG8, RGB8, RGBA8, SRGBA8, R16F, RG16F, RGBA16F, R32F, Depth24, Depth32F,
    BGRA8, SBGRA8, RGB10A2, R11G11B10F, Depth24Stencil8, Undefined };
enum class TextureFilter : std::uint8_t { Nearest, Linear, LinearMipmapLinear };
enum class TextureWrap : std::uint8_t { Repeat, ClampToEdge, MirroredRepeat, ClampToBorder };
enum class CompareOp : std::uint8_t { Never, Less, Equal, LessEqual, Greater, NotEqual, GreaterEqual, Always };
enum class CullMode : std::uint8_t { None, Back, Front };
enum class BlendMode : std::uint8_t { Alpha, Additive, Premultiplied };
enum class PrimitiveTopology : std::uint8_t { TriangleList, TriangleStrip, LineList, PointList };
enum class VertexFormat : std::uint8_t { Float, Float2, Float3, Float4, UByte4Norm, UInt };
enum class LoadOp : std::uint8_t { Load, Clear, DontCare };
enum class StoreOp : std::uint8_t { Store, DontCare };

enum class TextureUsage : std::uint8_t { Sampled = 1, RenderTarget = 2, DepthStencil = 4, Storage = 8, TransferSrc = 16, TransferDst = 32 };
constexpr TextureUsage operator|(TextureUsage a, TextureUsage b) { return static_cast<TextureUsage>(static_cast<std::uint8_t>(a) | static_cast<std::uint8_t>(b)); }
constexpr bool hasUsage(TextureUsage v, TextureUsage f) { return (static_cast<std::uint8_t>(v) & static_cast<std::uint8_t>(f)) != 0; }

// ---- Binding model (identical for OpenGL, Vulkan and D3D12; shaders are written once in Vulkan-flavoured GLSL) ----
//   uniform buffers : GLSL `layout(set = 0, binding = N)`  N < kMaxUniformSlots   (HLSL b#)
//   textures        : GLSL `layout(set = 1, binding = N)`  N < kMaxTextureSlots   (HLSL t# + s#, combined image sampler)
//   per-draw data   : GLSL `layout(push_constant)`  <= kMaxPushConstantBytes     (Vulkan push constants / D3D12 root constants)
// Resource state transitions/barriers are tracked per texture by the backend; the renderer never records barriers by hand.
constexpr unsigned kMaxUniformSlots = 4;
constexpr unsigned kMaxTextureSlots = 16;
constexpr unsigned kMaxPushConstantBytes = 128;
constexpr unsigned kMaxColorAttachments = 8;

struct DeviceCapabilities {
    Backend backend = Backend::OpenGL45;
    std::string deviceName;
    std::string apiVersion;
    int maxTextureSize = 0;
    int maxSamples = 1;
    bool debugOutput = false;
    bool directStateAccess = false;
    // v2
    std::uint32_t framesInFlight = 1;
    bool validationEnabled = false;
    bool discreteGpu = false;
    float maxAnisotropy = 1.0f;
    std::uint64_t dedicatedVideoMemory = 0;
};

// Backend creation options. Vulkan/D3D12 do not need a current GL context; `nativeWindow` is the GLFWwindow*
// used to pick a presentation-capable adapter/queue. All fields are optional.
struct DeviceCreateInfo {
    bool validation = false;          // Vulkan validation layer / D3D12 debug layer + GPU-based validation off
    int preferredAdapter = -1;        // index into the backend's adapter list; -1 = best (discrete, most VRAM)
    bool allowSoftwareAdapter = false;// WARP / lavapipe
    void* nativeWindow = nullptr;
    std::string appName = "ANVIL";
};

struct BufferDesc { std::size_t size = 0; BufferUsage usage = BufferUsage::Vertex; bool dynamic = false; std::string label; };
struct TextureDesc {
    int width = 1, height = 1, levels = 1; TextureFormat format = TextureFormat::RGBA8; std::string label;
    TextureUsage usage = TextureUsage::Sampled | TextureUsage::TransferDst;   // v2 (ignored by the OpenGL backend)
    int samples = 1;
};
struct SamplerDesc {
    TextureFilter minFilter = TextureFilter::Linear; TextureFilter magFilter = TextureFilter::Linear;
    TextureWrap wrapU = TextureWrap::Repeat, wrapV = TextureWrap::Repeat;
    bool compare = false; CompareOp compareOp = CompareOp::LessEqual;   // v2: hardware PCF shadow sampler
    float maxAnisotropy = 1.0f; bool whiteBorder = false;                // v2: ClampToBorder colour (opaque white / transparent black)
};
// GL backend: GLSL source. Vulkan/D3D12: precompiled blobs (SPIR-V / DXIL) produced by cmake/AnvilShaders.cmake.
struct ShaderDesc {
    std::string vertexSource, fragmentSource, label;
    std::vector<std::uint32_t> vertexSpirv, fragmentSpirv;   // v2
    std::vector<std::uint8_t> vertexDxil, fragmentDxil;      // v2
};
struct VertexBinding { std::uint32_t binding = 0, stride = 0; bool perInstance = false; };
struct VertexAttribute { std::uint32_t location = 0, binding = 0, offset = 0; VertexFormat format = VertexFormat::Float3; };
struct VertexLayout { std::vector<VertexBinding> bindings; std::vector<VertexAttribute> attributes; };
struct PipelineDesc {
    bool depthTest = true; bool depthWrite = true; bool blend = false; bool cull = true;
    // v2 (Vulkan/D3D12 bake all of this into the pipeline state object)
    CompareOp depthCompare = CompareOp::LessEqual;
    BlendMode blendMode = BlendMode::Alpha;
    CullMode cullMode = CullMode::Back;              // used when `cull` is true
    bool frontFaceCCW = true;
    PrimitiveTopology topology = PrimitiveTopology::TriangleList;
    VertexLayout vertexLayout;                       // empty = vertex-pulling / fullscreen triangle (SV_VertexID)
    std::vector<TextureFormat> colorFormats;         // must match the render pass this pipeline is used in
    TextureFormat depthFormat = TextureFormat::Undefined;
    float depthBiasConstant = 0.0f, depthBiasSlope = 0.0f;
    std::uint32_t pushConstantBytes = 0;             // <= kMaxPushConstantBytes
    int samples = 1;
    std::string label;
};

class Buffer { public: virtual ~Buffer() = default; virtual std::size_t size() const noexcept = 0; virtual void update(std::size_t offset, const void* data, std::size_t bytes) = 0; };
class Texture {
public:
    virtual ~Texture() = default; virtual int width() const noexcept = 0; virtual int height() const noexcept = 0;
    virtual TextureFormat format() const noexcept { return TextureFormat::RGBA8; }     // v2: Vulkan/D3D12 override
    // Opaque native handle for UI backends (ImGui): GL texture id / VkImageView / D3D12 SRV GPU handle. 0 if none.
    virtual std::uintptr_t nativeHandle() const noexcept { return 0; }
};
class Sampler { public: virtual ~Sampler() = default; };
class Shader { public: virtual ~Shader() = default; };
class Pipeline { public: virtual ~Pipeline() = default; };

struct ColorAttachment { std::shared_ptr<Texture> texture; LoadOp load = LoadOp::Clear; StoreOp store = StoreOp::Store; float clear[4] = {0, 0, 0, 0}; std::uint32_t mip = 0; };
struct DepthAttachment { std::shared_ptr<Texture> texture; LoadOp load = LoadOp::Clear; StoreOp store = StoreOp::Store; float clearDepth = 1.0f; };
struct RenderPassDesc { std::vector<ColorAttachment> colors; DepthAttachment depth; std::string label; };

struct UnsupportedByBackend : std::logic_error { using std::logic_error::logic_error; };

class CommandList {
public:
    virtual ~CommandList() = default;
    virtual void begin() = 0; virtual void end() = 0;
    virtual void setPipeline(const std::shared_ptr<Pipeline>& pipeline) = 0;
    virtual void bindVertexBuffer(const std::shared_ptr<Buffer>& buffer, unsigned binding = 0) = 0;
    virtual void bindIndexBuffer(const std::shared_ptr<Buffer>& buffer) = 0;   // 32-bit indices
    virtual void bindTexture(unsigned unit, const std::shared_ptr<Texture>& texture, const std::shared_ptr<Sampler>& sampler = {}) = 0;
    virtual void draw(std::uint32_t vertexCount, std::uint32_t firstVertex = 0) = 0;
    virtual void drawIndexed(std::uint32_t indexCount, std::uint32_t firstIndex = 0) = 0;

    // ---- v2: explicit-API surface. The OpenGL backend keeps the throwing defaults (its renderer still talks to GL directly). ----
    virtual void beginRenderPass(const RenderPassDesc&) { unsupported("beginRenderPass"); }
    virtual void endRenderPass() { unsupported("endRenderPass"); }
    virtual void setViewport(float, float, float, float, float = 0.0f, float = 1.0f) { unsupported("setViewport"); }
    virtual void setScissor(int, int, std::uint32_t, std::uint32_t) { unsupported("setScissor"); }
    virtual void bindUniformBuffer(unsigned, const std::shared_ptr<Buffer>&, std::size_t = 0, std::size_t = 0) { unsupported("bindUniformBuffer"); }
    virtual void pushConstants(const void*, std::uint32_t, std::uint32_t = 0) { unsupported("pushConstants"); }
    virtual void drawInstanced(std::uint32_t, std::uint32_t, std::uint32_t = 0, std::uint32_t = 0) { unsupported("drawInstanced"); }
    virtual void drawIndexedInstanced(std::uint32_t, std::uint32_t, std::uint32_t = 0, std::int32_t = 0, std::uint32_t = 0) { unsupported("drawIndexedInstanced"); }
    virtual void generateMipmaps(const std::shared_ptr<Texture>&) { unsupported("generateMipmaps"); }
    virtual void pushDebugGroup(const char*) {}
    virtual void popDebugGroup() {}
private:
    static void unsupported(const char* what) { throw UnsupportedByBackend(std::string("CommandList::") + what + " is not supported by this RHI backend"); }
};

struct SwapchainDesc { void* nativeWindow = nullptr; int width = 0, height = 0; bool vsync = true; std::uint32_t imageCount = 3; bool hdr10 = false; };
class Swapchain {
public:
    virtual ~Swapchain() = default;
    virtual void resize(int width, int height) = 0;
    virtual TextureFormat format() const noexcept = 0;
    virtual int width() const noexcept = 0; virtual int height() const noexcept = 0;
    // Returns the backbuffer to render into this frame, or null if the surface is minimised / out of date (skip the frame).
    virtual std::shared_ptr<Texture> acquire() = 0;
    virtual void present() = 0;
};

class Device {
public:
    virtual ~Device() = default;
    virtual const DeviceCapabilities& capabilities() const noexcept = 0;
    virtual std::shared_ptr<Buffer> createBuffer(const BufferDesc&, const void* initialData = nullptr) = 0;
    virtual std::shared_ptr<Texture> createTexture2D(const TextureDesc&, const void* initialData = nullptr) = 0;
    virtual std::shared_ptr<Sampler> createSampler(const SamplerDesc&) = 0;
    virtual std::shared_ptr<Shader> createShader(const ShaderDesc&) = 0;
    virtual std::shared_ptr<Pipeline> createPipeline(const std::shared_ptr<Shader>&, const PipelineDesc&) = 0;
    virtual std::unique_ptr<CommandList> createCommandList() = 0;

    // ---- v2 frame loop:  beginFrame -> swapchain.acquire -> record -> submit -> swapchain.present -> endFrame ----
    virtual std::unique_ptr<Swapchain> createSwapchain(const SwapchainDesc&) { throw UnsupportedByBackend("Device::createSwapchain is not supported by this RHI backend"); }
    virtual void beginFrame() {}                       // waits for the frame slot's fence, recycles per-frame upload memory
    virtual void submit(CommandList&) { throw UnsupportedByBackend("Device::submit is not supported by this RHI backend"); }
    virtual void endFrame() {}
    virtual void waitIdle() {}
};

std::unique_ptr<Device> createOpenGL45Device();
// Defined only when the matching backend is compiled in (ANVIL_WITH_VULKAN / ANVIL_WITH_D3D12).
std::unique_ptr<Device> createVulkanDevice(const DeviceCreateInfo&, Backend tier);
std::unique_ptr<Device> createD3D12Device(const DeviceCreateInfo&);

// The selector fails explicitly for backends that are not compiled into this build.
std::unique_ptr<Device> createDevice(Backend backend, const DeviceCreateInfo& info = {});
bool isBackendAvailable(Backend backend) noexcept;
const char* backendName(Backend backend) noexcept;
// "gl" / "opengl", "vulkan" / "vk" / "vulkan14", "vulkan12", "d3d12" / "dx12" / "directx12" (case-insensitive). False if unknown.
bool parseBackend(const char* text, Backend& out) noexcept;
// Reads ANVIL_BACKEND; returns `fallback` if unset, unknown, or not compiled in.
Backend backendFromEnvironment(Backend fallback = Backend::OpenGL45) noexcept;

} // namespace anvil::rhi
