#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/matrix_inverse.hpp>
#include <algorithm>
#include <cmath>

namespace anvil {

// Renderer-independent directional-light shadow camera. Both render paths use
// exactly the same stabilized frustum; explicit APIs opt into [0, 1] clip Z.
struct ShadowFrustum {
    glm::mat4 lightVP{1.0f};
    float texelWorld = 0.0f;
    glm::vec3 direction{0.0f, -1.0f, 0.0f};
};

inline ShadowFrustum buildShadowFrustum(const glm::vec3& cameraPosition,
                                        const glm::vec3& cameraForward,
                                        const glm::vec3& sunDirection,
                                        float radius, int mapSize,
                                        bool zeroToOneClipDepth = false) {
    radius = std::max(radius, 0.001f);
    mapSize = std::max(mapSize, 1);
    glm::vec3 dir = sunDirection;
    if (glm::dot(dir, dir) < 1.0e-12f) dir = glm::vec3(-0.4f, -1.0f, -0.3f);
    dir = glm::normalize(dir);
    const glm::vec3 up = std::abs(dir.y) > 0.99f ? glm::vec3(1, 0, 0) : glm::vec3(0, 1, 0);

    glm::vec3 center = cameraPosition + cameraForward * (radius * 0.5f);
    const glm::mat4 rotation = glm::lookAt(glm::vec3(0.0f), dir, up);
    const float texelWorld = 2.0f * radius / static_cast<float>(mapSize);
    glm::vec3 lightCenter = glm::vec3(rotation * glm::vec4(center, 1.0f));
    lightCenter.x = std::floor(lightCenter.x / texelWorld) * texelWorld;
    lightCenter.y = std::floor(lightCenter.y / texelWorld) * texelWorld;
    center = glm::vec3(glm::inverse(rotation) * glm::vec4(lightCenter, 1.0f));

    const glm::mat4 view = glm::lookAt(center - dir * radius * 2.0f, center, up);
    glm::mat4 projection = glm::ortho(-radius, radius, -radius, radius, 0.1f, radius * 4.0f);
    if (zeroToOneClipDepth) {
        glm::mat4 clipFix(1.0f);
        clipFix[2][2] = 0.5f;
        clipFix[3][2] = 0.5f;
        projection = clipFix * projection;
    }
    return {projection * view, texelWorld, dir};
}

} // namespace anvil
