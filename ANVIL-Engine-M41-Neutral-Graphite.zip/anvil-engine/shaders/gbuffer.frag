#version 450 core
layout(location = 0) out vec4 oAlbedo;
layout(location = 1) out vec4 oNormal;
layout(location = 2) out vec4 oMaterial;

in vec3 vNormal;
in vec2 vUV;

uniform vec3 uAlbedo;
uniform float uRoughness;
uniform float uMetallic;
uniform int uHasAlbedoMap;
layout(binding = 5) uniform sampler2D uAlbedoMap;

void main() {
    // simple checker on UV so large surfaces show scale/motion
    vec2 c = floor(vUV * 2.0);
    float checker = mod(c.x + c.y, 2.0) * 0.12 + 0.88;
    vec3 baseColor = uAlbedo * checker;
    if (uHasAlbedoMap != 0) baseColor *= texture(uAlbedoMap, vUV).rgb;
    oAlbedo = vec4(baseColor, 1.0);
    oNormal = vec4(normalize(vNormal), 1.0);
    oMaterial = vec4(uRoughness, uMetallic, 1.0, 1.0);
}
