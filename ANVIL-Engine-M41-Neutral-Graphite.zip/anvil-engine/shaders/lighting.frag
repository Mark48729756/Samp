#version 450 core
#define MAX_LIGHTS 32
const float PI = 3.14159265359;

in vec2 vUV;
out vec4 oColor;

layout(binding = 0) uniform sampler2D gAlbedo;
layout(binding = 1) uniform sampler2D gNormal;
layout(binding = 2) uniform sampler2D gMaterial;
layout(binding = 3) uniform sampler2D gDepth;
layout(binding = 4) uniform sampler2DShadow uShadow;

uniform mat4 uInvViewProj;
uniform mat4 uViewProj;
uniform int uSSAOEnabled;
uniform float uAORadius;
uniform float uAOStrength;
uniform vec3 uCamPos;
uniform vec3 uSunDir;
uniform vec3 uSunRadiance;
uniform int uLightCount;
uniform vec3 uLightPos[MAX_LIGHTS];
uniform vec3 uLightRadiance[MAX_LIGHTS];
uniform float uLightRadius[MAX_LIGHTS];
uniform mat4 uLightVP;
uniform int uShadowsOn;
uniform float uShadowBias;
uniform float uShadowTexel;
uniform float uShadowNormalOffset;
uniform int uSSREnabled;
uniform float uSSRStrength;
uniform int uFogEnabled;
uniform vec3 uFogColor;
uniform float uFogDensity;

// sun shadow: normal-offset + slope bias, 3x3 hardware-PCF taps
float sunShadow(vec3 P, vec3 N, vec3 L) {
    if (uShadowsOn == 0) return 1.0;
    vec4 lp = uLightVP * vec4(P + N * uShadowNormalOffset, 1.0);
    vec3 s = lp.xyz / lp.w * 0.5 + 0.5;
    if (s.z > 1.0 || s.x < 0.0 || s.y < 0.0 || s.x > 1.0 || s.y > 1.0) return 1.0;
    float bias = uShadowBias * (1.0 - clamp(dot(N, L), 0.0, 1.0)) + 0.0002;
    float sum = 0.0;
    for (int y = -1; y <= 1; ++y)
        for (int x = -1; x <= 1; ++x)
            sum += texture(uShadow, vec3(s.xy + vec2(x, y) * uShadowTexel, s.z - bias));
    return sum / 9.0;
}


// Screen-space ambient occlusion. Samples are projected from a small
// hemisphere around the receiver; depth is reconstructed into world space.
float ambientOcclusion(vec3 P, vec3 N) {
    if (uSSAOEnabled == 0) return 1.0;
    const vec3 kernel[12] = vec3[](
        vec3( 0.18, 0.12, 0.31), vec3(-0.24, 0.16, 0.28),
        vec3( 0.12,-0.32, 0.22), vec3(-0.34,-0.18, 0.20),
        vec3( 0.42, 0.08, 0.15), vec3(-0.40, 0.24, 0.12),
        vec3( 0.08, 0.48, 0.18), vec3(-0.12,-0.48, 0.16),
        vec3( 0.52,-0.22, 0.08), vec3(-0.50,-0.28, 0.10),
        vec3( 0.28, 0.42, 0.12), vec3(-0.28, 0.40, 0.14)
    );
    vec3 helper = abs(N.y) < 0.95 ? vec3(0,1,0) : vec3(1,0,0);
    vec3 T = normalize(cross(helper, N));
    vec3 B = normalize(cross(N, T));
    float occlusion = 0.0;
    float valid = 0.0;
    for (int i = 0; i < 12; ++i) {
        vec3 k = kernel[i];
        vec3 dir = normalize(T * k.x + B * k.y + N * abs(k.z));
        vec3 Q = P + dir * uAORadius;
        vec4 clip = uViewProj * vec4(Q, 1.0);
        if (clip.w <= 0.0) continue;
        vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
        if (any(lessThan(uv, vec2(0.002))) || any(greaterThan(uv, vec2(0.998)))) continue;
        float d = texture(gDepth, uv).r;
        if (d >= 0.99999) continue;
        vec4 h = uInvViewProj * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
        vec3 R = h.xyz / h.w;
        float rangeWeight = smoothstep(0.0, 1.0, uAORadius / (length(R - P) + 1e-4));
        float blocked = dot(N, R - P) > 0.025 ? 1.0 : 0.0;
        occlusion += blocked * rangeWeight;
        valid += 1.0;
    }
    float ao = 1.0 - (occlusion / max(valid, 1.0)) * uAOStrength;
    return clamp(ao, 0.25, 1.0);
}


// Bounded screen-space reflection. It is a local approximation: off-screen and
// hidden geometry cannot contribute, so the result fades smoothly with roughness.
vec3 screenReflection(vec3 P, vec3 N, vec3 V, float roughness) {
    if (uSSREnabled == 0 || roughness > 0.72) return vec3(0.0);
    vec3 R = reflect(-V, N);
    float stepLen = mix(0.12, 0.32, roughness);
    vec3 hitColor = vec3(0.0); float confidence = 0.0;
    for (int i=1; i<=28; ++i) {
        vec3 Q = P + R * (stepLen * float(i));
        vec4 clip = uViewProj * vec4(Q, 1.0);
        if (clip.w <= 0.0) break;
        vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
        if (any(lessThan(uv, vec2(0.002))) || any(greaterThan(uv, vec2(0.998)))) break;
        float sceneDepth = texture(gDepth, uv).r;
        if (sceneDepth < 0.99999) {
            vec4 h = uInvViewProj * vec4(uv*2.0-1.0, sceneDepth*2.0-1.0, 1.0);
            vec3 sceneP = h.xyz / h.w;
            float delta = length(sceneP-Q);
            if (delta < 0.22 + stepLen*float(i)*0.035 && dot(normalize(sceneP-P),N) > -0.15) {
                float edge = smoothstep(0.0,0.08,min(min(uv.x,uv.y),min(1.0-uv.x,1.0-uv.y)));
                confidence = (1.0-float(i)/30.0)*edge*(1.0-roughness/0.8);
                hitColor = texture(gAlbedo,uv).rgb;
                break;
            }
        }
    }
    return hitColor * confidence * uSSRStrength;
}

float distGGX(float NdotH, float a) {
    float a2 = a * a;
    float d = NdotH * NdotH * (a2 - 1.0) + 1.0;
    return a2 / (PI * d * d);
}
float geomSchlick(float NdotX, float k) { return NdotX / (NdotX * (1.0 - k) + k); }
vec3 fresnel(float cosT, vec3 F0) { return F0 + (1.0 - F0) * pow(clamp(1.0 - cosT, 0.0, 1.0), 5.0); }

vec3 brdf(vec3 N, vec3 V, vec3 L, vec3 radiance, vec3 albedo, float rough, float metal, vec3 F0) {
    vec3 H = normalize(V + L);
    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 1e-4);
    float a = rough * rough;
    float k = (rough + 1.0) * (rough + 1.0) / 8.0;
    float D = distGGX(max(dot(N, H), 0.0), a);
    float G = geomSchlick(NdotV, k) * geomSchlick(NdotL, k);
    vec3 F = fresnel(max(dot(H, V), 0.0), F0);
    vec3 spec = D * G * F / (4.0 * NdotV * NdotL + 1e-4);
    vec3 kD = (1.0 - F) * (1.0 - metal);
    return (kD * albedo / PI + spec) * radiance * NdotL;
}

void main() {
    float depth = texture(gDepth, vUV).r;
    vec3 skyTop = vec3(0.35, 0.55, 0.95), skyHorizon = vec3(0.85, 0.9, 1.0);

    vec4 ndc = vec4(vUV * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 wp = uInvViewProj * ndc;
    vec3 P = wp.xyz / wp.w;

    if (depth >= 1.0) {
        vec3 dir = normalize(P - uCamPos);
        oColor = vec4(mix(skyHorizon, skyTop, clamp(dir.y * 1.5, 0.0, 1.0)) * 1.2, 1.0);
        return;
    }

    vec3 albedo = texture(gAlbedo, vUV).rgb;
    vec3 N = normalize(texture(gNormal, vUV).xyz);
    vec2 rm = texture(gMaterial, vUV).rg;
    float rough = clamp(rm.x, 0.04, 1.0), metal = rm.y;
    vec3 V = normalize(uCamPos - P);
    vec3 F0 = mix(vec3(0.04), albedo, metal);

    vec3 Lsun = normalize(-uSunDir);
    vec3 Lo = brdf(N, V, Lsun, uSunRadiance, albedo, rough, metal, F0) * sunShadow(P, N, Lsun);
    for (int i = 0; i < uLightCount; ++i) {
        vec3 d = uLightPos[i] - P;
        float dist2 = max(dot(d, d), 0.01);
        float distanceToLight = sqrt(dist2);
        float range = uLightRadius[i] > 0.0 ? clamp(1.0 - pow(distanceToLight / uLightRadius[i], 4.0), 0.0, 1.0) : 1.0;
        range *= range;
        Lo += brdf(N, V, d * inversesqrt(dist2), uLightRadiance[i] * (range / dist2), albedo, rough, metal, F0);
    }

    // Energy-aware hemispherical ambient approximation. This is not IBL: the
    // environment cubemap convolution and BRDF LUT pipeline is a later milestone.
    float up = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 hemi = mix(vec3(0.045, 0.042, 0.040), vec3(0.19, 0.25, 0.36), up);
    vec3 Fambient = F0 + (max(vec3(1.0 - rough), F0) - F0) * pow(1.0 - max(dot(N, V), 0.0), 5.0);
    vec3 kAmbientDiffuse = (1.0 - Fambient) * (1.0 - metal);
    vec3 ambientDiffuse = hemi * albedo * kAmbientDiffuse;
    // Restrained roughness-aware specular fill prevents metals becoming black
    // without pretending that an environment map is present.
    vec3 ambientSpecular = hemi * Fambient * (0.10 + 0.12 * (1.0 - rough));
    float ao = ambientOcclusion(P, N);
    vec3 ambient = ambientDiffuse * ao + ambientSpecular;
    vec3 reflected = screenReflection(P, N, V, rough);
    vec3 color = Lo + ambient + reflected;
    if (uFogEnabled != 0) {
        float distanceToCamera = length(P-uCamPos);
        float fog = 1.0-exp(-max(uFogDensity,0.0)*distanceToCamera);
        color = mix(color,uFogColor,clamp(fog,0.0,0.92));
    }
    oColor = vec4(color, 1.0);
}
