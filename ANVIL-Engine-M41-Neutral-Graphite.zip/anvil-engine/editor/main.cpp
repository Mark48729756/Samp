// ANVIL Editor - Milestone 2
// Unity-style docking editor: Hierarchy / Viewport / Inspector / Project / Console / Render Settings,
// SVG icons (rasterized with nanosvg), move/rotate/scale gizmos, click-picking, Play mode with scene snapshot/restore.
#include <glad/gl.h>
#include <GLFW/glfw3.h>
#include <anvil/Application.h>
#include <anvil/Core.h>
#include <anvil/Scene.h>
#include <anvil/Texture2D.h>
#include <anvil/AssetDatabase.h>
#include <anvil/UI.h>
#include "Icons.h"

#include <imgui.h>
#include <imgui_internal.h>
#include <backends/imgui_impl_glfw.h>
#include <backends/imgui_impl_opengl3.h>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <cstring>
#include <string>
#include <vector>

using namespace anvil;
namespace fs = std::filesystem;

static std::vector<std::string> gConsole;
static void consoleSink(const char* s) {
    gConsole.emplace_back(s);
    if (gConsole.size() > 2000) gConsole.erase(gConsole.begin(), gConsole.begin() + 500);
}

static ImVec4 hex(unsigned rgb, float a = 1.0f) {
    return ImVec4(((rgb >> 16) & 255) / 255.0f, ((rgb >> 8) & 255) / 255.0f, (rgb & 255) / 255.0f, a);
}
static ImTextureID texId(unsigned t) { return (ImTextureID)(intptr_t)t; }

static void applyTheme() {
    ImGuiStyle& s = ImGui::GetStyle();

    // Neutral graphite editor theme inspired by professional DCC/game editors.
    // Keep the interface low-contrast; reserve color for semantic status only.
    s.WindowRounding = 0.0f;
    s.ChildRounding = 2.0f;
    s.FrameRounding = 2.0f;
    s.PopupRounding = 2.0f;
    s.GrabRounding = 2.0f;
    s.TabRounding = 2.0f;
    s.ScrollbarRounding = 4.0f;

    s.WindowPadding = ImVec2(8.0f, 8.0f);
    s.FramePadding = ImVec2(6.0f, 4.0f);
    s.ItemSpacing = ImVec2(8.0f, 5.0f);
    s.WindowBorderSize = 1.0f;
    s.ChildBorderSize = 1.0f;
    s.FrameBorderSize = 0.0f;
    s.PopupBorderSize = 1.0f;
    s.TabBarBorderSize = 1.0f;
    s.IndentSpacing = 14.0f;
    s.ScrollbarSize = 12.0f;
    s.SeparatorTextBorderSize = 1.0f;

    ImVec4* c = s.Colors;
    c[ImGuiCol_Text]                  = hex(0xD0D0D0);
    c[ImGuiCol_TextDisabled]          = hex(0x858585);
    c[ImGuiCol_WindowBg]              = hex(0x242424);
    c[ImGuiCol_ChildBg]               = hex(0x202020);
    c[ImGuiCol_PopupBg]               = hex(0x292929, 0.98f);
    c[ImGuiCol_Border]                = hex(0x3A3A3A);
    c[ImGuiCol_BorderShadow]          = hex(0x000000, 0.0f);

    c[ImGuiCol_FrameBg]               = hex(0x343434);
    c[ImGuiCol_FrameBgHovered]        = hex(0x414141);
    c[ImGuiCol_FrameBgActive]         = hex(0x494949);
    c[ImGuiCol_TitleBg]               = hex(0x1D1D1D);
    c[ImGuiCol_TitleBgActive]         = hex(0x292929);
    c[ImGuiCol_TitleBgCollapsed]      = hex(0x1D1D1D);
    c[ImGuiCol_MenuBarBg]             = hex(0x292929);

    c[ImGuiCol_ScrollbarBg]           = hex(0x1D1D1D);
    c[ImGuiCol_ScrollbarGrab]         = hex(0x484848);
    c[ImGuiCol_ScrollbarGrabHovered]  = hex(0x5A5A5A);
    c[ImGuiCol_ScrollbarGrabActive]   = hex(0x686868);

    c[ImGuiCol_CheckMark]             = hex(0xC0C0C0);
    c[ImGuiCol_SliderGrab]            = hex(0x929292);
    c[ImGuiCol_SliderGrabActive]      = hex(0xB0B0B0);
    c[ImGuiCol_Button]                = hex(0x383838);
    c[ImGuiCol_ButtonHovered]         = hex(0x484848);
    c[ImGuiCol_ButtonActive]          = hex(0x555555);

    c[ImGuiCol_Header]                = hex(0x414141);
    c[ImGuiCol_HeaderHovered]         = hex(0x4B4B4B);
    c[ImGuiCol_HeaderActive]          = hex(0x555555);
    c[ImGuiCol_Separator]             = hex(0x3A3A3A);
    c[ImGuiCol_SeparatorHovered]      = hex(0x666666);
    c[ImGuiCol_SeparatorActive]       = hex(0x777777);

    c[ImGuiCol_ResizeGrip]            = hex(0x555555, 0.25f);
    c[ImGuiCol_ResizeGripHovered]     = hex(0x777777, 0.65f);
    c[ImGuiCol_ResizeGripActive]      = hex(0x999999, 0.85f);

    c[ImGuiCol_Tab]                   = hex(0x292929);
    c[ImGuiCol_TabHovered]            = hex(0x484848);
    c[ImGuiCol_TabSelected]           = hex(0x3A3A3A);
    c[ImGuiCol_TabSelectedOverline]   = hex(0xA0A0A0);
    c[ImGuiCol_TabDimmed]             = hex(0x222222);
    c[ImGuiCol_TabDimmedSelected]     = hex(0x303030);
    c[ImGuiCol_DockingPreview]        = hex(0xA0A0A0, 0.22f);
    c[ImGuiCol_DockingEmptyBg]        = hex(0x181818);

    c[ImGuiCol_NavCursor]             = hex(0xA0A0A0, 0.65f);
    c[ImGuiCol_NavWindowingHighlight] = hex(0xD0D0D0, 0.65f);
    c[ImGuiCol_NavWindowingDimBg]     = hex(0x000000, 0.35f);
    c[ImGuiCol_ModalWindowDimBg]      = hex(0x000000, 0.55f);
}

class Editor : public Application {
public:
    Editor() : Application(1600, 900, "ANVIL Editor") {}
    ~Editor() override {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplGlfw_Shutdown();
        ImGui::DestroyContext();
        icons::shutdown();
        logSink() = nullptr;
    }

protected:
    // ------------------------------------------------------------------ lifecycle
    void onInit() override {
        logSink() = consoleSink;
        icons::init();
        renderer_ = std::make_unique<Renderer>(1280, 720);
        renderer_->presentToScreen = false;
        buildDefaultScene();
        buildDefaultUIDocument();
        scene_.initGpuResources(ANVIL_ROOT_DIR);
        assetDb_.scan(ANVIL_ROOT_DIR);
        cam_.position = {0.0f, 4.5f, 16.0f};
        cam_.pitch = -12.0f;

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard | ImGuiConfigFlags_DockingEnable;
        io.IniFilename = "anvil_editor.ini";
        ImGui_ImplGlfw_InitForOpenGL(window_.native(), true);
        ImGui_ImplOpenGL3_Init("#version 450");
        applyTheme();
        ImGui::GetStyle().FontSizeBase = 15.0f;

        if (const char* n = std::getenv("ANVIL_SELECT")) for (Entity& e : scene_.entities) if (e.name == n) selected_ = e.id;   // test hook
        float az, el;
        sunToAngles(az, el);
        sunAz_ = az; sunEl_ = el;
        ANVIL_LOG("ANVIL Editor ready. RMB + WASD to fly, LMB to select, drag gizmo axes to transform.");
    }

    void onUpdate(float dt) override {
        frameMs_ = frameMs_ * 0.95f + dt * 1000.0f * 0.05f;
        if (playing_ && !paused_) {
            playTime_ += dt;
            scene_.updateOrbits(playTime_);
            scene_.stepPhysics(dt);
        }
        ImGuiIO& io = ImGui::GetIO();
        if (!io.WantTextInput) {
            if (ImGui::IsKeyPressed(ImGuiKey_W)) gizmoMode_ = 0;
            if (ImGui::IsKeyPressed(ImGuiKey_E)) gizmoMode_ = 1;
            if (ImGui::IsKeyPressed(ImGuiKey_R)) gizmoMode_ = 2;
            if (selected_ && ImGui::IsKeyPressed(ImGuiKey_Delete)) deleteSelected();
            if (selected_ && io.KeyCtrl && ImGui::IsKeyPressed(ImGuiKey_D)) selected_ = scene_.duplicate(selected_).id;
            if (selected_ && ImGui::IsKeyPressed(ImGuiKey_F)) focusSelected();
        }
        ++frameNo_;
        if (const char* a = std::getenv("ANVIL_AUTOEXIT")) { if (frameNo_ > std::atoi(a) * 10) window_.close(); }
    }

    void onRender() override {
        // keep the render target the size of the Viewport panel (UI built last frame decided it)
        int vw = std::max(16, (int)vpSize_.x), vh = std::max(16, (int)vpSize_.y);
        if (vw != renderer_->width() || vh != renderer_->height()) renderer_->resize(vw, vh);

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        drawUI();
        ImGui::Render();

        scene_.collect(items_, lights_);
        renderer_->render(cam_, items_, lights_, scene_.sun);

        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glViewport(0, 0, window_.width(), window_.height());
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        if (const char* shot = std::getenv("ANVIL_SHOT")) {
            if (frameNo_ == 20) {
                int w = window_.width(), h = window_.height();
                std::vector<unsigned char> px((size_t)w * h * 3);
                glPixelStorei(GL_PACK_ALIGNMENT, 1);
                glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, px.data());
                if (FILE* f = std::fopen(shot, "wb")) {
                    std::fprintf(f, "P6\n%d %d\n255\n", w, h);
                    for (int y = h - 1; y >= 0; --y) std::fwrite(&px[(size_t)y * w * 3], 1, (size_t)w * 3, f);
                    std::fclose(f);
                }
                window_.close();
            }
        }
    }

private:
    // ------------------------------------------------------------------ scene setup
    void buildDefaultScene() {
        Entity& ground = scene_.add("Ground");
        ground.primitive = Primitive::Plane;
        ground.material = {{0.55f, 0.55f, 0.58f}, 0.8f, 0.0f};
        ground.physics.enabled = true; ground.physics.motion = physics::MotionType::Static;

        for (int i = 0; i < 7; ++i) {
            Entity& s = scene_.add("Sphere " + std::to_string(i + 1));
            s.primitive = Primitive::Sphere;
            s.position = {(i - 3) * 2.4f, 1.0f, 0.0f};
            s.material = {i % 2 ? glm::vec3(0.95f, 0.64f, 0.54f) : glm::vec3(0.8f, 0.1f, 0.1f), 0.05f + 0.15f * i, i < 4 ? 0.0f : 1.0f};
            s.position.y = 1.0f + 2.5f * (i % 3);                         // drop from different heights when Play is pressed
            s.physics.enabled = true; s.physics.restitution = 0.35f; s.physics.friction = 0.5f;
        }
        Entity& cube = scene_.add("Cube");
        cube.primitive = Primitive::Cube;
        cube.position = {0.0f, 1.0f, -5.0f};
        cube.scale = {1.5f, 1.5f, 1.5f};
        cube.material = {{0.2f, 0.45f, 0.8f}, 0.35f, 0.0f};
        cube.physics.enabled = true; cube.physics.mass = 8.0f;
        for (int i = 0; i < 6; ++i) {   // tumbling crates: proves full 3D rotation
            Entity& crate = scene_.add("Crate " + std::to_string(i + 1));
            crate.primitive = Primitive::Cube;
            crate.scale = glm::vec3(0.5f);
            crate.position = {-3.0f + (i % 3) * 0.9f, 6.0f + (i / 3) * 1.4f, -2.0f + 0.35f * (i % 2)};
            crate.rotation = {20.0f * i, 35.0f * i, 10.0f * i};
            crate.material = {{0.75f, 0.55f, 0.3f}, 0.7f, 0.0f};
            crate.physics.enabled = true; crate.physics.friction = 0.7f;
        }

        const glm::vec3 cols[3] = {{1.0f, 0.4f, 0.3f}, {0.3f, 1.0f, 0.5f}, {0.4f, 0.5f, 1.0f}};
        for (int i = 0; i < 3; ++i) {
            Entity& l = scene_.add("Point Light " + std::to_string(i + 1));
            l.isLight = true;
            l.lightColor = cols[i];
            l.lightIntensity = 120.0f;
            l.orbit = true;
            l.orbitCenter = {0.0f, 3.5f + i * 1.5f, 3.0f};
            l.orbitRadius = 9.0f;
            l.orbitPhase = i * 2.094f;
            l.position = l.orbitCenter + glm::vec3(std::cos(l.orbitPhase) * l.orbitRadius, 0.0f, std::sin(l.orbitPhase) * l.orbitRadius * 0.5f);
        }
    }

    Entity& createEntity(Primitive p, const char* name, bool light = false) {
        Entity& e = scene_.add(name);
        e.primitive = p;
        e.isLight = light;
        e.position = cam_.position + cam_.forward() * 6.0f;
        if (p == Primitive::Plane) e.scale = {0.1f, 1.0f, 0.1f};
        selected_ = e.id;
        ANVIL_LOG("Created %s", name);
        return e;
    }

    void deleteSelected() {
        if (Entity* e = scene_.find(selected_)) ANVIL_LOG("Deleted %s", e->name.c_str());
        scene_.remove(selected_);
        selected_ = 0;
    }

    void focusSelected() {
        if (Entity* e = scene_.find(selected_)) {
            const glm::mat4 world = scene_.worldModel(e->id);
            const glm::vec3 center(world[3]);
            const glm::vec3 scale(glm::length(glm::vec3(world[0])), glm::length(glm::vec3(world[1])), glm::length(glm::vec3(world[2])));
            float r = std::max(2.0f, glm::length(scale) * 2.0f);
            cam_.position = center - cam_.forward() * r * 2.0f;
        }
    }

    void sunToAngles(float& az, float& el) const {
        glm::vec3 d = -glm::normalize(scene_.sun.direction);
        el = glm::degrees(std::asin(glm::clamp(d.y, -1.0f, 1.0f)));
        az = glm::degrees(std::atan2(d.z, d.x));
    }
    void anglesToSun() {
        float az = glm::radians(sunAz_), el = glm::radians(sunEl_);
        scene_.sun.direction = -glm::vec3(std::cos(el) * std::cos(az), std::sin(el), std::cos(el) * std::sin(az));
    }

    // ------------------------------------------------------------------ small ui helpers
    void icon(Icon i, float size = 16.0f, ImVec4 tint = ImVec4(0.82f, 0.82f, 0.82f, 1.0f)) {
        ImGui::ImageWithBg(texId(icons::texture(i)), ImVec2(size, size), ImVec2(0, 0), ImVec2(1, 1), ImVec4(0, 0, 0, 0), tint);
    }
    bool iconButton(const char* id, Icon i, bool active, const char* tip, ImVec4 tint = ImVec4(0.85f, 0.85f, 0.85f, 1.0f)) {
        ImGui::PushStyleColor(ImGuiCol_Button, active ? hex(0x555555) : hex(0x000000, 0.0f));
        bool hit = ImGui::ImageButton(id, texId(icons::texture(i)), ImVec2(16, 16), ImVec2(0, 0), ImVec2(1, 1), ImVec4(0, 0, 0, 0), tint);
        ImGui::PopStyleColor();
        if (tip && ImGui::IsItemHovered()) ImGui::SetTooltip("%s", tip);
        return hit;
    }
    static Icon iconFor(const Entity& e) {
        if (e.isLight) return Icon::Light;
        switch (e.primitive) {
            case Primitive::Sphere: return Icon::Sphere;
            case Primitive::Cube:   return Icon::Cube;
            case Primitive::Plane:  return Icon::Plane;
            default:                return Icon::Hierarchy;
        }
    }
    void panelTitle(Icon i, const char* label) {
        icon(i, 14.0f, hex(0x9AA0A6)); ImGui::SameLine(0, 6); ImGui::TextDisabled("%s", label);
        ImGui::Separator();
    }

    // ------------------------------------------------------------------ ui
    void drawUI() {
        ImGuiViewport* vp = ImGui::GetMainViewport();
        drawMenuBar();
        drawToolbar(vp);
        drawStatusBar(vp);

        ImGuiID dock = ImGui::GetID("AnvilDock");
        ImGui::DockSpaceOverViewport(dock, vp);
        if (!layoutBuilt_) { layoutBuilt_ = true; if (!ImGui::DockBuilderGetNode(dock) || ImGui::DockBuilderGetNode(dock)->IsLeafNode()) buildLayout(dock, vp); }

        drawHierarchy();
        drawViewport();
        drawInspector();
        drawRenderSettings();
        drawProject();
        drawConsole();
        drawCodeEditor();
        drawUIDesigner();
    }

    void buildLayout(ImGuiID dock, ImGuiViewport* vp) {
        ImGui::DockBuilderRemoveNode(dock);
        ImGui::DockBuilderAddNode(dock, ImGuiDockNodeFlags_DockSpace);
        ImGui::DockBuilderSetNodeSize(dock, vp->WorkSize);
        ImGuiID center = dock, left, right, bottom;
        left = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 0.17f, nullptr, &center);
        right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 0.22f, nullptr, &center);
        bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, 0.26f, nullptr, &center);
        ImGui::DockBuilderDockWindow("Hierarchy", left);
        ImGui::DockBuilderDockWindow("Viewport", center);
        ImGui::DockBuilderDockWindow("Inspector", right);
        ImGui::DockBuilderDockWindow("UI Inspector", right);
        ImGui::DockBuilderDockWindow("Render Settings", right);
        ImGui::DockBuilderDockWindow("Project", bottom);
        ImGui::DockBuilderDockWindow("Console", bottom);
        ImGui::DockBuilderDockWindow("Code Editor", bottom);
        ImGui::DockBuilderDockWindow("UI Designer", bottom);
        ImGui::DockBuilderFinish(dock);
    }

    void drawMenuBar() {
        if (ImGui::BeginMainMenuBar()) {
            icon(Icon::Anvil, 18.0f, hex(0xC8C8C8));
            ImGui::SameLine(0, 6);
            ImGui::TextColored(hex(0xD0D0D0), "ANVIL");
            ImGui::SameLine(0, 14);
            if (ImGui::BeginMenu("File")) {
                if (ImGui::MenuItem("New Scene")) { scene_.stopPhysics(); scene_.entities.clear(); selected_ = 0; ANVIL_LOG("New scene"); }
                if (ImGui::MenuItem("Reset Demo Scene")) { scene_.stopPhysics(); scene_.entities.clear(); selected_ = 0; buildDefaultScene(); }
                ImGui::Separator();
                if (ImGui::MenuItem("Exit", "Alt+F4")) window_.close();
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Edit")) {
                if (ImGui::MenuItem("Duplicate", "Ctrl+D", false, selected_ != 0)) selected_ = scene_.duplicate(selected_).id;
                if (ImGui::MenuItem("Delete", "Del", false, selected_ != 0)) deleteSelected();
                if (ImGui::MenuItem("Focus Selected", "F", false, selected_ != 0)) focusSelected();
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("GameObject")) { createMenuItems(); ImGui::EndMenu(); }
            if (ImGui::BeginMenu("Window")) {
                if (ImGui::MenuItem("Reset Layout")) layoutBuilt_ = false, forceLayout_ = true;
                ImGui::EndMenu();
            }
            ImGui::EndMainMenuBar();
        }
        if (forceLayout_) { forceLayout_ = false; buildLayout(ImGui::GetID("AnvilDock"), ImGui::GetMainViewport()); layoutBuilt_ = true; }
    }

    void createMenuItems() {
        if (ImGui::MenuItem("Cube"))        createEntity(Primitive::Cube, "Cube");
        if (ImGui::MenuItem("Sphere"))      createEntity(Primitive::Sphere, "Sphere");
        if (ImGui::MenuItem("Plane"))       createEntity(Primitive::Plane, "Plane");
        if (ImGui::MenuItem("Point Light")) createEntity(Primitive::None, "Point Light", true);
        if (ImGui::MenuItem("Empty"))       createEntity(Primitive::None, "Empty");
    }

    void drawToolbar(ImGuiViewport* vp) {
        ImGuiWindowFlags f = ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking;
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8, 4));
        ImGui::PushStyleColor(ImGuiCol_WindowBg, hex(0x1F1F1F));
        if (ImGui::BeginViewportSideBar("##toolbar", vp, ImGuiDir_Up, 34.0f, f)) {
            // Transform tools
            if (iconButton("##move", Icon::Move, gizmoMode_ == 0, "Move (W)")) gizmoMode_ = 0;
            ImGui::SameLine();
            if (iconButton("##rot", Icon::Rotate, gizmoMode_ == 1, "Rotate (E)")) gizmoMode_ = 1;
            ImGui::SameLine();
            if (iconButton("##scl", Icon::Scale, gizmoMode_ == 2, "Scale (R)")) gizmoMode_ = 2;

            // centered play controls
            float w = 3 * 30.0f;
            ImGui::SameLine(vp->WorkSize.x * 0.5f - w * 0.5f);
            if (iconButton("##play", playing_ ? Icon::Stop : Icon::Play, playing_, playing_ ? "Stop (restores the scene)" : "Play", playing_ ? hex(0xFF8A80) : hex(0x8FE388))) togglePlay();
            ImGui::SameLine();
            if (iconButton("##pause", Icon::Pause, paused_ && playing_, "Pause") && playing_) paused_ = !paused_;
            ImGui::SameLine();
            if (iconButton("##step", Icon::Step, false, "Step one frame") && playing_) { playTime_ += 1.0f / 60.0f; scene_.updateOrbits(playTime_); scene_.stepPhysics(1.0f / 60.0f); }
        }
        ImGui::End();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
    }

    void togglePlay() {
        if (!playing_) {
            snapshot_ = scene_.entities;
            playing_ = true; paused_ = false; playTime_ = 0.0f;
            scene_.startPhysics();   // builds one backend body per Rigidbody (Jolt when compiled in)
            ANVIL_LOG("Play mode: scene snapshot saved, physics: %s (%zu bodies)", scene_.physicsBackendName(), scene_.physicsBodyCount());
        } else {
            scene_.stopPhysics();    // bodies must go before the snapshot replaces the entities
            scene_.entities = snapshot_;
            playing_ = false; paused_ = false;
            ANVIL_LOG("Stopped: scene restored");
        }
    }

    void drawStatusBar(ImGuiViewport* vp) {
        ImGuiWindowFlags f = ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_MenuBar;
        ImGui::PushStyleColor(ImGuiCol_MenuBarBg, hex(0x1F1F1F));
        if (ImGui::BeginViewportSideBar("##status", vp, ImGuiDir_Down, ImGui::GetFrameHeight(), f)) {
            if (ImGui::BeginMenuBar()) {
                const std::string& last = gConsole.empty() ? std::string("Ready") : gConsole.back();
                ImGui::TextDisabled("%s", last.c_str());
                char buf[96];
                std::snprintf(buf, sizeof buf, "%.1f ms  |  %d x %d  |  %s", frameMs_, renderer_->width(), renderer_->height(), playing_ ? (paused_ ? "PAUSED" : "PLAYING") : "EDIT");
                ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::CalcTextSize(buf).x - 14);
                ImGui::TextDisabled("%s", buf);
                ImGui::EndMenuBar();
            }
        }
        ImGui::End();
        ImGui::PopStyleColor();
    }

    // ------------------------------------------------------------------ hierarchy
    void drawHierarchyNode(uint32_t id) {
        Entity* e = scene_.find(id);
        if (!e) return;
        const auto children = scene_.childrenOf(id);
        ImGui::PushID(static_cast<int>(id));
        const bool leaf = children.empty();
        ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_SpanAvailWidth | ImGuiTreeNodeFlags_OpenOnArrow;
        if (leaf) flags |= ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen;
        if (selected_ == id) flags |= ImGuiTreeNodeFlags_Selected;
        const bool open = ImGui::TreeNodeEx("node", flags, "%s", e->name.c_str());
        if (ImGui::IsItemClicked()) selected_ = id;
        if (ImGui::BeginDragDropSource()) {
            ImGui::SetDragDropPayload("ANVIL_ENTITY", &id, sizeof(id));
            ImGui::TextUnformatted(e->name.c_str());
            ImGui::EndDragDropSource();
        }
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("ANVIL_ENTITY")) {
                const uint32_t dragged = *static_cast<const uint32_t*>(payload->Data);
                if (scene_.setParent(dragged, id)) ANVIL_LOG("Reparented entity %u under %u", dragged, id);
            }
            ImGui::EndDragDropTarget();
        }
        if (ImGui::BeginPopupContextItem()) {
            selected_ = id;
            if (ImGui::MenuItem("Duplicate", "Ctrl+D")) selected_ = scene_.duplicate(id).id;
            if (ImGui::MenuItem("Unparent", nullptr, false, e->parentId != 0)) scene_.setParent(id, 0);
            if (ImGui::MenuItem("Focus", "F")) focusSelected();
            if (ImGui::MenuItem("Delete", "Del")) deleteSelected();
            ImGui::EndPopup();
        }
        if (open && !leaf) {
            for (uint32_t child : children) drawHierarchyNode(child);
            ImGui::TreePop();
        }
        ImGui::PopID();
    }

    void drawHierarchy() {
        ImGui::Begin("Hierarchy");
        if (ImGui::Button("+ Create")) ImGui::OpenPopup("create");
        if (ImGui::BeginPopup("create")) { createMenuItems(); ImGui::EndPopup(); }
        ImGui::Separator();
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("ANVIL_ENTITY")) {
                scene_.setParent(*static_cast<const uint32_t*>(payload->Data), 0);
            }
            ImGui::EndDragDropTarget();
        }
        icon(Icon::Folder, 14.0f, hex(0xE8C56A)); ImGui::SameLine(0, 6);
        ImGui::TextUnformatted(playing_ ? "Demo Scene (playing)" : "Demo Scene");
        ImGui::Indent();
        const auto roots = scene_.childrenOf(0);
        for (uint32_t id : roots) drawHierarchyNode(id);
        ImGui::Unindent();
        ImGui::End();
    }

    // ------------------------------------------------------------------ inspector
    bool vec3Row(const char* label, glm::vec3& v, float speed, float reset) {
        bool changed = false;
        ImGui::PushID(label);
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(label);
        ImGui::SameLine(84);
        ImGui::SetNextItemWidth(-30);
        changed |= ImGui::DragFloat3("##v", &v.x, speed, 0.0f, 0.0f, "%.2f");
        ImGui::SameLine();
        if (ImGui::SmallButton("R")) { v = glm::vec3(reset); changed = true; }
        ImGui::PopID();
        return changed;
    }

    void drawInspector() {
        ImGui::Begin("Inspector");
        Entity* e = scene_.find(selected_);
        if (!e) { ImGui::TextDisabled("Nothing selected."); ImGui::TextDisabled("Click an object in the Viewport or Hierarchy."); ImGui::End(); return; }

        icon(iconFor(*e), 18.0f, e->isLight ? hex(0xF2D16B) : hex(0x8CB4E0));
        ImGui::SameLine();
        ImGui::Checkbox("##active", &e->active);
        ImGui::SameLine();
        char name[128];
        std::snprintf(name, sizeof name, "%s", e->name.c_str());
        ImGui::SetNextItemWidth(-1);
        if (ImGui::InputText("##name", name, sizeof name)) e->name = name;

        ImGui::SeparatorText("Hierarchy");
        ImGui::TextDisabled("Parent");
        ImGui::SameLine(84);
        ImGui::SetNextItemWidth(-1);
        const char* parentLabel = "<Scene Root>";
        if (Entity* parent = scene_.find(e->parentId)) parentLabel = parent->name.c_str();
        if (ImGui::BeginCombo("##parent", parentLabel)) {
            if (ImGui::Selectable("<Scene Root>", e->parentId == 0)) scene_.setParent(e->id, 0);
            for (const Entity& candidate : scene_.entities) {
                if (candidate.id == e->id) continue;
                ImGui::PushID(static_cast<int>(candidate.id));
                if (ImGui::Selectable(candidate.name.c_str(), e->parentId == candidate.id)) scene_.setParent(e->id, candidate.id);
                ImGui::PopID();
            }
            ImGui::EndCombo();
        }
        ImGui::SeparatorText("Transform (Local)");
        vec3Row("Position", e->position, 0.05f, 0.0f);
        vec3Row("Rotation", e->rotation, 0.5f, 0.0f);
        vec3Row("Scale", e->scale, 0.02f, 1.0f);

        if (e->primitive != Primitive::None) {
            ImGui::SeparatorText("Mesh Renderer");
            static const char* kPrims[] = {"None", "Sphere", "Cube", "Plane", "OBJ Model"};
            int p = (int)e->primitive;
            ImGui::SetNextItemWidth(-1);
            if (ImGui::Combo("##mesh", &p, kPrims, 5)) e->primitive = (Primitive)p;
            if (e->primitive == Primitive::Model) {
                char modelPath[512]; std::snprintf(modelPath, sizeof modelPath, "%s", e->modelPath.c_str());
                if (ImGui::InputText("OBJ Path", modelPath, sizeof modelPath)) { e->modelPath=modelPath; std::string err; std::filesystem::path resolved(modelPath); if(resolved.is_relative()) resolved=std::filesystem::path(ANVIL_ROOT_DIR)/resolved; auto loaded=Mesh::loadObj(resolved,&err); e->modelMesh=std::shared_ptr<Mesh>(loaded.release()); if(!e->modelMesh && *modelPath) ANVIL_LOG("OBJ: %s",err.c_str()); }
            }
            ImGui::ColorEdit3("Albedo", &e->material.albedo.x, ImGuiColorEditFlags_Float);
            ImGui::SliderFloat("Roughness", &e->material.roughness, 0.04f, 1.0f);
            ImGui::SliderFloat("Metallic", &e->material.metallic, 0.0f, 1.0f);
            char texturePath[512]; std::snprintf(texturePath, sizeof texturePath, "%s", e->material.albedoTexturePath.c_str());
            if (ImGui::InputText("Albedo Texture (PPM)", texturePath, sizeof texturePath)) {
                e->material.albedoTexturePath = texturePath; e->material.albedoTexture.reset();
                if (*texturePath) { std::filesystem::path p(texturePath); if (p.is_relative()) p = std::filesystem::path(ANVIL_ROOT_DIR) / p;
                    e->material.albedoTexture = Texture2D::load(p, true); }
            }
        }
        if (e->isLight) {
            ImGui::SeparatorText("Point Light");
            ImGui::ColorEdit3("Color", &e->lightColor.x, ImGuiColorEditFlags_Float);
            ImGui::DragFloat("Intensity", &e->lightIntensity, 1.0f, 0.0f, 5000.0f, "%.0f");
        }
        if (e->orbit) {
            ImGui::SeparatorText("Orbit (demo script)");
            vec3Row("Center", e->orbitCenter, 0.05f, 0.0f);
            ImGui::DragFloat("Radius", &e->orbitRadius, 0.05f, 0.0f, 100.0f);
            ImGui::DragFloat("Speed", &e->orbitSpeed, 0.01f, -5.0f, 5.0f);
            ImGui::TextDisabled("Runs only in Play mode.");
        }

        if (e->physics.enabled) {
            auto& c = e->physics;
            ImGui::SeparatorText("Rigidbody");
            static const char* kMotion[] = {"Static", "Kinematic", "Dynamic"};
            static const char* kShape[] = {"Box", "Sphere", "Capsule"};
            int motion = (int)c.motion;
            if (ImGui::Combo("Motion", &motion, kMotion, 3)) c.motion = (physics::MotionType)motion;
            ImGui::Checkbox("Auto-fit collider to mesh", &c.autoFit);
            const bool fitted = c.autoFit && (e->primitive == Primitive::Sphere || e->primitive == Primitive::Cube || e->primitive == Primitive::Plane);
            if (!fitted) {
                int shape = (int)c.shape;
                if (ImGui::Combo("Collider", &shape, kShape, 3)) c.shape = (physics::ShapeType)shape;
                if (c.shape == physics::ShapeType::Box) vec3Row("Half Extents", c.halfExtents, 0.02f, 1.0f);
                else ImGui::DragFloat("Radius", &c.radius, 0.01f, 0.01f, 100.0f);
                if (c.shape == physics::ShapeType::Capsule) ImGui::DragFloat("Half Height", &c.halfHeight, 0.01f, 0.01f, 100.0f);
            }
            if (c.motion == physics::MotionType::Dynamic) {
                ImGui::DragFloat("Mass", &c.mass, 0.1f, 0.01f, 100000.0f);
                ImGui::DragFloat("Gravity Scale", &c.gravityScale, 0.02f, -5.0f, 5.0f);
                ImGui::DragFloat("Linear Damping", &c.linearDamping, 0.005f, 0.0f, 10.0f);
                ImGui::DragFloat("Angular Damping", &c.angularDamping, 0.005f, 0.0f, 10.0f);
                ImGui::Checkbox("Continuous collision (fast bodies)", &c.continuous);
            }
            ImGui::SliderFloat("Friction", &c.friction, 0.0f, 1.0f);
            ImGui::SliderFloat("Bounciness", &c.restitution, 0.0f, 1.0f);
            ImGui::Checkbox("Is Trigger", &c.isTrigger);
            ImGui::TextDisabled(playing_ ? "Collider/body changes apply on the next Play." : "Simulated while Play mode runs.");
            if (ImGui::Button("Remove Rigidbody")) c.enabled = false;
        }

        ImGui::Spacing();
        ImGui::Separator();
        if (ImGui::Button("Add Component", ImVec2(-1, 0))) ImGui::OpenPopup("addcomp");
        if (ImGui::BeginPopup("addcomp")) {
            if (ImGui::MenuItem("Mesh Renderer", nullptr, false, e->primitive == Primitive::None)) e->primitive = Primitive::Sphere;
            if (ImGui::MenuItem("OBJ Model", nullptr, false, e->primitive != Primitive::Model)) e->primitive = Primitive::Model;
            if (ImGui::MenuItem("Rigidbody", nullptr, false, !e->physics.enabled)) e->physics.enabled = true;
            if (ImGui::MenuItem("Point Light", nullptr, false, !e->isLight)) e->isLight = true;
            if (ImGui::MenuItem("Orbit (demo script)", nullptr, false, !e->orbit)) { e->orbit = true; e->orbitCenter = e->position; }
            ImGui::EndPopup();
        }
        ImGui::End();
    }

    // ------------------------------------------------------------------ render settings
    void drawRenderSettings() {
        ImGui::Begin("Render Settings");
        RenderSettings& r = renderer_->settings;
        ImGui::SeparatorText("Sun");
        bool sunChanged = false;
        sunChanged |= ImGui::SliderFloat("Azimuth", &sunAz_, -180.0f, 180.0f, "%.0f deg");
        sunChanged |= ImGui::SliderFloat("Elevation", &sunEl_, 2.0f, 90.0f, "%.0f deg");
        if (sunChanged) anglesToSun();
        ImGui::ColorEdit3("Sun Color", &scene_.sun.color.x, ImGuiColorEditFlags_Float);
        ImGui::SliderFloat("Sun Intensity", &scene_.sun.intensity, 0.0f, 10.0f);
        ImGui::SeparatorText("Shadows");
        ImGui::Checkbox("Sun shadows", &r.shadows);
        ImGui::SliderFloat("Distance", &r.shadowRadius, 5.0f, 120.0f, "%.0f m");
        ImGui::SliderFloat("Bias", &r.shadowBias, 0.0f, 0.01f, "%.4f");
        ImGui::SeparatorText("Post Processing");
        ImGui::Checkbox("Bloom", &r.bloom);
        ImGui::SliderFloat("Threshold", &r.bloomThreshold, 0.2f, 4.0f);
        ImGui::Checkbox("Camera Motion Blur", &r.motionBlur);
        ImGui::SliderFloat("Motion Blur Strength", &r.motionBlurStrength, 0.0f, 1.0f, "%.2f");
        ImGui::TextDisabled("Camera reprojection; object velocity is a later pass.");
        ImGui::SeparatorText("Ambient Occlusion");
        ImGui::Checkbox("SSAO", &r.ssao);
        ImGui::SliderFloat("AO Radius", &r.aoRadius, 0.1f, 3.0f, "%.2f m");
        ImGui::SliderFloat("AO Strength", &r.aoStrength, 0.0f, 3.0f, "%.2f");
        ImGui::SliderFloat("Strength", &r.bloomStrength, 0.0f, 0.5f);
        ImGui::SliderFloat("Exposure", &r.exposure, 0.1f, 4.0f);
        ImGui::SeparatorText("Stats");
        ImGui::Text("Frame: %.2f ms (%.0f FPS)", frameMs_, frameMs_ > 0 ? 1000.0f / frameMs_ : 0.0f);
        ImGui::Text("Objects: %d   Point lights: %d / %d", (int)items_.size(), (int)lights_.size(), Renderer::kMaxPointLights);
        ImGui::TextDisabled("%s", (const char*)glGetString(GL_RENDERER));
        ImGui::End();
    }

    // ------------------------------------------------------------------ project + console
    void drawProject() {
        ImGui::Begin("Project");
        if (projDir_.empty()) projDir_ = ANVIL_ROOT_DIR;
        const fs::path root = ANVIL_ROOT_DIR;
        if (ImGui::SmallButton("..") && projDir_ != root) projDir_ = fs::path(projDir_).parent_path().string();
        ImGui::SameLine();
        ImGui::TextDisabled("%s", fs::relative(projDir_, root.parent_path()).string().c_str());
        ImGui::SameLine();
        if (ImGui::SmallButton("Refresh Index")) { std::string err; if (!assetDb_.scan(root, &err)) ANVIL_LOG("Asset scan: %s", err.c_str()); }
        ImGui::TextDisabled("Asset index: %zu files", assetDb_.assets().size());
        ImGui::Separator();
        std::vector<fs::directory_entry> entries;
        std::error_code ec;
        for (const auto& de : fs::directory_iterator(projDir_, ec)) {
            std::string n = de.path().filename().string();
            if (n.empty() || n[0] == '.' || n == "build") continue;
            entries.push_back(de);
        }
        std::sort(entries.begin(), entries.end(), [](const auto& a, const auto& b) {
            if (a.is_directory() != b.is_directory()) return a.is_directory();
            return a.path().filename() < b.path().filename();
        });
        for (const auto& de : entries) {
            const bool dir = de.is_directory();
            icon(dir ? Icon::Folder : Icon::File, 14.0f, dir ? hex(0xE8C56A) : hex(0xA8B0BA));
            ImGui::SameLine(0, 6);
            if (!dir) { const auto type=AssetDatabase::classify(de.path()); const char* tag=type==AssetType::Texture?" [Texture]":type==AssetType::Model?" [Model]":type==AssetType::Scene?" [Scene]":type==AssetType::Shader?" [Shader]":type==AssetType::Material?" [Material]":""; ImGui::TextDisabled("%s", tag); ImGui::SameLine(0, 4); }
            if (ImGui::Selectable(de.path().filename().string().c_str(), false, ImGuiSelectableFlags_AllowDoubleClick) && dir && ImGui::IsMouseDoubleClicked(0))
                projDir_ = de.path().string();
        }
        ImGui::End();
    }

    bool resolveProjectCodePath(fs::path& out) const {
        const fs::path root = fs::weakly_canonical(fs::path(ANVIL_ROOT_DIR));
        const fs::path candidate = fs::weakly_canonical(root / fs::path(codePath_));
        const fs::path relative = candidate.lexically_relative(root);
        if (relative.empty() || relative.is_absolute() || *relative.begin() == "..") return false;
        out = candidate;
        return true;
    }

    void loadCodeFile() {
        fs::path path;
        if (!resolveProjectCodePath(path)) {
            ANVIL_LOG("Code Editor: path must stay inside the project.");
            return;
        }
        std::ifstream file(path, std::ios::binary);
        if (!file) {
            ANVIL_LOG("Code Editor: cannot open %s", codePath_);
            return;
        }
        std::string contents((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        if (contents.size() >= codeBuffer_.size()) {
            ANVIL_LOG("Code Editor: file exceeds the 512 KiB editor buffer.");
            return;
        }
        std::fill(codeBuffer_.begin(), codeBuffer_.end(), '\0');
        std::copy(contents.begin(), contents.end(), codeBuffer_.begin());
        codeDirty_ = false;
        ANVIL_LOG("Code Editor: loaded %s", codePath_);
    }

    void saveCodeFile() {
        fs::path path;
        if (!resolveProjectCodePath(path)) {
            ANVIL_LOG("Code Editor: path must stay inside the project.");
            return;
        }
        std::error_code ec;
        fs::create_directories(path.parent_path(), ec);
        if (ec) {
            ANVIL_LOG("Code Editor: cannot create parent directory: %s", ec.message().c_str());
            return;
        }
        std::ofstream file(path, std::ios::binary | std::ios::trunc);
        if (!file) {
            ANVIL_LOG("Code Editor: cannot write %s", codePath_);
            return;
        }
        file.write(codeBuffer_.data(), (std::streamsize)std::strlen(codeBuffer_.data()));
        if (!file) {
            ANVIL_LOG("Code Editor: write failed for %s", codePath_);
            return;
        }
        codeDirty_ = false;
        ANVIL_LOG("Code Editor: saved %s", codePath_);
    }

    void drawCodeEditor() {
        ImGui::Begin("Code Editor");
        ImGui::SetNextItemWidth(-150.0f);
        ImGui::InputText("Project file", codePath_, sizeof(codePath_));
        ImGui::SameLine();
        if (ImGui::Button("Open")) loadCodeFile();
        ImGui::SameLine();
        if (ImGui::Button("Save")) saveCodeFile();
        ImGui::SameLine();
        if (ImGui::Button("Clear")) {
            std::fill(codeBuffer_.begin(), codeBuffer_.end(), '\0');
            codeDirty_ = true;
        }
        ImGui::TextDisabled("%s", codeDirty_ ? "Modified (not saved)" : "Saved / clean");
        ImGui::Separator();
        if (ImGui::InputTextMultiline("##anvil_source", codeBuffer_.data(), codeBuffer_.size(),
                                      ImVec2(-1.0f, -1.0f), ImGuiInputTextFlags_AllowTabInput)) {
            codeDirty_ = true;
        }
        ImGui::End();
    }

    // ------------------------------------------------------------------ visual UI designer (M40)
    void buildDefaultUIDocument() {
        uiRoot_.name = "Canvas";
        uiRoot_.layout.mode = ui::LayoutMode::Absolute;
        uiRoot_.style.background = {0.075f, 0.085f, 0.105f, 1.0f};
        auto title = std::make_unique<ui::Widget>(ui::WidgetType::Label, "Title");
        title->text = "ANVIL GAME";
        title->layout.preferredSize = {360, 58};
        title->layout.offsets = {220, 72, 0, 0};
        title->style.foreground = {0.95f, 0.68f, 0.25f, 1.0f};
        uiRoot_.add(std::move(title));
        auto play = std::make_unique<ui::Widget>(ui::WidgetType::Button, "PlayButton");
        play->text = "PLAY";
        play->layout.preferredSize = {220, 56};
        play->layout.offsets = {290, 190, 0, 0};
        play->style.background = {0.16f, 0.36f, 0.62f, 1.0f};
        play->style.foreground = {1.0f, 1.0f, 1.0f, 1.0f};
        play->style.cornerRadius = 8.0f;
        uiRoot_.add(std::move(play));
        uiSelected_ = uiRoot_.children().back()->id();
        ui::LayoutEngine::arrange(uiRoot_, {{0, 0}, {800, 450}});
    }

    void drawUIDesignerNode(ui::Widget& widget) {
        const std::string label = widget.name.empty() ? "Widget" : widget.name;
        const bool leaf = widget.children().empty();
        ImGui::PushID(static_cast<int>(widget.id() & 0x7fffffff));
        if (leaf) {
            if (ImGui::Selectable(label.c_str(), uiSelected_ == widget.id())) uiSelected_ = widget.id();
        } else {
            ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_SpanAvailWidth;
            if (uiSelected_ == widget.id()) flags |= ImGuiTreeNodeFlags_Selected;
            const bool open = ImGui::TreeNodeEx(label.c_str(), flags);
            if (ImGui::IsItemClicked()) uiSelected_ = widget.id();
            if (open) { for (const auto& child : widget.children()) drawUIDesignerNode(*child); ImGui::TreePop(); }
        }
        ImGui::PopID();
    }

    void drawUIPreviewNode(ui::Widget& widget, ImDrawList* draw, ImVec2 origin, float scale, int depth) {
        if (!widget.visible) return;
        const ImVec2 p(origin.x + widget.bounds.position.x * scale, origin.y + widget.bounds.position.y * scale);
        const ImVec2 q(p.x + widget.bounds.size.x * scale, p.y + widget.bounds.size.y * scale);
        if (depth > 0) {
            const auto& c = widget.style.background;
            ImU32 bg = ImGui::ColorConvertFloat4ToU32(ImVec4(c.r, c.g, c.b, c.a * widget.style.opacity));
            const float radius = std::max(0.0f, widget.style.cornerRadius * scale);
            if (widget.type == ui::WidgetType::Button || c.a > 0.001f)
                draw->AddRectFilled(p, q, bg, radius);
            draw->AddRect(p, q, widget.id() == uiSelected_ ? IM_COL32(255, 190, 70, 255) : IM_COL32(90, 100, 115, 180), radius, 0, widget.id() == uiSelected_ ? 2.0f : 1.0f);
            if (!widget.text.empty()) {
                const auto& f = widget.style.foreground;
                draw->AddText(ImVec2(p.x + 8.0f * scale, p.y + 7.0f * scale), ImGui::ColorConvertFloat4ToU32(ImVec4(f.r, f.g, f.b, f.a)), widget.text.c_str());
            } else if (widget.type == ui::WidgetType::Label) {
                draw->AddText(ImVec2(p.x + 6, p.y + 6), IM_COL32(220, 220, 220, 255), widget.name.c_str());
            }
        }
        for (const auto& child : widget.children()) drawUIPreviewNode(*child, draw, origin, scale, depth + 1);
    }

    void drawUIDesigner() {
        ImGui::Begin("UI Designer");
        if (ImGui::Button("+ Panel")) addUIWidget(ui::WidgetType::Panel);
        ImGui::SameLine(); if (ImGui::Button("+ Button")) addUIWidget(ui::WidgetType::Button);
        ImGui::SameLine(); if (ImGui::Button("+ Label")) addUIWidget(ui::WidgetType::Label);
        ImGui::SameLine(); if (ImGui::Button("Delete") && uiSelected_ != uiRoot_.id()) {
            if (removeUIWidget(uiRoot_, uiSelected_)) uiSelected_ = uiRoot_.id();
        }
        ImGui::SameLine();
        if (ImGui::Button("Save UI")) {
            std::error_code ec; fs::create_directories(fs::path(ANVIL_ROOT_DIR) / "assets/ui", ec);
            std::string err;
            if (!ui::saveDocument(uiRoot_, (fs::path(ANVIL_ROOT_DIR) / "assets/ui/main.anvilui").string(), &err)) ANVIL_LOG("UI save failed: %s", err.c_str());
            else ANVIL_LOG("UI document saved: assets/ui/main.anvilui");
        }
        ImGui::SameLine();
        if (ImGui::Button("Load UI")) {
            std::string err; auto loaded = ui::loadDocument((fs::path(ANVIL_ROOT_DIR) / "assets/ui/main.anvilui").string(), &err);
            if (loaded) { uiRoot_ = std::move(*loaded); uiSelected_ = uiRoot_.id(); }
            else ANVIL_LOG("UI load failed: %s", err.c_str());
        }
        ImGui::Separator();
        const float leftWidth = std::max(150.0f, ImGui::GetContentRegionAvail().x * 0.22f);
        ImGui::BeginChild("ui_hierarchy", ImVec2(leftWidth, 0), true);
        ImGui::TextDisabled("WIDGET TREE");
        drawUIDesignerNode(uiRoot_);
        ImGui::EndChild();
        ImGui::SameLine();
        ImGui::BeginChild("ui_canvas_area", ImVec2(0, 0), true, ImGuiWindowFlags_NoScrollbar);
        ImGui::TextDisabled("PREVIEW · 800 × 450 · Drag widgets to position");
        ImVec2 avail = ImGui::GetContentRegionAvail();
        const float scale = std::max(0.05f, std::min(avail.x / 800.0f, std::max(1.0f, avail.y) / 450.0f));
        const ImVec2 canvasSize(800.0f * scale, 450.0f * scale);
        ImVec2 canvasPos = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton("ui_preview_surface", canvasSize, ImGuiButtonFlags_MouseButtonLeft);
        ImDrawList* draw = ImGui::GetWindowDrawList();
        const auto& rootBg = uiRoot_.style.background;
        draw->AddRectFilled(canvasPos, ImVec2(canvasPos.x + canvasSize.x, canvasPos.y + canvasSize.y), ImGui::ColorConvertFloat4ToU32(ImVec4(rootBg.r, rootBg.g, rootBg.b, rootBg.a)));
        ui::LayoutEngine::arrange(uiRoot_, {{0, 0}, {800, 450}});
        drawUIPreviewNode(uiRoot_, draw, canvasPos, scale, 0);
        const ImVec2 mouse = ImGui::GetIO().MousePos;
        const bool inCanvas = mouse.x >= canvasPos.x && mouse.y >= canvasPos.y && mouse.x < canvasPos.x + canvasSize.x && mouse.y < canvasPos.y + canvasSize.y;
        if (inCanvas && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            ui::Widget* hit = ui::hitTest(uiRoot_, {(mouse.x - canvasPos.x) / scale, (mouse.y - canvasPos.y) / scale});
            if (hit) uiSelected_ = hit->id();
            ui::Widget* selected = uiRoot_.find(uiSelected_);
            if (selected && selected != &uiRoot_) { uiDragActive_ = true; uiDragMouseStart_ = mouse; uiDragOffsetStart_ = {selected->layout.offsets.left, selected->layout.offsets.top}; }
        }
        if (uiDragActive_ && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
            if (ui::Widget* selected = uiRoot_.find(uiSelected_)) {
                selected->layout.offsets.left = uiDragOffsetStart_.x + (mouse.x - uiDragMouseStart_.x) / scale;
                selected->layout.offsets.top = uiDragOffsetStart_.y + (mouse.y - uiDragMouseStart_.y) / scale;
            }
        }
        if (ImGui::IsMouseReleased(ImGuiMouseButton_Left)) uiDragActive_ = false;
        ImGui::EndChild();
        ImGui::End();
        drawUIInspector();
    }

    void addUIWidget(ui::WidgetType type) {
        ui::Widget* parent = uiRoot_.find(uiSelected_);
        if (!parent || (parent->type != ui::WidgetType::Panel && parent != &uiRoot_)) parent = &uiRoot_;
        const char* kind = type == ui::WidgetType::Button ? "Button" : type == ui::WidgetType::Label ? "Label" : "Panel";
        auto item = std::make_unique<ui::Widget>(type, std::string(kind) + std::to_string(parent->children().size() + 1));
        item->text = type == ui::WidgetType::Button ? "Button" : type == ui::WidgetType::Label ? "Label" : "";
        item->layout.preferredSize = type == ui::WidgetType::Label ? ui::Vec2{180, 36} : ui::Vec2{180, 52};
        item->layout.offsets = {40.0f + 18.0f * static_cast<float>(parent->children().size()), 40.0f + 18.0f * static_cast<float>(parent->children().size()), 0, 0};
        if (type == ui::WidgetType::Button) item->style.background = {0.16f, 0.36f, 0.62f, 1.0f};
        uiSelected_ = parent->add(std::move(item)).id();
    }

    bool removeUIWidget(ui::Widget& parent, ui::WidgetId id) {
        if (parent.remove(id)) return true;
        for (const auto& child : parent.children()) if (removeUIWidget(*child, id)) return true;
        return false;
    }

    void drawUIInspector() {
        ImGui::Begin("UI Inspector");
        ui::Widget* w = uiRoot_.find(uiSelected_);
        if (!w) { ImGui::TextDisabled("Select a widget in the UI Designer."); ImGui::End(); return; }
        if (uiInspectorId_ != w->id()) {
            uiInspectorId_ = w->id();
            std::snprintf(uiNameBuffer_, sizeof(uiNameBuffer_), "%s", w->name.c_str());
            std::snprintf(uiTextBuffer_, sizeof(uiTextBuffer_), "%s", w->text.c_str());
        }
        if (ImGui::InputText("Name", uiNameBuffer_, sizeof(uiNameBuffer_))) w->name = uiNameBuffer_;
        if (ImGui::InputText("Text", uiTextBuffer_, sizeof(uiTextBuffer_))) w->text = uiTextBuffer_;
        ImGui::SeparatorText("Rect Transform");
        ImGui::DragFloat2("Position", &w->layout.offsets.left, 1.0f);
        ImGui::DragFloat2("Size", &w->layout.preferredSize.x, 1.0f, 1.0f, 4096.0f);
        ImGui::DragFloat4("Margins", &w->layout.margin.left, 1.0f);
        ImGui::SeparatorText("Appearance");
        float bg[4] = {w->style.background.r, w->style.background.g, w->style.background.b, w->style.background.a};
        if (ImGui::ColorEdit4("Background", bg)) w->style.background = {bg[0], bg[1], bg[2], bg[3]};
        float fg[4] = {w->style.foreground.r, w->style.foreground.g, w->style.foreground.b, w->style.foreground.a};
        if (ImGui::ColorEdit4("Foreground", fg)) w->style.foreground = {fg[0], fg[1], fg[2], fg[3]};
        ImGui::DragFloat("Corner Radius", &w->style.cornerRadius, 0.5f, 0.0f, 64.0f);
        ImGui::Checkbox("Visible", &w->visible);
        ImGui::Checkbox("Enabled", &w->enabled);
        ImGui::End();
    }

    void drawConsole() {
        ImGui::Begin("Console");
        if (ImGui::SmallButton("Clear")) gConsole.clear();
        ImGui::Separator();
        ImGui::BeginChild("log", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);
        for (const std::string& l : gConsole) ImGui::TextUnformatted(l.c_str());
        if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 4.0f) ImGui::SetScrollHereY(1.0f);
        ImGui::EndChild();
        ImGui::End();
    }

    // ------------------------------------------------------------------ viewport: camera, picking, gizmo
    bool project(const glm::mat4& vp, const glm::vec3& p, ImVec2& out) const {
        glm::vec4 c = vp * glm::vec4(p, 1.0f);
        if (c.w <= 0.001f) return false;
        glm::vec3 n = glm::vec3(c) / c.w;
        out = ImVec2(vpMin_.x + (n.x * 0.5f + 0.5f) * vpSize_.x, vpMin_.y + (1.0f - (n.y * 0.5f + 0.5f)) * vpSize_.y);
        return true;
    }

    static float distPointSegment(ImVec2 p, ImVec2 a, ImVec2 b) {
        float vx = b.x - a.x, vy = b.y - a.y, wx = p.x - a.x, wy = p.y - a.y;
        float len2 = vx * vx + vy * vy;
        float t = len2 > 0 ? glm::clamp((wx * vx + wy * vy) / len2, 0.0f, 1.0f) : 0.0f;
        float dx = a.x + vx * t - p.x, dy = a.y + vy * t - p.y;
        return std::sqrt(dx * dx + dy * dy);
    }

    void mouseRay(const glm::mat4& inv, ImVec2 mouse, glm::vec3& o, glm::vec3& d) const {
        float nx = (mouse.x - vpMin_.x) / vpSize_.x * 2.0f - 1.0f;
        float ny = 1.0f - (mouse.y - vpMin_.y) / vpSize_.y * 2.0f;
        glm::vec4 n = inv * glm::vec4(nx, ny, -1.0f, 1.0f), f = inv * glm::vec4(nx, ny, 1.0f, 1.0f);
        n /= n.w; f /= f.w;
        o = glm::vec3(n);
        d = glm::normalize(glm::vec3(f) - glm::vec3(n));
    }

    // returns hit distance along the (world) ray, or -1
    float rayHit(const Entity& e, const glm::vec3& o, const glm::vec3& d) const {
        glm::mat4 inv = glm::inverse(scene_.worldModel(e.id));
        glm::vec3 lo = glm::vec3(inv * glm::vec4(o, 1.0f)), ld = glm::vec3(inv * glm::vec4(d, 0.0f));
        if (e.primitive == Primitive::Sphere) {
            float a = glm::dot(ld, ld), b = 2.0f * glm::dot(lo, ld), c = glm::dot(lo, lo) - 1.0f;
            float disc = b * b - 4 * a * c;
            if (disc < 0) return -1.0f;
            float t = (-b - std::sqrt(disc)) / (2 * a);
            return t >= 0 ? t : -1.0f;
        }
        glm::vec3 h = Scene::localHalfExtents(e);
        float tmin = 0.0f, tmax = 1e9f;
        for (int i = 0; i < 3; ++i) {
            if (std::abs(ld[i]) < 1e-8f) { if (lo[i] < -h[i] || lo[i] > h[i]) return -1.0f; continue; }
            float t1 = (-h[i] - lo[i]) / ld[i], t2 = (h[i] - lo[i]) / ld[i];
            if (t1 > t2) std::swap(t1, t2);
            tmin = std::max(tmin, t1); tmax = std::min(tmax, t2);
            if (tmin > tmax) return -1.0f;
        }
        return tmin;
    }

    void drawViewport() {
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::Begin("Viewport", nullptr, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
        ImGui::PopStyleVar();

        ImVec2 avail = ImGui::GetContentRegionAvail();
        vpSize_ = ImVec2(std::max(avail.x, 16.0f), std::max(avail.y, 16.0f));
        vpMin_ = ImGui::GetCursorScreenPos();
        ImGui::Image(texId(renderer_->outputTexture()), vpSize_, ImVec2(0, 1), ImVec2(1, 0));
        ImGui::SetCursorScreenPos(vpMin_);
        ImGui::InvisibleButton("##vp", vpSize_, ImGuiButtonFlags_MouseButtonLeft | ImGuiButtonFlags_MouseButtonMiddle | ImGuiButtonFlags_MouseButtonRight);
        const bool hovered = ImGui::IsItemHovered();
        const bool active = ImGui::IsItemActive();
        ImGuiIO& io = ImGui::GetIO();
        ImDrawList* dl = ImGui::GetWindowDrawList();

        // fly camera: hold RMB, WASD/QE, Shift = fast, wheel = dolly
        if (active && ImGui::IsMouseDown(ImGuiMouseButton_Right)) {
            cam_.yaw += io.MouseDelta.x * 0.15f;
            cam_.pitch = glm::clamp(cam_.pitch - io.MouseDelta.y * 0.15f, -89.0f, 89.0f);
            float sp = (io.KeyShift ? 20.0f : 7.0f) * io.DeltaTime;
            if (ImGui::IsKeyDown(ImGuiKey_W)) cam_.position += cam_.forward() * sp;
            if (ImGui::IsKeyDown(ImGuiKey_S)) cam_.position -= cam_.forward() * sp;
            if (ImGui::IsKeyDown(ImGuiKey_D)) cam_.position += cam_.right() * sp;
            if (ImGui::IsKeyDown(ImGuiKey_A)) cam_.position -= cam_.right() * sp;
            if (ImGui::IsKeyDown(ImGuiKey_E)) cam_.position.y += sp;
            if (ImGui::IsKeyDown(ImGuiKey_Q)) cam_.position.y -= sp;
        }
        if (hovered && io.MouseWheel != 0.0f) cam_.position += cam_.forward() * io.MouseWheel * 2.0f;

        const float aspect = vpSize_.x / vpSize_.y;
        const glm::mat4 view = cam_.view(), proj = cam_.proj(aspect), vp = proj * view;
        const glm::mat4 invVP = glm::inverse(vp);

        // light icons
        for (const Entity& e : scene_.entities) {
            if (!e.isLight || !e.active) continue;
            ImVec2 s;
            if (!project(vp, glm::vec3(scene_.worldModel(e.id)[3]), s)) continue;
            dl->AddImage(texId(icons::texture(Icon::Light)), ImVec2(s.x - 11, s.y - 11), ImVec2(s.x + 11, s.y + 11), ImVec2(0, 0), ImVec2(1, 1),
                         ImGui::ColorConvertFloat4ToU32(ImVec4(e.lightColor.r * 0.4f + 0.6f, e.lightColor.g * 0.4f + 0.6f, e.lightColor.b * 0.4f + 0.6f, 0.95f)));
        }

        Entity* sel = scene_.find(selected_);
        int hoverAxis = -1;
        glm::vec3 axes[3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        const ImU32 axisCol[3] = {IM_COL32(230, 70, 70, 255), IM_COL32(90, 200, 90, 255), IM_COL32(80, 130, 240, 255)};

        if (sel) {
            // selection outline (oriented bounding box)
            glm::vec3 h = Scene::localHalfExtents(*sel);
            glm::mat4 m = scene_.worldModel(sel->id);
            ImVec2 c[8]; bool ok[8];
            for (int i = 0; i < 8; ++i) ok[i] = project(vp, glm::vec3(m * glm::vec4((i & 1 ? h.x : -h.x), (i & 2 ? h.y : -h.y), (i & 4 ? h.z : -h.z), 1.0f)), c[i]);
            const int edges[12][2] = {{0,1},{2,3},{4,5},{6,7},{0,2},{1,3},{4,6},{5,7},{0,4},{1,5},{2,6},{3,7}};
            for (auto& ed : edges) if (ok[ed[0]] && ok[ed[1]]) dl->AddLine(c[ed[0]], c[ed[1]], IM_COL32(240, 170, 60, 200), 1.5f);

            // move gizmo, constant screen size
            ImVec2 o;
            const glm::vec3 selectedWorld(scene_.worldModel(sel->id)[3]);
            if (project(vp, selectedWorld, o)) {
                float len = glm::length(selectedWorld - cam_.position) * 0.16f;
                ImVec2 tip[3]; bool tipOk[3];
                float best = 9.0f;
                for (int a = 0; a < 3; ++a) {
                    tipOk[a] = project(vp, selectedWorld + axes[a] * len, tip[a]);
                    if (tipOk[a] && hovered && dragAxis_ < 0 && !ImGui::IsMouseDown(ImGuiMouseButton_Right)) {
                        float d = distPointSegment(io.MousePos, o, tip[a]);
                        if (d < best) { best = d; hoverAxis = a; }
                    }
                }
                int shown = dragAxis_ >= 0 ? dragAxis_ : hoverAxis;
                for (int a = 0; a < 3; ++a) {
                    if (!tipOk[a]) continue;
                    ImU32 col = (a == shown) ? IM_COL32(255, 230, 90, 255) : axisCol[a];
                    dl->AddLine(o, tip[a], col, a == shown ? 4.0f : 3.0f);
                    if (gizmoMode_ == 1) {
                        dl->AddCircle(tip[a], 7.0f, col, 16, 2.5f);
                    } else if (gizmoMode_ == 2) {
                        dl->AddRectFilled(ImVec2(tip[a].x - 5, tip[a].y - 5),
                                          ImVec2(tip[a].x + 5, tip[a].y + 5), col);
                    } else {
                        ImVec2 dir(tip[a].x - o.x, tip[a].y - o.y);
                        float l = std::sqrt(dir.x * dir.x + dir.y * dir.y) + 1e-5f;
                        dir = ImVec2(dir.x / l, dir.y / l);
                        ImVec2 n(-dir.y, dir.x);
                        dl->AddTriangleFilled(ImVec2(tip[a].x + dir.x * 12, tip[a].y + dir.y * 12),
                                              ImVec2(tip[a].x + n.x * 5, tip[a].y + n.y * 5), ImVec2(tip[a].x - n.x * 5, tip[a].y - n.y * 5), col);
                    }
                }
                dl->AddCircleFilled(o, 4.0f, IM_COL32(240, 240, 240, 255));
            }
        }

        // left click: start axis drag or pick
        if (ImGui::IsItemClicked(ImGuiMouseButton_Left)) {
            glm::vec3 ro, rd;
            mouseRay(invVP, io.MousePos, ro, rd);
            if (sel && hoverAxis >= 0) {
                dragAxis_ = hoverAxis;
                dragStartPos_ = sel->position;
                dragStartWorld_ = glm::vec3(scene_.worldModel(sel->id)[3]);
                dragStartRotation_ = sel->rotation;
                dragStartScale_ = sel->scale;
                dragStartS_ = axisParam(dragStartWorld_, axes[hoverAxis], ro, rd);
            } else {
                float bestT = 1e9f; uint32_t pick = 0;
                for (const Entity& e : scene_.entities) {
                    if (!e.active) continue;
                    float t = rayHit(e, ro, rd);
                    if (t >= 0 && t < bestT) { bestT = t; pick = e.id; }
                }
                selected_ = pick;
            }
        }
        if (dragAxis_ >= 0) {
            if (ImGui::IsMouseDown(ImGuiMouseButton_Left) && sel) {
                glm::vec3 ro, rd;
                mouseRay(invVP, io.MousePos, ro, rd);
                float s = axisParam(dragStartWorld_, axes[dragAxis_], ro, rd);
                const float delta = s - dragStartS_;
                if (gizmoMode_ == 0) {
                    glm::vec3 worldPosition = dragStartWorld_ + axes[dragAxis_] * delta;
                    glm::mat4 parentWorld = sel->parentId ? scene_.worldModel(sel->parentId) : glm::mat4(1.0f);
                    sel->position = glm::vec3(glm::inverse(parentWorld) * glm::vec4(worldPosition, 1.0f));
                } else if (gizmoMode_ == 1) {
                    sel->rotation = dragStartRotation_;
                    sel->rotation[dragAxis_] += delta * 90.0f;
                } else {
                    sel->scale = dragStartScale_;
                    sel->scale[dragAxis_] = glm::max(0.01f, dragStartScale_[dragAxis_] + delta * 0.25f);
                }
            } else dragAxis_ = -1;
        }

        // viewport overlay label
        dl->AddText(ImVec2(vpMin_.x + 10, vpMin_.y + 8), IM_COL32(255, 255, 255, 140), "Perspective");
        ImGui::End();
    }

    // parameter along the (infinite) axis line closest to the mouse ray
    static float axisParam(const glm::vec3& p, const glm::vec3& a, const glm::vec3& ro, const glm::vec3& rd) {
        glm::vec3 w0 = p - ro;
        float b = glm::dot(a, rd), d = glm::dot(a, w0), e = glm::dot(rd, w0);
        float den = 1.0f - b * b;
        return std::abs(den) < 1e-4f ? 0.0f : (b * e - d) / den;
    }

    // ------------------------------------------------------------------ state
    std::unique_ptr<Renderer> renderer_;
    Scene scene_;
    AssetDatabase assetDb_;
    Camera cam_;
    std::vector<DrawItem> items_;
    std::vector<PointLight> lights_;

    uint32_t selected_ = 0;
    ImVec2 vpSize_{1280, 720}, vpMin_{0, 0};
    int dragAxis_ = -1;
    int gizmoMode_ = 0; // 0 Move, 1 Rotate, 2 Scale
    glm::vec3 dragStartPos_{0.0f}, dragStartWorld_{0.0f}, dragStartRotation_{0.0f}, dragStartScale_{1.0f};
    float dragStartS_ = 0.0f;

    bool playing_ = false, paused_ = false;
    float playTime_ = 0.0f;
    std::vector<Entity> snapshot_;

    ui::Widget uiRoot_{ui::WidgetType::Panel, "Canvas"};
    ui::WidgetId uiSelected_ = 0, uiInspectorId_ = 0;
    bool uiDragActive_ = false;
    ImVec2 uiDragMouseStart_{};
    ui::Vec2 uiDragOffsetStart_{};
    char uiNameBuffer_[128]{};
    char uiTextBuffer_[256]{};

    float sunAz_ = 0.0f, sunEl_ = 60.0f;
    float frameMs_ = 16.0f;
    int frameNo_ = 0;
    bool layoutBuilt_ = false, forceLayout_ = false;
    std::string projDir_;
    char codePath_[512] = "scripts/main.cpp";
    std::vector<char> codeBuffer_ = std::vector<char>(512 * 1024, '\0');
    bool codeDirty_ = false;
};

int main() {
    Editor app;
    app.run();
    return 0;
}
