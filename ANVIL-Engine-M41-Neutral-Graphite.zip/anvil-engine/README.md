# ANVIL Engine

C++20 game engine by ANVIL studio. Goal: Rage (2008) class tech, then physically based / photoreal rendering.

## Milestone 1 (this ZIP)
- CMake + FetchContent (GLFW 3.4, GLM 1.0.1, glad2 OpenGL 4.5 core) - nothing to install by hand except Python+jinja2
- `Window` (GLFW, input, mouse capture), `Application` (main loop, fixed 60 Hz + variable update)
- `Renderer`: deferred G-buffer (albedo / normal RGBA16F / roughness-metal / depth32F),
  Cook-Torrance GGX PBR, sun + up to 32 point lights, HDR (RGBA16F), ACES tonemap
- `Mesh` (sphere / plane / cube), `Shader`, `Camera`
- `sandbox`: PBR sphere grid, moving lights, fly camera

## Milestone 2 (editor + lighting)
- `anvil_editor`: Unity-style docking editor (Dear ImGui docking): Hierarchy, Viewport, Inspector, Render Settings, Project, Console
- SVG icons (rasterized with nanosvg), dark theme, toolbar, status bar
- Scene/Entity (flat): Cube / Sphere / Plane / Point Light, create/duplicate/delete, Add Component
- Viewport: RMB+WASD fly camera, click picking, selection outline, Move / Rotate / Scale gizmos (X/Y/Z axes; W/E/R shortcuts)
- Play / Pause / Step: scene is snapshotted on Play and restored on Stop (demo "Orbit" script moves lights)
- Renderer: sun shadow map (2048, PCF, normal-offset), bloom (13-tap down / tent up), output to texture
- Not done yet: parenting, scene save/load, undo/redo, textures/models, CSM, SSR, TAA, IBL


## Milestone 3 (ambient occlusion pass)
- Added configurable SSAO in the deferred lighting pass (12 projected hemisphere samples).
- SSAO is applied to indirect/ambient light, not direct sun or point-light contribution.
- Added editor controls: SSAO enable, AO radius, AO strength.
- OpenGL 4.5 core; no new runtime dependency.

Notes:
- SSAO is a screen-space approximation and can show edge halos/noise; it is not ray-traced GI.
- Cascaded shadow maps, temporal accumulation/TAA, SSR, IBL, texture assets, glTF, scene hierarchy,
  serialization and undo/redo remain future milestones. The Windows binary ZIP is the original M2 build;
  rebuild this source package to use M3 changes.

## Build
Requirements: C++20 compiler, CMake >= 3.20, Python 3 + `pip install jinja2`, internet for first configure.

    cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    cmake --build build --config Release
    ./build/sandbox/sandbox        (Windows: build\sandbox\Release\sandbox.exe)

Controls: WASD move, Q/E down/up, Shift fast, mouse look, Esc quit.
Debug: `ANVIL_AUTOEXIT=1` exits after 1 s; `ANVIL_SHOT=file.ppm` dumps a frame.

## M14–M19: Physics + 2015-era rendering uplift

- CPU fixed-step rigid-body prototype: gravity, AABB contacts, penetration correction, restitution and friction.
- Renderer additions: bounded screen-space reflections (SSR), distance fog and FXAA. Existing HDR/ACES, bloom, SSAO, deferred PBR and shadow-map passes remain.
- SSR is screen-space only: it cannot reflect off-screen objects and is not a substitute for environment probes or ray tracing.
- Physics currently handles axis-aligned boxes only; rotation-aware convex collision, CCD, joints, vehicles and character controllers require a dedicated production physics integration (e.g. Jolt).
- Graphics API status: **OpenGL 4.5 is implemented. Vulkan and Direct3D 12 are not implemented yet**; the RHI is currently an OpenGL-only foundation.

## Roadmap
1. Resource system: textures (stb_image, mipmaps, sRGB), model loading (glTF), material system with PBR texture maps, normal mapping
2. Cascaded shadow maps, point-light shadows, SSAO, bloom, TAA, IBL + sky/atmosphere
3. Scene/ECS (EnTT), transforms, culling, LOD
4. Physics (Jolt), vehicles, character controller
5. Megatexture-style virtual texturing (the Rage idea), terrain streaming
6. Audio, scripting, asset pipeline/editor, then Vulkan backend, GI / ray tracing for photorealism


## Milestone 4 (transform gizmo tools)
- Enabled Move / Rotate / Scale toolbar modes and W/E/R shortcuts.
- Axis dragging now edits position, Euler rotation (90 degrees per world-unit drag), or scale (0.25 scale units per world-unit drag).
- Scale is clamped to a positive minimum to avoid zero/negative transform values.
- The viewport draws distinct arrow, ring-handle, and square-handle markers for the three modes.
- This is a lightweight custom editor gizmo, not a full axis-plane / arcball implementation. Rotation and scale currently use the same projected axis-drag interaction as Move.

## Rendering Hardware Interface (RHI)

M5 foundation work introduces a backend-neutral API in `engine/include/anvil/rhi`:

- `RHI.h` defines device capabilities, resource descriptors, GPU resource interfaces and command-list contracts.
- `OpenGLRHI.h` / `OpenGLRHI.cpp` provide the first OpenGL 4.5 implementation using Direct State Access.
- `ResourceManager.h` / `ResourceManager.cpp` retain shared GPU resources, assign stable runtime IDs and expose resource inventory/statistics.

The existing M4 renderer, mesh and shader classes intentionally remain operational and are not silently switched to the new API. This staged boundary lets the renderer migrate incrementally without risking the current deferred/PBR path. Create the OpenGL device only after `Window` has created the context and loaded GLAD:

```cpp
auto device = anvil::rhi::createOpenGL45Device();
anvil::rhi::ResourceManager resources;
auto buffer = device->createBuffer({sizeof(vertices), anvil::rhi::BufferUsage::Vertex, true, "Example vertices"}, vertices);
auto bufferId = resources.retain(buffer, anvil::rhi::ResourceKind::Buffer, "Example vertices", sizeof(vertices));
// ... use the resource while the OpenGL context is current ...
resources.release(bufferId);
```

GPU object destruction calls OpenGL, so release tracked resources and destroy RHI objects before tearing down the window/context. The initial command list is an immediate-mode OpenGL command encoder; it is not a deferred multithreaded command buffer. Vertex attribute/VAO layout remains the responsibility of the caller in this first RHI increment.

## M6 foundation: scenes, history and ECS

This revision adds three editor/runtime foundations:

- `anvil/SceneSerializer.h`: versioned JSON scene save/load. Loading validates the format version and entity IDs and builds a candidate scene before replacing the live scene.
- `anvil/UndoRedo.h`: bounded command history with undo/redo cursor semantics and redo-branch invalidation after a new edit. Commands are supplied by editor operations as undo/redo callables.
- `anvil/ECS.h`: a small type-erased component registry with stable entity handles, typed component storage, `view<T...>()`, and entity destruction cleanup.

The existing `Scene`/`Entity` API remains intact for compatibility. The ECS is intentionally introduced alongside it; converting every editor and renderer path in one pass would create unnecessary regressions. Scene serialization currently covers the scene sun and all fields of the existing flat `Entity` model. Format version is explicit (`1`) so future schema migrations can be added safely.

## Milestone 7 (scene hierarchy and inspector workflow)
- Added parent IDs to scene entities and local-space transforms.
- Scene now exposes child enumeration, cycle-safe reparenting, and hierarchical world matrices.
- Rendering consumes world transforms for meshes and point lights.
- Hierarchy panel is now a recursive tree with drag-and-drop parenting, unparenting, and context actions.
- Inspector exposes the parent relationship and labels transform values as local-space values.
- Scene format advanced to version 2; version 1 scenes remain loadable as root-level entities.
- Removing a parent promotes its children to the scene root rather than deleting them.

Hierarchy transforms are intentionally local to their parent. Reparenting changes the resulting world transform; a future transform tool milestone will add a keep-world-transform option and full matrix decomposition.

## M8–M13: Assets, materials and model import

The latest milestone adds a project asset index (`AssetDatabase`), a small PPM texture loader (`Texture2D`), textured base-color support in the deferred G-buffer, and an OBJ mesh importer. Scene format v4 persists model and texture paths while retaining v1–v3 loading compatibility. The editor Inspector accepts project-relative OBJ and PPM paths, and the Project panel can refresh its asset index.

Example assets are in `assets/models/quad.obj` and `assets/textures/checker.ppm`. To use them, set a Mesh Renderer to **OBJ Model** and enter `assets/models/quad.obj`, or enter `assets/textures/checker.ppm` in the Albedo Texture field.

A focused asset-index test is available through CTest (`anvil_asset_database_tests`). To run it without downloading graphics dependencies, configure with `-DANVIL_ASSET_TESTS_ONLY=ON`. The complete project still fetches GLFW, GLM, GLAD, ImGui and NanoSVG through CMake FetchContent, so the first configure requires network access.

### Optional production physics
The built-in AABB physics prototype remains dependency-free. To enable the Jolt Physics adapter (box rigid bodies, static/dynamic bodies, fixed-step simulation), configure with `-DANVIL_WITH_JOLT=ON`. CMake fetches Jolt Physics 5.2.0, so the first configure requires network access. See `M20-M25-CHANGELOG.md` for current backend status.


## M26–M31 update
- Scene-level bridge for attaching CPU physics bodies to root entities and synchronizing dynamic transforms.
- Physics prototype now supports linear damping and per-body gravity scale with finite-input validation.
- Jolt global registration is thread-safe; enable the optional adapter with `-DANVIL_WITH_JOLT=ON`.
- PBR ambient lighting uses roughness-aware Fresnel energy handling; this is not yet image-based lighting.
- OpenGL 4.5 is the only working renderer backend. Vulkan and Direct3D 12 are still unavailable.
- See `M26-M31-CHANGELOG.md` for implementation and verification limits.


## M32: Jolt in Scene/ECS
Scene physics now runs through `IPhysicsBackend` (Jolt or the dependency-free fallback). Add a **Rigidbody** in the editor and press Play.

    cmake -S . -B build -DANVIL_WITH_JOLT=ON          # full engine + editor with Jolt (fetches Jolt 5.2.0)
    cmake -S . -B build -DANVIL_PHYSICS_ONLY=ON -DANVIL_WITH_JOLT=ON   # physics + tests only, no window/GL
    ctest --test-dir build

See `M32-CHANGELOG.md` (includes fixes for scene save/load and the old Jolt adapter). Vulkan, Direct3D 12, IBL/HDR and cascaded shadows are the next stages and are **not** implemented yet.


## M33: RHI v2 foundation (Vulkan 1.4 + Direct3D 12, stage 1 of 5)
RHI now describes swapchains, render passes, pipeline state, push constants and a frame loop; the window can be created without OpenGL; shaders are authored once in Vulkan-GLSL and cross-compiled to SPIR-V and DXIL (`cmake/AnvilShaders.cmake`). The Vulkan and D3D12 backends themselves are **not** implemented yet - see `M33-CHANGELOG.md` for the 5-stage plan.


## M36 update

OpenGL and RHI now share the CPU-side stabilized directional-shadow frustum calculation (`anvil/ShadowMath.h`). RHI applies the explicit-API clip-depth conversion inside that shared helper. Direct3D 12 shader compilation can be enabled with `-DANVIL_COMPILE_D3D12_SHADERS=ON` (requires `glslc`, `spirv-cross`, and `dxc`). Direct3D 12 is intentionally still marked unavailable until its native backend is implemented and validated; DXIL shader compilation alone is not a usable backend. See `M36-CHANGELOG.md`.


## M37: Direct3D 12 backend integration (initial)
A Windows-only D3D12 implementation is now available behind `-DANVIL_WITH_D3D12=ON`. This enables the DXIL shader build and the native D3D12 device, descriptor heaps, graphics PSOs, command lists, resource transitions and GLFW swapchain. See `M37-CHANGELOG.md` for requirements and validation limits. The legacy editor still uses OpenGL; migration of the editor viewport to `RhiRenderer` is a separate integration step.

## UI runtime (M39)

`anvil/UI.h` provides a renderer-independent retained widget tree and deterministic layout pass. Widgets support absolute anchors, horizontal/vertical stack containers, fixed/fill sizing, padding, margins, min/max constraints, recursive ID lookup/removal and hit testing. The UI runtime is intentionally independent of OpenGL/Vulkan/D3D12 so projects can author and test UI documents without a graphics context. Rendering, input/focus routing, serialization and the visual canvas are staged follow-ups.


## M40 — Visual UI Designer foundation

M40 adds a dockable UI Designer to the editor. It provides a widget tree, a scaled 800×450 preview canvas, direct selection and drag positioning, a property inspector, and save/load for versioned `.anvilui` documents under `assets/ui/`. Supported initial widgets are Panel, Button and Label. The preview is editor-side drawing; it is not yet the final runtime UI renderer.

UI documents use the `ANVIL_UI 1` header and are validated when loaded. The dependency-free UI tests cover layout, hit testing, widget ownership and document round-tripping.

See `M40-CHANGELOG.md` for implementation scope and known limitations.


## M41 — Neutral Graphite Editor Theme
- Replaced saturated blue editor highlights with restrained neutral-gray interaction states.
- Unified docked panels, tabs, controls, borders and separators under a low-distraction graphite palette.
- Kept semantic status colors distinct from the base UI theme.
- See `M41-CHANGELOG.md` for the palette and verification scope.
