#pragma once
#include "Camera.h"
#include "Mesh.h"
#include "Shader.h"
#include "Texture2D.h"
#include <memory>
#include <string>
#include <vector>

namespace anvil {

struct Material {
    glm::vec3 albedo{0.8f};
    float roughness = 0.5f;
    float metallic = 0.0f;
    std::string albedoTexturePath;
    std::shared_ptr<Texture2D> albedoTexture;
};

struct DrawItem {
    const Mesh* mesh = nullptr;
    glm::mat4 model{1.0f};
    Material material;
};

struct PointLight {
    glm::vec3 position{0.0f};
    glm::vec3 color{1.0f};
    float intensity = 50.0f;
    float radius = 12.0f; // smooth finite range; <= 0 keeps inverse-square-only falloff
};

struct Sun {
    glm::vec3 direction{-0.4f, -1.0f, -0.3f};
    glm::vec3 color{1.0f, 0.95f, 0.85f};
    float intensity = 2.0f;
};

struct RenderSettings {
    float exposure = 1.0f;
    bool  shadows = true;
    float shadowRadius = 30.0f;     // half-extent of the sun shadow frustum, meters
    float shadowBias = 0.0008f;
    bool  bloom = true;
    bool  ssao = true;
    float aoRadius = 0.85f;
    float aoStrength = 1.35f;
    float bloomThreshold = 1.0f;
    float bloomStrength = 0.06f;
    bool screenSpaceReflections = true;
    float reflectionStrength = 0.55f;
    bool distanceFog = false;
    glm::vec3 fogColor{0.55f,0.65f,0.75f};
    float fogDensity = 0.012f;
    bool fxaa = true;
};

// Deferred PBR renderer:
//   sun shadow map -> G-buffer -> Cook-Torrance lighting (HDR) -> bloom -> ACES tonemap -> LDR output texture
class Renderer {
public:
    static constexpr int kMaxPointLights = 32;
    static constexpr int kBloomLevels = 5;
    static constexpr int kShadowSize = 2048;

    Renderer(int width, int height);
    ~Renderer();
    Renderer(const Renderer&) = delete;
    Renderer& operator=(const Renderer&) = delete;

    void resize(int width, int height);
    void render(const Camera& cam, const std::vector<DrawItem>& items,
                const std::vector<PointLight>& lights, const Sun& sun);

    // Final LDR image (RGBA8). The editor shows this inside its Viewport panel.
    unsigned outputTexture() const { return ldrColor_; }
    int width() const { return w_; }
    int height() const { return h_; }

    RenderSettings settings;
    bool presentToScreen = true;   // blit output to the default framebuffer (game mode)

private:
    void createTargets();
    void destroyTargets();
    void shadowPass(const Camera& cam, const std::vector<DrawItem>& items, const Sun& sun);
    void bloomPass();

    int w_, h_;
    std::unique_ptr<Shader> gbufferShader_, lightingShader_, postShader_, shadowShader_, bloomDown_, bloomUp_;
    unsigned gFbo_ = 0, gAlbedo_ = 0, gNormal_ = 0, gMaterial_ = 0, gDepth_ = 0;
    unsigned hdrFbo_ = 0, hdrColor_ = 0;
    unsigned ldrFbo_ = 0, ldrColor_ = 0;
    unsigned shadowFbo_ = 0, shadowTex_ = 0;
    unsigned bloomFbo_[kBloomLevels] = {}, bloomTex_[kBloomLevels] = {};
    int bloomW_[kBloomLevels] = {}, bloomH_[kBloomLevels] = {};
    glm::mat4 lightVP_{1.0f};
    float shadowTexelWorld_ = 0.0f;
    unsigned emptyVao_ = 0;
};

} // namespace anvil
