# M100

Release SDK: package manifest validation for headers, runtime and editor; final commercial release requires platform builds, legal review, shader compilation and GPU QA.
