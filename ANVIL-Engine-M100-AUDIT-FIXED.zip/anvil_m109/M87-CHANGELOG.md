# M87

Material Editor: editable scalar parameters with range clamping and material layer definitions.
