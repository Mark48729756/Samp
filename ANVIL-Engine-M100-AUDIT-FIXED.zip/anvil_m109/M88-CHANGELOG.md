# M88

Animation Editor: sorted float keyframes, replacement at duplicate times and linear sampling.
