# M69 — Advanced material foundations

- Added `MaterialLayer.h`: bounded parallax-occlusion reference traversal, normalized material-layer blending and triplanar axis weighting.
- Added `shaders/rhi/material_parallax.glsl`: reusable POM and triplanar helper functions for Vulkan GLSL material shaders.
- Texture-array/material descriptor integration, tangent-space asset validation and renderer material editor integration remain pending.
