# M94

Multithreaded Rendering foundation: task dependency graph with cycle-safe topological ordering; worker pool and command recording integration remain future work.
