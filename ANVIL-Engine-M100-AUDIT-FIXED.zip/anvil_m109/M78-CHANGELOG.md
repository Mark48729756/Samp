# M78 — Branching Dialogue System
- Added dialogue nodes, speaker/text/voice-event metadata, and indexed player choices.
- Added conditional choices using boolean flags and flag mutation on selection.
- Added linear node advancement, start/stop state, and invalid-transition rejection.
- Voice events are metadata only; playback and subtitle UI integration remain future work.
