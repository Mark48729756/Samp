# M63 — LOD transition support

- Added a two-level LOD transition result with a configurable fade band.
- The result provides primary/secondary LOD IDs and a normalized secondary weight for renderer-side dithering or cross-fade.
- Model import, per-entity LOD mesh ownership and actual draw cross-fading remain future integration work.
