# M86

Asset Pipeline: extension classification, import options and asset metadata validation. No third-party FBX/glTF decoder is bundled.
