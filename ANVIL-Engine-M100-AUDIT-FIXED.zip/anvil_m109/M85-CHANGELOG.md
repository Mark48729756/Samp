# M85

Node Editor: graph nodes, directed links and cycle prevention.
