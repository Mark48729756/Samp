# M81 — Deterministic Destruction Core
- Added seeded deterministic chunk generation around a fracture center.
- Added radial impulse application, fixed-step-clamped integration, and per-chunk deactivation.
- Chunk geometry generation, mesh remeshing, joints, and renderer integration remain future work.
