# M91

Cinematic Rendering: camera/post settings validation and circle-of-confusion reference calculation.
