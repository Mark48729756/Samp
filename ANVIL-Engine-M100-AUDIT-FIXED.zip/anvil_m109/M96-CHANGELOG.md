# M96

AI System: four-neighbour grid A* pathfinding and obstacle map.
