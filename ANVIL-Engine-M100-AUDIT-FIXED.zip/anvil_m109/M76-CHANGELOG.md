# M76 — Ragdoll Constraints
- Added a CPU distance-constraint ragdoll prototype with inverse-mass weighting, stiffness, bounded solver iterations, activation and animation blend control.
- This is not yet a full rigid-body ragdoll: collision shapes, angular constraints, joint limits and physics-backend integration remain future work.
