# M93

GPU Profiler foundation: bounded timing history, average and percentile statistics; hardware timestamp queries remain backend work.
