# M95

Vehicle System: longitudinal force integration, braking, drag and steering input model; wheel suspension/contacts are not yet integrated.
