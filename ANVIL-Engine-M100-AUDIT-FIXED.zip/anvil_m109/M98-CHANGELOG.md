# M98

Build Pipeline: build manifest and safe relative artifact destination validation; platform packaging/signing is not implemented.
