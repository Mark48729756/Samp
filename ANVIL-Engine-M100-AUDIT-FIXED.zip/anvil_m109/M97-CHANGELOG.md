# M97

Gameplay Framework: inventory, persistent flags and in-memory save snapshots; disk serialization and mission scripting remain future work.
