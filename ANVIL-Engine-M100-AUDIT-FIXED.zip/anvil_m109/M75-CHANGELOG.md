# M75 — Animation Graph
- Added named animation states, directed transitions, cross-fade timing and a 1D blend-tree sampler returning lower/upper clips and blend alpha.
- The blend-tree result is a sampling contract; blending multiple clips into one final pose and editor graph authoring remain follow-up integration work.
