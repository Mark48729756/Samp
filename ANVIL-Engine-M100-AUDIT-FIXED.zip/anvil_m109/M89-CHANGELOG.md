# M89

Hardware Ray Tracing foundation: CPU-side geometry/instance scene model and validation. DXR/Vulkan acceleration structures and GPU dispatch are not implemented.
