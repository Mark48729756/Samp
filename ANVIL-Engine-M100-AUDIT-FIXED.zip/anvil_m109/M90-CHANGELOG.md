# M90

Advanced GI: CPU-side irradiance probe volume storage and lookup foundation; no runtime probe capture or GPU integration.
