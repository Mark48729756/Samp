# M82 — Constraint Physics
- Added a small Verlet particle solver with inverse-mass handling.
- Added iterative distance constraints with configurable stiffness and gravity integration.
- Added bounded timestep and iteration count for stability.
- This is a lightweight cloth/rope constraint foundation, not a complete rigid-body, vehicle, or cloth production solver.
