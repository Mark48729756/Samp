# Hyper VR OS (картборд)
Kotlin + CameraX + MediaPipe Hands.
Этап 1-3 (+браузер): оконный менеджер, док, лаунчер, приложения (Часы, Заметки, Калькулятор, Настройки, Браузер), виртуальная клавиатура RU/EN, среды Закат/Ночь, passthrough.
Сборка: GitHub Actions (.github/workflows/build.yml) -> Releases -> HyperVR.apk
