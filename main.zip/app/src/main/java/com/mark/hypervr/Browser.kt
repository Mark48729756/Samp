package com.mark.hypervr

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.SystemClock
import android.view.MotionEvent
import android.webkit.WebView
import org.json.JSONObject
import kotlin.math.min

interface OnClose {
    fun onClose(v: VrView)
}

/** Скрытый WebView, который периодически «фотографируется» в Bitmap для показа в VR-окне. */
class WebHost(val web: WebView) {
    val bmp: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private val cv = Canvas(bmp)
    private var lastCap = 0L
    private var downTime = 0L

    fun capture() {
        val now = SystemClock.uptimeMillis()
        if (now - lastCap < 80) return
        lastCap = now
        try {
            cv.drawColor(Color.WHITE)
            web.draw(cv)
        } catch (e: Throwable) {
        }
    }

    fun touch(action: Int, x: Float, y: Float) {
        val now = SystemClock.uptimeMillis()
        if (action == MotionEvent.ACTION_DOWN) downTime = now
        val ev = MotionEvent.obtain(downTime, now, action, x, y, 0)
        web.dispatchTouchEvent(ev)
        ev.recycle()
    }

    fun load(raw: String) {
        val s = raw.trim()
        if (s.isEmpty()) return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(' ') || !s.contains('.') -> "https://www.google.com/search?q=" + Uri.encode(s)
            else -> "https://$s"
        }
        web.loadUrl(url)
    }

    fun js(code: String, cb: ((String) -> Unit)? = null) {
        web.evaluateJavascript(code) { r -> cb?.invoke(r ?: "") }
    }

    companion object {
        const val W = 1000
        const val H = 640
    }
}

class BrowserApp : App("Браузер", 1000f, 720f), OnClose {
    private val buf = StringBuilder()
    private var editing = false
    private var vv: VrView? = null
    private var lx = 0f
    private var ly = 0f

    private val urlSink = object : TextSink {
        override fun type(s: String) {
            if (s == "\n") {
                vv?.web?.load(buf.toString())
                editing = false
            } else buf.append(s)
        }

        override fun backspace() {
            if (buf.isNotEmpty()) buf.deleteCharAt(buf.length - 1)
        }
    }

    private val pageSink = object : TextSink {
        override fun type(s: String) {
            val h = vv?.web ?: return
            if (s == "\n") h.js(JS_ENTER) else h.js(JS_INS + "(" + JSONObject.quote(s) + ")")
        }

        override fun backspace() {
            vv?.web?.js(JS_DEL)
        }
    }

    override fun onClose(v: VrView) {
        if (v.focus === urlSink || v.focus === pageSink) v.focus = null
    }

    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        vv = v
        val host = v.web
        if (host == null) {
            v.text(c, "WebView недоступен", r.centerX(), r.centerY(), 32f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
            return
        }
        host.capture()

        // панель
        val y0 = r.top + 8f * u
        val y1 = y0 + 56f * u
        var x = r.left + 12f * u
        val rect = RectF()
        rect.set(x, y0, x + 64f * u, y1)
        v.button(c, w, rect, "←", 30f * u) { if (host.web.canGoBack()) host.web.goBack() }
        x += 72f * u
        rect.set(x, y0, x + 64f * u, y1)
        v.button(c, w, rect, "→", 30f * u) { if (host.web.canGoForward()) host.web.goForward() }
        x += 72f * u
        rect.set(x, y0, x + 110f * u, y1)
        v.button(c, w, rect, "Обн.", 24f * u) { host.web.reload() }
        x += 118f * u
        rect.set(x, y0, x + 110f * u, y1)
        v.button(c, w, rect, "Домой", 24f * u) { host.load("https://www.google.com") }
        x += 118f * u

        val url = RectF(x, y0, r.right - 12f * u, y1)
        val focused = v.focus === urlSink
        v.fill(c, url, 14f * u, if (focused) col(0xFF16263A) else col(0xFF101A28))
        if (focused) v.strokeRound(c, url, 14f * u, 3f * u, col(0xFF4FC3F7))
        val shown = if (editing) buf.toString() else (host.web.url ?: "")
        val line = v.wrapLines(shown, 24f * u, url.width() - 28f * u)
        val t = if (line.isNotEmpty()) line[0] else ""
        v.text(c, t, url.left + 14f * u, url.centerY() + 8f * u, 24f * u, col(0xFFFFFFFF))
        if (focused && (SystemClock.uptimeMillis() / 500) % 2 == 0L) {
            v.text(c, "|", url.left + 14f * u + v.measure(t, 24f * u), url.centerY() + 8f * u, 24f * u, col(0xFF4FC3F7), true)
        }
        v.hotspot(w, url, 91) {
            buf.setLength(0)
            editing = true
            v.focus = urlSink
            v.openKeyboard(w)
        }

        // прогресс загрузки
        val pr = host.web.progress
        if (pr in 1..99) {
            rect.set(r.left, y1 + 3f * u, r.left + r.width() * pr / 100f, y1 + 7f * u)
            v.fill(c, rect, 2f * u, col(0xFF4FC3F7))
        }

        // страница
        val area = RectF(r.left, y1 + 10f * u, r.right, r.bottom)
        val s = min(area.width() / WebHost.W, area.height() / WebHost.H)
        val dst = RectF(area.left, area.top, area.left + WebHost.W * s, area.top + WebHost.H * s)
        v.drawBmp(c, host.bmp, dst)
        v.pointerArea(w, dst, 92,
            { px, py ->
                lx = (px - dst.left) / s
                ly = (py - dst.top) / s
                host.touch(MotionEvent.ACTION_DOWN, lx, ly)
            },
            { px, py ->
                lx = (px - dst.left) / s
                ly = (py - dst.top) / s
                host.touch(MotionEvent.ACTION_MOVE, lx, ly)
            },
            {
                host.touch(MotionEvent.ACTION_UP, lx, ly)
                v.postDelayed({
                    host.js(JS_CHECK) { res ->
                        if (res == "true") {
                            v.focus = pageSink
                            v.openKeyboard(w)
                        } else if (v.focus === pageSink) v.focus = null
                    }
                }, 250)
            })
    }

    companion object {
        private const val JS_INS = "(function(t){var e=document.activeElement;if(!e)return;var n=e.tagName;if(n==='INPUT'||n==='TEXTAREA'){var pr=n==='INPUT'?HTMLInputElement.prototype:HTMLTextAreaElement.prototype;var d=Object.getOwnPropertyDescriptor(pr,'value');d.set.call(e,e.value+t);e.dispatchEvent(new Event('input',{bubbles:true}));}else if(e.isContentEditable){document.execCommand('insertText',false,t);}})"
        private const val JS_DEL = "(function(){var e=document.activeElement;if(!e)return;var n=e.tagName;if(n==='INPUT'||n==='TEXTAREA'){var pr=n==='INPUT'?HTMLInputElement.prototype:HTMLTextAreaElement.prototype;var d=Object.getOwnPropertyDescriptor(pr,'value');d.set.call(e,e.value.slice(0,-1));e.dispatchEvent(new Event('input',{bubbles:true}));}else if(e.isContentEditable){document.execCommand('delete');}})()"
        private const val JS_ENTER = "(function(){var e=document.activeElement;if(!e)return;['keydown','keypress','keyup'].forEach(function(k){e.dispatchEvent(new KeyboardEvent(k,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));});if(e.form){if(e.form.requestSubmit)e.form.requestSubmit();else e.form.submit();}})()"
        private const val JS_CHECK = "(function(){var e=document.activeElement;return !!e&&(e.tagName==='INPUT'||e.tagName==='TEXTAREA'||e.isContentEditable);})()"
    }
}
