package com.mark.hypervr

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.media.ExifInterface
import android.media.MediaPlayer
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.util.LruCache
import android.view.Surface
import android.view.TextureView
import java.util.Collections
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MediaItem(val id: Long, val uri: Uri, val name: String, val durMs: Long)

object MediaLoader {
    val exec: ExecutorService = Executors.newFixedThreadPool(2)
    private val thumbs = LruCache<Long, Bitmap>(90)
    private val pending: MutableSet<Long> = Collections.synchronizedSet(HashSet<Long>())

    fun queryImages(ctx: Context, limit: Int): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        try {
            val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
            ctx.contentResolver.query(base, proj, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                while (c.moveToNext() && out.size < limit) {
                    val id = c.getLong(iId)
                    out.add(MediaItem(id, ContentUris.withAppendedId(base, id), c.getString(iName) ?: "", 0L))
                }
            }
        } catch (e: Throwable) {
        }
        return out
    }

    fun queryVideos(ctx: Context, limit: Int): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        try {
            val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION)
            ctx.contentResolver.query(base, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                while (c.moveToNext() && out.size < limit) {
                    val id = c.getLong(iId)
                    out.add(MediaItem(id, ContentUris.withAppendedId(base, id), c.getString(iName) ?: "", c.getLong(iDur)))
                }
            }
        } catch (e: Throwable) {
        }
        return out
    }

    fun decode(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (max(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            var orient = ExifInterface.ORIENTATION_NORMAL
            try {
                ctx.contentResolver.openInputStream(uri)?.use {
                    orient = ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            } catch (e: Throwable) {
            }
            val deg = when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg == 0f) return bmp
            val m = Matrix()
            m.postRotate(deg)
            return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (e: Throwable) {
            return null
        }
    }

    /** Возвращает миниатюру, если она уже готова; иначе запускает загрузку в фоне. */
    fun thumb(ctx: Context, item: MediaItem): Bitmap? {
        val b = thumbs.get(item.id)
        if (b != null) return b
        if (pending.add(item.id)) {
            exec.execute {
                val d = decode(ctx, item.uri, 256)
                if (d != null) thumbs.put(item.id, d)
                pending.remove(item.id)
            }
        }
        return null
    }

    fun cached(item: MediaItem): Bitmap? = thumbs.get(item.id)
}

/** Скрытый TextureView под VrView: MediaPlayer рисует в него, кадры забираем в Bitmap. */
class VideoHost(val tv: TextureView) {
    val bmp: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    private var surface: Surface? = null
    private var mp: MediaPlayer? = null
    @Volatile private var prepared = false
    private var lastCap = 0L
    var error: String = ""

    fun attach(st: SurfaceTexture) {
        surface = Surface(st)
    }

    fun play(ctx: Context, uri: Uri) {
        stop()
        val s = surface
        if (s == null) {
            error = "Видео-поверхность ещё не готова, попробуй ещё раз"
            return
        }
        error = ""
        try {
            val m = MediaPlayer()
            m.setSurface(s)
            m.setDataSource(ctx, uri)
            m.setOnPreparedListener {
                prepared = true
                it.start()
            }
            m.setOnErrorListener { _, _, _ ->
                error = "Не удалось воспроизвести"
                true
            }
            m.prepareAsync()
            mp = m
        } catch (e: Throwable) {
            error = "Ошибка: " + e.message
        }
    }

    fun toggle() {
        val m = mp ?: return
        if (!prepared) return
        try {
            if (m.isPlaying) m.pause() else m.start()
        } catch (e: Throwable) {
        }
    }

    fun pause() {
        try {
            if (prepared && mp?.isPlaying == true) mp?.pause()
        } catch (e: Throwable) {
        }
    }

    fun isPlaying(): Boolean = try {
        prepared && mp?.isPlaying == true
    } catch (e: Throwable) {
        false
    }

    fun duration(): Int = try {
        if (prepared) mp?.duration ?: 0 else 0
    } catch (e: Throwable) {
        0
    }

    fun position(): Int = try {
        if (prepared) mp?.currentPosition ?: 0 else 0
    } catch (e: Throwable) {
        0
    }

    fun seekTo(ms: Int) {
        try {
            if (prepared) mp?.seekTo(ms.coerceIn(0, max(0, duration())))
        } catch (e: Throwable) {
        }
    }

    fun stop() {
        prepared = false
        try {
            mp?.release()
        } catch (e: Throwable) {
        }
        mp = null
    }

    fun capture() {
        val now = SystemClock.uptimeMillis()
        if (now - lastCap < 33) return
        lastCap = now
        if (!prepared) return
        try {
            tv.getBitmap(bmp)
        } catch (e: Throwable) {
        }
    }

    companion object {
        const val W = 640
        const val H = 360
    }
}

internal fun storagePrompt(v: VrView, c: Canvas, w: Win, r: RectF) {
    val u = v.U
    v.text(c, "Нужен доступ к фото и видео", r.centerX(), r.centerY() - 30f * u, 34f * u, col(0xFFFFFFFF), true, Paint.Align.CENTER)
    val b = RectF(r.centerX() - 200f * u, r.centerY() + 10f * u, r.centerX() + 200f * u, r.centerY() + 90f * u)
    v.button(c, w, b, "Разрешить доступ", 30f * u, true) { v.requestStorage() }
}

private fun fitText(v: VrView, s: String, size: Float, maxW: Float): String {
    val l = v.wrapLines(s, size, maxW)
    return if (l.isNotEmpty()) l[0] else ""
}

private fun fmtMs(ms: Int): String {
    val s = ms / 1000
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

// =====================================================================
//  Галерея
// =====================================================================
class GalleryApp : App("Галерея", 920f, 660f) {
    @Volatile private var items: List<MediaItem>? = null
    private var loading = false
    private var page = 0
    private var viewIdx = -1
    @Volatile private var full: Bitmap? = null
    @Volatile private var fullFor = -1
    private var fullBusy = false

    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        if (!v.storageOk) {
            storagePrompt(v, c, w, r)
            return
        }
        val list = items
        if (list == null) {
            if (!loading) {
                loading = true
                val ctx = v.context
                MediaLoader.exec.execute { items = MediaLoader.queryImages(ctx, 240) }
            }
            v.text(c, "Загрузка…", r.centerX(), r.centerY(), 32f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
            return
        }
        if (list.isEmpty()) {
            v.text(c, "Фотографий не найдено", r.centerX(), r.centerY(), 32f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
            return
        }
        if (viewIdx in list.indices) drawViewer(v, c, w, r, list) else drawGrid(v, c, w, r, list)
    }

    private fun drawGrid(v: VrView, c: Canvas, w: Win, r: RectF, list: List<MediaItem>) {
        val u = v.U
        val cols = 4
        val rows = 3
        val per = cols * rows
        val pages = (list.size + per - 1) / per
        page = page.coerceIn(0, pages - 1)
        val pad = 12f * u
        val gap = 10f * u
        val barH = 70f * u
        val tw = (r.width() - 2 * pad - (cols - 1) * gap) / cols
        val th = (r.height() - 2 * pad - barH - (rows - 1) * gap) / rows
        val rect = RectF()
        val inner = RectF()
        for (k in 0 until per) {
            val idx = page * per + k
            if (idx >= list.size) break
            val x = r.left + pad + (k % cols) * (tw + gap)
            val y = r.top + pad + (k / cols) * (th + gap)
            rect.set(x, y, x + tw, y + th)
            v.button(c, w, rect, "", 10f, false, true) { viewIdx = idx }
            inner.set(rect.left + 4f * u, rect.top + 4f * u, rect.right - 4f * u, rect.bottom - 4f * u)
            val t = MediaLoader.thumb(v.context, list[idx])
            if (t != null) v.drawBmpCrop(c, t, inner)
        }
        val by0 = r.bottom - barH + 6f * u
        val by1 = r.bottom - 10f * u
        rect.set(r.left + pad, by0, r.left + pad + 160f * u, by1)
        v.button(c, w, rect, "◀", 30f * u) { if (page > 0) page-- }
        rect.set(r.right - pad - 160f * u, by0, r.right - pad, by1)
        v.button(c, w, rect, "▶", 30f * u) { if (page < pages - 1) page++ }
        v.text(c, "Стр. ${page + 1} из $pages  ·  ${list.size} фото", r.centerX(), (by0 + by1) / 2f + 10f * u, 26f * u, col(0xCCFFFFFF), false, Paint.Align.CENTER)
    }

    private fun drawViewer(v: VrView, c: Canvas, w: Win, r: RectF, list: List<MediaItem>) {
        val u = v.U
        val item = list[viewIdx]
        val idx = viewIdx
        val rect = RectF()
        val y0 = r.top + 8f * u
        val y1 = y0 + 60f * u
        rect.set(r.left + 12f * u, y0, r.left + 192f * u, y1)
        v.button(c, w, rect, "← Сетка", 26f * u, true) { viewIdx = -1 }
        rect.set(r.right - 12f * u - 140f * u, y0, r.right - 12f * u, y1)
        v.button(c, w, rect, "▶", 30f * u) { if (viewIdx < list.size - 1) viewIdx++ }
        rect.set(r.right - 12f * u - 292f * u, y0, r.right - 12f * u - 152f * u, y1)
        v.button(c, w, rect, "◀", 30f * u) { if (viewIdx > 0) viewIdx-- }
        v.text(c, fitText(v, item.name, 24f * u, r.width() - 560f * u), r.left + 210f * u, (y0 + y1) / 2f + 9f * u, 24f * u, col(0xCCFFFFFF))

        if (fullFor != idx && !fullBusy) {
            fullBusy = true
            val ctx = v.context
            MediaLoader.exec.execute {
                val b = MediaLoader.decode(ctx, item.uri, 1600)
                full = b
                fullFor = idx
                fullBusy = false
            }
        }
        val area = RectF(r.left + 8f * u, y1 + 8f * u, r.right - 8f * u, r.bottom - 8f * u)
        val bmp = if (fullFor == idx) full else MediaLoader.cached(item)
        if (bmp != null) {
            val s = min(area.width() / bmp.width, area.height() / bmp.height)
            val dw = bmp.width * s
            val dh = bmp.height * s
            rect.set(area.centerX() - dw / 2f, area.centerY() - dh / 2f, area.centerX() + dw / 2f, area.centerY() + dh / 2f)
            v.drawBmp(c, bmp, rect)
        } else {
            v.text(c, "Загрузка…", area.centerX(), area.centerY(), 30f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
        }
    }
}

// =====================================================================
//  Видеоплеер
// =====================================================================
class VideoApp : App("Видео", 920f, 660f), OnClose {
    @Volatile private var items: List<MediaItem>? = null
    private var loading = false
    private var page = 0
    private var playing: MediaItem? = null

    override fun onClose(v: VrView) {
        v.video?.stop()
    }

    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        if (!v.storageOk) {
            storagePrompt(v, c, w, r)
            return
        }
        val list = items
        if (list == null) {
            if (!loading) {
                loading = true
                val ctx = v.context
                MediaLoader.exec.execute { items = MediaLoader.queryVideos(ctx, 200) }
            }
            v.text(c, "Загрузка…", r.centerX(), r.centerY(), 32f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
            return
        }
        if (list.isEmpty()) {
            v.text(c, "Видео не найдено", r.centerX(), r.centerY(), 32f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
            return
        }
        val cur = playing
        if (cur == null) drawList(v, c, w, r, list) else drawPlayer(v, c, w, r, cur)
    }

    private fun drawList(v: VrView, c: Canvas, w: Win, r: RectF, list: List<MediaItem>) {
        val u = v.U
        val per = 7
        val pages = (list.size + per - 1) / per
        page = page.coerceIn(0, pages - 1)
        val pad = 12f * u
        val barH = 70f * u
        val rowH = (r.height() - 2 * pad - barH) / per
        val rect = RectF()
        for (k in 0 until per) {
            val idx = page * per + k
            if (idx >= list.size) break
            val it0 = list[idx]
            rect.set(r.left + pad, r.top + pad + k * rowH, r.right - pad, r.top + pad + (k + 1) * rowH - 8f * u)
            val label = fitText(v, it0.name, 26f * u, rect.width() - 160f * u) + "   " + fmtMs(it0.durMs.toInt())
            v.button(c, w, rect, label, 26f * u) {
                playing = it0
                v.video?.play(v.context, it0.uri)
            }
        }
        val by0 = r.bottom - barH + 6f * u
        val by1 = r.bottom - 10f * u
        rect.set(r.left + pad, by0, r.left + pad + 160f * u, by1)
        v.button(c, w, rect, "◀", 30f * u) { if (page > 0) page-- }
        rect.set(r.right - pad - 160f * u, by0, r.right - pad, by1)
        v.button(c, w, rect, "▶", 30f * u) { if (page < pages - 1) page++ }
        v.text(c, "Стр. ${page + 1} из $pages", r.centerX(), (by0 + by1) / 2f + 10f * u, 26f * u, col(0xCCFFFFFF), false, Paint.Align.CENTER)
    }

    private fun drawPlayer(v: VrView, c: Canvas, w: Win, r: RectF, item: MediaItem) {
        val u = v.U
        val host = v.video
        if (host == null) {
            v.text(c, "Видео недоступно", r.centerX(), r.centerY(), 32f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
            return
        }
        host.capture()
        val ctrlH = 150f * u
        val area = RectF(r.left + 8f * u, r.top + 8f * u, r.right - 8f * u, r.bottom - ctrlH)
        val s = min(area.width() / VideoHost.W, area.height() / VideoHost.H)
        val dw = VideoHost.W * s
        val dh = VideoHost.H * s
        val dst = RectF(area.centerX() - dw / 2f, area.centerY() - dh / 2f, area.centerX() + dw / 2f, area.centerY() + dh / 2f)
        v.fill(c, dst, 4f * u, col(0xFF000000))
        v.drawBmp(c, host.bmp, dst)
        if (host.error.isNotEmpty()) {
            v.text(c, host.error, dst.centerX(), dst.centerY(), 28f * u, col(0xFFFFB4B4), false, Paint.Align.CENTER)
        }

        val dur = host.duration()
        val pos = host.position()
        val sl = RectF(r.left + 40f * u, r.bottom - ctrlH + 14f * u, r.right - 40f * u, r.bottom - ctrlH + 54f * u)
        v.slider(c, w, sl, if (dur > 0) pos.toFloat() / dur else 0f) { host.seekTo((it * dur).toInt()) }
        v.text(c, fmtMs(pos) + " / " + fmtMs(dur), r.centerX(), sl.bottom + 30f * u, 24f * u, col(0xCCFFFFFF), false, Paint.Align.CENTER)

        val y0 = r.bottom - 72f * u
        val y1 = r.bottom - 12f * u
        val rect = RectF()
        var x = r.left + 12f * u
        rect.set(x, y0, x + 190f * u, y1)
        v.button(c, w, rect, "← Список", 26f * u, true) {
            host.stop()
            playing = null
        }
        x += 202f * u
        rect.set(x, y0, x + 150f * u, y1)
        v.button(c, w, rect, "-10 с", 26f * u) { host.seekTo(host.position() - 10000) }
        x += 162f * u
        rect.set(x, y0, x + 190f * u, y1)
        v.button(c, w, rect, if (host.isPlaying()) "Пауза" else "Играть", 28f * u, true) { host.toggle() }
        x += 202f * u
        rect.set(x, y0, x + 150f * u, y1)
        v.button(c, w, rect, "+10 с", 26f * u) { host.seekTo(host.position() + 10000) }
    }
}
