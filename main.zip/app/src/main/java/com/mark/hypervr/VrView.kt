package com.mark.hypervr

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import android.view.SoundEffectConstants
import android.view.View
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

internal fun col(v: Long): Int = v.toInt()

/** Окно приложения. Позиция задана в мировых координатах: угол по горизонтали (рад) и y верхнего края. */
class Win(var ang: Float, var wy: Float, var w: Float, var h: Float, val app: App) {
    val born: Long = SystemClock.uptimeMillis()
}

private class Env(
    val sky: IntArray, val skyPos: FloatArray,
    val water: IntArray, val waterPos: FloatArray,
    val ridge: IntArray, val fore: Int, val tree: Int,
    val core: Int, val glow: IntArray, val bodyAng: Float,
    val cloud: Int, val glint: Int, val stars: Boolean
)

private val ENVS = listOf(
    Env(
        intArrayOf(col(0xFF0E1A3A), col(0xFF3B4A7A), col(0xFFE08A6B), col(0xFFF6C58B)), floatArrayOf(0f, 0.45f, 0.82f, 1f),
        intArrayOf(col(0xFFE9A77A), col(0xFF35557A), col(0xFF0B1E33)), floatArrayOf(0f, 0.35f, 1f),
        intArrayOf(col(0xFF7A6E94), col(0xFF4C4270), col(0xFF2A2347)), col(0xFF100B20), col(0xFF0C0818),
        col(0xFFFFF4D6), intArrayOf(col(0xFFFFF2C8), col(0x88FFC27A), col(0x00FFB070)), 0.35f,
        col(0x55FFE4D0), col(0xFFFFD9A0), false
    ),
    Env(
        intArrayOf(col(0xFF02050F), col(0xFF0B1630), col(0xFF1B2D55), col(0xFF33496F)), floatArrayOf(0f, 0.45f, 0.82f, 1f),
        intArrayOf(col(0xFF2A4064), col(0xFF0F1D36), col(0xFF050B18)), floatArrayOf(0f, 0.35f, 1f),
        intArrayOf(col(0xFF263052), col(0xFF182040), col(0xFF0D1226)), col(0xFF05070F), col(0xFF03050A),
        col(0xFFE8F0FF), intArrayOf(col(0xFFE8F0FF), col(0x66AFC8FF), col(0x00AFC8FF)), -0.5f,
        col(0x25AFC8FF), col(0xFFC8DCFF), true
    )
)

class VrView(private val ctx: Context) : View(ctx) {

    private class Click(
        val rect: RectF, val owner: Any, val id: Int, val dwell: Boolean,
        val onPress: (Float, Float) -> Unit, val onDrag: ((Float, Float) -> Unit)?,
        val onRelease: (() -> Unit)? = null
    )

    private class Hit(val kind: Int, val win: Win?, val click: Click?)
    private class Snap(val bmp: Bitmap, val hands: List<HandData>, val t: Long)
    private class Cloud(var ang: Float, val y: Float, val s: Float, val speed: Float)

    var onExit: (() -> Unit)? = null
    @Volatile var status: String = ""
    @Volatile private var snap: Snap? = null

    // ---- настройки ОС ----
    private val prefs = ctx.getSharedPreferences("hypervr", Context.MODE_PRIVATE)
    internal var passthrough = prefs.getBoolean("passthrough", false)
    internal var handSkin = prefs.getBoolean("handSkin", true)
    internal var dwellOn = prefs.getBoolean("dwell", true)
    internal var envIndex = prefs.getInt("env", 0).coerceIn(0, ENVS.size - 1)
    internal var pinchK = prefs.getFloat("pinchK", 0.24f).coerceIn(0.15f, 0.35f)
    internal var depthV = prefs.getFloat("depthV", 0.5f).coerceIn(0f, 1f)
    internal var ipdV = prefs.getFloat("ipdV", 0.5f).coerceIn(0f, 1f)

    // ---- система окон ----
    private val windows = ArrayList<Win>()
    internal var web: WebHost? = null
    internal var video: VideoHost? = null
    internal var onRequestStorage: (() -> Unit)? = null
    internal var storageOk = false
    private var storageT = 99f
    private val srcRect = Rect()
    internal var focus: TextSink? = null
    private var booted = false

    // ---- геометрия ----
    private var ew = 0f
    private var eh = 0f
    private var u = 1f
    internal val U: Float get() = u
    private var pxPerRad = 1f

    // ---- голова ----
    private var yaw = 0f
    private var pitch = 0f
    private var lastYawRaw = 0f
    private var yawBias = 0f

    // ---- ввод ----
    private val handPts = Array(2) { FloatArray(42) }
    private var handCount = 0
    private val handSmOk = BooleanArray(2)
    private val handLive = BooleanArray(2)
    private val handLost = FloatArray(2)
    private val handPinch = FloatArray(2)
    private val handSeen = BooleanArray(2)
    private var primary = 0
    private var frameDt = 0.016f
    private var px = 0f
    private var py = 0f
    private var pValid = false
    private var pPressed = false
    private var touching = false
    private var tx = 0f
    private var ty = 0f
    private var hover: Hit? = null
    private var active: Hit? = null
    private var grabOffX = 0f
    private var grabOffY = 0f
    private var ownerAtPtr: Any? = null
    private var dwellId = 0
    private var dwellT = 0f
    private var dwellDone = false

    private val DOCK = Any()
    private val dockRect = RectF()
    private var clickCur = ArrayList<Click>()
    private var clickPrev = ArrayList<Click>()
    private var registering = false

    // ---- время/система ----
    private var lastT = System.nanoTime()
    private var time = 0f
    private var fpsAcc = 0f
    private var fpsN = 0
    internal var fps = 0f
    internal var timeStr = ""
    internal var dateStr = ""
    private var battery = -1
    private var batteryT = 99f
    private var timeT = 99f
    private val sdfTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val sdfDate = SimpleDateFormat("EEEE, d MMMM", Locale("ru"))
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val batteryMgr = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    // ---- рисовалки ----
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val r = RectF()
    private val wr = RectF()
    private val hr = RectF()
    private val normFace = Typeface.create("sans-serif", Typeface.NORMAL)
    private val boldFace = Typeface.create("sans-serif-medium", Typeface.BOLD)
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)

    private var skyShader: Shader? = null
    private var waterShader: Shader? = null
    private var sunShader: Shader? = null

    private val clouds = ArrayList<Cloud>()
    private val shAng = FloatArray(40) { wrapAng(it * 2.399f) }
    private val shY = FloatArray(40) { ((it * 0.618f) % 1f) }
    private val shLen = FloatArray(40) { 40f + ((it * 37) % 100) }
    private val starAng = FloatArray(90) { wrapAng(it * 2.399f * 1.7f) }
    private val starY = FloatArray(90) { ((it * 0.371f) % 1f) }
    private val treeCount = 30
    private val treeAng = FloatArray(treeCount) { wrapAng(it * TWO_PI / treeCount + ((it * 37) % 11) * 0.01f) }

    init {
        for (i in 0 until 8) {
            clouds.add(Cloud(wrapAng(i * 0.8f), 0.08f + ((i * 29) % 30) / 100f, 0.7f + ((i * 13) % 10) / 10f, 0.004f + (i % 3) * 0.002f))
        }
    }

    // =====================================================================
    //  API для системы и приложений
    // =====================================================================

    fun setFrame(bmp: Bitmap, hands: List<HandData>) {
        snap = Snap(bmp, hands, SystemClock.uptimeMillis())
    }

    /** Матрица поворота устройства -> мир. Направление взгляда = задняя камера (-Z устройства). */
    fun onRotationMatrix(m: FloatArray) {
        val fx = -m[2]
        val fy = -m[5]
        val fz = -m[8]
        lastYawRaw = atan2(fx, fy)
        pitch = asin(fz.coerceIn(-1f, 1f))
        yaw = wrapAng(lastYawRaw - yawBias)
    }

    internal fun saveSettings() {
        prefs.edit()
            .putBoolean("passthrough", passthrough)
            .putBoolean("handSkin", handSkin)
            .putBoolean("dwell", dwellOn)
            .putInt("env", envIndex)
            .putFloat("pinchK", pinchK)
            .putFloat("depthV", depthV)
            .putFloat("ipdV", ipdV)
            .apply()
    }

    internal fun loadNotes(): String = prefs.getString("notes", "") ?: ""
    internal fun saveNotes(s: String) {
        prefs.edit().putString("notes", s).apply()
    }

    internal fun togglePass() {
        passthrough = !passthrough
        saveSettings()
    }

    internal fun setEnv(i: Int) {
        envIndex = i.coerceIn(0, ENVS.size - 1)
        buildShaders()
        saveSettings()
    }

    internal fun getVolume(): Float {
        return try {
            audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                max(1, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
        } catch (e: Exception) {
            0.5f
        }
    }

    internal fun setVolume(f: Float) {
        try {
            val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (f * mx).toInt().coerceIn(0, mx), 0)
        } catch (e: Exception) {
        }
    }

    internal fun requestStorage() {
        onRequestStorage?.invoke()
    }

    internal fun refreshStorage() {
        var ok = true
        for (perm in requiredPerms()) {
            if (ContextCompat.checkSelfPermission(ctx, perm) != PackageManager.PERMISSION_GRANTED) ok = false
        }
        storageOk = ok
    }

    internal fun drawBmpCrop(c: Canvas, bmp: Bitmap, dst: RectF) {
        val bw = bmp.width.toFloat()
        val bh = bmp.height.toFloat()
        val dr = dst.width() / dst.height()
        var sl = 0f
        var st = 0f
        var sr = bw
        var sb = bh
        if (bw / bh > dr) {
            val nw = bh * dr
            sl = (bw - nw) / 2f
            sr = sl + nw
        } else {
            val nh = bw / dr
            st = (bh - nh) / 2f
            sb = st + nh
        }
        srcRect.set(sl.toInt(), st.toInt(), sr.toInt(), sb.toInt())
        c.drawBitmap(bmp, srcRect, dst, bmpPaint)
    }

    internal fun launch(info: AppInfo) {
        val ex = windows.firstOrNull { it.app.name == info.name }
        if (ex != null) {
            front(ex)
            centerWin(ex)
            return
        }
        spawn(info.factory())
    }

    internal fun closeWin(w: Win) {
        windows.remove(w)
        val a = w.app
        if (a is TextSink && focus === a) focus = null
        if (a is OnClose) a.onClose(this)
        if (active?.win === w) active = null
        hover = null
    }

    internal fun openKeyboard(near: Win) {
        val ex = windows.firstOrNull { it.app is KeyboardApp }
        if (ex != null) {
            front(ex)
            return
        }
        val kw = spawn(KeyboardApp())
        kw.ang = near.ang
        kw.wy = near.wy + near.h + 16f * u
    }

    private fun front(w: Win) {
        windows.remove(w)
        windows.add(w)
    }

    private fun centerWin(w: Win) {
        w.ang = yaw
        w.wy = (eh - w.h) / 2f - pitchOff()
    }

    private fun spawn(app: App): Win {
        val ww = min(app.defW * u, ew * 0.94f)
        val hh = min(app.defH * u, eh * 0.92f)
        val casc = windows.size % 4
        val w = Win(yaw + casc * 0.05f, (eh - hh) / 2f - pitchOff() + casc * 24f * u, ww, hh, app)
        windows.add(w)
        return w
    }

    private fun gatherWindows() {
        if (windows.isEmpty()) return
        var total = 0f
        for (w in windows) total += w.w / pxPerRad + 0.06f
        var a = yaw - total / 2f
        for (w in windows) {
            val span = w.w / pxPerRad
            w.ang = a + span / 2f
            w.wy = (eh - w.h) / 2f - pitchOff() - 40f * u
            a += span + 0.06f
        }
    }

    // ---- примитивы для приложений ----

    internal fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT
    ) {
        tp.textSize = size
        tp.color = color
        tp.textAlign = align
        tp.typeface = if (bold) boldFace else normFace
        c.drawText(s, x, y, tp)
    }

    internal fun measure(s: String, size: Float, bold: Boolean = false): Float {
        tp.textSize = size
        tp.typeface = if (bold) boldFace else normFace
        return tp.measureText(s)
    }

    internal fun wrapLines(s: String, size: Float, maxW: Float): List<String> {
        tp.textSize = size
        tp.typeface = normFace
        val out = ArrayList<String>()
        for (para in s.split('\n')) {
            var rest = para
            if (rest.isEmpty()) out.add("")
            while (rest.isNotEmpty()) {
                var n = tp.breakText(rest, true, maxW, null)
                if (n <= 0) n = 1
                out.add(rest.substring(0, n))
                rest = rest.substring(n)
            }
        }
        return out
    }

    internal fun fill(c: Canvas, rect: RectF, rad: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawRoundRect(rect, rad, rad, p)
    }

    internal fun strokeRound(c: Canvas, rect: RectF, rad: Float, width: Float, color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = width
        p.color = color
        c.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.FILL
    }

    internal fun fillCircle(c: Canvas, x: Float, y: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawCircle(x, y, rad, p)
    }

    internal fun button(
        c: Canvas, owner: Any, rect: RectF, label: String, size: Float,
        accent: Boolean = false, dwell: Boolean = true, onClick: () -> Unit
    ) {
        val hov = pValid && owner === ownerAtPtr && rect.contains(px, py)
        val id = label.hashCode() * 31 + System.identityHashCode(owner)
        val color = when {
            hov && pPressed -> col(0xFF4FC3F7)
            hov -> col(0xFF35506E)
            accent -> col(0xFF1E4E6E)
            else -> col(0xFF1B2A3C)
        }
        fill(c, rect, 14f * u, color)
        if (label.isNotEmpty()) {
            text(c, label, rect.centerX(), rect.centerY() + size * 0.35f, size, col(0xFFFFFFFF), true, Paint.Align.CENTER)
        }
        if (hov && dwell && dwellOn && id == dwellId && !dwellDone && dwellT > 0f) {
            p.style = Paint.Style.FILL
            p.color = col(0xFF4FC3F7)
            c.drawRect(rect.left + 10f * u, rect.bottom - 7f * u, rect.left + 10f * u + (rect.width() - 20f * u) * (dwellT / DWELL), rect.bottom - 3f * u, p)
        }
        if (registering) clickCur.add(Click(RectF(rect), owner, id, dwell, { _, _ -> onClick() }, null))
    }

    internal fun hotspot(owner: Any, rect: RectF, id: Int, onClick: () -> Unit) {
        if (registering) clickCur.add(Click(RectF(rect), owner, id, false, { _, _ -> onClick() }, null))
    }

    internal fun drawBmp(c: Canvas, bmp: Bitmap, dst: RectF) {
        c.drawBitmap(bmp, null, dst, bmpPaint)
    }

    internal fun pointerArea(
        owner: Any, rect: RectF, id: Int,
        down: (Float, Float) -> Unit, move: (Float, Float) -> Unit, up: () -> Unit
    ) {
        if (registering) clickCur.add(Click(RectF(rect), owner, id, false, down, move, up))
    }

    internal fun slider(c: Canvas, owner: Any, rect: RectF, value: Float, onChange: (Float) -> Unit) {
        val v = value.coerceIn(0f, 1f)
        val cy = rect.centerY()
        r.set(rect.left, cy - 5f * u, rect.right, cy + 5f * u)
        fill(c, r, 5f * u, col(0xFF2A3B50))
        r.set(rect.left, cy - 5f * u, rect.left + rect.width() * v, cy + 5f * u)
        fill(c, r, 5f * u, col(0xFF4FC3F7))
        fillCircle(c, rect.left + rect.width() * v, cy, 20f * u, col(0xFFFFFFFF))
        if (registering) {
            val rc = RectF(rect)
            val h: (Float, Float) -> Unit = { x, _ -> onChange(((x - rc.left) / rc.width()).coerceIn(0f, 1f)) }
            clickCur.add(Click(rc, owner, 5, false, h, h))
        }
    }

    // =====================================================================
    //  Размеры, шейдеры
    // =====================================================================

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        ew = w / 2f
        eh = h.toFloat()
        u = eh / 1080f
        pxPerRad = ew * 0.7f
        buildShaders()
        if (!booted) {
            booted = true
            launch(LAUNCHER_INFO)
        }
    }

    private fun buildShaders() {
        if (ew <= 0f) return
        val e = ENVS[envIndex]
        val hy = eh * 0.58f
        skyShader = LinearGradient(0f, 0f, 0f, hy, e.sky, e.skyPos, Shader.TileMode.CLAMP)
        waterShader = LinearGradient(0f, hy, 0f, eh, e.water, e.waterPos, Shader.TileMode.CLAMP)
        sunShader = RadialGradient(0f, 0f, 260f * u, e.glow, floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP)
    }

    // =====================================================================
    //  Ввод
    // =====================================================================

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touching = true
                val x = ev.x
                tx = if (x < ew) x else x - ew
                ty = ev.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }

    private fun mapHands() {
        val sn = snap
        if (sn == null || SystemClock.uptimeMillis() - sn.t > 500) {
            for (i in 0..1) {
                handLive[i] = false
                handSmOk[i] = false
            }
            handCount = 0
            return
        }
        val fw = sn.bmp.width.toFloat()
        val fh = sn.bmp.height.toFloat()
        val s = max(ew / fw, eh / fh)
        val ox = (ew - fw * s) / 2f
        val oy = (eh - fh * s) / 2f
        val k = 1f - exp(-frameDt * 28f)
        val kp = 1f - exp(-frameDt * 45f)
        handSeen[0] = false
        handSeen[1] = false
        for (h in sn.hands) {
            val wx = ox + h.xy[0] * fw * s
            val wy = oy + h.xy[1] * fh * s
            // сопоставляем с уже отслеживаемой рукой по близости запястья
            var slot = -1
            var bd = Float.MAX_VALUE
            for (i in 0..1) {
                if (!handSeen[i] && handLive[i]) {
                    val d = hypot(wx - handPts[i][0], wy - handPts[i][1])
                    if (d < bd) {
                        bd = d
                        slot = i
                    }
                }
            }
            if (slot >= 0 && bd > ew * 0.45f) slot = -1
            if (slot < 0) {
                for (i in 0..1) {
                    if (!handSeen[i] && !handLive[i]) {
                        slot = i
                        break
                    }
                }
            }
            if (slot < 0) continue
            handSeen[slot] = true
            val dst = handPts[slot]
            val smooth = handSmOk[slot]
            for (i in 0 until 21) {
                val tx0 = ox + h.xy[2 * i] * fw * s
                val ty0 = oy + h.xy[2 * i + 1] * fh * s
                if (smooth) {
                    dst[2 * i] += (tx0 - dst[2 * i]) * k
                    dst[2 * i + 1] += (ty0 - dst[2 * i + 1]) * k
                } else {
                    dst[2 * i] = tx0
                    dst[2 * i + 1] = ty0
                }
            }
            handPinch[slot] = if (smooth) handPinch[slot] + (h.pinch - handPinch[slot]) * kp else h.pinch
            handSmOk[slot] = true
            handLive[slot] = true
            handLost[slot] = 0f
        }
        // потерянную руку удерживаем HOLD секунд (поворот ладони, кратковременное перекрытие)
        for (i in 0..1) {
            if (!handSeen[i] && handLive[i]) {
                handLost[i] += frameDt
                if (handLost[i] > HOLD) {
                    handLive[i] = false
                    handSmOk[i] = false
                }
            }
        }
        handCount = (if (handLive[0]) 1 else 0) + (if (handLive[1]) 1 else 0)
        if (!handLive[primary] && handLive[1 - primary]) primary = 1 - primary
    }

    private fun pitchOff(): Float = pitch * pxPerRad

    private fun winRect(w: Win, out: RectF) {
        val cx = ew / 2f + wrapAng(w.ang - yaw) * pxPerRad
        val top = w.wy + pitchOff()
        out.set(cx - w.w / 2f, top, cx + w.w / 2f, top + w.h)
    }

    private fun ownerAt(x: Float, y: Float): Any? {
        if (dockRect.contains(x, y)) return DOCK
        for (i in windows.indices.reversed()) {
            winRect(windows[i], hr)
            if (hr.contains(x, y)) return windows[i]
        }
        return null
    }

    private fun hitTest(x: Float, y: Float): Hit? {
        for (i in clickPrev.indices.reversed()) {
            val cl = clickPrev[i]
            if (cl.owner === DOCK && cl.rect.contains(x, y)) return Hit(K_CLICK, null, cl)
        }
        for (i in windows.indices.reversed()) {
            val w = windows[i]
            winRect(w, hr)
            if (!hr.contains(x, y)) continue
            val ccx = hr.right - 34f * u
            val ccy = hr.top + 32f * u
            if (hypot(x - ccx, y - ccy) < 28f * u) return Hit(K_CLOSE, w, null)
            if (y < hr.top + TITLE * u) return Hit(K_TITLE, w, null)
            if (x > hr.right - 56f * u && y > hr.bottom - 56f * u) return Hit(K_RESIZE, w, null)
            for (j in clickPrev.indices.reversed()) {
                val cl = clickPrev[j]
                if (cl.owner === w && cl.rect.contains(x, y)) return Hit(K_CLICK, w, cl)
            }
            return Hit(K_BODY, w, null)
        }
        return null
    }

    private fun updateInput(dt: Float) {
        mapHands()
        var valid = false
        var now = false

        if (touching) {
            px = tx
            py = ty
            valid = true
            now = true
        } else if (handCount > 0) {
            val pi = primary
            val q = handPts[pi]
            val d = handPinch[pi]
            // курсор плавно переходит от кончика указательного к точке щипка
            val a = ((0.07f - d) / 0.045f).coerceIn(0f, 1f)
            px = q[16] + ((q[8] + q[16]) / 2f - q[16]) * a
            py = q[17] + ((q[9] + q[17]) / 2f - q[17]) * a
            valid = true
            val on = pinchK * 0.14f
            now = if (pPressed) d < on * 1.6f else d < on
            val o = 1 - pi
            if (handLive[o] && !now && handPinch[o] < on && handPinch[pi] > on * 1.6f) primary = o
        }

        ownerAtPtr = if (valid) ownerAt(px, py) else null

        if (!valid) {
            hover = null
        } else if (touching) {
            if (!pPressed) hover = hitTest(px, py)
        } else if (!now) {
            hover = hitTest(px, py)
        }
        pValid = valid

        val down = now && !pPressed
        val up = !now && pPressed
        if (down) {
            val h = hover
            active = h
            if (h != null) {
                if (h.kind == K_CLICK) playSoundEffect(SoundEffectConstants.CLICK)
                val w = h.win
                when (h.kind) {
                    K_CLICK -> h.click?.onPress?.invoke(px, py)
                    K_CLOSE -> if (w != null) closeWin(w)
                    K_TITLE -> if (w != null) {
                        front(w)
                        winRect(w, hr)
                        grabOffX = px - hr.left
                        grabOffY = py - hr.top
                    }
                    K_RESIZE -> if (w != null) {
                        front(w)
                        winRect(w, hr)
                        grabOffX = px - hr.right
                        grabOffY = py - hr.bottom
                    }
                    K_BODY -> if (w != null) front(w)
                }
                if (h.kind == K_CLICK && w != null) front(w)
            }
            hover = null
        }
        if (up || !valid) {
            active?.click?.onRelease?.invoke()
            active = null
        }

        val a = active
        if (now && a != null) {
            val w = a.win
            when (a.kind) {
                K_TITLE -> if (w != null) {
                    val left = px - grabOffX
                    w.ang = yaw + (left + w.w / 2f - ew / 2f) / pxPerRad
                    w.wy = py - grabOffY - pitchOff()
                }
                K_RESIZE -> if (w != null) {
                    winRect(w, hr)
                    val left = hr.left
                    val nw = max(MIN_W * u, px - grabOffX - left)
                    val nh = max(MIN_H * u, py - grabOffY - hr.top)
                    w.w = nw
                    w.h = nh
                    w.ang = yaw + (left + nw / 2f - ew / 2f) / pxPerRad
                }
                K_CLICK -> a.click?.onDrag?.invoke(px, py)
            }
        }
        pPressed = now

        // нажатие задержкой пальца
        val hv = hover
        val hc = hv?.click
        if (dwellOn && !now && !touching && valid && hv != null && hv.kind == K_CLICK && hc != null && hc.dwell) {
            if (hc.id != dwellId) {
                dwellId = hc.id
                dwellT = 0f
                dwellDone = false
            } else if (!dwellDone) {
                dwellT += dt
                if (dwellT >= DWELL) {
                    dwellDone = true
                    playSoundEffect(SoundEffectConstants.CLICK)
                    hc.onPress(px, py)
                }
            }
        } else {
            dwellId = 0
            dwellT = 0f
            dwellDone = false
        }
    }

    // =====================================================================
    //  Кадр
    // =====================================================================

    override fun onDraw(c: Canvas) {
        if (ew <= 0f) return
        val now = System.nanoTime()
        val dt = ((now - lastT) / 1e9f).coerceIn(0f, 0.1f)
        lastT = now
        time += dt
        fpsAcc += dt
        fpsN++
        if (fpsAcc >= 1f) {
            fps = fpsN / fpsAcc
            fpsN = 0
            fpsAcc = 0f
            dateStr = sdfDate.format(Date())
        }
        batteryT += dt
        if (batteryT > 10f) {
            batteryT = 0f
            battery = try {
                batteryMgr.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            } catch (e: Exception) {
                -1
            }
        }
        timeT += dt
        if (timeT > 0.25f) {
            timeT = 0f
            val d = Date()
            timeStr = sdfTime.format(d)
            dateStr = sdfDate.format(d)
        }
        storageT += dt
        if (storageT > 1f) {
            storageT = 0f
            refreshStorage()
        }
        for (cl in clouds) cl.ang = wrapAng(cl.ang + cl.speed * dt)

        val tmp = clickPrev
        clickPrev = clickCur
        clickCur = tmp
        clickCur.clear()

        frameDt = dt
        updateInput(dt)

        c.drawColor(col(0xFF000000))
        for (e in 0..1) {
            registering = e == 0
            c.save()
            c.clipRect(e * ew, 0f, (e + 1) * ew, eh)
            val ipd = (ipdV - 0.5f) * 160f * u
            c.translate(e * ew + (if (e == 0) -ipd else ipd), 0f)
            drawEye(c, if (e == 0) 1f else -1f)
            c.restore()
        }
        registering = false
        p.style = Paint.Style.FILL
        p.color = col(0x40FFFFFF)
        c.drawRect(ew - 1f, 0f, ew + 1f, eh, p)

        postInvalidateOnAnimation()
    }

    private fun drawEye(c: Canvas, sgn: Float) {
        if (passthrough) drawCamera(c) else drawEnvironment(c)

        c.save()
        c.translate(sgn * depthV * 20f * u, 0f)
        drawWindows(c)
        drawDock(c)
        for (i in 0..1) if (handLive[i]) drawHand(c, handPts[i], passthrough || !handSkin)
        drawCursor(c)
        c.restore()

        val msg = if (status.isNotEmpty()) status else if (handCount == 0) "Покажи руку камере" else ""
        if (msg.isNotEmpty()) text(c, msg, ew / 2f, dockRect.top - 16f * u, 24f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
    }

    // ---------------------------------------------------------------- окна и док

    private fun drawWindows(c: Canvas) {
        for (i in windows.indices) {
            val w = windows[i]
            winRect(w, wr)
            if (wr.right < -100f * u || wr.left > ew + 100f * u) continue
            val top = i == windows.size - 1
            val rc = RectF(wr)
            val age = ((SystemClock.uptimeMillis() - w.born) / 220f).coerceIn(0f, 1f)
            val sc = 0.88f + 0.12f * (1f - (1f - age) * (1f - age))
            c.save()
            c.scale(sc, sc, rc.centerX(), rc.centerY())

            fill(c, rc, 24f * u, col(0xE60C121C))
            c.save()
            c.clipRect(rc.left, rc.top, rc.right, rc.top + TITLE * u)
            fill(c, rc, 24f * u, if (top) col(0xFF2B4258) else col(0xF0243447))
            c.restore()
            text(c, w.app.name, rc.left + 26f * u, rc.top + 42f * u, 28f * u, col(0xFFFFFFFF), true)

            // кнопка закрытия
            val ccx = rc.right - 34f * u
            val ccy = rc.top + 32f * u
            val hovClose = pValid && ownerAtPtr === w && hypot(px - ccx, py - ccy) < 28f * u
            fillCircle(c, ccx, ccy, 22f * u, if (hovClose) col(0xFFE5484D) else col(0x55FFFFFF))
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3.5f * u
            p.strokeCap = Paint.Cap.ROUND
            p.color = col(0xFFFFFFFF)
            c.drawLine(ccx - 8f * u, ccy - 8f * u, ccx + 8f * u, ccy + 8f * u, p)
            c.drawLine(ccx - 8f * u, ccy + 8f * u, ccx + 8f * u, ccy - 8f * u, p)

            // уголок изменения размера
            p.strokeWidth = 3f * u
            p.color = col(0x99FFFFFF)
            c.drawLine(rc.right - 14f * u, rc.bottom - 30f * u, rc.right - 30f * u, rc.bottom - 14f * u, p)
            c.drawLine(rc.right - 14f * u, rc.bottom - 18f * u, rc.right - 18f * u, rc.bottom - 14f * u, p)
            p.strokeCap = Paint.Cap.BUTT

            val cr = RectF(rc.left, rc.top + TITLE * u, rc.right, rc.bottom)
            c.save()
            c.clipRect(cr)
            w.app.draw(this, c, w, cr)
            c.restore()
            c.restore()
        }
    }

    private fun drawDock(c: Canvas) {
        val dw = min(1000f * u, ew * 0.94f)
        val dh = 96f * u
        dockRect.set(ew / 2f - dw / 2f, eh - dh - 34f * u, ew / 2f + dw / 2f, eh - 34f * u)
        fill(c, dockRect, 48f * u, col(0xD9101A28))
        val iw = dw - 32f * u
        val gap = 10f * u
        val top = dockRect.top + 14f * u
        val bot = dockRect.bottom - 14f * u
        var x = dockRect.left + 16f * u
        val rect = RectF()

        rect.set(x, top, x + iw * 0.27f, bot)
        button(c, DOCK, rect, "Приложения", 26f * u, true) { launch(LAUNCHER_INFO) }
        x += iw * 0.27f + gap

        rect.set(x, top, x + iw * 0.19f, bot)
        button(c, DOCK, rect, "Собрать", 26f * u) { gatherWindows() }
        x += iw * 0.19f + gap

        rect.set(x, top, x + iw * 0.27f, bot)
        button(c, DOCK, rect, if (passthrough) "Фон: Камера" else "Фон: Среда", 26f * u) { togglePass() }

        val info = if (battery >= 0) timeStr.substring(0, 5) + "  " + battery + "%" else timeStr.substring(0, 5)
        text(c, info, dockRect.right - 24f * u, dockRect.centerY() + 10f * u, 30f * u, col(0xFFFFFFFF), true, Paint.Align.RIGHT)
    }

    private fun drawCursor(c: Canvas) {
        if (!pValid) return
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f * u
        p.color = col(0xFFFFFFFF)
        c.drawCircle(px, py, 20f * u, p)
        if (pPressed) {
            p.style = Paint.Style.FILL
            p.color = col(0xAA4FC3F7)
            c.drawCircle(px, py, 14f * u, p)
        } else if (dwellId != 0 && !dwellDone && dwellT > 0f) {
            p.style = Paint.Style.STROKE
            p.color = col(0xFF4FC3F7)
            p.strokeWidth = 6f * u
            hr.set(px - 28f * u, py - 28f * u, px + 28f * u, py + 28f * u)
            c.drawArc(hr, -90f, 360f * dwellT / DWELL, false, p)
        }
        p.style = Paint.Style.FILL
    }

    // ---------------------------------------------------------------- Passthrough

    private fun drawCamera(c: Canvas) {
        val f = snap?.bmp
        if (f != null) {
            val s = max(ew / f.width, eh / f.height)
            val dw = f.width * s
            val dh = f.height * s
            r.set((ew - dw) / 2f, (eh - dh) / 2f, (ew + dw) / 2f, (eh + dh) / 2f)
            c.drawBitmap(f, null, r, bmpPaint)
        } else {
            c.drawColor(col(0xFF0A0A10))
            text(c, "Нет изображения с камеры", ew / 2f, eh / 2f, 36f * u, col(0x88FFFFFF), false, Paint.Align.CENTER)
        }
    }

    // ---------------------------------------------------------------- Среда «Дом»

    private fun rf(a: Float, k1: Int, k2: Int, k3: Int, ph: Float): Float =
        0.6f * sin(k1 * a + ph) + 0.3f * sin(k2 * a + ph * 1.7f) + 0.1f * sin(k3 * a + ph * 2.3f)

    private fun ridge(
        c: Canvas, baseY: Float, amp: Float, k1: Int, k2: Int, k3: Int,
        ph: Float, color: Int, bottom: Float
    ) {
        path.reset()
        path.moveTo(-8f, bottom)
        var x = -8f
        while (x <= ew + 8f) {
            val a = yaw + (x - ew / 2f) / pxPerRad
            path.lineTo(x, baseY - amp * (0.5f + 0.5f * rf(a, k1, k2, k3, ph)))
            x += 8f
        }
        path.lineTo(ew + 8f, bottom)
        path.close()
        p.style = Paint.Style.FILL
        p.color = color
        c.drawPath(path, p)
    }

    private fun drawEnvironment(c: Canvas) {
        val e = ENVS[envIndex]
        val hy = eh * 0.58f
        c.save()
        c.translate(0f, pitchOff().coerceIn(-eh * 0.45f, eh * 0.45f))

        p.style = Paint.Style.FILL
        p.shader = skyShader
        c.drawRect(0f, -eh * 2f, ew, hy + 2f, p)
        p.shader = null

        if (e.stars) {
            p.color = col(0xFFFFFFFF)
            for (i in 0 until 90) {
                val x = ew / 2f + wrapAng(starAng[i] - yaw) * pxPerRad
                if (abs(x - ew / 2f) > ew / 2f + 10f) continue
                val y = starY[i] * hy * 0.85f - eh * 0.2f
                p.alpha = (110 + 140 * (0.5f + 0.5f * sin(time * 2f + i))).toInt().coerceIn(0, 255)
                c.drawCircle(x, y, (1.2f + (i % 3)) * u, p)
            }
            p.alpha = 255
        }

        val sx = ew / 2f + wrapAng(e.bodyAng - yaw) * pxPerRad
        val sy = hy - 70f * u
        if (abs(sx - ew / 2f) < ew / 2f + 300f * u) {
            c.save()
            c.translate(sx, sy)
            p.shader = sunShader
            c.drawCircle(0f, 0f, 260f * u, p)
            p.shader = null
            p.color = e.core
            c.drawCircle(0f, 0f, 46f * u, p)
            c.restore()
        }

        p.color = e.cloud
        for (cl in clouds) {
            val cx = ew / 2f + wrapAng(cl.ang - yaw) * pxPerRad
            if (abs(cx - ew / 2f) > ew / 2f + 200f * u) continue
            val cy = eh * cl.y
            val s = cl.s * u
            r.set(cx - 130f * s, cy - 24f * s, cx + 130f * s, cy + 24f * s)
            c.drawOval(r, p)
            r.set(cx - 80f * s, cy - 50f * s, cx + 60f * s, cy + 10f * s)
            c.drawOval(r, p)
            r.set(cx - 20f * s, cy - 40f * s, cx + 110f * s, cy + 14f * s)
            c.drawOval(r, p)
        }

        ridge(c, hy, 170f * u, 2, 5, 11, 0.4f, e.ridge[0], hy + 2f)
        ridge(c, hy, 120f * u, 3, 7, 13, 2.1f, e.ridge[1], hy + 2f)
        ridge(c, hy, 80f * u, 4, 9, 17, 4.0f, e.ridge[2], hy + 2f)

        p.style = Paint.Style.FILL
        p.shader = waterShader
        c.drawRect(0f, hy, ew, eh * 3f, p)
        p.shader = null

        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f * u
        for (i in 0 until 40) {
            val x = ew / 2f + wrapAng(shAng[i] - yaw) * pxPerRad
            if (abs(x - ew / 2f) > ew / 2f + 100f * u) continue
            val y = hy + 14f * u + shY[i] * (eh * 0.88f - hy)
            p.color = e.glint
            p.alpha = (30f + 80f * (0.5f + 0.5f * sin(time * 1.7f + i))).toInt()
            c.drawLine(x - shLen[i] * u / 2f, y, x + shLen[i] * u / 2f, y, p)
        }
        if (abs(sx - ew / 2f) < ew / 2f + 300f * u) {
            for (i in 0 until 18) {
                val y = hy + 8f * u + i * i * 1.3f * u + i * 6f * u
                val half = (24f + i * 8f) * u * (0.5f + 0.5f * sin(time * 2.3f + i * 1.7f))
                p.color = e.glint
                p.alpha = max(20, 170 - i * 8)
                c.drawLine(sx - half, y, sx + half, y, p)
            }
        }
        p.alpha = 255
        p.strokeCap = Paint.Cap.BUTT

        val fBase = eh * 0.9f
        val fAmp = 60f * u
        ridge(c, fBase, fAmp, 2, 6, 10, 1.3f, e.fore, eh * 3f)
        p.style = Paint.Style.FILL
        p.color = e.tree
        for (i in 0 until treeCount) {
            val x = ew / 2f + wrapAng(treeAng[i] - yaw) * pxPerRad
            if (abs(x - ew / 2f) > ew / 2f + 120f * u) continue
            val h = (80f + ((i * 53) % 90)) * u
            val by = fBase - fAmp * (0.5f + 0.5f * rf(treeAng[i], 2, 6, 10, 1.3f)) + 8f * u
            for (l in 0..2) {
                val yt = by - h * (1f - l * 0.28f)
                val yb = yt + h * 0.5f
                val hw = h * 0.32f * (0.55f + 0.5f * l)
                path.reset()
                path.moveTo(x, yt)
                path.lineTo(x - hw, yb)
                path.lineTo(x + hw, yb)
                path.close()
                c.drawPath(path, p)
            }
        }
        c.restore()
    }

    // ---------------------------------------------------------------- Рука

    private fun handShape(c: Canvas, q: FloatArray, s: Float, extra: Float) {
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        var dx = q[0] - q[18]
        var dy = q[1] - q[19]
        val dl = max(hypot(dx, dy), 1f)
        dx /= dl
        dy /= dl
        p.style = Paint.Style.STROKE
        p.strokeWidth = 0.24f * s + extra
        c.drawLine(q[0], q[1], q[0] + dx * s * 0.8f, q[1] + dy * s * 0.8f, p)

        path.reset()
        path.moveTo(q[0], q[1])
        for (idx in PALM) path.lineTo(q[2 * idx], q[2 * idx + 1])
        path.close()
        p.style = Paint.Style.FILL_AND_STROKE
        p.strokeWidth = 0.2f * s + extra
        c.drawPath(path, p)

        p.style = Paint.Style.STROKE
        for (fi in FINGERS.indices) {
            val f = FINGERS[fi]
            val w0 = when (fi) {
                0 -> 0.24f
                4 -> 0.17f
                else -> 0.2f
            }
            val w1 = w0 * 0.75f
            for (k in 0..2) {
                p.strokeWidth = (w0 + (w1 - w0) * k / 2f) * s + extra
                c.drawLine(q[2 * f[k]], q[2 * f[k] + 1], q[2 * f[k + 1]], q[2 * f[k + 1] + 1], p)
            }
        }
    }

    private fun drawHand(c: Canvas, q: FloatArray, outlineOnly: Boolean) {
        val s = max(hypot(q[0] - q[18], q[1] - q[19]), 20f)
        if (outlineOnly) {
            var minX = Float.MAX_VALUE
            var minY = Float.MAX_VALUE
            var maxX = -Float.MAX_VALUE
            var maxY = -Float.MAX_VALUE
            for (i in 0 until 21) {
                minX = min(minX, q[2 * i]); maxX = max(maxX, q[2 * i])
                minY = min(minY, q[2 * i + 1]); maxY = max(maxY, q[2 * i + 1])
            }
            val m = s * 1.2f
            c.saveLayer(minX - m, minY - m, maxX + m, maxY + m, null)
            p.color = col(0x404FC3F7)
            handShape(c, q, s, 0.34f * s)
            p.color = col(0xE6FFFFFF)
            handShape(c, q, s, 0.09f * s)
            p.xfermode = clearMode
            p.color = col(0xFF000000)
            handShape(c, q, s, 0f)
            p.xfermode = null
            c.restore()
            return
        }

        p.color = col(0x304FC3F7)
        handShape(c, q, s, 0.34f * s)
        p.color = col(0xF0E9F6FF)
        handShape(c, q, s, 0.08f * s)
        p.color = col(0xFFD7A084)
        handShape(c, q, s, 0f)

        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 0.05f * s
        p.color = col(0x35FFFFFF)
        for (f in FINGERS) {
            for (k in 0..2) c.drawLine(q[2 * f[k]], q[2 * f[k] + 1], q[2 * f[k + 1]], q[2 * f[k + 1] + 1], p)
        }

        p.strokeWidth = 0.022f * s
        p.color = col(0x60733A2B)
        for (f in FINGERS) {
            for (k in 1..2) {
                val ax = q[2 * f[k + 1]] - q[2 * f[k - 1]]
                val ay = q[2 * f[k + 1] + 1] - q[2 * f[k - 1] + 1]
                val l = max(hypot(ax, ay), 1f)
                val nx = -ay / l
                val ny = ax / l
                val cx = q[2 * f[k]]
                val cy = q[2 * f[k] + 1]
                val h = 0.07f * s
                c.drawLine(cx - nx * h, cy - ny * h, cx + nx * h, cy + ny * h, p)
            }
        }

        p.style = Paint.Style.FILL
        p.color = col(0xB0F6E0D8)
        for (f in FINGERS) {
            val tx1 = q[2 * f[3]]
            val ty1 = q[2 * f[3] + 1]
            val ax = tx1 - q[2 * f[2]]
            val ay = ty1 - q[2 * f[2] + 1]
            val l = max(hypot(ax, ay), 1f)
            val ang = Math.toDegrees(atan2(ay, ax).toDouble()).toFloat()
            c.save()
            c.translate(tx1 - ax / l * 0.045f * s, ty1 - ay / l * 0.045f * s)
            c.rotate(ang)
            r.set(-0.07f * s, -0.05f * s, 0.07f * s, 0.05f * s)
            c.drawOval(r, p)
            c.restore()
        }
    }

    companion object {
        private const val DISPARITY = 10f
        private const val DWELL = 1.4f
        private const val HOLD = 0.3f
        private const val TITLE = 64f
        private const val MIN_W = 320f
        private const val MIN_H = 240f
        private const val K_CLICK = 1
        private const val K_CLOSE = 2
        private const val K_TITLE = 3
        private const val K_RESIZE = 4
        private const val K_BODY = 5
        fun requiredPerms(): Array<String> =
            if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

        private val TWO_PI = (Math.PI * 2.0).toFloat()
        private val PI_F = Math.PI.toFloat()
        private val PALM = intArrayOf(1, 5, 9, 13, 17)
        private val FINGERS = arrayOf(
            intArrayOf(1, 2, 3, 4),
            intArrayOf(5, 6, 7, 8),
            intArrayOf(9, 10, 11, 12),
            intArrayOf(13, 14, 15, 16),
            intArrayOf(17, 18, 19, 20)
        )

        fun wrapAng(a: Float): Float {
            var v = a % TWO_PI
            if (v > PI_F) v -= TWO_PI
            if (v < -PI_F) v += TWO_PI
            return v
        }
    }
}
