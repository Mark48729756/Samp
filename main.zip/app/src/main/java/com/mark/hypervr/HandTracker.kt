package com.mark.hypervr

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import kotlin.math.sqrt

/** xy — 21 точка в долях кадра [x0,y0,...]; pinch — расстояние большой–указательный в метрах (3D, не зависит от поворота руки). */
class HandData(val xy: FloatArray, val pinch: Float)

/**
 * MediaPipe HandLandmarker в режиме VIDEO: между кадрами рука отслеживается по прошлой позе,
 * поэтому повёрнутая или частично закрытая рука не теряется так легко, как при поиске заново в каждом кадре.
 * Создавать и вызывать нужно из одного потока (важно для GPU).
 */
class HandTracker(context: Context, val gpu: Boolean) {

    private val landmarker: HandLandmarker
    private var lastTs = 0L

    init {
        val base = BaseOptions.builder()
            .setModelAssetPath("hand_landmarker.task")
            .setDelegate(if (gpu) Delegate.GPU else Delegate.CPU)
            .build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.VIDEO)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.3f)
            .setMinHandPresenceConfidence(0.3f)
            .setMinTrackingConfidence(0.3f)
            .build()
        landmarker = HandLandmarker.createFromOptions(context, options)
    }

    fun detect(bmp: Bitmap, tsMs: Long): List<HandData> {
        val ts = if (tsMs > lastTs) tsMs else lastTs + 1
        lastTs = ts
        val result = landmarker.detectForVideo(BitmapImageBuilder(bmp).build(), ts)
        val out = ArrayList<HandData>()
        val lms = result.landmarks()
        val worlds = result.worldLandmarks()
        for (hi in lms.indices) {
            val hand = lms[hi]
            val arr = FloatArray(42)
            for (i in 0 until 21) {
                arr[i * 2] = hand[i].x()
                arr[i * 2 + 1] = hand[i].y()
            }
            var pinch = 0.2f
            if (hi < worlds.size) {
                val w = worlds[hi]
                val dx = w[4].x() - w[8].x()
                val dy = w[4].y() - w[8].y()
                val dz = w[4].z() - w[8].z()
                pinch = sqrt(dx * dx + dy * dy + dz * dz)
            }
            out.add(HandData(arr, pinch))
        }
        return out
    }

    fun close() {
        landmarker.close()
    }
}
