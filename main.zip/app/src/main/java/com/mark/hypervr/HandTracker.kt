package com.mark.hypervr

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker

/** Обёртка над MediaPipe HandLandmarker. Для каждой руки 21 точка: [x0,y0,x1,y1,...] (0..1). */
class HandTracker(context: Context) {

    private val landmarker: HandLandmarker

    init {
        val base = BaseOptions.builder()
            .setModelAssetPath("hand_landmarker.task")
            .build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.IMAGE)
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .build()
        landmarker = HandLandmarker.createFromOptions(context, options)
    }

    fun detect(bmp: Bitmap): List<FloatArray> {
        val result = landmarker.detect(BitmapImageBuilder(bmp).build())
        val out = ArrayList<FloatArray>()
        for (hand in result.landmarks()) {
            val arr = FloatArray(42)
            for (i in 0 until 21) {
                arr[i * 2] = hand[i].x()
                arr[i * 2 + 1] = hand[i].y()
            }
            out.add(arr)
        }
        return out
    }

    fun close() {
        landmarker.close()
    }
}
