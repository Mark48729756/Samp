package com.mark.hypervr

import android.Manifest
import android.content.pm.PackageManager
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.os.Bundle
import android.util.Log
import android.util.Size
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var vr: VrView
    private var tracker: HandTracker? = null
    private var webView: WebView? = null
    private lateinit var analysisExecutor: ExecutorService
    private lateinit var sensorManager: SensorManager
    private var rotSensor: Sensor? = null
    private val rot = FloatArray(9)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else vr.status = "Нет доступа к камере — только касания экрана"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        vr = VrView(this)
        vr.onExit = { finish() }

        // Скрытый WebView под VrView: его «снимки» показывает окно «Браузер».
        val root = FrameLayout(this)
        try {
            val web = WebView(this)
            @SuppressLint("SetJavaScriptEnabled")
            val st = web.settings
            st.javaScriptEnabled = true
            st.domStorageEnabled = true
            web.setBackgroundColor(Color.WHITE)
            web.webViewClient = WebViewClient()
            web.loadUrl("https://www.google.com")
            root.addView(web, FrameLayout.LayoutParams(WebHost.W, WebHost.H))
            webView = web
            vr.web = WebHost(web)
        } catch (e: Throwable) {
            Log.e(TAG, "WebView init failed", e)
        }
        root.addView(vr, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        analysisExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        rotSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        try {
            tracker = HandTracker(this)
        } catch (e: Throwable) {
            Log.e(TAG, "HandTracker init failed", e)
            vr.status = "Трекинг рук не запустился: ${e.message}"
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
        rotSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        super.onPause()
        webView?.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        analysisExecutor.shutdown()
        webView?.destroy()
        tracker?.close()
    }

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, event.values)
        vr.onRotationMatrix(rot)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /** Выбираем камеру с самым коротким фокусным расстоянием (ultra-wide), если система её отдаёт. */
    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun wideSelector(): CameraSelector {
        return CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .addCameraFilter { infos ->
                val best = infos.minByOrNull { info ->
                    val f = Camera2CameraInfo.from(info)
                        .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                    f?.minOrNull() ?: 100f
                }
                if (best != null) listOf(best) else infos
            }
            .build()
    }

    @Suppress("DEPRECATION")
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(analysisExecutor) { proxy ->
                try {
                    val raw = proxy.toBitmap()
                    val deg = proxy.imageInfo.rotationDegrees
                    val bmp: Bitmap = if (deg != 0) {
                        val m = Matrix()
                        m.postRotate(deg.toFloat())
                        Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                    } else raw
                    val hands = tracker?.detect(bmp) ?: emptyList()
                    vr.setFrame(bmp, hands)
                } catch (e: Throwable) {
                    Log.e(TAG, "analyze failed", e)
                } finally {
                    proxy.close()
                }
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, wideSelector(), analysis)
            } catch (e: Exception) {
                Log.w(TAG, "wide camera failed, fallback to default", e)
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
                } catch (e2: Exception) {
                    vr.status = "Камера не запустилась: ${e2.message}"
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    companion object {
        private const val TAG = "HyperVR"
    }
}
