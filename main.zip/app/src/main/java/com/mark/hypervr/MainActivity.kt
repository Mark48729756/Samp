package com.mark.hypervr

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.os.Bundle
import android.util.Log
import android.util.Size
import android.view.TextureView
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var vr: VrView
    private var webView: WebView? = null
    private var videoHost: VideoHost? = null
    private lateinit var analysisExecutor: ExecutorService
    private lateinit var sensorManager: SensorManager
    private var rotSensor: Sensor? = null
    private val rot = FloatArray(9)

    // Всё ниже используется только в потоке анализа камеры
    private var tracker: HandTracker? = null
    private var trackerFailed = false
    private var rawBmp: Bitmap? = null
    private val outBmps = arrayOfNulls<Bitmap>(3)
    private var outIdx = 0
    private val blit = Paint(Paint.FILTER_BITMAP_FLAG)
    private val srcR = Rect()
    private val dstR = RectF()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else vr.status = "Нет доступа к камере — только касания экрана"
        }

    private val storageLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vr.refreshStorage()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        vr = VrView(this)
        vr.onExit = { finish() }
        vr.onRequestStorage = { storageLauncher.launch(VrView.requiredPerms()) }

        // Скрытые WebView и TextureView под VrView: окна «Браузер» и «Видео» показывают их «снимки».
        val root = FrameLayout(this)
        try {
            val web = WebView(this)
            val st = web.settings
            st.javaScriptEnabled = true
            st.domStorageEnabled = true
            web.setBackgroundColor(Color.WHITE)
            web.webViewClient = WebViewClient()
            web.loadUrl("https://www.google.com")
            root.addView(web, FrameLayout.LayoutParams(WebHost.W, WebHost.H))
            webView = web
            vr.web = WebHost(web)
        } catch (e: Throwable) {
            Log.e(TAG, "WebView init failed", e)
        }
        try {
            val tv = TextureView(this)
            val vh = VideoHost(tv)
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    vh.attach(st)
                }

                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            root.addView(tv, FrameLayout.LayoutParams(VideoHost.W, VideoHost.H))
            videoHost = vh
            vr.video = vh
        } catch (e: Throwable) {
            Log.e(TAG, "TextureView init failed", e)
        }
        root.addView(vr, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        analysisExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        rotSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        vr.refreshStorage()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
        vr.refreshStorage()
        rotSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        super.onPause()
        webView?.onPause()
        videoHost?.pause()
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        videoHost?.stop()
        webView?.destroy()
        analysisExecutor.execute { tracker?.close() }
        analysisExecutor.shutdown()
    }

    override fun onSensorChanged(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, event.values)
        vr.onRotationMatrix(rot)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /** Выбираем камеру с самым коротким фокусным расстоянием (ultra-wide), если система её отдаёт. */
    @androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
    private fun wideSelector(): CameraSelector {
        return CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .addCameraFilter { infos ->
                val best = infos.minByOrNull { info ->
                    val f = Camera2CameraInfo.from(info)
                        .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                    f?.minOrNull() ?: 100f
                }
                if (best != null) listOf(best) else infos
            }
            .build()
    }

    private fun ensureTracker() {
        if (tracker != null || trackerFailed) return
        try {
            tracker = HandTracker(this, true)
        } catch (e: Throwable) {
            Log.w(TAG, "GPU tracker failed, using CPU", e)
            try {
                tracker = HandTracker(this, false)
            } catch (e2: Throwable) {
                trackerFailed = true
                vr.status = "Трекинг рук не запустился: ${e2.message}"
            }
        }
    }

    private fun detectSafe(bmp: Bitmap, ts: Long): List<HandData> {
        ensureTracker()
        val t = tracker ?: return emptyList()
        return try {
            t.detect(bmp, ts)
        } catch (e: Throwable) {
            Log.w(TAG, "detect failed (gpu=${t.gpu})", e)
            if (t.gpu) {
                try {
                    t.close()
                } catch (e3: Throwable) {
                }
                tracker = null
                try {
                    tracker = HandTracker(this, false)
                } catch (e4: Throwable) {
                    trackerFailed = true
                }
            }
            emptyList()
        }
    }

    /** Копирует кадр камеры в переиспользуемые Bitmap-ы и поворачивает «вверх головой». */
    private fun convert(proxy: androidx.camera.core.ImageProxy): Bitmap {
        val w = proxy.width
        val h = proxy.height
        val deg = proxy.imageInfo.rotationDegrees
        var raw = rawBmp
        var rw = w
        try {
            val plane = proxy.planes[0]
            val pw = plane.rowStride / 4
            if (raw == null || raw.width != pw || raw.height != h) {
                raw = Bitmap.createBitmap(pw, h, Bitmap.Config.ARGB_8888)
                rawBmp = raw
            }
            val buf = plane.buffer
            buf.rewind()
            raw!!.copyPixelsFromBuffer(buf)
        } catch (e: Exception) {
            raw = proxy.toBitmap()
            rw = raw.width
        }
        val src = raw!!
        val ow = if (deg == 90 || deg == 270) h else rw
        val oh = if (deg == 90 || deg == 270) rw else h
        var out = outBmps[outIdx]
        if (out == null || out.width != ow || out.height != oh) {
            out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
            outBmps[outIdx] = out
        }
        outIdx = (outIdx + 1) % outBmps.size
        val cv = Canvas(out)
        cv.save()
        when (deg) {
            90 -> {
                cv.translate(h.toFloat(), 0f)
                cv.rotate(90f)
            }
            180 -> {
                cv.translate(rw.toFloat(), h.toFloat())
                cv.rotate(180f)
            }
            270 -> {
                cv.translate(0f, rw.toFloat())
                cv.rotate(270f)
            }
        }
        srcR.set(0, 0, rw, h)
        dstR.set(0f, 0f, rw.toFloat(), h.toFloat())
        cv.drawBitmap(src, srcR, dstR, blit)
        cv.restore()
        return out
    }

    @Suppress("DEPRECATION")
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(analysisExecutor) { proxy ->
                try {
                    val bmp = convert(proxy)
                    val hands = detectSafe(bmp, proxy.imageInfo.timestamp / 1_000_000L)
                    vr.setFrame(bmp, hands)
                } catch (e: Throwable) {
                    Log.e(TAG, "analyze failed", e)
                } finally {
                    proxy.close()
                }
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, wideSelector(), analysis)
            } catch (e: Exception) {
                Log.w(TAG, "wide camera failed, fallback to default", e)
                try {
                    provider.unbindAll()
                    provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
                } catch (e2: Exception) {
                    vr.status = "Камера не запустилась: ${e2.message}"
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    companion object {
        private const val TAG = "HyperVR"
    }
}
