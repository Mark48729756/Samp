package com.mark.hypervr

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/** Всё, во что можно печатать с виртуальной клавиатуры. */
interface TextSink {
    fun type(s: String)
    fun backspace()
}

abstract class App(val name: String, val defW: Float, val defH: Float) {
    /** r — область содержимого окна в координатах глаза. */
    abstract fun draw(v: VrView, c: Canvas, w: Win, r: RectF)
}

class AppInfo(val name: String, val color: Int, val factory: () -> App)

val LAUNCHER_INFO = AppInfo("Приложения", col(0xFF4FC3F7)) { LauncherApp() }

val ALL_APPS: List<AppInfo> = listOf(
    AppInfo("Браузер", col(0xFFEC407A)) { BrowserApp() },
    AppInfo("Часы", col(0xFF42A5F5)) { ClockApp() },
    AppInfo("Заметки", col(0xFFFFB74D)) { NotesApp() },
    AppInfo("Калькулятор", col(0xFF66BB6A)) { CalcApp() },
    AppInfo("Настройки", col(0xFFAB8FFF)) { SettingsApp() },
    AppInfo("Клавиатура", col(0xFF4DD0E1)) { KeyboardApp() }
)

// =====================================================================
//  Лаунчер
// =====================================================================
class LauncherApp : App("Приложения", 840f, 470f) {
    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        val pad = 24f * u
        val gap = 16f * u
        val cols = 4
        val rows = 2
        val tw = (r.width() - 2 * pad - (cols - 1) * gap) / cols
        val th = (r.height() - 2 * pad - (rows - 1) * gap) / rows
        val rect = RectF()
        val items = ArrayList<Triple<String, Int, () -> Unit>>()
        for (info in ALL_APPS) {
            items.add(Triple(info.name, info.color) {
                v.launch(info)
                v.closeWin(w)
            })
        }
        items.add(Triple("Выход", col(0xFFEF5350)) { v.onExit?.invoke() })
        for ((i, item) in items.withIndex()) {
            val cx = i % cols
            val cy = i / cols
            val x = r.left + pad + cx * (tw + gap)
            val y = r.top + pad + cy * (th + gap)
            rect.set(x, y, x + tw, y + th)
            val action = item.third
            v.button(c, w, rect, "", 10f, false, true) { action() }
            // иконка и подпись поверх кнопки
            v.fillCircle(c, rect.centerX(), rect.top + th * 0.4f, th * 0.24f, item.second)
            v.text(c, item.first.substring(0, 1), rect.centerX(), rect.top + th * 0.4f + th * 0.09f, th * 0.26f, col(0xFFFFFFFF), true, Paint.Align.CENTER)
            v.text(c, item.first, rect.centerX(), rect.bottom - th * 0.12f, 23f * u, col(0xFFFFFFFF), false, Paint.Align.CENTER)
        }
    }
}

// =====================================================================
//  Часы + секундомер
// =====================================================================
class ClockApp : App("Часы", 560f, 420f) {
    private var running = false
    private var acc = 0L
    private var startAt = 0L

    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        v.text(c, v.timeStr, r.centerX(), r.top + 110f * u, 100f * u, col(0xFFFFFFFF), true, Paint.Align.CENTER)
        v.text(c, v.dateStr, r.centerX(), r.top + 150f * u, 28f * u, col(0xAAFFFFFF), false, Paint.Align.CENTER)
        val ms = acc + if (running) SystemClock.uptimeMillis() - startAt else 0L
        val t = ms / 100
        val s = String.format(Locale.US, "%02d:%02d.%d", t / 600, (t / 10) % 60, t % 10)
        v.text(c, s, r.centerX(), r.top + 235f * u, 60f * u, col(0xFF4FC3F7), true, Paint.Align.CENTER)
        val rect = RectF()
        val bw = (r.width() - 3 * 24f * u) / 2f
        rect.set(r.left + 24f * u, r.top + 262f * u, r.left + 24f * u + bw, r.top + 332f * u)
        v.button(c, w, rect, if (running) "Стоп" else "Старт", 32f * u, true) {
            if (running) {
                acc += SystemClock.uptimeMillis() - startAt
                running = false
            } else {
                startAt = SystemClock.uptimeMillis()
                running = true
            }
        }
        rect.offset(bw + 24f * u, 0f)
        v.button(c, w, rect, "Сброс", 32f * u) {
            running = false
            acc = 0L
        }
    }
}

// =====================================================================
//  Заметки (печать с виртуальной клавиатуры)
// =====================================================================
class NotesApp : App("Заметки", 680f, 480f), TextSink {
    private val text = StringBuilder()
    private var loaded = false
    private var vv: VrView? = null

    override fun type(s: String) {
        text.append(s)
        vv?.saveNotes(text.toString())
    }

    override fun backspace() {
        if (text.isNotEmpty()) text.deleteCharAt(text.length - 1)
        vv?.saveNotes(text.toString())
    }

    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        vv = v
        if (!loaded) {
            text.append(v.loadNotes())
            loaded = true
        }
        val area = RectF(r.left + 16f * u, r.top + 16f * u, r.right - 16f * u, r.bottom - 96f * u)
        val focused = v.focus === this
        v.fill(c, area, 14f * u, if (focused) col(0xFF16263A) else col(0xFF101A28))
        if (focused) v.strokeRound(c, area, 14f * u, 3f * u, col(0xFF4FC3F7))
        v.hotspot(w, area, 77) {
            v.focus = this
            v.openKeyboard(w)
        }

        val size = 32f * u
        val maxW = area.width() - 32f * u
        val lines = v.wrapLines(text.toString(), size, maxW)
        val lineH = size * 1.3f
        val maxLines = ((area.height() - 32f * u) / lineH).toInt().coerceAtLeast(1)
        val from = (lines.size - maxLines).coerceAtLeast(0)
        if (text.isEmpty() && !focused) {
            v.text(c, "Нажми сюда и печатай пальцем", area.left + 16f * u, area.top + 16f * u + size, size, col(0x66FFFFFF))
        }
        var y = area.top + 16f * u + size
        for (i in from until lines.size) {
            v.text(c, lines[i], area.left + 16f * u, y, size, col(0xFFFFFFFF))
            if (i == lines.size - 1 && focused && (SystemClock.uptimeMillis() / 500) % 2 == 0L) {
                val tw = v.measure(lines[i], size)
                v.text(c, "|", area.left + 16f * u + tw, y, size, col(0xFF4FC3F7), true)
            }
            y += lineH
        }

        val rect = RectF()
        val bw = (r.width() - 3 * 16f * u) / 2f
        rect.set(r.left + 16f * u, r.bottom - 80f * u, r.left + 16f * u + bw, r.bottom - 16f * u)
        v.button(c, w, rect, "Очистить", 28f * u) {
            text.setLength(0)
            v.saveNotes("")
        }
        rect.offset(bw + 16f * u, 0f)
        v.button(c, w, rect, "Клавиатура", 28f * u, true) {
            v.focus = this
            v.openKeyboard(w)
        }
    }
}

// =====================================================================
//  Калькулятор
// =====================================================================
class CalcApp : App("Калькулятор", 480f, 650f) {
    private var display = "0"
    private var acc = 0.0
    private var op = ' '
    private var fresh = true

    private fun fmt(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "Ошибка"
        if (d == Math.floor(d) && abs(d) < 1e15) return d.toLong().toString()
        return String.format(Locale.US, "%.8f", d).trimEnd('0').trimEnd('.')
    }

    private fun compute() {
        val cur = display.toDoubleOrNull() ?: 0.0
        acc = when (op) {
            '+' -> acc + cur
            '-' -> acc - cur
            '×' -> acc * cur
            '÷' -> if (cur == 0.0) Double.NaN else acc / cur
            else -> cur
        }
        display = fmt(acc)
    }

    private fun press(k: String) {
        if (display == "Ошибка" && k != "C") return
        when (k) {
            "C" -> { display = "0"; acc = 0.0; op = ' '; fresh = true }
            "⌫" -> { display = if (display.length > 1) display.dropLast(1) else "0" }
            "±" -> { if (display != "0") display = if (display.startsWith("-")) display.drop(1) else "-$display" }
            "+", "-", "×", "÷" -> { compute(); op = k[0]; fresh = true }
            "=" -> { compute(); op = ' '; fresh = true }
            "." -> {
                if (fresh) { display = "0."; fresh = false }
                else if (!display.contains('.')) display += "."
            }
            else -> {
                if (fresh || display == "0") { display = k; fresh = false }
                else if (display.length < 14) display += k
            }
        }
    }

    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        val disp = RectF(r.left + 16f * u, r.top + 12f * u, r.right - 16f * u, r.top + 120f * u)
        v.fill(c, disp, 14f * u, col(0xFF101A28))
        val size = if (display.length > 10) 44f * u else 64f * u
        v.text(c, display, disp.right - 20f * u, disp.centerY() + size * 0.35f, size, col(0xFFFFFFFF), true, Paint.Align.RIGHT)
        val keys = arrayOf(
            "C", "⌫", "±", "÷",
            "7", "8", "9", "×",
            "4", "5", "6", "-",
            "1", "2", "3", "+",
            "0", "00", ".", "="
        )
        val gap = 10f * u
        val gx = r.left + 16f * u
        val gy = disp.bottom + 14f * u
        val cw = (r.width() - 32f * u - 3 * gap) / 4f
        val ch = (r.bottom - 16f * u - gy - 4 * gap) / 5f
        val rect = RectF()
        for (i in keys.indices) {
            val x = gx + (i % 4) * (cw + gap)
            val y = gy + (i / 4) * (ch + gap)
            rect.set(x, y, x + cw, y + ch)
            val k = keys[i]
            val accent = k == "=" || k == "+" || k == "-" || k == "×" || k == "÷"
            v.button(c, w, rect, k, 34f * u, accent, false) {
                if (k == "00") { press("0"); press("0") } else press(k)
            }
        }
    }
}

// =====================================================================
//  Настройки
// =====================================================================
class SettingsApp : App("Настройки", 740f, 590f) {
    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        val rowH = 78f * u
        var y = r.top + 10f * u
        val rect = RectF()
        val rx = r.right - 24f * u

        fun label(s: String) {
            v.text(c, s, r.left + 28f * u, y + rowH * 0.62f, 30f * u, col(0xFFFFFFFF))
        }

        // фон
        label("Фон")
        rect.set(rx - 300f * u, y + 8f * u, rx, y + rowH - 8f * u)
        v.button(c, w, rect, if (v.passthrough) "Камера (passthrough)" else "Виртуальная среда", 24f * u, true) { v.togglePass() }
        y += rowH

        // среда
        label("Среда")
        val half = 140f * u
        rect.set(rx - 2 * half - 12f * u, y + 8f * u, rx - half - 12f * u, y + rowH - 8f * u)
        v.button(c, w, rect, "Закат", 26f * u, v.envIndex == 0) { v.setEnv(0) }
        rect.set(rx - half, y + 8f * u, rx, y + rowH - 8f * u)
        v.button(c, w, rect, "Ночь", 26f * u, v.envIndex == 1) { v.setEnv(1) }
        y += rowH

        // руки
        label("Руки в среде")
        rect.set(rx - 300f * u, y + 8f * u, rx, y + rowH - 8f * u)
        v.button(c, w, rect, if (v.handSkin) "Кожа" else "Только контур", 26f * u, true) { v.handSkin = !v.handSkin; v.saveSettings() }
        y += rowH

        // dwell
        label("Нажатие задержкой")
        rect.set(rx - 300f * u, y + 8f * u, rx, y + rowH - 8f * u)
        v.button(c, w, rect, if (v.dwellOn) "Включено" else "Выключено", 26f * u, true) { v.dwellOn = !v.dwellOn; v.saveSettings() }
        y += rowH

        // громкость
        label("Громкость")
        rect.set(rx - 300f * u, y + 8f * u, rx, y + rowH - 8f * u)
        v.slider(c, w, rect, v.getVolume()) { v.setVolume(it) }
        y += rowH

        // щипок
        label("Чувствительность щипка")
        rect.set(rx - 300f * u, y + 8f * u, rx, y + rowH - 8f * u)
        v.slider(c, w, rect, (v.pinchK - 0.15f) / 0.2f) { v.pinchK = 0.15f + it * 0.2f; v.saveSettings() }
    }
}

// =====================================================================
//  Виртуальная клавиатура
// =====================================================================
class KeyboardApp : App("Клавиатура", 1000f, 440f) {
    private var ru = true
    private var shift = false

    private class Key(val label: String, val units: Float, val accent: Boolean, val action: () -> Unit)

    private fun send(v: VrView, s: String) {
        v.focus?.type(if (shift) s.uppercase() else s)
        shift = false
    }

    override fun draw(v: VrView, c: Canvas, w: Win, r: RectF) {
        val u = v.U
        val rows = if (ru) listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
        else listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

        val list = ArrayList<List<Key>>()
        list.add("1234567890".map { ch -> Key(ch.toString(), 1f, false) { send(v, ch.toString()) } })
        list.add(rows[0].map { ch -> Key(ch.toString(), 1f, false) { send(v, ch.toString()) } })
        list.add(rows[1].map { ch -> Key(ch.toString(), 1f, false) { send(v, ch.toString()) } })
        val r3 = ArrayList<Key>()
        r3.add(Key("⇧", 1.5f, shift) { shift = !shift })
        for (ch in rows[2]) r3.add(Key(ch.toString(), 1f, false) { send(v, ch.toString()) })
        r3.add(Key("⌫", 1.5f, false) { v.focus?.backspace() })
        list.add(r3)
        list.add(
            listOf(
                Key(if (ru) "RU" else "EN", 1.5f, true) { ru = !ru },
                Key(",", 1f, false) { send(v, ",") },
                Key("пробел", 5f, false) { v.focus?.type(" ") },
                Key(".", 1f, false) { send(v, ".") },
                Key("⏎", 2f, true) { v.focus?.type("\n") }
            )
        )

        val padX = 16f * u
        val padY = 10f * u
        val unitW = (r.width() - 2 * padX) / 12f
        val rowH = (r.height() - 2 * padY) / 5f
        val rect = RectF()
        for ((ri, row) in list.withIndex()) {
            var total = 0f
            for (k in row) total += k.units
            var x = r.left + padX + (12f - total) / 2f * unitW
            val y = r.top + padY + ri * rowH
            for (k in row) {
                rect.set(x + 3f * u, y + 3f * u, x + k.units * unitW - 3f * u, y + rowH - 3f * u)
                val label = if (shift && k.label.length == 1 && k.label[0].isLetter()) k.label.uppercase() else k.label
                v.button(c, w, rect, label, min(rowH * 0.42f, 34f * u), k.accent, false, k.action)
                x += k.units * unitW
            }
        }
    }
}
