# KIEV · CINE
Cinema camera for Android (Camera2, minSdk 26). Leica-style UI, Apple-style SVG icons (`/svg`), "Kiev" look.

## Build
* Android Studio: open the folder → Run. 
* Or push to GitHub: `.github/workflows/build.yml` builds the debug APK (Artifacts). `./gradlew assembleDebug` works locally too (Gradle 8.9 wrapper included).

## Features
* Manual ISO / shutter (180° default) / focus distance / EV / zoom / white balance, tick-dial with haptics
* All cameras: every lens by 35mm-equivalent (24mm, 48mm…), selfie, **USB/external cameras** (Android Camera2 external)
* **MAX** resolution by default: the biggest frame the phone's camera + encoder can record at the chosen aspect / fps (tap the resolution to pick another size)
* Cinema aspect ratios cut from the full sensor frame: **2.39:1 (default)**, 2:1, 1.85:1, 16:9, 4:3, 1:1, FULL. 24 / 25 / 30 / 60 fps, HEVC (H.264 fallback), ~0.4 bit/px, AAC 320 kbps 48 kHz
* Cinema focus: ring pull between two marks (hold A / B = store, tap = eased pull, time in MENU), peaking turns on by itself in manual focus
* Leica-style UI: plain readouts, tap a value to open its dial, everything else lives in MENU. App always starts in landscape
* Stabilization: OIS + EIS (preview stabilization on Android 13+)
* High-quality noise reduction / edge processing
* External monitor: clean feed (no UI) to HDMI / USB-C / Cast display
* FTP / FTPS auto-upload after each take
* Tap to focus (double-tap = centre), pinch to zoom
* Exposure tools: histogram, zebra (≥95 %), focus peaking, REC audio meter; in-camera sharpening off by default (SHARP toggles it)
* Device report (top-bar sliders button): what this phone really exposes to apps — 10-bit/HDR profiles, high-speed modes, audio inputs, encoders; SHARE sends it as text
* Frame lines dim everything outside the recorded aspect; optional thirds. REC timer, animated REC button
* "Kiev" look: live preview + `Kiev_Look.cube` (33³) written next to clips for DaVinci / Premiere / FCP

Clips: `Movies/KievCine/` (visible in Gallery, Android 10+). On older Android: `Android/data/com.mark.kievcine/files/Movies/KievCine/`

## Notes
* FTP password is encrypted with an Android Keystore key.
* Frame-rate choices are limited to what the selected lens really supports.
* Clips that are cut short (app sent to background) are still saved and uploaded.
