package com.mark.kievcine

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.MeteringRectangle
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Range
import android.util.Size
import android.view.Surface
import androidx.compose.runtime.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

data class CamInfo(val id: String, val label: String)
/** w,h = what the camera delivers; maxFps = what camera + encoder can do at that size */
data class VideoMode(val label: String, val w: Int, val h: Int, val maxFps: Int)
/** ratio = width / height, 0 = whole sensor frame */
data class Aspect(val label: String, val ratio: Float)

val ASPECTS = listOf(
    Aspect("2.39:1", 2.39f), Aspect("2:1", 2f), Aspect("1.85:1", 1.85f),
    Aspect("16:9", 16f / 9f), Aspect("4:3", 4f / 3f), Aspect("1:1", 1f), Aspect("FULL", 0f))

/** centre crop of a (rw x rh) frame to the aspect; sizes are multiples of 8 on the cropped side so encoders stay happy */
fun outSize(rw: Int, rh: Int, ratio: Float): Pair<Int, Int> {
    if (ratio <= 0f) return rw to rh
    var w = rw; var h = rh
    if (ratio >= rw.toFloat() / rh) h = (rw / ratio).toInt() / 8 * 8 else w = (rh * ratio).toInt() / 8 * 8
    return w to h
}

private fun videoCaps(mime: String): MediaCodecInfo.VideoCapabilities? = try {
    MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }
        .mapNotNull { try { it.getCapabilitiesForType(mime).videoCapabilities } catch (_: Exception) { null } }
        .maxByOrNull { it.supportedWidths.upper.toLong() * it.supportedHeights.upper }
} catch (_: Exception) { null }

class CamState {
    var cameras by mutableStateOf(listOf<CamInfo>())
    var camId by mutableStateOf("")
    var modes by mutableStateOf(listOf<VideoMode>())
    var mode by mutableIntStateOf(0)
    var autoRes by mutableStateOf(true)          // MAX: always the biggest frame the phone can record at this aspect / fps
    var aspect by mutableIntStateOf(0)           // default: 2.39:1 cinema scope
    var outW by mutableIntStateOf(0)
    var outH by mutableIntStateOf(0)
    var rackA by mutableFloatStateOf(-1f)
    var rackB by mutableFloatStateOf(-1f)
    var rackSec by mutableFloatStateOf(2f)
    var fps by mutableIntStateOf(24)
    var autoExp by mutableStateOf(true)
    var autoFocus by mutableStateOf(true)
    var isoT by mutableFloatStateOf(0.3f)
    var shutT by mutableFloatStateOf(0.5f)
    var focusT by mutableFloatStateOf(0f)
    var evT by mutableFloatStateOf(0.5f)
    var zoomT by mutableFloatStateOf(0f)
    var wb by mutableIntStateOf(0)
    var stab by mutableStateOf(true)
    var kiev by mutableStateOf(true)
    var thirds by mutableStateOf(false)
    var recording by mutableStateOf(false)
    var recSec by mutableIntStateOf(0)
    var ftp by mutableStateOf("")
    var fpsOptions by mutableStateOf(listOf(24, 25, 30, 60))
    var codec by mutableStateOf("HEVC")
    var hist by mutableStateOf(false)
    var zebra by mutableStateOf(false)
    var peaking by mutableStateOf(false)
    var sharp by mutableStateOf(false)
    var level by mutableFloatStateOf(0f)
    var error by mutableStateOf("")
    var isoMin = 100; var isoMax = 800
    var expMin = 100_000L; var expMax = 100_000_000L
    var minFocus = 0f
    var evMin = -6; var evMax = 6; var evStep = 0.1667f
    var zMin = 1f; var zMax = 1f
}

class CameraEngine(private val ctx: Context) {
    val st = CamState()
    val dir: File = (ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: ctx.filesDir).let { File(it, "KievCine").apply { mkdirs() } }
    var rotation by mutableIntStateOf(Surface.ROTATION_90)
    /** called (on the camera thread) with every finished, valid clip */
    var onClip: ((File) -> Unit)? = null
    var previewSize = Size(1920, 1080); private set

    private val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val ht = HandlerThread("cine").also { it.start() }
    private val h = Handler(ht.looper)
    private var dev: CameraDevice? = null
    private var ses: CameraCaptureSession? = null
    private var chars: CameraCharacteristics? = null
    @Volatile private var texture: SurfaceTexture? = null
    @Volatile private var previewSurface: Surface? = null
    @Volatile private var focusRegion: Array<MeteringRectangle>? = null
    private var active = false
    private var opening = false
    private var gen = 0
    private var sesId = 0
    private var defaultsCam = ""
    private var defaultsShutter = ""
    @Volatile private var monitorSurface: Surface? = null
    private var builder: CaptureRequest.Builder? = null
    @Volatile private var recorder: CineRecorder? = null

    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    // ---------- discovery ----------
    fun listCameras() {
        val out = mutableListOf<Pair<Float, CamInfo>>()
        for (id in mgr.cameraIdList) {
            val c = mgr.getCameraCharacteristics(id)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            if (caps != null && !caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) continue
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val eq = if (f != null && sz != null) f * 43.27f / hypot(sz.width, sz.height) else 0f
            val label = when (facing) {
                CameraCharacteristics.LENS_FACING_FRONT -> "SELFIE"
                CameraCharacteristics.LENS_FACING_EXTERNAL -> "USB $id"
                else -> if (eq > 0) "${eq.roundToInt()}mm" else "CAM $id"
            }
            out += (if (facing == CameraCharacteristics.LENS_FACING_BACK) eq else 999f) to CamInfo(id, label)
        }
        st.cameras = out.sortedBy { it.first }.map { it.second }
        if (st.camId.isEmpty() || st.cameras.none { it.id == st.camId }) {
            st.camId = st.cameras.firstOrNull { it.label.endsWith("mm") && abs((it.label.removeSuffix("mm").toIntOrNull() ?: 0) - 26) < 8 }?.id
                ?: st.cameras.firstOrNull()?.id ?: ""
        }
    }

    private fun readRanges() {
        val c = chars ?: return
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val recSizes = map?.getOutputSizes(MediaRecorder::class.java)?.toList() ?: emptyList()
        val texSizes = map?.getOutputSizes(SurfaceTexture::class.java)?.toList() ?: emptyList()
        var sizes = recSizes.filter { r -> texSizes.any { it.width == r.width && it.height == r.height } }
        if (sizes.isEmpty()) sizes = texSizes
        val caps = videoCaps(MediaFormat.MIMETYPE_VIDEO_HEVC) ?: videoCaps(MediaFormat.MIMETYPE_VIDEO_AVC)
        sizes = sizes.filter { z ->
            minOf(z.width, z.height) >= 720 && z.width % 2 == 0 && z.height % 2 == 0 &&
                (caps?.let { try { it.isSizeSupported(z.width, z.height) } catch (_: Exception) { false } } ?: (z.width <= 3840))
        }
        var modes = sizes.sortedByDescending { it.width.toLong() * it.height }.map { z ->
            val d = try { map?.getOutputMinFrameDuration(MediaRecorder::class.java, z) ?: 0L } catch (_: Exception) { 0L }
            var mf = if (d > 0) (1_000_000_000L / d).toInt() else 30
            caps?.let { try { mf = min(mf, it.getSupportedFrameRatesFor(z.width, z.height).upper.toInt()) } catch (_: Exception) {} }
            VideoMode("${z.width}×${z.height}", z.width, z.height, mf)
        }.filter { it.maxFps >= 24 }
        if (modes.isEmpty()) modes = listOf(VideoMode("1280×720", 1280, 720, 30))
        st.modes = modes
        val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
        val opts = listOf(24, 25, 30, 60).filter { f -> ranges.any { it.lower <= f && f <= it.upper } }.ifEmpty { listOf(30) }
        if (st.fps !in opts) st.fps = opts.minByOrNull { abs(it - st.fps) } ?: 30
        if (st.autoRes) {
            var bi = bestMode(st.fps)
            if (bi < 0) { st.fps = opts.first(); bi = max(bestMode(st.fps), 0) }
            st.mode = bi
        } else if (st.mode >= modes.size) st.mode = 0
        val m = modes[st.mode]
        st.fpsOptions = opts.filter { it <= m.maxFps }.ifEmpty { listOf(opts.first()) }
        if (st.fps !in st.fpsOptions) st.fps = st.fpsOptions.last()
        refreshOut()
        val ps = map?.getOutputSizes(SurfaceTexture::class.java)?.toList() ?: emptyList()
        previewSize = ps.filter { it.width * m.h == it.height * m.w && it.width <= 1920 }.maxByOrNull { it.width }
            ?: ps.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height } ?: Size(1280, 720)

        c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let { st.isoMin = it.lower; st.isoMax = min(it.upper, 3200) }
        c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let { st.expMin = max(it.lower, 125_000L); st.expMax = it.upper }
        st.minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)?.let { st.evMin = it.lower; st.evMax = it.upper }
        st.evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.1667f
        if (Build.VERSION.SDK_INT >= 30) {
            c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let { st.zMin = it.lower; st.zMax = it.upper }
        } else { st.zMin = 1f; st.zMax = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f }
        // sane cinematic defaults: ISO ~200, 1.0x, EV 0 (only when the lens changes, so user settings survive fps / resolution changes)
        if (defaultsCam != st.camId) {
            defaultsCam = st.camId
            st.isoT = ((ln(200f) - ln(st.isoMin.toFloat())) / (ln(st.isoMax.toFloat()) - ln(st.isoMin.toFloat()))).coerceIn(0f, 1f)
            st.evT = if (st.evMax > st.evMin) (0f - st.evMin) / (st.evMax - st.evMin) else 0.5f
            st.zoomT = if (st.zMax > st.zMin) ((1f - st.zMin) / (st.zMax - st.zMin)).coerceIn(0f, 1f) else 0f
        }
        // 180° shutter, recomputed whenever lens or frame rate changes
        val key = "${st.camId}@${st.fps}"
        if (defaultsShutter != key) {
            defaultsShutter = key
            val lo = ln(st.expMin.toFloat()); val hi = ln(minOf(st.expMax, 1_000_000_000L / st.fps).toFloat())
            st.shutT = if (hi > lo) ((ln(1e9f / (2 * st.fps)) - lo) / (hi - lo)).coerceIn(0f, 1f) else 0f
        }
    }

    /** clockwise degrees that make a camera buffer upright for the current display rotation */
    fun orientationHint(): Int {
        val sensor = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val rot = when (rotation) { Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0 }
        val front = chars?.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        return if (front) (sensor + rot) % 360 else (sensor - rot + 360) % 360
    }

    private fun outFor(m: VideoMode): Pair<Int, Int> {
        val land = orientationHint() % 180 == 0
        return outSize(if (land) m.w else m.h, if (land) m.h else m.w, ASPECTS[st.aspect].ratio)
    }

    /** biggest recorded frame (after the aspect crop) that can run at this fps; -1 if none */
    private fun bestMode(fps: Int): Int {
        var best = -1; var area = -1L
        st.modes.forEachIndexed { i, m ->
            if (m.maxFps >= fps) { val (w, hh) = outFor(m); val a = w.toLong() * hh; if (a > area) { area = a; best = i } }
        }
        return best
    }

    private fun refreshOut() {
        val m = st.modes.getOrNull(st.mode) ?: return
        val (w, hh) = outFor(m); st.outW = w; st.outH = hh
    }

    fun setAspect(i: Int) {
        st.aspect = i
        h.post {
            if (st.autoRes && st.modes.isNotEmpty() && recorder == null) {
                val old = st.mode; val nb = bestMode(st.fps)
                if (nb >= 0 && nb != old) { st.mode = nb; refreshOut(); closeInternal(); openInternal(); return@post }
            }
            refreshOut()
        }
    }

    /** MAX -> every size the phone offers (biggest first) -> MAX */
    fun cycleRes() {
        if (st.autoRes) { st.autoRes = false; st.mode = 0 }
        else if (st.mode + 1 < st.modes.size) st.mode++
        else st.autoRes = true
        restart()
    }

    // ---------- value helpers ----------
    fun isoValue() = exp(ln(st.isoMin.toFloat()) + (ln(st.isoMax.toFloat()) - ln(st.isoMin.toFloat())) * st.isoT).roundToInt()
    fun shutterNs(): Long {
        val lo = ln(st.expMin.toFloat()); val hi = ln(minOf(st.expMax, 1_000_000_000L / st.fps).toFloat())
        return exp(lo + (hi - lo) * st.shutT).toLong()
    }
    fun shutterText() = "1/" + (1e9 / shutterNs()).roundToInt()
    fun focusText() = if (st.focusT <= 0.01f || st.minFocus <= 0f) "∞" else "%.2f m".format(1f / (st.focusT * st.minFocus))
    private fun evIndex() = (st.evMin + (st.evMax - st.evMin) * st.evT).roundToInt()
    fun evText() = "%+.1f".format(evIndex() * st.evStep)
    fun zoomValue() = st.zMin + (st.zMax - st.zMin) * st.zoomT
    fun zoomText() = "%.1f×".format(zoomValue())

    private fun IntArray?.has(v: Int) = this?.contains(v) == true

    private fun applyTo(b: CaptureRequest.Builder) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        if (!st.autoExp) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoValue())
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterNs())
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, max(1_000_000_000L / st.fps, shutterNs()))
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIndex())
        }
        if (st.minFocus > 0f) {
            if (st.autoFocus) b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
            else { b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF); b.set(CaptureRequest.LENS_FOCUS_DISTANCE, st.focusT * st.minFocus) }
        }
        focusRegion?.let { reg ->
            if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0) > 0 && st.autoFocus) b.set(CaptureRequest.CONTROL_AF_REGIONS, reg)
            if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0) > 0 && st.autoExp) b.set(CaptureRequest.CONTROL_AE_REGIONS, reg)
        }
        val awb = intArrayOf(CaptureRequest.CONTROL_AWB_MODE_AUTO, CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT, CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
            CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT, CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT)[st.wb]
        if (c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES).has(awb)) b.set(CaptureRequest.CONTROL_AWB_MODE, awb)
        // stabilization: OIS + EIS (preview-stabilization on API 33+)
        if (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION).has(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON))
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, if (st.stab) CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON else CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)
        val vs = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
        if (st.stab) {
            if (Build.VERSION.SDK_INT >= 33 && vs.has(2)) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, 2)
            else if (vs.has(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
        } else if (vs.has(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF)
        // ultra-quality processing
        if (c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES).has(CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY))
            b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
        // cinema look: in-camera sharpening off by default (it paints halos on edges); SHARP switches it back on
        val em = if (st.sharp) CaptureRequest.EDGE_MODE_HIGH_QUALITY else CaptureRequest.EDGE_MODE_OFF
        if (c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES).has(em)) b.set(CaptureRequest.EDGE_MODE, em)
        // frame rate
        val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.toList() ?: emptyList()
        (ranges.firstOrNull { it.lower == st.fps && it.upper == st.fps } ?: ranges.filter { it.lower <= st.fps && it.upper >= st.fps }.minByOrNull { it.upper - it.lower })
            ?.let { b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
        // zoom
        if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoomValue())
        else c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)?.let { r ->
            val z = zoomValue(); val w = (r.width() / z).toInt(); val hh = (r.height() / z).toInt()
            b.set(CaptureRequest.SCALER_CROP_REGION, Rect(r.centerX() - w / 2, r.centerY() - hh / 2, r.centerX() + w / 2, r.centerY() + hh / 2))
        }
    }

    // ---------- lifecycle ----------
    fun setTexture(t: SurfaceTexture?) {
        previewSurface?.release()
        texture = t
        previewSurface = t?.let { Surface(it) }
    }
    fun setMonitorSurface(s: Surface?) {
        if (monitorSurface == s) return
        monitorSurface = s
        h.post { if (dev != null && recorder == null) createSession(null) }
    }
    fun start() { h.post { active = true; openInternal() } }
    fun restart() { h.post { closeInternal(); openInternal() } }
    fun stop() { h.post { active = false; if (recorder != null) finishRecorder(); closeInternal() } }
    /** stops the camera thread for good; call from Activity.onDestroy */
    fun release() { h.post { active = false; closeInternal(); ht.quitSafely() } }
    fun selectCamera(id: String) { st.camId = id; focusRegion = null; restart() }

    /** nx, ny: 0..1 position inside the upright viewfinder. null clears the focus point (back to the centre). */
    fun tapFocus(nx: Float?, ny: Float?) {
        h.post {
            val c = chars ?: return@post
            if (nx == null || ny == null) { focusRegion = null }
            else {
                if (c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) return@post
                val r = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return@post
                // the upright picture equals the sensor array on ROTATION_90 and is turned 180° on ROTATION_270
                val flip = rotation == Surface.ROTATION_270
                val x = if (flip) 1f - nx else nx; val y = if (flip) 1f - ny else ny
                val half = (r.width() * 0.06f).toInt()
                val cx = (r.left + x * r.width()).toInt().coerceIn(r.left + half, r.right - half)
                val cy = (r.top + y * r.height()).toInt().coerceIn(r.top + half, r.bottom - half)
                focusRegion = arrayOf(MeteringRectangle(cx - half, cy - half, half * 2, half * 2, MeteringRectangle.METERING_WEIGHT_MAX - 1))
            }
            val b = builder ?: return@post
            try { applyTo(b); ses?.setRepeatingRequest(b.build(), null, h) } catch (_: Exception) {}
        }
    }
    fun apply() {
        h.post {
            val b = builder ?: return@post
            try { applyTo(b); ses?.setRepeatingRequest(b.build(), null, h) } catch (_: Exception) {}
        }
    }

    private fun cameraError(code: Int) = when (code) {
        CameraDevice.StateCallback.ERROR_CAMERA_IN_USE -> "Camera is in use by another app"
        CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE -> "Too many cameras open"
        CameraDevice.StateCallback.ERROR_CAMERA_DISABLED -> "Camera disabled by policy"
        else -> "Camera error $code"
    }

    private fun openInternal() {
        if (!active || opening || dev != null || texture == null || !granted(Manifest.permission.CAMERA)) return
        try {
            if (st.cameras.isEmpty() || st.camId.isEmpty()) listCameras()
            if (st.camId.isEmpty()) { st.error = "No cameras"; return }
            chars = mgr.getCameraCharacteristics(st.camId); readRanges()
            val my = gen
            opening = true
            @Suppress("MissingPermission")
            mgr.openCamera(st.camId, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) {
                    opening = false
                    // a close / restart / stop happened while this camera was still opening: drop it and open the latest request
                    if (!active || my != gen) { c.close(); if (active) openInternal(); return }
                    dev = c; createSession(null)
                }
                override fun onDisconnected(c: CameraDevice) {
                    opening = false; c.close()
                    if (my != gen) { if (active) openInternal(); return }
                    if (recorder != null) finishRecorder()
                    closeInternal(); st.error = "Camera disconnected"
                }
                override fun onError(c: CameraDevice, e: Int) {
                    opening = false; c.close()
                    if (my != gen) { if (active) openInternal(); return }
                    abortRecorder(); closeInternal(); st.error = cameraError(e)
                }
            }, h)
        } catch (e: Exception) { opening = false; st.error = e.message ?: "open failed" }
    }

    private fun closeInternal() {
        gen++; sesId++
        try { ses?.close() } catch (_: Exception) {}
        try { dev?.close() } catch (_: Exception) {}
        ses = null; dev = null; builder = null
    }

    private fun fail(msg: String) { st.error = msg; abortRecorder() }

    @Suppress("DEPRECATION")
    private fun createSession(rec: Surface?, after: () -> Unit = {}) {
        val cam = dev ?: return; val tex = texture ?: return; val ps = previewSurface ?: return
        val id = ++sesId
        try {
            tex.setDefaultBufferSize(previewSize.width, previewSize.height)
            val targets = mutableListOf(ps)
            monitorSurface?.takeIf { it.isValid }?.let { targets += it }
            rec?.let { targets += it }
            val b = cam.createCaptureRequest(if (rec != null) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW)
            targets.forEach { b.addTarget(it) }
            applyTo(b); builder = b
            try { ses?.close() } catch (_: Exception) {}
            ses = null
            cam.createCaptureSession(targets, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (id != sesId) { s.close(); return }   // superseded while configuring
                    ses = s
                    try { s.setRepeatingRequest(b.build(), null, h); st.error = ""; after() } catch (e: Exception) { fail(e.message ?: "session") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { if (id == sesId) fail("Configure failed") }
            }, h)
        } catch (e: Exception) { fail(e.message ?: "session") }
    }

    // ---------- recording ----------
    private fun makeRecorder(mime: String): CineRecorder {
        val m = st.modes[st.mode]
        val hint = orientationHint()
        val (ow, oh) = outFor(m)
        val f = File(dir, "KIEV_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4")
        val bpp = if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC) 0.40 else 0.60
        val br = (ow.toLong() * oh * max(st.fps, 24) * bpp).toLong().coerceIn(12_000_000L, 250_000_000L).toInt()
        val realtime = chars?.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) == CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
        val r = CineRecorder(f, m.w, m.h, ow, oh, hint, mime, br, st.fps, granted(Manifest.permission.RECORD_AUDIO), realtime)
        r.prepare()
        return r
    }

    fun startRecording() {
        h.post {
            if (recorder != null || dev == null || st.modes.isEmpty()) return@post
            try {
                val r = try { makeRecorder(MediaFormat.MIMETYPE_VIDEO_HEVC).also { st.codec = "HEVC" } }
                        catch (_: Exception) { makeRecorder(MediaFormat.MIMETYPE_VIDEO_AVC).also { st.codec = "H.264" } }
                recorder = r
                createSession(r.surface) { try { r.start(); st.recording = true } catch (e: Exception) { fail(e.message ?: "rec") } }
            } catch (e: Exception) { st.error = e.message ?: "recorder" }
        }
    }

    /** throw away a recorder that never started (or whose session died) */
    private fun abortRecorder() {
        val r = recorder ?: return
        try { r.abort() } catch (_: Exception) {}
        recorder = null; st.recording = false
    }

    private fun finishRecorder(): File? {
        val r = recorder ?: return null
        try { ses?.stopRepeating(); ses?.abortCaptures() } catch (_: Exception) {}
        try { ses?.close() } catch (_: Exception) {}
        ses = null; sesId++
        val ok = try { r.stop() } catch (_: Exception) { false }
        recorder = null; st.recording = false
        if (!ok) return null
        val f = r.file0
        onClip?.invoke(f)
        return f
    }

    /** 0..1 microphone peak (−60…0 dBFS) since the last call; 0 when not recording */
    fun micLevel(): Float = recorder?.micLevel() ?: 0f

    fun stopRecording(done: (File?) -> Unit = {}) {
        h.post { val f = finishRecorder(); createSession(null); done(f) }
    }
}
