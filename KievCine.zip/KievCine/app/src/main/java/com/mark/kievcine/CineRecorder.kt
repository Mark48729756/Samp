package com.mark.kievcine

import android.graphics.SurfaceTexture
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max

/**
 * Cinema recorder: camera -> GL (centre crop to any aspect, rotation) -> HEVC / H.264 -> MP4, plus AAC audio.
 * MediaRecorder cannot crop, so 2.39:1, 2:1, 1.85:1 ... are cut from the full sensor frame here.
 *
 * @param srcW,srcH camera buffer size
 * @param outW,outH final upright frame
 * @param rotDeg    clockwise degrees needed to make the camera buffer upright (0/90/180/270)
 */
class CineRecorder(
    private val file: File,
    private val srcW: Int, private val srcH: Int,
    private val outW: Int, private val outH: Int,
    private val rotDeg: Int,
    private val mime: String,
    private var bitrate: Int,
    private val fps: Int,
    private val withAudio: Boolean,
    private val camClockIsBoottime: Boolean
) {
    companion object {
        private const val RATE = 48_000
        private const val EGL_RECORDABLE_ANDROID = 0x3142
        private const val VS = """
            attribute vec4 aPos; attribute vec2 aTex;
            uniform mat4 uST; uniform mat4 uTM;
            varying vec2 vTex;
            void main() {
                gl_Position = aPos;
                vec4 t = uTM * vec4(aTex - vec2(0.5), 0.0, 1.0);
                vTex = (uST * vec4(t.xy + vec2(0.5), 0.0, 1.0)).xy;
            }"""
        private const val FS = """
            #extension GL_OES_EGL_image_external : require
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vTex; uniform samplerExternalOES sTex;
            void main() { gl_FragColor = texture2D(sTex, vTex); }"""
    }

    // ----- public -----
    val surface: Surface get() = camSurface ?: throw IllegalStateException("not prepared")
    @Volatile var peak = 0
    val file0: File get() = file

    // ----- video -----
    private var venc: MediaCodec? = null
    private var vin: Surface? = null
    private val glThread = HandlerThread("cine-gl").also { it.start() }
    private val gl = Handler(glThread.looper)
    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ectx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var esurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var prog = 0
    private var tex = 0
    private var aPos = 0; private var aTex = 0; private var uST = 0; private var uTM = 0
    private var camTex: SurfaceTexture? = null
    private var camSurface: Surface? = null
    private val stMat = FloatArray(16)
    private val tmMat = FloatArray(16)
    private lateinit var quad: FloatBuffer

    // ----- audio -----
    private var arec: AudioRecord? = null
    private var aenc: MediaCodec? = null
    private var audioOk = false

    // ----- mux -----
    private var muxer: MediaMuxer? = null
    private val mlock = java.util.concurrent.locks.ReentrantLock()
    private val mcond = mlock.newCondition()
    private val wLock = Any()
    private var expected = 1
    private var tracks = 0
    @Volatile private var muxStarted = false
    @Volatile private var videoFrames = 0

    @Volatile private var active = false
    @Volatile private var stopAudio = false
    @Volatile private var forceExit = false
    private var baseNs = 0L
    private var bootOffset = 0L
    private var vThread: Thread? = null
    private var aThread: Thread? = null
    private var released = false

    private fun boot() = SystemClock.elapsedRealtimeNanos()

    // =====================================================================================
    fun prepare() {
        try {
            // --- video encoder ---
            val enc = MediaCodec.createEncoderByType(mime)
            venc = enc
            try {
                enc.codecInfo.getCapabilitiesForType(mime).videoCapabilities?.bitrateRange?.let { bitrate = it.clamp(bitrate) }
            } catch (_: Exception) {}
            fun fmt(vbr: Boolean) = MediaFormat.createVideoFormat(mime, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                if (vbr) setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
                setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
                setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
            }
            try {
                enc.configure(fmt(true), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            } catch (_: Exception) {
                enc.reset()
                enc.configure(fmt(false), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            }
            vin = enc.createInputSurface()
            enc.start()

            // --- GL on its own thread ---
            val latch = CountDownLatch(1)
            var glErr: Exception? = null
            gl.post {
                try { initGl() } catch (e: Exception) { glErr = e }
                latch.countDown()
            }
            if (!latch.await(5, TimeUnit.SECONDS)) throw IllegalStateException("GL init timeout")
            glErr?.let { throw it }

            // --- audio (optional) ---
            if (withAudio) {
                try {
                    val ch = AudioFormat.CHANNEL_IN_STEREO
                    val min = AudioRecord.getMinBufferSize(RATE, ch, AudioFormat.ENCODING_PCM_16BIT)
                    val ar = AudioRecord(MediaRecorder.AudioSource.CAMCORDER, RATE, ch, AudioFormat.ENCODING_PCM_16BIT, max(min * 4, 65536))
                    if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); throw IllegalStateException("audio") }
                    arec = ar
                    val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 2).apply {
                        setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                        setInteger(MediaFormat.KEY_BIT_RATE, 320_000)
                        setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                    }
                    val ae = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                    ae.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    ae.start()
                    aenc = ae
                    audioOk = true
                } catch (_: Exception) {
                    try { arec?.release() } catch (_: Exception) {}
                    try { aenc?.release() } catch (_: Exception) {}
                    arec = null; aenc = null; audioOk = false
                }
            }
            expected = if (audioOk) 2 else 1

            muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        } catch (e: Exception) {
            abort()
            throw e
        }
    }

    /** the camera session is configured and frames are about to flow */
    fun start() {
        baseNs = boot()
        bootOffset = boot() - System.nanoTime()
        vThread = Thread({ videoDrain() }, "cine-vdrain").also { it.start() }
        if (audioOk) aThread = Thread({ audioLoop() }, "cine-audio").also { it.start() }
        active = true
    }

    /** 0..1 microphone peak (-60..0 dBFS) since the last call */
    fun micLevel(): Float {
        val a = peak; peak = 0
        if (a <= 0) return 0f
        return ((20f * log10(a / 32768f) + 60f) / 60f).coerceIn(0f, 1f)
    }

    /** finish the file. Returns true when it holds a playable clip. */
    fun stop(): Boolean {
        if (released) return false
        // 1. no more video frames; tell the encoder
        val done = CountDownLatch(1)
        gl.post {
            active = false
            try { venc?.signalEndOfInputStream() } catch (_: Exception) {}
            done.countDown()
        }
        done.await(2, TimeUnit.SECONDS)
        stopAudio = true
        vThread?.join(6000); aThread?.join(6000)
        forceExit = true
        vThread?.join(500); aThread?.join(500)
        val ok = muxStarted && videoFrames > 0
        release()
        if (!ok) file.delete()
        return ok
    }

    /** throw everything away (camera died, start failed) */
    fun abort() {
        active = false; stopAudio = true; forceExit = true
        try { vThread?.join(500); aThread?.join(500) } catch (_: Exception) {}
        release()
        file.delete()
    }

    private fun release() {
        if (released) return
        released = true
        val latch = CountDownLatch(1)
        gl.post { try { releaseGl() } catch (_: Exception) {}; latch.countDown() }
        latch.await(2, TimeUnit.SECONDS)
        try { venc?.stop() } catch (_: Exception) {}
        try { venc?.release() } catch (_: Exception) {}
        try { aenc?.stop() } catch (_: Exception) {}
        try { aenc?.release() } catch (_: Exception) {}
        try { arec?.stop() } catch (_: Exception) {}
        try { arec?.release() } catch (_: Exception) {}
        if (muxStarted) { try { muxer?.stop() } catch (_: Exception) {} }
        try { muxer?.release() } catch (_: Exception) {}
        glThread.quitSafely()
        try { camSurface?.release() } catch (_: Exception) {}
        try { vin?.release() } catch (_: Exception) {}
    }

    // =====================================================================================
    // GL
    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
        val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { val log = GLES20.glGetShaderInfoLog(s); GLES20.glDeleteShader(s); throw IllegalStateException("shader: $log") }
        return s
    }

    private fun initGl() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) throw IllegalStateException("EGL init")
        val attr = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL_RECORDABLE_ANDROID, 1, EGL14.EGL_NONE)
        val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        if (!EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0) || n[0] == 0) throw IllegalStateException("EGL config")
        ectx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        esurf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], vin, intArrayOf(EGL14.EGL_NONE), 0)
        if (!EGL14.eglMakeCurrent(dpy, esurf, esurf, ectx)) throw IllegalStateException("EGL current")

        val vs = shader(GLES20.GL_VERTEX_SHADER, VS); val fs = shader(GLES20.GL_FRAGMENT_SHADER, FS)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs); GLES20.glAttachShader(prog, fs); GLES20.glLinkProgram(prog)
        val ok = IntArray(1); GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw IllegalStateException("GL link")
        aPos = GLES20.glGetAttribLocation(prog, "aPos"); aTex = GLES20.glGetAttribLocation(prog, "aTex")
        uST = GLES20.glGetUniformLocation(prog, "uST"); uTM = GLES20.glGetUniformLocation(prog, "uTM")

        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        quad = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f)); position(0)
        }

        // centred output coords -> centred coords of the camera buffer: rotate, then crop
        val rw = if (rotDeg % 180 == 0) srcW else srcH
        val rh = if (rotDeg % 180 == 0) srcH else srcW
        val fx = outW.toFloat() / rw; val fy = outH.toFloat() / rh
        // R maps upright -> buffer
        val r00: Float; val r01: Float; val r10: Float; val r11: Float
        when (rotDeg) {
            90 -> { r00 = 0f; r01 = -1f; r10 = 1f; r11 = 0f }
            180 -> { r00 = -1f; r01 = 0f; r10 = 0f; r11 = -1f }
            270 -> { r00 = 0f; r01 = 1f; r10 = -1f; r11 = 0f }
            else -> { r00 = 1f; r01 = 0f; r10 = 0f; r11 = 1f }
        }
        android.opengl.Matrix.setIdentityM(tmMat, 0)
        tmMat[0] = r00 * fx; tmMat[4] = r01 * fy      // row 0
        tmMat[1] = r10 * fx; tmMat[5] = r11 * fy      // row 1

        val st = SurfaceTexture(tex)
        st.setDefaultBufferSize(srcW, srcH)
        st.setOnFrameAvailableListener({ onFrame(it) }, gl)
        camTex = st
        camSurface = Surface(st)
    }

    private fun onFrame(st: SurfaceTexture) {
        if (released) return
        try { st.updateTexImage() } catch (_: Exception) { return }
        if (!active) return
        val camNs = st.timestamp
        val pts = (if (camClockIsBoottime) camNs else camNs + bootOffset) - baseNs
        if (pts < 0) return
        st.getTransformMatrix(stMat)
        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glClearColor(0f, 0f, 0f, 1f); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniformMatrix4fv(uST, 1, false, stMat, 0)
        GLES20.glUniformMatrix4fv(uTM, 1, false, tmMat, 0)
        quad.position(0); GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2); GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aTex)
        EGLExt.eglPresentationTimeANDROID(dpy, esurf, pts)
        EGL14.eglSwapBuffers(dpy, esurf)
    }

    private fun releaseGl() {
        try { camTex?.setOnFrameAvailableListener(null) } catch (_: Exception) {}
        try { camTex?.release() } catch (_: Exception) {}
        if (dpy != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (esurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, esurf)
            if (ectx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ectx)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(dpy)
        }
        dpy = EGL14.EGL_NO_DISPLAY; ectx = EGL14.EGL_NO_CONTEXT; esurf = EGL14.EGL_NO_SURFACE
    }

    // =====================================================================================
    // muxing
    private fun addTrack(f: MediaFormat): Int {
        mlock.lock()
        try {
            val m = muxer ?: return -1
            if (muxStarted) return -1
            val idx = m.addTrack(f); tracks++
            if (tracks >= expected) { m.start(); muxStarted = true; mcond.signalAll(); return idx }
            var left = 3_000_000_000L
            while (!muxStarted && left > 0) left = mcond.awaitNanos(left)
            if (!muxStarted) { m.start(); muxStarted = true; mcond.signalAll() }   // the other track never came: go on without it
            return idx
        } finally { mlock.unlock() }
    }

    private fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (track < 0 || !muxStarted) return
        synchronized(wLock) {
            try { muxer?.writeSampleData(track, buf, info) } catch (_: Exception) {}
        }
    }

    private fun videoDrain() {
        val enc = venc ?: return
        val info = MediaCodec.BufferInfo()
        var track = -1
        try {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, 10_000)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> if (forceExit) return
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> track = addTrack(enc.outputFormat)
                    i >= 0 -> {
                        val b = enc.getOutputBuffer(i)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (b != null && info.size > 0) {
                            b.position(info.offset); b.limit(info.offset + info.size)
                            write(track, b, info); videoFrames++
                        }
                        enc.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun audioLoop() {
        val ar = arec ?: return; val ac = aenc ?: return
        val info = MediaCodec.BufferInfo()
        val pcm = ByteArray(8192)
        var track = -1
        var frames = 0L
        var startNs = -1L
        var eosSent = false

        fun drain(wait: Boolean): Boolean {   // true when EOS came out
            while (true) {
                val i = ac.dequeueOutputBuffer(info, if (wait) 10_000 else 0)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> track = addTrack(ac.outputFormat)
                    i >= 0 -> {
                        val b = ac.getOutputBuffer(i)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (b != null && info.size > 0) { b.position(info.offset); b.limit(info.offset + info.size); write(track, b, info) }
                        ac.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return true
                    }
                }
            }
        }

        try {
            ar.startRecording()
            while (!forceExit) {
                if (!eosSent) {
                    val n = ar.read(pcm, 0, pcm.size)
                    if (n > 0) {
                        if (startNs < 0) startNs = max(boot() - (n / 4) * 1_000_000_000L / RATE, baseNs)
                        var p = 0
                        var j = 0
                        while (j + 1 < n) { val s = abs((pcm[j].toInt() and 0xFF) or (pcm[j + 1].toInt() shl 8)); if (s > p) p = s; j += 2 }
                        if (p > peak) peak = p
                        var off = 0
                        while (off < n && !forceExit) {
                            val ii = ac.dequeueInputBuffer(10_000)
                            if (ii < 0) { drain(false); continue }
                            val ib = ac.getInputBuffer(ii) ?: continue
                            ib.clear()
                            val c = minOf(ib.remaining(), n - off)
                            ib.put(pcm, off, c)
                            val pts = (startNs - baseNs + frames * 1_000_000_000L / RATE) / 1000
                            ac.queueInputBuffer(ii, 0, c, pts, 0)
                            frames += c / 4; off += c
                        }
                    }
                    if (stopAudio) {
                        var ii = -1
                        var tries = 0
                        while (ii < 0 && tries++ < 50) { ii = ac.dequeueInputBuffer(10_000); if (ii < 0) drain(false) }
                        if (ii >= 0) {
                            val pts = (max(startNs, baseNs) - baseNs + frames * 1_000_000_000L / RATE) / 1000
                            ac.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            eosSent = true
                        } else return
                    }
                    if (drain(false)) return
                } else {
                    if (drain(true)) return
                }
            }
        } catch (_: Exception) {}
    }
}
