package com.mark.kievcine

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.os.Build
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Plain-text report of what this phone really lets a third-party app do with its cameras, audio inputs and encoders. */
object Diagnostics {
    private val caps = listOf(
        "BACKWARD_COMPATIBLE", "MANUAL_SENSOR", "MANUAL_POST_PROCESSING", "RAW", "PRIVATE_REPROCESSING", "READ_SENSOR_SETTINGS",
        "BURST_CAPTURE", "YUV_REPROCESSING", "DEPTH_OUTPUT", "CONSTRAINED_HIGH_SPEED_VIDEO", "MOTION_TRACKING", "LOGICAL_MULTI_CAMERA",
        "MONOCHROME", "SECURE_IMAGE_DATA", "SYSTEM_CAMERA", "OFFLINE_PROCESSING", "ULTRA_HIGH_RESOLUTION_SENSOR", "REMOSAIC_REPROCESSING",
        "DYNAMIC_RANGE_TEN_BIT", "STREAM_USE_CASE", "COLOR_SPACE_PROFILES"
    )

    private fun rangeName(p: Long) = when (p) { 1L -> "SDR"; 2L -> "HLG10"; 4L -> "HDR10"; 8L -> "HDR10+"; else -> "DV/other($p)" }

    private fun hevcProfile(p: Int) = when (p) { 1 -> "Main"; 2 -> "Main10"; 4096 -> "Main10-HDR10"; 8192 -> "Main10-HDR10+"; else -> "p$p" }

    fun report(ctx: Context): String {
        val sb = StringBuilder()
        fun l(s: String = "") { sb.append(s).append('\n') }
        fun <T> safe(label: String, block: () -> T): T? = try { block() } catch (e: Exception) { l("  $label: unavailable (${e.javaClass.simpleName})"); null }

        l("KIEV·CINE capability report")
        l("${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        l()
        l("== CAMERAS ==")
        safe("camera list") {
            val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            for (id in mgr.cameraIdList) {
                val c = mgr.getCameraCharacteristics(id)
                val facing = when (c.get(CameraCharacteristics.LENS_FACING)) { 0 -> "front"; 1 -> "back"; 2 -> "external"; else -> "?" }
                val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
                val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                val eq = if (f != null && sz != null) (f * 43.27f / hypot(sz.width, sz.height)).roundToInt() else 0
                val level = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) { 0 -> "LIMITED"; 1 -> "FULL"; 2 -> "LEGACY"; 3 -> "LEVEL_3"; 4 -> "EXTERNAL"; else -> "?" }
                l("[$id] $facing ${if (eq > 0) "${eq}mm-eq" else ""} · $level")
                l("  capabilities: " + (c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.joinToString(", ") { caps.getOrElse(it) { "cap$it" } } ?: "-"))
                if (Build.VERSION.SDK_INT >= 28) c.physicalCameraIds.takeIf { it.isNotEmpty() }?.let { l("  physical cameras: ${it.joinToString()}") }
                if (Build.VERSION.SDK_INT >= 33) {
                    val d = c.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)
                    l("  10-bit / HDR profiles: " + (d?.supportedProfiles?.joinToString(", ") { rangeName(it) } ?: "none (SDR only)"))
                }
                val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                l("  video sizes: " + (map?.getOutputSizes(MediaRecorder::class.java)?.sortedByDescending { it.width * it.height }?.take(6)?.joinToString { "${it.width}x${it.height}" } ?: "-"))
                l("  fps ranges: " + (c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.joinToString { "${it.lower}-${it.upper}" } ?: "-"))
                map?.highSpeedVideoSizes?.takeIf { it.isNotEmpty() }?.let { hs ->
                    l("  high-speed: " + hs.sortedByDescending { it.width * it.height }.take(3).joinToString { s -> "${s.width}x${s.height}@" + map?.getHighSpeedVideoFpsRangesFor(s)?.maxOfOrNull { it.upper } })
                }
                c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let { l("  ISO: ${it.lower}-${it.upper}") }
                c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let { l("  shutter: 1/${(1e9 / it.lower).roundToInt()} … ${it.upper / 1_000_000} ms") }
                l("  min focus distance: ${c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE)} dpt")
                if (Build.VERSION.SDK_INT >= 30) c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.let { l("  zoom ratio: ${it.lower}-${it.upper}") }
                l("  video stabilization modes: " + (c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.joinToString() ?: "-") + "  (0 off, 1 on, 2 preview)")
                l("  OIS modes: " + (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.joinToString() ?: "-"))
                l("  noise reduction modes: " + (c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)?.joinToString() ?: "-") +
                    " · edge modes: " + (c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)?.joinToString() ?: "-"))
                l()
            }
        }

        l("== AUDIO INPUTS ==")
        safe("audio") {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            for (d in am.getDevices(AudioManager.GET_DEVICES_INPUTS))
                l("type ${d.type} \"${d.productName}\" channels=${d.channelCounts.joinToString()} rates=${d.sampleRates.joinToString()}")
        }
        l()
        l("== VIDEO ENCODERS ==")
        safe("codecs") {
            val wanted = setOf("video/hevc", "video/dolby-vision", "video/av01")
            for (ci in MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos) {
                if (!ci.isEncoder) continue
                for (t in ci.supportedTypes) {
                    if (t !in wanted) continue
                    val cap = ci.getCapabilitiesForType(t)
                    val vc = cap.videoCapabilities
                    val profiles = cap.profileLevels.map { it.profile }.distinct().joinToString { if (t == "video/hevc") hevcProfile(it) else "p$it" }
                    val hw = if (Build.VERSION.SDK_INT >= 29) (if (ci.isHardwareAccelerated) "hw" else "sw") else "?"
                    l("${ci.name} [$t] $hw · up to ${vc.supportedWidths.upper}x${vc.supportedHeights.upper} · ≤${vc.bitrateRange.upper / 1_000_000} Mbps · $profiles")
                }
            }
        }
        return sb.toString()
    }
}
