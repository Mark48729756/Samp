package com.mark.kievcine

import android.graphics.ColorMatrix
import java.io.File

/** "Kiev" look: lifted blacks, warm skin, soft green cast in mids, cooled-down blues, gentle contrast (Soviet Kiev rangefinder + Arsenal glass feel). */
private fun kiev(r: Float, g: Float, b: Float): FloatArray {
    val cr = (r - .5f) * 1.10f + .5f; val cg = (g - .5f) * 1.10f + .5f; val cb = (b - .5f) * 1.10f + .5f
    return floatArrayOf(
        1.06f * cr + .03f * cg - .02f * cb + .02f,
        .01f * cr + 1.00f * cg + .00f * cb + .015f,
        -.02f * cr + .02f * cg + .88f * cb + .03f)
}

fun kievMatrix(): ColorMatrix {
    val o = kiev(0f, 0f, 0f); val x = kiev(1f, 0f, 0f); val y = kiev(0f, 1f, 0f); val z = kiev(0f, 0f, 1f)
    fun row(i: Int) = floatArrayOf(x[i] - o[i], y[i] - o[i], z[i] - o[i], 0f, o[i] * 255f)
    return ColorMatrix(row(0) + row(1) + row(2) + floatArrayOf(0f, 0f, 0f, 1f, 0f))
}

/** Writes Kiev_Look.cube (33^3) next to the clips so the same look can be applied in DaVinci / FCP / Premiere. */
fun writeKievCube(dir: File) {
    val f = File(dir, "Kiev_Look.cube"); if (f.exists()) return
    val n = 33; val sb = StringBuilder("TITLE \"Kiev Look\"\nLUT_3D_SIZE $n\n")
    for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
        val o = kiev(r / (n - 1f), g / (n - 1f), b / (n - 1f))
        sb.append("%.6f %.6f %.6f\n".format(java.util.Locale.US, o[0].coerceIn(0f, 1f), o[1].coerceIn(0f, 1f), o[2].coerceIn(0f, 1f)))
    }
    f.writeText(sb.toString())
}
