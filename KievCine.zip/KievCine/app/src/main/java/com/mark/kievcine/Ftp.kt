package com.mark.kievcine

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPReply
import org.apache.commons.net.ftp.FTPSClient
import org.apache.commons.net.io.CopyStreamAdapter
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class FtpConfig(val host: String = "", val port: Int = 21, val user: String = "anonymous", val pass: String = "", val dir: String = "/", val ftps: Boolean = false, val auto: Boolean = true)

/** AES-GCM with a non-exportable key in the Android Keystore, so the FTP password never sits in plain text on disk. */
private object Vault {
    private const val ALIAS = "kiev_ftp_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    fun encrypt(plain: String): String? = try {
        if (plain.isEmpty()) "" else {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            Base64.encodeToString(c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        }
    } catch (_: Exception) { null }

    fun decrypt(blob: String): String = try {
        if (blob.isEmpty()) "" else {
            val raw = Base64.decode(blob, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        }
    } catch (_: Exception) { "" }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("kiev", 0)

    fun load(): FtpConfig {
        val enc = sp.getString("w2", null)
        // "w" is the legacy plain-text password from older builds; it is migrated on the next save
        val pass = if (enc != null) Vault.decrypt(enc) else sp.getString("w", "").orEmpty()
        return FtpConfig(
            sp.getString("h", "").orEmpty(), sp.getInt("p", 21), sp.getString("u", "anonymous").orEmpty(), pass,
            sp.getString("d", "/").orEmpty(), sp.getBoolean("s", false), sp.getBoolean("a", true)
        )
    }

    fun save(c: FtpConfig) {
        val e = sp.edit().putString("h", c.host).putInt("p", c.port).putString("u", c.user)
            .putString("d", c.dir).putBoolean("s", c.ftps).putBoolean("a", c.auto)
        val blob = Vault.encrypt(c.pass)
        if (blob != null) e.putString("w2", blob).remove("w")
        else e.remove("w2").putString("w", c.pass)   // keystore unavailable on this device: fall back rather than lose the password
        e.apply()
    }
}

/** returns null on success or an error text */
fun ftpUpload(cfg: FtpConfig, f: File, progress: (Int) -> Unit): String? {
    val c: FTPClient = if (cfg.ftps) FTPSClient() else FTPClient()
    return try {
        c.connectTimeout = 15_000
        c.defaultTimeout = 30_000
        c.connect(cfg.host, cfg.port)
        if (!FTPReply.isPositiveCompletion(c.replyCode)) return "server refused (${c.replyCode})"
        c.soTimeout = 30_000
        c.setDataTimeout(java.time.Duration.ofSeconds(60))
        c.setControlKeepAliveTimeout(java.time.Duration.ofSeconds(20))
        if (!c.login(cfg.user, cfg.pass)) return "login failed"
        if (c is FTPSClient) { c.execPBSZ(0); c.execPROT("P") }
        c.enterLocalPassiveMode()
        c.setFileType(FTP.BINARY_FILE_TYPE)
        c.bufferSize = 1 shl 20
        for (part in cfg.dir.split('/').filter { it.isNotBlank() }) {
            if (!c.changeWorkingDirectory(part)) {
                c.makeDirectory(part)
                if (!c.changeWorkingDirectory(part)) return "cannot open folder $part"
            }
        }
        val total = f.length().coerceAtLeast(1)
        var last = -1
        c.copyStreamListener = object : CopyStreamAdapter() {
            override fun bytesTransferred(t: Long, n: Int, s: Long) {
                val p = (t * 100 / total).toInt().coerceIn(0, 100)
                if (p != last) { last = p; progress(p) }
            }
        }
        // upload under a temporary name so a half-sent clip is never mistaken for a finished one
        val tmp = f.name + ".part"
        f.inputStream().use { if (!c.storeFile(tmp, it)) return "store failed (${c.replyCode})" }
        c.deleteFile(f.name)
        if (!c.rename(tmp, f.name)) return "rename failed (${c.replyCode})"
        null
    } catch (e: Exception) { e.message ?: e.javaClass.simpleName }
    finally { try { if (c.isConnected) { try { c.logout() } catch (_: Exception) {}; c.disconnect() } } catch (_: Exception) {} }
}

/** Connects, logs in and opens (creating if needed) the target folder. Returns null when everything works. */
fun ftpTest(cfg: FtpConfig): String? {
    val c: FTPClient = if (cfg.ftps) FTPSClient() else FTPClient()
    return try {
        c.connectTimeout = 10_000
        c.connect(cfg.host, cfg.port)
        if (!FTPReply.isPositiveCompletion(c.replyCode)) return "server refused (${c.replyCode})"
        if (!c.login(cfg.user, cfg.pass)) return "login failed"
        if (c is FTPSClient) { c.execPBSZ(0); c.execPROT("P") }
        c.enterLocalPassiveMode()
        for (part in cfg.dir.split('/').filter { it.isNotBlank() }) {
            if (!c.changeWorkingDirectory(part)) { c.makeDirectory(part); if (!c.changeWorkingDirectory(part)) return "cannot open folder $part" }
        }
        null
    } catch (e: Exception) { e.message ?: e.javaClass.simpleName }
    finally { try { if (c.isConnected) { try { c.logout() } catch (_: Exception) {}; c.disconnect() } } catch (_: Exception) {} }
}

/** Uploads on a background thread, retrying a few times with a growing pause (field networks are flaky). */
fun uploadAsync(cfg: FtpConfig, f: File, status: (String) -> Unit, done: (Boolean) -> Unit = {}) {
    Thread {
        var err: String? = null
        for (attempt in 1..3) {
            status(if (attempt == 1) "FTP 0%" else "FTP retry $attempt")
            err = ftpUpload(cfg, f) { status("FTP $it%") }
            if (err == null) break
            // wrong credentials will not fix themselves
            if (err == "login failed") break
            try { Thread.sleep(3000L * attempt) } catch (_: InterruptedException) { break }
        }
        status(if (err == null) "FTP ✓ ${f.name}" else "FTP ✗ $err")
        done(err == null)
    }.apply { isDaemon = false; name = "kiev-ftp" }.start()
}
