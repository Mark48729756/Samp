package com.mark.kievcine

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/**
 * Copies a finished clip into the public Movies/KievCine folder (visible in Gallery / Google Photos).
 * Needs no permission on Android 10+. Returns true when the copy is complete.
 */
fun exportToGallery(ctx: Context, f: File): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false   // keep the original where it is
    val r = ctx.contentResolver
    val v = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/KievCine")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val uri = (try { r.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) } catch (_: Exception) { null }) ?: return false
    return try {
        val out = r.openOutputStream(uri) ?: throw java.io.IOException("no stream")
        out.use { o -> f.inputStream().use { it.copyTo(o, 1 shl 20) } }
        v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
        r.update(uri, v, null, null)
        true
    } catch (_: Exception) {
        try { r.delete(uri, null, null) } catch (_: Exception) {}
        false
    }
}
