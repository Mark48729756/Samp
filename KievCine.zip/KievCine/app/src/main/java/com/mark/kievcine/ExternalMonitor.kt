package com.mark.kievcine

import android.app.Presentation
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Clean (no UI overlay) program feed to HDMI / USB-C / wireless display. */
class ExternalMonitor(private val ctx: Context, private val engine: CameraEngine) {
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    var connected by mutableStateOf(false)
    var enabled by mutableStateOf(true)
    private var pres: Presentation? = null
    private val listener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) = refresh()
        override fun onDisplayRemoved(id: Int) = refresh()
        override fun onDisplayChanged(id: Int) {}
    }

    fun start() { dm.registerDisplayListener(listener, Handler(Looper.getMainLooper())); refresh() }
    fun stop() { dm.unregisterDisplayListener(listener); hide() }
    fun toggle() { enabled = !enabled; refresh() }

    fun refresh() {
        val d = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull()
        connected = d != null
        if (d != null && enabled) show(d) else hide()
    }

    private fun show(d: Display) {
        if (pres?.display?.displayId == d.displayId) return
        hide()
        val sv = SurfaceView(ctx)
        sv.holder.setFixedSize(engine.previewSize.width, engine.previewSize.height)
        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) { engine.setMonitorSurface(h.surface) }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { engine.setMonitorSurface(null) }
        })
        pres = object : Presentation(ctx, d) {
            override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(sv) }
        }.also { try { it.show() } catch (_: Exception) { pres = null } }
    }

    private fun hide() { pres?.let { try { it.dismiss() } catch (_: Exception) {} }; if (pres != null) engine.setMonitorSurface(null); pres = null }
}
