package com.mark.kievcine

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix as AMatrix
import android.graphics.Paint
import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.TextureView
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.floor

val Ink = Color(0xFF0A0A0A)
val Red = Color(0xFFE30613)      // Leica red dot
val Ivory = Color(0xFFEDE9E0)
val Dim = Color(0x99EDE9E0)
val Hair = Color(0x33EDE9E0)
private const val N = 100        // ticks on the dial

@Composable fun CineTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Red, background = Ink, surface = Color(0xFF141414), onSurface = Ivory, onPrimary = Ivory), content = content)

@Composable fun Ic(id: Int, tint: Color = Ivory, size: Dp = 22.dp) = Icon(painterResource(id), null, Modifier.size(size), tint = tint)

@Composable fun Mono(t: String, c: Color = Ivory, s: Int = 12, w: FontWeight = FontWeight.Light, sp: Float = 1.5f) =
    Text(t, color = c, fontSize = s.sp, fontFamily = FontFamily.Monospace, fontWeight = w, letterSpacing = sp.sp)

@Composable fun RoundBtn(icon: Int, on: Boolean = false, onClick: () -> Unit) {
    val bg by animateColorAsState(if (on) Ivory else Color(0x44000000), tween(220), label = "bg")
    val fg by animateColorAsState(if (on) Ink else Ivory, tween(220), label = "fg")
    val src = remember { MutableInteractionSource() }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pr) 0.88f else 1f, spring(0.5f, 500f), label = "sc")
    Box(Modifier.size(42.dp).scale(sc).clip(CircleShape).background(bg).border(1.dp, Hair, CircleShape)
        .clickable(src, null, onClick = onClick), Alignment.Center) { Ic(icon, fg) }
}

@Composable fun Chip(t: String, on: Boolean = false, onClick: () -> Unit) {
    val c by animateColorAsState(if (on) Ivory else Dim, tween(200), label = "chip")
    val src = remember { MutableInteractionSource() }
    Box(Modifier.clip(RoundedCornerShape(50)).border(1.dp, if (on) Ivory else Hair, RoundedCornerShape(50))
        .background(Color(0x55000000)).clickable(src, null, onClick = onClick).padding(horizontal = 11.dp, vertical = 5.dp)) { Mono(t, c, 11) }
}

@Composable fun RecButton(rec: Boolean, onClick: () -> Unit) {
    val corner by animateDpAsState(if (rec) 6.dp else 28.dp, spring(0.55f, 380f), label = "c")
    val size by animateDpAsState(if (rec) 26.dp else 56.dp, spring(0.55f, 380f), label = "s")
    Box(Modifier.size(76.dp).border(2.dp, Ivory, CircleShape).clip(CircleShape)
        .clickable(remember { MutableInteractionSource() }, null, onClick = onClick), Alignment.Center) {
        Box(Modifier.size(size).clip(RoundedCornerShape(corner)).background(Red))
    }
}

@Composable fun TickDial(value: Float, enabled: Boolean, onChange: (Float) -> Unit, modifier: Modifier) {
    val cur by rememberUpdatedState(value); val oc by rememberUpdatedState(onChange)
    val hap = LocalHapticFeedback.current
    val sp = with(LocalDensity.current) { 14.dp.toPx() }
    Canvas(modifier.pointerInput(enabled) {
        if (enabled) detectHorizontalDragGestures { _, dx ->
            val old = cur; val nv = (old - dx / (sp * N * 0.5f)).coerceIn(0f, 1f)
            if (floor(nv * N) != floor(old * N)) hap.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            oc(nv)
        }
    }) {
        val cx = size.width / 2; val off = value * N * sp
        for (i in 0..N) {
            val x = cx + i * sp - off; if (x < 0 || x > size.width) continue
            val major = i % 5 == 0
            val a = (1f - (abs(x - cx) / cx).coerceIn(0f, 1f) * 0.85f) * (if (enabled) 1f else 0.3f)
            drawLine(Ivory.copy(alpha = a), Offset(x, size.height * (if (major) .2f else .45f)), Offset(x, size.height * .85f), if (major) 2.5f else 1.2f)
        }
        drawLine(Red, Offset(cx, 0f), Offset(cx, size.height), 3.5f)
    }
}

private fun TextureView.applyRotation(rot: Int) =
    setTransform(AMatrix().apply { if (rot == Surface.ROTATION_270) postRotate(180f, width / 2f, height / 2f) })

enum class Ctl(val label: String) { ISO("ISO"), SHUTTER("SHUTTER"), FOCUS("FOCUS"), EV("EV"), ZOOM("ZOOM"), WB("WB") }

@Composable fun Tap(t: String, on: Boolean = false, s: Int = 12, w: FontWeight = FontWeight.Light, onClick: () -> Unit) {
    val c by animateColorAsState(if (on) Ivory else Dim, tween(200), label = "tap")
    Box(Modifier.clickable(remember { MutableInteractionSource() }, null, onClick = onClick).padding(horizontal = 7.dp, vertical = 6.dp)) { Mono(t, c, s, w) }
}

@Composable fun MenuRow(label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(remember { MutableInteractionSource() }, null, onClick = onClick).padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Mono(label, Ivory, 12, FontWeight.Light, 2.5f)
        Spacer(Modifier.weight(1f))
        Mono(value, if (value == "ON") Ivory else Dim, 12, FontWeight.Medium)
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(Hair))
}

@Composable
fun CineApp(engine: CameraEngine, monitor: ExternalMonitor, prefs: Prefs) {
    val ctx = LocalContext.current
    val s = engine.st
    var ftp by remember { mutableStateOf(prefs.load()) }
    var showFtp by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(Ctl.SHUTTER) }
    var dialOpen by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = it[Manifest.permission.CAMERA] == true; if (granted) engine.start()
    }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }
    val ftpNow by rememberUpdatedState(ftp)
    val scopes = remember { Scopes() }
    var tv by remember { mutableStateOf<TextureView?>(null) }
    val scope = rememberCoroutineScope()
    val rackJob = remember { arrayOfNulls<Job>(1) }

    // focus peaking switches itself on while pulling focus by hand
    val peakOn = s.peaking || (!s.autoFocus && dialOpen && tab == Ctl.FOCUS)
    // histogram / zebra / peaking: a 320x180 copy of the preview, a few times per second, only while one of them is on
    LaunchedEffect(tv, s.hist, s.zebra, peakOn) {
        val view = tv ?: return@LaunchedEffect
        if (!s.hist && !s.zebra && !peakOn) { scopes.clear(); return@LaunchedEffect }
        val bmp = Bitmap.createBitmap(320, 180, Bitmap.Config.ARGB_8888)
        while (true) {
            if (view.isAvailable) {
                view.getBitmap(bmp)
                withContext(Dispatchers.Default) { scopes.analyze(bmp, s.zebra, peakOn) }
            }
            delay(150)
        }
    }
    // audio peak meter while recording
    LaunchedEffect(s.recording) {
        s.level = 0f
        while (s.recording) { s.level = maxOf(engine.micLevel(), s.level * 0.8f); delay(70) }
        s.level = 0f
    }
    // every finished clip (also one cut short by leaving the app) goes to FTP
    DisposableEffect(engine) {
        val app = ctx.applicationContext
        engine.onClip = { f ->
            val c = ftpNow
            val upload = c.auto && c.host.isNotBlank()
            Thread {
                val saved = exportToGallery(app, f)   // Movies/KievCine; the original stays if this fails
                if (upload) {
                    uploadAsync(c, f, { s.ftp = it }, { sent -> if (saved && sent) f.delete() })
                } else if (saved) {
                    f.delete()
                }
            }.start()
        }
        onDispose { engine.onClip = null }
    }
    LaunchedEffect(s.ftp) { if (s.ftp.startsWith("FTP ✓") || s.ftp.startsWith("FTP ✗")) { delay(10_000); s.ftp = "" } }
    LaunchedEffect(s.recording) { s.recSec = 0; while (s.recording) { delay(1000); s.recSec++ } }

    fun tOf(c: Ctl) = when (c) { Ctl.ISO -> s.isoT; Ctl.SHUTTER -> s.shutT; Ctl.FOCUS -> s.focusT; Ctl.EV -> s.evT; Ctl.ZOOM -> s.zoomT; Ctl.WB -> 0f }
    fun setT(c: Ctl, v: Float) {
        when (c) { Ctl.ISO -> s.isoT = v; Ctl.SHUTTER -> s.shutT = v; Ctl.FOCUS -> { rackJob[0]?.cancel(); s.focusT = v }; Ctl.EV -> s.evT = v; Ctl.ZOOM -> s.zoomT = v; Ctl.WB -> {} }
        engine.apply()
    }
    fun readout(c: Ctl) = when (c) {
        Ctl.ISO -> if (s.autoExp) "AUTO" else engine.isoValue().toString()
        Ctl.SHUTTER -> if (s.autoExp) "AUTO" else engine.shutterText()
        Ctl.FOCUS -> if (s.autoFocus) "AF" else engine.focusText()
        Ctl.EV -> if (s.autoExp) engine.evText() else "—"
        Ctl.ZOOM -> engine.zoomText()
        Ctl.WB -> listOf("AUTO", "DAY", "CLOUD", "TUNGST", "FLUOR")[s.wb]
    }
    fun dialEnabled(c: Ctl) = when (c) { Ctl.ISO, Ctl.SHUTTER -> !s.autoExp; Ctl.FOCUS -> !s.autoFocus; Ctl.EV -> s.autoExp; else -> true }

    /** cinema focus pull: eased move of the focus ring to a stored mark */
    fun rackTo(target: Float) {
        rackJob[0]?.cancel()
        s.autoFocus = false; engine.apply()
        val from = s.focusT
        val ms = (s.rackSec * 1000f).coerceAtLeast(200f)
        rackJob[0] = scope.launch {
            val t0 = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val p = ((now - t0) / 1_000_000f / ms).coerceIn(0f, 1f)
                val e = p * p * (3f - 2f * p)
                s.focusT = from + (target - from) * e
                engine.apply()
                if (p >= 1f) break
            }
        }
    }

    val m = s.modes.getOrNull(s.mode)
    val srcAspect = if (m != null) m.w.toFloat() / m.h else 16f / 9f
    val aspect = ASPECTS[s.aspect.coerceIn(0, ASPECTS.size - 1)]

    Box(Modifier.fillMaxSize().background(Ink)) {
        // ---------- viewfinder ----------
        var focusPt by remember { mutableStateOf<Offset?>(null) }
        LaunchedEffect(focusPt) { if (focusPt != null) { delay(900); focusPt = null } }
        Box(Modifier.align(Alignment.Center).fillMaxHeight().aspectRatio(srcAspect)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { o -> if (s.autoFocus) { engine.tapFocus(o.x / size.width, o.y / size.height); focusPt = o } },
                    onDoubleTap = { engine.tapFocus(null, null); focusPt = Offset(size.width / 2f, size.height / 2f) })
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, _, zoom, _ ->
                    if (zoom != 1f && s.zMax > s.zMin) {
                        val z = (engine.zoomValue() * zoom).coerceIn(s.zMin, s.zMax)
                        s.zoomT = (z - s.zMin) / (s.zMax - s.zMin); engine.apply()
                    }
                }
            }) {
            val paint = remember { Paint().apply { colorFilter = ColorMatrixColorFilter(kievMatrix()) } }
            AndroidView(factory = { c ->
                TextureView(c).apply {
                    tv = this
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(t: SurfaceTexture, w: Int, h: Int) { engine.setTexture(t); applyRotation(engine.rotation); engine.start() }
                        override fun onSurfaceTextureSizeChanged(t: SurfaceTexture, w: Int, h: Int) { applyRotation(engine.rotation) }
                        override fun onSurfaceTextureDestroyed(t: SurfaceTexture): Boolean { engine.stop(); engine.setTexture(null); return true }
                        override fun onSurfaceTextureUpdated(t: SurfaceTexture) {}
                    }
                }
            }, update = { it.setLayerType(View.LAYER_TYPE_HARDWARE, if (s.kiev) paint else null); it.applyRotation(engine.rotation) }, modifier = Modifier.fillMaxSize())
            // frame lines: everything outside the recorded aspect is dimmed
            Canvas(Modifier.fillMaxSize()) {
                if (s.kiev) drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0x99000000)), center, size.maxDimension * 0.62f))
                var fx = 0f; var fy = 0f; var fw = size.width; var fh = size.height
                if (aspect.ratio > 0f) {
                    if (aspect.ratio >= size.width / size.height) { fh = size.width / aspect.ratio; fy = (size.height - fh) / 2f }
                    else { fw = size.height * aspect.ratio; fx = (size.width - fw) / 2f }
                }
                val dim = Color(0xD9000000)
                if (fy > 0f) {
                    drawRect(dim, Offset.Zero, Size(size.width, fy))
                    drawRect(dim, Offset(0f, fy + fh), Size(size.width, size.height - fy - fh))
                }
                if (fx > 0f) {
                    drawRect(dim, Offset.Zero, Size(fx, size.height))
                    drawRect(dim, Offset(fx + fw, 0f), Size(size.width - fx - fw, size.height))
                }
                if (s.thirds) for (i in 1..2) {
                    drawLine(Hair, Offset(fx + fw * i / 3, fy), Offset(fx + fw * i / 3, fy + fh), 1f)
                    drawLine(Hair, Offset(fx, fy + fh * i / 3), Offset(fx + fw, fy + fh * i / 3), 1f)
                }
                scopes.overlay?.let { drawImage(it, dstSize = IntSize(size.width.toInt(), size.height.toInt()), filterQuality = FilterQuality.None) }
                drawRect(Hair, Offset(fx, fy), Size(fw, fh), style = Stroke(1f))
                focusPt?.let { drawCircle(Ivory, 34.dp.toPx(), it, style = Stroke(2.5f)) }
            }
        }

        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout)) {
            // ---------- top: plain readouts ----------
            Row(Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.padding(end = 6.dp).size(11.dp)) { drawCircle(Red) }
                val free = !s.recording
                Tap(aspect.label, true, 12, FontWeight.Medium) { if (free) engine.setAspect((s.aspect + 1) % ASPECTS.size) }
                Tap(if (s.autoRes) "MAX" else (m?.label ?: "—"), true, 12) { if (free && s.modes.isNotEmpty()) engine.cycleRes() }
                if (s.outW > 0) Mono("${s.outW}×${s.outH}", Dim, 11)
                Tap("${s.fps}", true, 12) { if (free) { val o = s.fpsOptions; s.fps = o[(o.indexOf(s.fps) + 1) % o.size]; engine.restart() } }
                Mono(s.codec, Dim, 11)
            }
            Row(Modifier.align(Alignment.TopEnd).padding(end = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                AnimatedVisibility(s.recording, enter = fadeIn(), exit = fadeOut()) {
                    val a by rememberInfiniteTransition(label = "rec").animateFloat(1f, 0.2f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a")
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Canvas(Modifier.size(9.dp)) { drawCircle(Red.copy(alpha = a)) }
                        Mono("%02d:%02d".format(s.recSec / 60, s.recSec % 60), Ivory, 13, FontWeight.Medium)
                        Canvas(Modifier.size(54.dp, 6.dp)) {
                            drawRect(Hair)
                            drawRect(if (s.level > 0.92f) Red else Ivory, size = Size(size.width * s.level, size.height))
                        }
                        Spacer(Modifier.width(6.dp))
                    }
                }
                if (s.ftp.isNotEmpty()) Mono(s.ftp, if (s.ftp.contains("✗")) Red else Ivory, 11)
                Tap("MENU", false, 12) { showMenu = true }
            }

            // ---------- lenses ----------
            Column(Modifier.align(Alignment.CenterStart).padding(start = 8.dp)) {
                s.cameras.forEach { c -> Tap(c.label, c.id == s.camId, 11) { if (!s.recording && c.id != s.camId) engine.selectCamera(c.id) } }
            }

            // ---------- record ----------
            Box(Modifier.align(Alignment.CenterEnd).padding(end = 18.dp)) {
                RecButton(s.recording) { if (s.recording) engine.stopRecording() else engine.startRecording() }
            }

            // ---------- scopes ----------
            if (s.hist) Canvas(Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 10.dp).size(120.dp, 56.dp)
                .clip(RoundedCornerShape(6.dp)).background(Color(0x88000000))) {
                val hh = scopes.hist; val bw = size.width / hh.size
                for (i in hh.indices) drawRect(Ivory.copy(alpha = 0.85f), Offset(i * bw, size.height * (1f - hh[i])), Size(bw * 0.8f, size.height * hh[i]))
            }

            // ---------- exposure / focus readouts + dial ----------
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth(0.62f).padding(bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedVisibility(dialOpen, enter = fadeIn(tween(160)), exit = fadeOut(tween(120))) {
                    Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x99000000)).padding(horizontal = 12.dp, vertical = 4.dp)) {
                        AnimatedContent(tab, transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(100)) }, label = "dial") { c ->
                            if (c == Ctl.WB) Row(Modifier.height(46.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("AUTO", "DAY", "CLOUD", "TUNGST", "FLUOR").forEachIndexed { i, n -> Tap(n, s.wb == i, 11) { s.wb = i; engine.apply() } }
                            } else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (c == Ctl.ISO || c == Ctl.SHUTTER) Tap("A", s.autoExp, 12, FontWeight.Medium) { s.autoExp = !s.autoExp; engine.apply() }
                                if (c == Ctl.FOCUS) Tap("AF", s.autoFocus, 12, FontWeight.Medium) { rackJob[0]?.cancel(); s.autoFocus = !s.autoFocus; engine.apply() }
                                TickDial(tOf(c), dialEnabled(c), { setT(c, it) }, Modifier.weight(1f).height(46.dp))
                                if (c == Ctl.FOCUS) {
                                    // tap = pull to the mark, hold = store the current focus as the mark
                                    listOf("A" to 0, "B" to 1).forEach { (n, slot) ->
                                        val mark = if (slot == 0) s.rackA else s.rackB
                                        val col = if (mark >= 0f) Ivory else Dim
                                        Box(Modifier.pointerInput(slot) {
                                            detectTapGestures(
                                                onTap = { val t = if (slot == 0) s.rackA else s.rackB; if (t >= 0f) rackTo(t) },
                                                onLongPress = { if (slot == 0) s.rackA = s.focusT else s.rackB = s.focusT })
                                        }.padding(horizontal = 9.dp, vertical = 8.dp)) { Mono(if (mark >= 0f) "$n●" else n, col, 13, FontWeight.Medium) }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Ctl.values().forEach { c ->
                        val sel = c == tab && dialOpen
                        val col by animateColorAsState(if (sel) Ivory else Dim, tween(200), label = "t")
                        Column(Modifier.clickable(remember { MutableInteractionSource() }, null) {
                            if (c == tab && dialOpen) dialOpen = false else { tab = c; dialOpen = true }
                        }.padding(horizontal = 9.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Mono(c.label, col, 9, sp = 2f)
                            Mono(readout(c), col, 14, if (sel) FontWeight.Medium else FontWeight.Light)
                            val w by animateDpAsState(if (sel) 18.dp else 0.dp, spring(0.7f, 500f), label = "u")
                            Box(Modifier.padding(top = 3.dp).height(2.dp).width(w).background(Red))
                        }
                    }
                }
            }

            if (!granted) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Mono("CAMERA ACCESS REQUIRED", Ivory, 13, FontWeight.Medium, 3f)
                Chip("GRANT") { launcher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }
            }
            if (s.error.isNotEmpty()) Box(Modifier.align(Alignment.TopCenter).padding(top = 40.dp)) { Mono(s.error, Red, 11) }
        }

        // ---------- menu ----------
        if (showMenu) Box(Modifier.fillMaxSize().background(Color(0xB3000000))
            .clickable(remember { MutableInteractionSource() }, null) { showMenu = false }) {
            Column(Modifier.align(Alignment.CenterEnd).padding(end = 28.dp).width(300.dp).fillMaxHeight(0.9f)
                .clip(RoundedCornerShape(16.dp)).background(Color(0xFF111111)).border(1.dp, Hair, RoundedCornerShape(16.dp))
                .clickable(remember { MutableInteractionSource() }, null) {}
                .verticalScroll(rememberScrollState())) {
                fun onOff(b: Boolean) = if (b) "ON" else "OFF"
                MenuRow("FILM LOOK", onOff(s.kiev)) { s.kiev = !s.kiev }
                MenuRow("THIRDS", onOff(s.thirds)) { s.thirds = !s.thirds }
                MenuRow("STABILIZE", onOff(s.stab)) { s.stab = !s.stab; engine.apply() }
                MenuRow("HISTOGRAM", onOff(s.hist)) { s.hist = !s.hist }
                MenuRow("ZEBRA", onOff(s.zebra)) { s.zebra = !s.zebra }
                MenuRow("FOCUS PEAK", onOff(s.peaking)) { s.peaking = !s.peaking }
                MenuRow("SHARPEN", onOff(s.sharp)) { s.sharp = !s.sharp; engine.apply() }
                MenuRow("RACK TIME", "${s.rackSec.toInt()} s") { s.rackSec = when { s.rackSec < 2f -> 2f; s.rackSec < 4f -> 4f; s.rackSec < 8f -> 8f; else -> 1f } }
                if (monitor.connected) MenuRow("MONITOR", onOff(monitor.enabled)) { monitor.toggle() }
                MenuRow("FTP", onOff(ftp.host.isNotBlank() && ftp.auto)) { showMenu = false; showFtp = true }
                MenuRow("DEVICE REPORT", "›") { showMenu = false; showInfo = true }
            }
        }
    }

    if (showInfo) {
        val report = remember { Diagnostics.report(ctx) }
        AlertDialog(onDismissRequest = { showInfo = false }, containerColor = Color(0xFF141414),
            title = { Mono("DEVICE REPORT", Ivory, 14, FontWeight.Medium, 3f) },
            text = { Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                Text(report, color = Ivory, fontSize = 10.sp, fontFamily = FontFamily.Monospace, lineHeight = 14.sp) } },
            confirmButton = { TextButton({
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, report) }
                ctx.startActivity(Intent.createChooser(i, null))
            }) { Mono("SHARE", Red, 13, FontWeight.Medium) } },
            dismissButton = { TextButton({ showInfo = false }) { Mono("CLOSE", Dim, 13) } })
    }
    if (showFtp) FtpDialog(ftp, { showFtp = false }) { ftp = it; prefs.save(it); showFtp = false }
}

@Composable
fun FtpDialog(cfg: FtpConfig, onDismiss: () -> Unit, onSave: (FtpConfig) -> Unit) {
    var host by remember { mutableStateOf(cfg.host) }; var port by remember { mutableStateOf(cfg.port.toString()) }
    var user by remember { mutableStateOf(cfg.user) }; var pass by remember { mutableStateOf(cfg.pass) }
    var test by remember { mutableStateOf("") }; var dir by remember { mutableStateOf(cfg.dir) }; var ftps by remember { mutableStateOf(cfg.ftps) }; var auto by remember { mutableStateOf(cfg.auto) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Color(0xFF141414),
        title = { Mono("FTP · AUTO OFFLOAD", Ivory, 14, FontWeight.Medium, 3f) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(host, { host = it }, label = { Text("Host") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(port, { port = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.width(90.dp))
                    OutlinedTextField(dir, { dir = it }, label = { Text("Folder") }, singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(user, { user = it }, label = { Text("User") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.weight(1f))
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(ftps, { ftps = it }); Spacer(Modifier.width(8.dp)); Mono("FTPS (TLS)", Ivory, 12) }
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(auto, { auto = it }); Spacer(Modifier.width(8.dp)); Mono("Upload after each take", Ivory, 12) }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chip("TEST") {
                        test = "…"
                        val cfg = FtpConfig(host.trim(), (port.toIntOrNull() ?: 21).coerceIn(1, 65535), user, pass, dir, ftps, auto)
                        Thread { val e = ftpTest(cfg); test = if (e == null) "✓ OK" else "✗ $e" }.start()
                    }
                    if (test.isNotEmpty()) Mono(test, if (test.startsWith("✗")) Red else Ivory, 11)
                }
            }
        },
        confirmButton = { TextButton({ onSave(FtpConfig(host.trim(), (port.toIntOrNull() ?: 21).coerceIn(1, 65535), user, pass, dir, ftps, auto)) }) { Mono("SAVE", Red, 13, FontWeight.Medium) } },
        dismissButton = { TextButton(onDismiss) { Mono("CANCEL", Dim, 13) } })
}
