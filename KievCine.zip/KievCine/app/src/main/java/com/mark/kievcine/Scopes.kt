package com.mark.kievcine

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlin.math.abs
import kotlin.math.sqrt

/** Histogram, zebra and focus-peaking computed from a small copy of the live preview (no extra camera stream needed). */
class Scopes {
    var hist by mutableStateOf(FloatArray(64))
    var overlay by mutableStateOf<ImageBitmap?>(null)

    fun clear() { overlay = null }

    fun analyze(bmp: Bitmap, zebra: Boolean, peaking: Boolean) {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        val luma = IntArray(w * h)
        val bins = FloatArray(64)
        for (i in px.indices) {
            val p = px[i]
            val y = (((p shr 16) and 255) * 54 + ((p shr 8) and 255) * 183 + (p and 255) * 19) shr 8   // Rec.709 luma
            luma[i] = y; bins[y shr 2] += 1f
        }
        val mx = bins.max().coerceAtLeast(1f)
        for (i in bins.indices) bins[i] = sqrt(bins[i] / mx)   // sqrt keeps shadows and highlights visible
        hist = bins

        if (!zebra && !peaking) { overlay = null; return }
        val out = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (zebra && luma[i] >= 245 && ((x + y) and 7) < 4) { out[i] = 0xDDFF2D2D.toInt(); continue }
            if (peaking && x < w - 1 && y < h - 1) {
                val e = abs(luma[i + 1] - luma[i]) + abs(luma[i + w] - luma[i])
                if (e > 38) out[i] = 0xFF39FF14.toInt()
            }
        }
        overlay = Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888).asImageBitmap()
    }
}
