package com.mark.kievcine

import android.content.pm.ActivityInfo
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.view.Display
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private lateinit var engine: CameraEngine
    private lateinit var monitor: ExternalMonitor
    private lateinit var prefs: Prefs

    /** sensorLandscape flips 90° <-> 270° without recreating the activity, so follow the display ourselves */
    private val rotationListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { if (displayId == Display.DEFAULT_DISPLAY) updateRotation() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE   // always starts (and stays) landscape
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        engine = CameraEngine(this); prefs = Prefs(this)
        monitor = ExternalMonitor(this, engine)
        Thread { writeKievCube(engine.dir) }.start()   // 36k-line LUT: keep it off the UI thread
        setContent { CineTheme { CineApp(engine, monitor, prefs) } }
    }

    @Suppress("DEPRECATION")
    private fun updateRotation() { windowManager.defaultDisplay?.let { engine.rotation = it.rotation } }

    override fun onResume() {
        super.onResume()
        updateRotation()
        getSystemService(DisplayManager::class.java).registerDisplayListener(rotationListener, null)
        monitor.start(); engine.start()
    }

    override fun onPause() {
        getSystemService(DisplayManager::class.java).unregisterDisplayListener(rotationListener)
        monitor.stop(); engine.stop(); super.onPause()
    }

    override fun onDestroy() { engine.release(); super.onDestroy() }
}
