package com.embededly.Clock

import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.AccessTimeFilled
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.HourglassBottom
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.lens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private val DOCK_H = 64.dp
private val SEG = 86.dp
private const val LENS_GROW = .30f

/**
 * Стеклянный док с каплей-линзой, как в Галерее: капля растёт под пальцем, чуть выступает за границы дока,
 * искажает иконки и пружинит между вкладками. Вкладок несколько — капля тянется за пальцем и подхватывает ближайшую.
 */
@Composable
fun GlassDock(backdrop: Backdrop, tab: Int, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val tabs = listOf(
        Icons.Filled.Alarm to tr("Будильник", "Alarm"),
        Icons.Filled.AccessTimeFilled to tr("Мировые часы", "World Clock"),
        Icons.Filled.Timer to tr("Секундомер", "Stopwatch"),
        Icons.Filled.HourglassBottom to tr("Таймер", "Timer"),
    )
    val n = tabs.size
    val dens = LocalDensity.current
    val segPx = with(dens) { SEG.toPx() }
    val dockHPx = with(dens) { DOCK_H.toPx() }
    val dropInsetPx = with(dens) { 3.dp.toPx() }
    val bulgePx = with(dens) { 5.dp.toPx() }
    val bulgeXPx = with(dens) { 4.dp.toPx() }
    val scope = rememberCoroutineScope()
    val pos = remember { Animatable(tab.toFloat()) }
    var pressed by remember { mutableStateOf(false) }
    val spec: AnimationSpec<Float> = spring(.62f, 420f)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) LENS_GROW else 0f, spring(.52f, 330f), label = "grow")
    // искажение иконок внутри капли держится минимум ~170 мс после отпускания и плавно гаснет
    var distortOn by remember { mutableStateOf(false) }
    val distort by animateFloatAsState(
        if (distortOn) 1f else 0f,
        if (distortOn) spring(.8f, 700f) else tween(300, easing = FastOutSlowInEasing), label = "distort"
    )
    val onTabNow by rememberUpdatedState(onTab)

    LaunchedEffect(tab) { if (!pressed) pos.animateTo(tab.toFloat(), spec) }

    /** Прямоугольник капли в координатах дока: растёт от своего центра. */
    fun dropRect(): Rect {
        val w = segPx * (1f + grow) - dropInsetPx * 2f
        val open = (grow / LENS_GROW).coerceIn(0f, 1f)
        val restH = dockHPx - dropInsetPx * 2f
        val h = restH + (dockHPx + 2f * bulgePx - restH) * open
        val bx = bulgeXPx * open
        val x = (pos.value * segPx - (w - segPx) / 2f).coerceIn(-bx, (segPx * n - w + bx).coerceAtLeast(-bx))
        val y = (dockHPx - h) / 2f
        return Rect(x, y, x + w, y + h)
    }

    val dockBackdrop = rememberLayerBackdrop()
    val idle = pal.fg.copy(alpha = .85f)
    val dockSurface = lerp(pal.glass, Color.Black, if (pal.dark) .15f else 0f).copy(alpha = if (pal.dark) .5f else .62f)

    Box(
        modifier.size(SEG * n, DOCK_H)
            .pointerInput(segPx, spec) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    pressed = true; distortOn = true; lift = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    var x = down.position.x
                    fun target() = (x / segPx - .5f).coerceIn(0f, (n - 1).toFloat())
                    scope.launch { pos.animateTo(target(), spec) }
                    drag(down.id) { ch ->
                        x = ch.position.x
                        scope.launch { pos.snapTo(target()) }
                        ch.consume()
                    }
                    val t = target().roundToInt()
                    pressed = false
                    scope.launch { delay(170); if (!pressed) distortOn = false }
                    scope.launch { pos.animateTo(t.toFloat(), spec) }
                    scope.launch { delay(220); if (!pressed) lift = false }
                    onTabNow(t)
                }
            }
    ) {
        // 1) основа дока: стеклянная панель + иконки; пишется в dockBackdrop, чтобы капля преломляла и док, и иконки.
        // Внешний слой вырезает дырку под каплей — иначе оригинальные иконки видны сквозь стекло и «двоятся».
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    val r = dropRect().deflate(1f)
                    drawRoundRect(Color.Black, r.topLeft, r.size, CornerRadius(minOf(r.width, r.height) / 2f), blendMode = BlendMode.Clear)
                }
        ) {
            Box(Modifier.fillMaxSize().layerBackdrop(dockBackdrop)) {
                Box(
                    Modifier.fillMaxSize().glass(backdrop, CircleShape, dockSurface, 8f, 10f, 16f)
                        .border(1.dp, Color.White.copy(alpha = rimAlpha()), CircleShape)
                )
                Row(Modifier.fillMaxSize()) {
                    tabs.forEachIndexed { i, (icon, label) ->
                        val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                        val col = lerp(idle, pal.fg, k)
                        Column(
                            Modifier.weight(1f).fillMaxHeight().graphicsLayer {
                                // иконка и подпись «выходят» из капли: под ней чуть растут и приподнимаются
                                val o = (grow / LENS_GROW).coerceIn(0f, 1f)
                                val sc = 1f + .16f * k * o
                                scaleX = sc; scaleY = sc
                                translationY = -3.dp.toPx() * k * o
                            },
                            Arrangement.Center, Alignment.CenterHorizontally
                        ) {
                            Icon(icon, null, tint = col, modifier = Modifier.size(25.dp))
                            Text(label, color = col, fontSize = 12.sp, lineHeight = 13.sp, maxLines = 2, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
        // 2) капля: два слоя стекла одной формы — фон под доком и сам док с иконками поверх.
        // Размер и положение — через layout (не scale), иначе backdrop считает координаты без учёта масштаба.
        Box(Modifier.fillMaxSize().wrapContentSize(Alignment.TopStart, unbounded = true)) {
            val open = (grow / LENS_GROW).coerceIn(0f, 1f)
            val refH = 9f * (1f + open * .15f)
            val refA = 14f * (1f + open * .25f)
            Box(
                Modifier
                    .offset { val r = dropRect(); IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                    .layout { measurable, _ ->
                        val r = dropRect()
                        val w = r.width.roundToInt().coerceAtLeast(1)
                        val h = r.height.roundToInt().coerceAtLeast(1)
                        val pl = measurable.measure(Constraints.fixed(w, h))
                        layout(w, h) { pl.place(0, 0) }
                    }
            ) {
                Box(Modifier.fillMaxSize().glass(backdrop, CircleShape, Color.White.copy(alpha = .06f), 0f, refH, refA))
                Box(
                    Modifier.fillMaxSize().drawBackdrop(
                        dockBackdrop, { CircleShape },
                        effects = { val d = distort; if (d > .01f) lens((refH * 1.8f * d).dp.toPx(), (refA * 1.8f * d).dp.toPx()) }
                    )
                )
                Box(Modifier.fillMaxSize().border(1.dp, Color.White.copy(alpha = .12f + .30f * open), CircleShape))
            }
        }
    }
}
