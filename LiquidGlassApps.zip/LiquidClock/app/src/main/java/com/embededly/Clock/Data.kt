package com.embededly.Clock

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

private val RU_LANGS = setOf("ru", "uk", "be", "kk", "uz", "az", "ky", "tg")
fun tr(ru: String, en: String): String = if (Locale.getDefault().language in RU_LANGS) ru else en

fun p2(n: Int) = n.toString().padStart(2, '0')

/** Время для показа: пара «10:05» + «AM»/«PM» (пусто в 24-часовом формате). */
fun timeStr(h: Int, m: Int, h24: Boolean): Pair<String, String> =
    if (h24) "${p2(h)}:${p2(m)}" to "" else "${if (h % 12 == 0) 12 else h % 12}:${p2(m)}" to (if (h < 12) "AM" else "PM")

/** days: битовая маска, бит 0 = понедельник … бит 6 = воскресенье; 0 = один раз. */
data class Alarm(val id: Int, val hour: Int, val minute: Int, val days: Int, val label: String, val enabled: Boolean)

class City(val id: String, val ru: String, val en: String) { val name get() = tr(ru, en) }

val CITIES = listOf(
    City("Europe/Moscow", "Москва", "Moscow"), City("Europe/Kiev", "Киев", "Kyiv"),
    City("Europe/London", "Лондон", "London"), City("Europe/Paris", "Париж", "Paris"),
    City("Europe/Berlin", "Берлин", "Berlin"), City("Europe/Madrid", "Мадрид", "Madrid"),
    City("Europe/Rome", "Рим", "Rome"), City("Europe/Istanbul", "Стамбул", "Istanbul"),
    City("Asia/Almaty", "Алматы", "Almaty"), City("Asia/Tashkent", "Ташкент", "Tashkent"),
    City("Asia/Tbilisi", "Тбилиси", "Tbilisi"), City("Asia/Yerevan", "Ереван", "Yerevan"),
    City("Asia/Baku", "Баку", "Baku"), City("Asia/Dubai", "Дубай", "Dubai"),
    City("Asia/Tehran", "Тегеран", "Tehran"), City("Asia/Kolkata", "Дели", "Delhi"),
    City("Asia/Bangkok", "Бангкок", "Bangkok"), City("Asia/Singapore", "Сингапур", "Singapore"),
    City("Asia/Shanghai", "Пекин", "Beijing"), City("Asia/Hong_Kong", "Гонконг", "Hong Kong"),
    City("Asia/Seoul", "Сеул", "Seoul"), City("Asia/Tokyo", "Токио", "Tokyo"),
    City("Asia/Yekaterinburg", "Екатеринбург", "Yekaterinburg"), City("Asia/Novosibirsk", "Новосибирск", "Novosibirsk"),
    City("Asia/Vladivostok", "Владивосток", "Vladivostok"), City("Australia/Sydney", "Сидней", "Sydney"),
    City("Pacific/Auckland", "Окленд", "Auckland"), City("Africa/Cairo", "Каир", "Cairo"),
    City("Africa/Johannesburg", "Йоханнесбург", "Johannesburg"), City("Africa/Lagos", "Лагос", "Lagos"),
    City("America/New_York", "Нью-Йорк", "New York"), City("America/Chicago", "Чикаго", "Chicago"),
    City("America/Denver", "Денвер", "Denver"), City("America/Los_Angeles", "Лос-Анджелес", "Los Angeles"),
    City("America/Toronto", "Торонто", "Toronto"), City("America/Mexico_City", "Мехико", "Mexico City"),
    City("America/Sao_Paulo", "Сан-Паулу", "São Paulo"), City("America/Argentina/Buenos_Aires", "Буэнос-Айрес", "Buenos Aires"),
    City("Pacific/Honolulu", "Гонолулу", "Honolulu"),
)

fun cityName(id: String) = CITIES.firstOrNull { it.id == id }?.name ?: id.substringAfterLast('/').replace('_', ' ')

val DAY_SHORT get() = listOf(tr("Пн", "Mo"), tr("Вт", "Tu"), tr("Ср", "We"), tr("Чт", "Th"), tr("Пт", "Fr"), tr("Сб", "Sa"), tr("Вс", "Su"))

fun daysText(d: Int): String = when (d) {
    0 -> tr("Один раз", "Once")
    127 -> tr("Каждый день", "Every day")
    31 -> tr("По будням", "Weekdays")
    96 -> tr("По выходным", "Weekends")
    else -> DAY_SHORT.filterIndexed { i, _ -> ((d shr i) and 1) == 1 }.joinToString(" ")
}

/** Ближайший момент срабатывания после from. */
fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
    for (d in 0..7) {
        val t = Calendar.getInstance().apply {
            timeInMillis = from; add(Calendar.DAY_OF_YEAR, d)
            set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (t.timeInMillis <= from) continue
        val dow = (t.get(Calendar.DAY_OF_WEEK) + 5) % 7 // понедельник = 0
        if (a.days == 0 || ((a.days shr dow) and 1) == 1) return t.timeInMillis
    }
    return from + 86_400_000L
}

/** Всё, что надо помнить между запусками: формат времени, города, будильники и таймер. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("clock", Context.MODE_PRIVATE)

    var h24: Boolean
        get() = sp.getBoolean("h24", true)
        set(v) { sp.edit().putBoolean("h24", v).apply() }

    fun cities(): List<String> {
        val s = sp.getString("cities", null) ?: return listOf("Europe/Moscow", "Europe/London", "America/New_York", "Asia/Tokyo")
        return runCatching { JSONArray(s).let { a -> List(a.length()) { a.getString(it) } } }.getOrDefault(emptyList())
    }
    fun saveCities(l: List<String>) { sp.edit().putString("cities", JSONArray(l).toString()).apply() }

    fun alarms(): List<Alarm> {
        val s = sp.getString("alarms", null) ?: return emptyList()
        return runCatching {
            val a = JSONArray(s)
            List(a.length()) {
                val o = a.getJSONObject(it)
                Alarm(o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getInt("d"), o.optString("l"), o.getBoolean("e"))
            }
        }.getOrDefault(emptyList())
    }
    fun saveAlarms(l: List<Alarm>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("h", it.hour).put("m", it.minute).put("d", it.days).put("l", it.label).put("e", it.enabled)) }
        sp.edit().putString("alarms", a.toString()).apply()
    }
    fun nextAlarmId(): Int = (alarms().maxOfOrNull { it.id } ?: 0) + 1

    // таймер: total — исходная длительность, end — когда сработает (0 = не идёт), left — остаток на паузе (0 = нет паузы)
    var timerRecent: String
        get() = sp.getString("t_recent", "") ?: ""
        set(v) { sp.edit().putString("t_recent", v).apply() }
    var timerTotal: Long
        get() = sp.getLong("t_total", 0L)
        set(v) { sp.edit().putLong("t_total", v).apply() }
    var timerEnd: Long
        get() = sp.getLong("t_end", 0L)
        set(v) { sp.edit().putLong("t_end", v).apply() }
    var timerLeft: Long
        get() = sp.getLong("t_left", 0L)
        set(v) { sp.edit().putLong("t_left", v).apply() }
    var timerH: Int
        get() = sp.getInt("t_h", 0)
        set(v) { sp.edit().putInt("t_h", v).apply() }
    var timerM: Int
        get() = sp.getInt("t_m", 5)
        set(v) { sp.edit().putInt("t_m", v).apply() }
    var timerS: Int
        get() = sp.getInt("t_s", 0)
        set(v) { sp.edit().putInt("t_s", v).apply() }
}
