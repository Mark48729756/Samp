package com.embededly.Clock

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import java.util.TimeZone

/** Экран сработавшего будильника/таймера поверх блокировки: большое время, «Отложить» и «Стоп». */
class RingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        val id = intent.getIntExtra("id", 0)
        val kind = intent.getStringExtra("kind") ?: "alarm"
        val label = intent.getStringExtra("label") ?: ""
        setContent {
            ClockTheme {
                RingScreen(
                    Ring.title(kind, label), kind != "timer",
                    onSnooze = { Ring.snooze(this, id, kind, label); finish() },
                    onStop = { Ring.stop(this, id); finish() },
                )
            }
        }
    }
}

@Composable
private fun RingScreen(title: String, canSnooze: Boolean, onSnooze: () -> Unit, onStop: () -> Unit) {
    val pal = LocalPal.current
    val backdrop = rememberLayerBackdrop()
    val now by rememberNowMs(false)
    val d = dayMs(now, TimeZone.getDefault())
    val (tt, _) = timeStr((d / 3_600_000L).toInt(), ((d / 60_000L) % 60).toInt(), true)
    Box(Modifier.fillMaxSize().background(pal.bg)) {
        Box(Modifier.fillMaxSize().glassBackdropLayer(backdrop))
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tt, style = TNUM, color = pal.fg, fontSize = 92.sp, fontWeight = FontWeight.Thin)
                    Text(title, color = pal.sub, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                if (canSnooze) GlassKey(backdrop, CircleShape, pal.glass, Modifier.fillMaxWidth().height(64.dp), onTap = onSnooze) {
                    Text(tr("Отложить на $SNOOZE_MIN мин", "Snooze for $SNOOZE_MIN min"), color = pal.fg, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                }
                GlassKey(backdrop, CircleShape, pal.accent.copy(alpha = .95f), Modifier.fillMaxWidth().height(64.dp), onTap = onStop) {
                    Text(tr("Стоп", "Stop"), color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
