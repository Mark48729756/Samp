package com.embededly.Clock

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Стеклянная панель: размытие + линза-преломление поверх backdrop (как в Калькуляторе и Галерее). */
fun Modifier.glass(
    backdrop: Backdrop, shape: Shape, surface: Color,
    blurDp: Float = 4f, refH: Float = 8f, refA: Float = 12f,
): Modifier = this.drawBackdrop(
    backdrop, { shape },
    effects = {
        if (blurDp > 0f) blur(blurDp.dp.toPx())
        if (refH > 0f) lens(refH.dp.toPx(), refA.dp.toPx())
    },
    onDrawSurface = { drawRect(surface) }
)

@Composable
fun rimAlpha(): Float = if (LocalPal.current.dark) .07f else .55f

/** Стеклянная карточка списка. */
@Composable
fun Modifier.glassCard(backdrop: Backdrop, radius: Int = 28): Modifier {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(radius.dp)
    return this.glass(backdrop, shape, pal.glass.copy(alpha = pal.glass.alpha * .85f), 3f, 8f, 12f)
        .border(1.dp, Color.White.copy(alpha = rimAlpha()), shape)
}

/** Плоская карточка списка (как на скриншотах: тёмно-серая, без стекла). */
@Composable
fun Modifier.flatCard(radius: Int = 28): Modifier =
    this.clip(RoundedCornerShape(radius.dp)).background(LocalPal.current.card)

private const val GROW = .09f

/**
 * Стеклянная клавиша/кнопка. При касании вырастает от центра («капля») и плавно возвращается; у быстрого тапа эффект держится ~170 мс.
 * Размер меняется через layout, а не scale, чтобы преломление не «уезжало».
 */
@Composable
fun GlassKey(
    backdrop: Backdrop, shape: Shape, surface: Color, modifier: Modifier = Modifier,
    enabled: Boolean = true, onTap: () -> Unit, content: @Composable BoxScope.() -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val tapNow by rememberUpdatedState(onTap)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) GROW else 0f, spring(.52f, 330f), label = "keyGrow")
    val open = (grow / GROW).coerceIn(0f, 1f)
    val edge = rimAlpha() + .22f * open
    Box(
        modifier.zIndex(if (lift || grow > .002f) 1f else 0f).graphicsLayer { alpha = if (enabled) 1f else .45f }
            .pointerInput(enabled) {
                detectTapGestures(
                    onPress = {
                        if (enabled) { lift = true; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                        tryAwaitRelease()
                        scope.launch { delay(170); lift = false }
                    },
                    onTap = { if (enabled) tapNow() },
                )
            }
    ) {
        Box(
            Modifier.fillMaxSize()
                .layout { m, c ->
                    val w = (c.maxWidth * (1f + grow)).roundToInt()
                    val h = (c.maxHeight * (1f + grow * 1.1f)).roundToInt()
                    val pl = m.measure(Constraints.fixed(w, h))
                    layout(c.maxWidth, c.maxHeight) { pl.place((c.maxWidth - w) / 2, (c.maxHeight - h) / 2) }
                }
                .glass(backdrop, shape, surface, 3f, 8f * (1f + open * .2f), 12f * (1f + open * .3f))
                .border(1.dp, Color.White.copy(alpha = edge), shape),
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

/** Переключатель в стиле стекла (вместо Material Switch). */
@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val x by animateFloatAsState(if (checked) 1f else 0f, spring(.7f, 500f), label = "sw")
    Box(
        Modifier.size(52.dp, 32.dp).clip(CircleShape)
            .background(lerp(pal.fg.copy(alpha = .18f), Color(0xFF34C759), x))
            .clickable(remember { MutableInteractionSource() }, null) { onChange(!checked) }
            .padding(3.dp)
    ) {
        Box(
            Modifier.offset(x = 20.dp * x).size(26.dp).clip(CircleShape).background(Color.White)
                .border(.5.dp, Color.Black.copy(alpha = .12f), CircleShape)
        )
    }
}

/** Кнопка-«капсула» (вместо Material Button). */
@Composable
fun GlassButton(
    text: String, modifier: Modifier = Modifier, enabled: Boolean = true, primary: Boolean = true,
    color: Color = LocalPal.current.accent, onClick: () -> Unit,
) {
    val pal = LocalPal.current
    Box(
        modifier.height(48.dp).graphicsLayer { alpha = if (enabled) 1f else .4f }
            .clip(CircleShape)
            .background(if (primary) color else pal.fg.copy(alpha = .12f))
            .border(1.dp, Color.White.copy(alpha = .16f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Color.White else pal.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/**
 * Окно, которое вываливается каплей из точки касания, растёт до своего размера и при закрытии схлопывается обратно.
 * onDismissed вызывается уже после анимации схлопывания. Все диалоги приложения (добавление города, будильник, подтверждение)
 * строятся на нём, как в Галерее.
 */
@Composable
fun DropWindow(backdrop: Backdrop, onDismissed: () -> Unit, body: @Composable ColumnScope.(close: () -> Unit) -> Unit) {
    val pal = LocalPal.current
    val touch = LocalTouch.current
    val origin = remember { touch.value }
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val gone = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf(false) }
    val close: () -> Unit = {
        if (!closing) {
            closing = true
            scope.launch {
                launch { fade.animateTo(0f, tween(100)) }
                launch { ax.animateTo(0f, tween(230, easing = FastOutSlowInEasing)) }
                ay.animateTo(0f, tween(250, easing = FastOutSlowInEasing))
                gone.animateTo(1f, tween(130, easing = FastOutSlowInEasing)) // шарик втягивается и тает, а не пропадает рывком
                onDismissed()
            }
        }
    }
    LaunchedEffect(Unit) {
        launch { ax.animateTo(1f, spring(.5f, 300f)) }
        launch { ay.animateTo(1f, spring(.42f, 230f)) }
        launch { delay(80); fade.animateTo(1f, tween(200)) }
    }
    BackHandler(onBack = close)
    val shape = RoundedCornerShape(30.dp)
    val surface = pal.glass.copy(alpha = if (pal.dark) .78f else .86f)
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize()
                .drawBehind { drawRect(Color.Black.copy(alpha = .40f * ay.value.coerceIn(0f, 1f))) }
                .clickable(remember { MutableInteractionSource() }, null) { close() }
        )
        Layout(
            modifier = Modifier.fillMaxSize(),
            content = {
                Box(
                    Modifier.graphicsLayer { alpha = 1f - gone.value }
                        .glass(backdrop, shape, surface, 16f, 10f, 18f)
                        .border(1.dp, Color.White.copy(alpha = rimAlpha() + .05f), shape)
                )
                Column(
                    Modifier.graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }
                        .clickable(remember { MutableInteractionSource() }, null) { }
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) { body(close) }
            }
        ) { ms, c ->
            val margin = 24.dp.roundToPx()
            val w = (c.maxWidth - 2 * margin).coerceIn(1, 420.dp.roundToPx())
            val cont = ms[1].measure(Constraints(w, w, 0, (c.maxHeight - 2 * margin).coerceAtLeast(1)))
            val mn = 40.dp.toPx() * (1f - .85f * gone.value)
            val cw = (mn + (cont.width - mn) * ax.value).coerceAtLeast(1f)
            val ch = (mn + (cont.height - mn) * ay.value).coerceAtLeast(1f)
            val fcx = c.maxWidth / 2f
            val fcy = c.maxHeight / 2f
            val ox = if (origin.isSpecified) origin.x else fcx
            val oy = if (origin.isSpecified) origin.y else c.maxHeight * .8f
            val q = ax.value
            val cx = ox + (fcx - ox) * q
            val cy = oy + (fcy - oy) * q
            val glassP = ms[0].measure(Constraints.fixed(cw.roundToInt(), ch.roundToInt()))
            layout(c.maxWidth, c.maxHeight) {
                glassP.place((cx - cw / 2f).roundToInt(), (cy - ch / 2f).roundToInt())
                cont.place((cx - cont.width / 2f).roundToInt(), (cy - cont.height / 2f).roundToInt())
            }
        }
    }
}

/** Окно подтверждения (удаление и т.п.): две кнопки, действие запускается сразу, окно схлопывается следом. */
@Composable
fun GlassConfirm(
    backdrop: Backdrop, title: String, text: String, confirm: String, cancel: String,
    danger: Boolean = false, onConfirm: () -> Unit, onDismiss: () -> Unit,
) {
    val pal = LocalPal.current
    DropWindow(backdrop, onDismiss) { close ->
        Text(title, color = pal.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(text, color = pal.sub, fontSize = 15.sp)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(cancel, Modifier.weight(1f), primary = false) { close() }
            GlassButton(confirm, Modifier.weight(1f), color = if (danger) Color(0xFFFF3B30) else pal.accent) { close(); onConfirm() }
        }
    }
}
