package com.embededly.Clock

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

private sealed interface Dlg {
    data object AddCity : Dlg
    data class EditAlarm(val a: Alarm?) : Dlg
    data class DelCity(val id: String) : Dlg
}

/** Фон, который «видит» стекло: ровный цвет + мягкие цветные пятна, чтобы преломление было заметно. */
@Composable
fun Modifier.glassBackdropLayer(backdrop: LayerBackdrop): Modifier {
    val pal = LocalPal.current
    return this.layerBackdrop(backdrop).background(pal.bg)
}

@Composable
fun ClockApp() {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val store = remember { Store(ctx.applicationContext) }
    val backdrop = rememberLayerBackdrop()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var h24 by remember { mutableStateOf(store.h24) }
    val cities = remember { mutableStateListOf<String>().also { it.addAll(store.cities()) } }
    val alarms = remember { mutableStateListOf<Alarm>().also { it.addAll(store.alarms()) } }
    val sw = remember { SwState() }
    val tm = remember { TimerState(ctx.applicationContext, store) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    val menuMorph = remember { MenuMorph() }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomPad = 64.dp + 10.dp + navBottom + 18.dp

    // будильник или таймер сработал при открытом приложении — перечитываем сохранённое состояние
    LaunchedEffect(Bus.version) {
        alarms.clear(); alarms.addAll(store.alarms()); tm.reload()
    }

    fun putAlarm(a: Alarm) {
        val sorted = (alarms.filter { it.id != a.id } + a).sortedWith(compareBy({ it.hour }, { it.minute }))
        alarms.clear(); alarms.addAll(sorted)
        store.saveAlarms(sorted)
        try { if (a.enabled) Sched.schedule(ctx, a) else Sched.cancel(ctx, a) } catch (_: Exception) { }
    }
    fun removeAlarm(a: Alarm) {
        alarms.removeAll { it.id == a.id }
        store.saveAlarms(alarms.toList()); Sched.cancel(ctx, a)
    }

    val titles = listOf(tr("Будильник", "Alarm"), tr("Мировые часы", "World Clock"), tr("Секундомер", "Stopwatch"), tr("Таймер", "Timer"))

    CompositionLocalProvider(LocalH24 provides h24) {
        Box(Modifier.fillMaxSize().background(pal.bg)) {
            Box(Modifier.fillMaxSize().glassBackdropLayer(backdrop))
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Spacer(Modifier.height(56.dp))
                Row(Modifier.fillMaxWidth().height(76.dp).padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Crossfade(tab, animationSpec = tween(220), label = "title") {
                        Text(titles[it], color = pal.fg, fontSize = 40.sp, fontWeight = FontWeight.Normal, maxLines = 1)
                    }
                }
                Box(Modifier.weight(1f)) {
                    AnimatedContent(
                        tab,
                        transitionSpec = {
                            val dir = if (targetState > initialState) 1 else -1
                            (slideInHorizontally(tween(340)) { it / 5 * dir } + fadeIn(tween(260))) togetherWith
                                (slideOutHorizontally(tween(260)) { -it / 5 * dir } + fadeOut(tween(160)))
                        },
                        label = "tab"
                    ) { t ->
                        when (t) {
                            0 -> AlarmsPage(backdrop, alarms, bottomPad, { a, on -> putAlarm(a.copy(enabled = on)) }) { dlg = Dlg.EditAlarm(it) }
                            1 -> WorldPage(backdrop, cities, bottomPad) { dlg = Dlg.DelCity(it) }
                            2 -> StopwatchPage(backdrop, sw, bottomPad)
                            else -> TimerPage(backdrop, tm, bottomPad)
                        }
                    }
                }
            }

            GlassDock(backdrop, tab, { tab = it; menuOpen = false }, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp))

            GlassMenu(
                menuOpen, backdrop, { menuOpen = false },
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 61.dp, end = 12.dp),
                anchor = Alignment.TopEnd, riseDp = -54f, riseXDp = 0f, minDp = 46f, menuWidthDp = 250f, morph = menuMorph
            ) {
                GlassMenuItem(if (h24) tr("12-часовой формат", "12-hour time") else tr("24-часовой формат", "24-hour time")) {
                    menuOpen = false; h24 = !h24; store.h24 = h24
                }
            }
            // кнопки рисуются ПОСЛЕ меню: у них свой стеклянный фон, и капля вылетает из-под кнопки «⋮»
            AnimatedVisibility(
                tab <= 1, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 7.dp, end = 68.dp),
                enter = fadeIn(tween(220)) + scaleIn(tween(260), .6f), exit = fadeOut(tween(140)) + scaleOut(tween(180), .6f)
            ) {
                GlassIconButton(backdrop, Icons.Outlined.Add) { menuOpen = false; dlg = if (tab == 1) Dlg.AddCity else Dlg.EditAlarm(null) }
            }
            MorphAnchor(
                menuMorph, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 7.dp, end = 12.dp).size(46.dp),
                glass = { },
                icon = { Icon(Icons.Outlined.MoreVert, null, tint = pal.fg) }, onClick = { menuOpen = !menuOpen }
            )

            when (val d = dlg) {
                Dlg.AddCity -> AddCityDialog(backdrop, cities, onPick = { cities.add(it); store.saveCities(cities.toList()) }, onDismiss = { dlg = null })
                is Dlg.EditAlarm -> AlarmEditor(
                    backdrop, d.a,
                    onSave = { hh, mm, dd, ll ->
                        putAlarm(Alarm(d.a?.id ?: store.nextAlarmId(), hh, mm, dd, ll, true))
                    },
                    onDelete = { d.a?.let { removeAlarm(it) } }, onDismiss = { dlg = null }
                )
                is Dlg.DelCity -> GlassConfirm(
                    backdrop, tr("Удалить город?", "Remove city?"), cityName(d.id), tr("Удалить", "Remove"), tr("Отмена", "Cancel"),
                    danger = true, onConfirm = { cities.remove(d.id); store.saveCities(cities.toList()) }, onDismiss = { dlg = null }
                )
                null -> {}
            }
        }
    }
}

@Composable
fun GlassIconButton(backdrop: Backdrop, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.size(46.dp).clickable(remember { MutableInteractionSource() }, null) { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = pal.fg, modifier = Modifier.size(28.dp)) }
}
