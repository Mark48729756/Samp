package com.embededly.Clock

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

const val TIMER_ID = 900_000
private const val SNOOZE_BASE = 500_000
private const val CHANNEL = "ring"
const val SNOOZE_MIN = 10

/** Сообщает открытому интерфейсу, что будильник сработал и список в хранилище мог измениться. */
object Bus { var version by mutableIntStateOf(0) }

object Sched {
    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pi(ctx: Context, req: Int, id: Int, kind: String, label: String): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, req,
            Intent(ctx, AlarmReceiver::class.java).setAction("com.embededly.Clock.RING")
                .putExtra("id", id).putExtra("kind", kind).putExtra("label", label),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun show(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun set(ctx: Context, at: Long, p: PendingIntent) =
        am(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(at, show(ctx)), p)

    fun schedule(ctx: Context, a: Alarm) = set(ctx, nextTrigger(a), pi(ctx, a.id, a.id, "alarm", a.label))
    fun cancel(ctx: Context, a: Alarm) = am(ctx).cancel(pi(ctx, a.id, a.id, "alarm", a.label))
    fun setTimer(ctx: Context, end: Long) = set(ctx, end, pi(ctx, TIMER_ID, TIMER_ID, "timer", ""))
    fun cancelTimer(ctx: Context) = am(ctx).cancel(pi(ctx, TIMER_ID, TIMER_ID, "timer", ""))
    fun snooze(ctx: Context, id: Int, kind: String, label: String) =
        set(ctx, System.currentTimeMillis() + SNOOZE_MIN * 60_000L, pi(ctx, SNOOZE_BASE + id, id, kind, label))

    fun restoreAll(ctx: Context) {
        val st = Store(ctx)
        st.alarms().filter { it.enabled }.forEach { schedule(ctx, it) }
        if (st.timerEnd > System.currentTimeMillis()) setTimer(ctx, st.timerEnd)
    }
}

object Ring {
    fun title(kind: String, label: String) =
        label.ifBlank { if (kind == "timer") tr("Таймер", "Timer") else tr("Будильник", "Alarm") }

    private fun action(ctx: Context, act: String, id: Int, kind: String, label: String): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id * 3 + (if (act == "STOP") 1 else 2),
            Intent(ctx, ActionReceiver::class.java).setAction(act)
                .putExtra("id", id).putExtra("kind", kind).putExtra("label", label),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun ring(ctx: Context, id: Int, kind: String, label: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        nm.createNotificationChannel(NotificationChannel(CHANNEL, tr("Будильник и таймер", "Alarm and timer"), NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
            enableVibration(true); vibrationPattern = longArrayOf(0, 600, 400, 600)
            setBypassDnd(true)
        })
        val open = PendingIntent.getActivity(
            ctx, id,
            Intent(ctx, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("id", id).putExtra("kind", kind).putExtra("label", label),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(ctx, R.drawable.ic_stat_clock)
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_clock)
            .setContentTitle(title(kind, label))
            .setContentText(timeStr(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY), java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE), true).first)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true).setAutoCancel(false)
            .setFullScreenIntent(open, true).setContentIntent(open)
            .addAction(Notification.Action.Builder(icon, tr("Отложить", "Snooze"), action(ctx, "SNOOZE", id, kind, label)).build())
            .addAction(Notification.Action.Builder(icon, tr("Стоп", "Stop"), action(ctx, "STOP", id, kind, label)).build())
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT // звук и вибрация повторяются, пока не нажмут «Стоп»
        nm.notify(id, n)
    }

    fun stop(ctx: Context, id: Int) =
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(id)

    fun snooze(ctx: Context, id: Int, kind: String, label: String) {
        stop(ctx, id); Sched.snooze(ctx, id, kind, label)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val id = i.getIntExtra("id", 0)
        val kind = i.getStringExtra("kind") ?: "alarm"
        var label = i.getStringExtra("label") ?: ""
        if (kind == "alarm") {
            val st = Store(ctx)
            val list = st.alarms().toMutableList()
            val ix = list.indexOfFirst { it.id == id }
            if (ix >= 0) {
                val a = list[ix]; label = a.label
                if (a.days == 0) { list[ix] = a.copy(enabled = false); st.saveAlarms(list) } else Sched.schedule(ctx, a)
            }
        } else if (kind == "timer") {
            val st = Store(ctx); st.timerEnd = 0L; st.timerLeft = 0L
        }
        Ring.ring(ctx, id, kind, label)
        Bus.version++
    }
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val id = i.getIntExtra("id", 0)
        if (i.action == "SNOOZE") Ring.snooze(ctx, id, i.getStringExtra("kind") ?: "alarm", i.getStringExtra("label") ?: "")
        else Ring.stop(ctx, id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { Sched.restoreAll(ctx) }
}
