package com.embededly.Clock

import android.content.Context
import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max

// ───────────────────────── Мир ─────────────────────────

@Composable
fun WorldPage(backdrop: Backdrop, cities: List<String>, bottomPad: Dp, onRemove: (String) -> Unit) {
    val pal = LocalPal.current
    val h24 = LocalH24.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "local") {
            val smooth = rememberNowMs(true)
            val sec = rememberNowMs(false)
            val tz = TimeZone.getDefault()
            Column(Modifier.fillMaxWidth().glassCard(backdrop, 36).padding(vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AnalogClock(smooth, tz, 230.dp)
                val d = dayMs(sec.value, tz)
                val (tt, ap) = timeStr((d / 3_600_000L).toInt(), ((d / 60_000L) % 60).toInt(), h24)
                Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.Bottom) {
                    Text(tt, style = TNUM, color = pal.fg, fontSize = 46.sp, fontWeight = FontWeight.Light)
                    if (ap.isNotEmpty()) Text(ap, color = pal.sub, fontSize = 18.sp, modifier = Modifier.padding(start = 6.dp, bottom = 8.dp))
                }
                val date = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()))
                Text(date.replaceFirstChar { it.uppercase() }, color = pal.sub, fontSize = 16.sp)
            }
        }
        items(cities, key = { it }) { id ->
            val sec = rememberNowMs(false)
            val zone = ZoneId.of(id)
            val tz = TimeZone.getTimeZone(id)
            val d = dayMs(sec.value, tz)
            val (tt, ap) = timeStr((d / 3_600_000L).toInt(), ((d / 60_000L) % 60).toInt(), h24)
            val diffDays = ChronoUnit.DAYS.between(LocalDate.now(), ZonedDateTime.now(zone).toLocalDate()).toInt()
            val offMin = (zone.rules.getOffset(java.time.Instant.now()).totalSeconds - ZonedDateTime.now().offset.totalSeconds) / 60
            val day = when (diffDays) { 0 -> tr("Сегодня", "Today"); 1 -> tr("Завтра", "Tomorrow"); -1 -> tr("Вчера", "Yesterday"); else -> "" }
            val off = (if (offMin >= 0) "+" else "−") + (abs(offMin) / 60).toString() + (if (abs(offMin) % 60 != 0) ":" + p2(abs(offMin) % 60) else "") + tr(" ч", " h")
            Row(
                Modifier.animateItem().fillMaxWidth().glassCard(backdrop, 28)
                    .pointerInput(id) { detectTapGestures(onLongPress = { onRemove(id) }) }
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(cityName(id), color = pal.fg, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                    Text(if (day.isEmpty()) off else "$day, $off", color = pal.sub, fontSize = 14.sp, maxLines = 1)
                }
                Text(tt, style = TNUM, color = pal.fg, fontSize = 38.sp, fontWeight = FontWeight.Light)
                if (ap.isNotEmpty()) Text(ap, color = pal.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 4.dp, top = 12.dp))
            }
        }
        item(key = "hint") {
            Text(tr("Удерживайте город, чтобы удалить", "Hold a city to remove it"), color = pal.sub, fontSize = 13.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        }
    }
}

// ───────────────────────── Будильник ─────────────────────────

@Composable
fun AlarmsPage(backdrop: Backdrop, alarms: List<Alarm>, bottomPad: Dp, onToggle: (Alarm, Boolean) -> Unit, onEdit: (Alarm) -> Unit) {
    val pal = LocalPal.current
    val h24 = LocalH24.current
    if (alarms.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(bottom = bottomPad), contentAlignment = Alignment.Center) {
            Text(tr("Нет будильников\nНажмите «+», чтобы добавить", "No alarms\nTap “+” to add one"), color = pal.sub, fontSize = 17.sp, textAlign = TextAlign.Center)
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(alarms, key = { it.id }) { a ->
            val (tt, ap) = timeStr(a.hour, a.minute, h24)
            Row(
                Modifier.animateItem().fillMaxWidth().glassCard(backdrop, 28)
                    .pointerInput(a.id) { detectTapGestures(onTap = { onEdit(a) }) }
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f).graphicsLayer { alpha = if (a.enabled) 1f else .45f }) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(tt, style = TNUM, color = pal.fg, fontSize = 46.sp, fontWeight = FontWeight.Light)
                        if (ap.isNotEmpty()) Text(ap, color = pal.fg, fontSize = 18.sp, modifier = Modifier.padding(start = 6.dp, bottom = 9.dp))
                    }
                    Text(if (a.label.isBlank()) daysText(a.days) else a.label + ", " + daysText(a.days).lowercase(), color = pal.sub, fontSize = 15.sp, maxLines = 1)
                }
                GlassSwitch(a.enabled) { onToggle(a, it) }
            }
        }
    }
}

// ───────────────────────── Секундомер ─────────────────────────

class SwState {
    var running by mutableStateOf(false)
    var base = 0L
    var acc by mutableLongStateOf(0L)
    val laps = mutableStateListOf<Long>() // накопленное время на момент каждого круга, новые — в начале

    fun elapsed(tick: Long) = if (running) acc + max(0L, tick - base) else acc
    fun toggle() {
        if (running) { acc += SystemClock.elapsedRealtime() - base; running = false }
        else { base = SystemClock.elapsedRealtime(); running = true }
    }
    fun lapOrReset() {
        if (running) laps.add(0, elapsed(SystemClock.elapsedRealtime())) else { acc = 0L; laps.clear() }
    }
}

fun fmtSw(ms: Long): String {
    val cs = (ms / 10) % 100
    val s = (ms / 1000) % 60
    val m = (ms / 60_000) % 60
    val h = ms / 3_600_000
    return (if (h > 0) "$h:${p2(m.toInt())}" else p2(m.toInt())) + ":" + p2(s.toInt()) + "," + p2(cs.toInt())
}

@Composable
fun StopwatchPage(backdrop: Backdrop, sw: SwState, bottomPad: Dp) {
    val pal = LocalPal.current
    var tick by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(sw.running) { while (sw.running) { withFrameNanos { }; tick = SystemClock.elapsedRealtime() } }
    val ms = sw.elapsed(tick)
    val durations = sw.laps.mapIndexed { i, t -> t - (sw.laps.getOrNull(i + 1) ?: 0L) }
    val best = if (durations.size >= 2) durations.min() else -1L
    val worst = if (durations.size >= 2) durations.max() else -1L

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(36.dp))
        Text(fmtSw(ms), style = TNUM, color = pal.fg, fontSize = 72.sp, fontWeight = FontWeight.Thin, maxLines = 1)
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            RoundBtn(backdrop, if (sw.running) tr("Круг", "Lap") else tr("Сброс", "Reset"), enabled = sw.running || ms > 0L) { sw.lapOrReset() }
            RoundBtn(backdrop, if (sw.running) tr("Стоп", "Stop") else tr("Старт", "Start"),
                tint = if (sw.running) Color(0xFFFF3B30) else Color(0xFF34C759)) { sw.toggle() }
        }
        Spacer(Modifier.height(24.dp))
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = bottomPad)
        ) {
            itemsIndexed(durations, key = { i, _ -> sw.laps.size - i }) { i, d ->
                val col = when (d) { best -> Color(0xFF34C759); worst -> Color(0xFFFF3B30); else -> pal.fg }
                Row(Modifier.animateItem().fillMaxWidth().padding(vertical = 11.dp)) {
                    Text(tr("Круг ", "Lap ") + (sw.laps.size - i), color = col, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    Text(fmtSw(d), style = TNUM, color = col, fontSize = 17.sp)
                }
            }
        }
    }
}

/** Круглая стеклянная кнопка (секундомер, таймер). tint — цвет подписи и лёгкая подсветка стекла. */
@Composable
fun RoundBtn(backdrop: Backdrop, text: String, modifier: Modifier = Modifier, tint: Color? = null, enabled: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPal.current
    val surface = if (tint != null) tint.copy(alpha = if (pal.dark) .32f else .26f) else pal.glass
    GlassKey(backdrop, CircleShape, surface, modifier.size(92.dp), enabled, onClick) {
        Text(text, color = tint ?: pal.fg, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

// ───────────────────────── Таймер ─────────────────────────

class TimerState(private val ctx: Context, private val st: Store) {
    var total by mutableLongStateOf(st.timerTotal)
    var end by mutableLongStateOf(st.timerEnd)    // > 0 — идёт
    var left by mutableLongStateOf(st.timerLeft)  // > 0 — на паузе
    var h by mutableIntStateOf(st.timerH)
    var m by mutableIntStateOf(st.timerM)
    var s by mutableIntStateOf(st.timerS)

    val running get() = end > 0L
    val paused get() = !running && left > 0L
    val idle get() = !running && !paused

    fun remaining(now: Long) = if (running) max(0L, end - now) else left

    private fun save() { st.timerTotal = total; st.timerEnd = end; st.timerLeft = left }

    fun start() {
        val t = ((h * 3600L) + m * 60L + s) * 1000L
        if (t <= 0L) return
        st.timerH = h; st.timerM = m; st.timerS = s
        total = t; left = 0L; end = System.currentTimeMillis() + t
        Sched.setTimer(ctx, end); save()
    }
    fun pause() {
        left = max(1L, end - System.currentTimeMillis()); end = 0L
        Sched.cancelTimer(ctx); save()
    }
    fun resume() {
        end = System.currentTimeMillis() + left; left = 0L
        Sched.setTimer(ctx, end); save()
    }
    fun cancel() {
        end = 0L; left = 0L; Sched.cancelTimer(ctx); save()
    }
    /** Таймер дошёл до нуля, пока приложение открыто: звонит уведомление, здесь просто сбрасываем состояние. */
    fun finished() { end = 0L; left = 0L; save() }
    fun reload() { end = st.timerEnd; left = st.timerLeft; total = st.timerTotal }
}

@Composable
fun TimerPage(backdrop: Backdrop, tm: TimerState, bottomPad: Dp) {
    val pal = LocalPal.current
    val mode = if (tm.idle) 0 else 1
    AnimatedContent(
        mode,
        transitionSpec = { (fadeIn(tween(280)) + scaleIn(tween(320), .92f)) togetherWith (fadeOut(tween(180)) + scaleOut(tween(220), .96f)) },
        label = "timerMode"
    ) { m ->
        Column(Modifier.fillMaxSize().padding(bottom = bottomPad), horizontalAlignment = Alignment.CenterHorizontally) {
            if (m == 0) {
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp).glassCard(backdrop, 32).padding(vertical = 16.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    WheelWithLabel(24, tm.h, tr("ч", "h"), Modifier.weight(1f)) { tm.h = it }
                    WheelWithLabel(60, tm.m, tr("мин", "min"), Modifier.weight(1f)) { tm.m = it }
                    WheelWithLabel(60, tm.s, tr("с", "s"), Modifier.weight(1f)) { tm.s = it }
                }
                Spacer(Modifier.weight(1f))
                RoundBtn(backdrop, tr("Старт", "Start"), tint = Color(0xFF34C759), enabled = tm.h + tm.m + tm.s > 0) { tm.start() }
                Spacer(Modifier.weight(1f))
            } else {
                var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
                LaunchedEffect(tm.running) {
                    while (tm.running) {
                        withFrameNanos { }
                        now = System.currentTimeMillis()
                        if (now >= tm.end) { tm.finished(); break }
                    }
                }
                val rem = tm.remaining(now)
                val frac = if (tm.total > 0) (rem.toFloat() / tm.total).coerceIn(0f, 1f) else 0f
                Spacer(Modifier.height(16.dp))
                Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = 10.dp.toPx()
                        val inset = w / 2f
                        drawArc(pal.fg.copy(alpha = .10f), 0f, 360f, false, Offset(inset, inset), Size(size.width - w, size.height - w), style = Stroke(w))
                        drawArc(pal.accent, -90f, 360f * frac, false, Offset(inset, inset), Size(size.width - w, size.height - w), style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val secs = (rem + 999) / 1000
                        val hh = secs / 3600; val mm = (secs / 60) % 60; val ss = secs % 60
                        Text(if (hh > 0) "$hh:${p2(mm.toInt())}:${p2(ss.toInt())}" else "${p2(mm.toInt())}:${p2(ss.toInt())}",
                            style = TNUM, color = pal.fg, fontSize = if (hh > 0) 52.sp else 64.sp, fontWeight = FontWeight.Thin, maxLines = 1)
                        if (tm.running) {
                            val c = java.util.Calendar.getInstance().apply { timeInMillis = tm.end }
                            val (tt, ap) = timeStr(c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), LocalH24.current)
                            Text(tr("Сигнал в ", "Rings at ") + tt + (if (ap.isNotEmpty()) " $ap" else ""), color = pal.sub, fontSize = 15.sp)
                        } else Text(tr("Пауза", "Paused"), color = pal.sub, fontSize = 15.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    RoundBtn(backdrop, tr("Отмена", "Cancel")) { tm.cancel() }
                    if (tm.running) RoundBtn(backdrop, tr("Пауза", "Pause"), tint = pal.accent) { tm.pause() }
                    else RoundBtn(backdrop, tr("Далее", "Resume"), tint = Color(0xFF34C759)) { tm.resume() }
                }
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun WheelWithLabel(count: Int, value: Int, label: String, modifier: Modifier, onChange: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Wheel(count, value, Modifier.width(56.dp), onChange = onChange)
        Text(label, color = pal.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 2.dp))
    }
}
