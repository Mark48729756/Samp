package com.embededly.Clock

import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.Icons
import androidx.compose.material3.Icon
import android.content.Context
import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max

// ───────────────────────── Мир ─────────────────────────

private fun hoursWord(n: Int): String =
    if (tr("r", "e") == "r") when {
        n % 10 == 1 && n % 100 != 11 -> "час"
        n % 10 in 2..4 && n % 100 !in 12..14 -> "часа"
        else -> "часов"
    } else if (n == 1) "hour" else "hours"

@Composable
fun WorldPage(backdrop: Backdrop, cities: List<String>, bottomPad: Dp, onRemove: (String) -> Unit) {
    val pal = LocalPal.current
    val h24 = LocalH24.current
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "local") {
            val smooth = rememberNowMs(true)
            val sec = rememberNowMs(false)
            val tz = TimeZone.getDefault()
            Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AnalogClock(smooth, tz, 280.dp)
                val d = dayMs(sec.value, tz)
                val (tt, ap) = timeStr((d / 3_600_000L).toInt(), ((d / 60_000L) % 60).toInt(), h24)
                val ss = ((d / 1000L) % 60).toInt()
                Row(Modifier.padding(top = 22.dp), verticalAlignment = Alignment.Bottom) {
                    Text(tt + ":" + p2(ss), style = TNUM, color = pal.fg, fontSize = 38.sp, fontWeight = FontWeight.Medium)
                    if (ap.isNotEmpty()) Text(ap, color = pal.sub, fontSize = 16.sp, modifier = Modifier.padding(start = 6.dp, bottom = 5.dp))
                }
                val date = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault()))
                Text(tr("Местное время", "Local time") + "  " + date, color = pal.sub, fontSize = 18.sp)
            }
        }
        items(cities, key = { it }) { id ->
            val sec = rememberNowMs(false)
            val zone = ZoneId.of(id)
            val tz = TimeZone.getTimeZone(id)
            val d = dayMs(sec.value, tz)
            val (tt, ap) = timeStr((d / 3_600_000L).toInt(), ((d / 60_000L) % 60).toInt(), h24)
            val offMin = (zone.rules.getOffset(java.time.Instant.now()).totalSeconds - ZonedDateTime.now().offset.totalSeconds) / 60
            val hrs = abs(offMin) / 60
            val mins = abs(offMin) % 60
            val num = hrs.toString() + (if (mins != 0) ":" + p2(mins) else "")
            val unit = if (mins != 0) tr("часов", "hours") else hoursWord(hrs)
            val off = (if (offMin >= 0) "+" else "-") + num + " " + unit
            val date = ZonedDateTime.now(zone).format(DateTimeFormatter.ofPattern("d MMM", Locale.getDefault()))
            Row(
                Modifier.animateItem().fillMaxWidth().flatCard(28)
                    .pointerInput(id) { detectTapGestures(onLongPress = { onRemove(id) }) }
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(cityName(id), color = pal.fg, fontSize = 26.sp, fontWeight = FontWeight.Normal, maxLines = 1)
                    Text("$date | $off", color = pal.sub, fontSize = 16.sp, maxLines = 1)
                }
                Text(tt, style = TNUM, color = pal.fg, fontSize = 48.sp, fontWeight = FontWeight.Light)
                if (ap.isNotEmpty()) Text(ap, color = pal.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 4.dp, top = 12.dp))
            }
        }
        item(key = "hint") {
            Text(tr("Удерживайте город, чтобы удалить", "Hold a city to remove it"), color = pal.sub, fontSize = 13.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
        }
    }
}

// ───────────────────────── Будильник ─────────────────────────

@Composable
fun AlarmsPage(backdrop: Backdrop, alarms: List<Alarm>, bottomPad: Dp, onToggle: (Alarm, Boolean) -> Unit, onEdit: (Alarm) -> Unit) {
    val pal = LocalPal.current
    val h24 = LocalH24.current
    if (alarms.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(bottom = bottomPad), contentAlignment = Alignment.Center) {
            Text(tr("Нет будильников\nНажмите «+», чтобы добавить", "No alarms\nTap “+” to add one"), color = pal.sub, fontSize = 17.sp, textAlign = TextAlign.Center)
        }
        return
    }
    val nowMs = rememberNowMs(false).value
    val nextIn = alarms.filter { it.enabled }.minOfOrNull { nextTrigger(it, nowMs) - nowMs }
    val status = if (nextIn == null) tr("Все будильники выключены", "All alarms are off") else {
        val totalMin = (nextIn + 59_999L) / 60_000L
        val dd = (totalMin / 1440).toInt(); val hh = ((totalMin / 60) % 24).toInt(); val mm = (totalMin % 60).toInt()
        val ru = tr("Сработает через ", "Rings in ") +
            (if (dd > 0) "$dd " + tr("д ", "d ") else "") + (if (hh > 0) "$hh " + tr("ч ", "h ") else "") + "$mm " + tr("мин", "min")
        ru
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "status") {
            Box(Modifier.fillMaxWidth().padding(vertical = 40.dp, horizontal = 12.dp), contentAlignment = Alignment.Center) {
                Text(status, color = pal.fg, fontSize = 34.sp, fontWeight = FontWeight.Normal, textAlign = TextAlign.Center, lineHeight = 40.sp)
            }
        }
        items(alarms, key = { it.id }) { a ->
            val (tt, ap) = timeStr(a.hour, a.minute, h24)
            Row(
                Modifier.animateItem().fillMaxWidth().flatCard(28)
                    .pointerInput(a.id) { detectTapGestures(onTap = { onEdit(a) }) }
                    .padding(horizontal = 22.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f).graphicsLayer { alpha = if (a.enabled) 1f else .45f }) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(tt, style = TNUM, color = pal.fg, fontSize = 48.sp, fontWeight = FontWeight.Normal)
                        if (ap.isNotEmpty()) Text(ap, color = pal.fg, fontSize = 18.sp, modifier = Modifier.padding(start = 6.dp, bottom = 9.dp))
                    }
                    Text(if (a.label.isBlank()) daysText(a.days) else a.label + ", " + daysText(a.days).lowercase(), color = pal.sub, fontSize = 17.sp, maxLines = 1)
                }
                GlassSwitch(a.enabled) { onToggle(a, it) }
            }
        }
    }
}

// ───────────────────────── Секундомер ─────────────────────────

class SwState {
    var running by mutableStateOf(false)
    var base = 0L
    var acc by mutableLongStateOf(0L)
    val laps = mutableStateListOf<Long>() // накопленное время на момент каждого круга, новые — в начале

    fun elapsed(tick: Long) = if (running) acc + max(0L, tick - base) else acc
    fun toggle() {
        if (running) { acc += SystemClock.elapsedRealtime() - base; running = false }
        else { base = SystemClock.elapsedRealtime(); running = true }
    }
    fun lapOrReset() {
        if (running) laps.add(0, elapsed(SystemClock.elapsedRealtime())) else { acc = 0L; laps.clear() }
    }
}

fun fmtSw(ms: Long): String {
    val cs = (ms / 10) % 100
    val s = (ms / 1000) % 60
    val m = (ms / 60_000) % 60
    val h = ms / 3_600_000
    return (if (h > 0) "$h:${p2(m.toInt())}" else p2(m.toInt())) + ":" + p2(s.toInt()) + "." + p2(cs.toInt())
}

@Composable
fun StopwatchPage(backdrop: Backdrop, sw: SwState, bottomPad: Dp) {
    val pal = LocalPal.current
    var tick by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(sw.running) { while (sw.running) { withFrameNanos { }; tick = SystemClock.elapsedRealtime() } }
    val ms = sw.elapsed(tick)
    val durations = sw.laps.mapIndexed { i, t -> t - (sw.laps.getOrNull(i + 1) ?: 0L) }
    val best = if (durations.size >= 2) durations.min() else -1L
    val worst = if (durations.size >= 2) durations.max() else -1L

    Column(Modifier.fillMaxSize().padding(bottom = bottomPad), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f))
        Text(fmtSw(ms), style = TNUM, color = pal.fg, fontSize = 62.sp, fontWeight = FontWeight.Normal, maxLines = 1)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 28.dp, end = 28.dp, top = 12.dp)) {
                itemsIndexed(durations, key = { i, _ -> sw.laps.size - i }) { i, d ->
                    val col = when (d) { best -> Color(0xFF34C759); worst -> Color(0xFFFF3B30); else -> pal.fg }
                    Row(Modifier.animateItem().fillMaxWidth().padding(vertical = 9.dp)) {
                        Text(tr("Круг ", "Lap ") + (sw.laps.size - i), color = col, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        Text(fmtSw(d), style = TNUM, color = col, fontSize = 17.sp)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            if (sw.running || ms > 0L) PillBtn(backdrop, text = if (sw.running) tr("Круг", "Lap") else tr("Сброс", "Reset")) { sw.lapOrReset() }
            PillBtn(backdrop, icon = if (sw.running) Icons.Filled.Pause else Icons.Filled.PlayArrow) { sw.toggle() }
        }
    }
}

/** Плоская кнопка-«таблетка» (как на скриншотах): синяя иконка или текст. */
@Composable
fun PillBtn(backdrop: Backdrop, icon: ImageVector? = null, text: String? = null, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPal.current
    GlassKey(backdrop, CircleShape, pal.card, modifier.size(width = 112.dp, height = 52.dp), enabled, onClick) {
        if (icon != null) Icon(icon, null, tint = pal.accent, modifier = Modifier.size(30.dp))
        else Text(text.orEmpty(), color = pal.fg, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Круглая стеклянная кнопка (секундомер, таймер). tint — цвет подписи и лёгкая подсветка стекла. */
@Composable
fun RoundBtn(backdrop: Backdrop, text: String, modifier: Modifier = Modifier, tint: Color? = null, enabled: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPal.current
    val surface = if (tint != null) tint.copy(alpha = if (pal.dark) .32f else .26f) else pal.glass
    GlassKey(backdrop, CircleShape, surface, modifier.size(92.dp), enabled, onClick) {
        Text(text, color = tint ?: pal.fg, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

// ───────────────────────── Таймер ─────────────────────────

class TimerState(private val ctx: Context, private val st: Store) {
    var total by mutableLongStateOf(st.timerTotal)
    var end by mutableLongStateOf(st.timerEnd)    // > 0 — идёт
    var left by mutableLongStateOf(st.timerLeft)  // > 0 — на паузе
    var h by mutableIntStateOf(st.timerH)
    var m by mutableIntStateOf(st.timerM)
    var s by mutableIntStateOf(st.timerS)

    val recent = mutableStateListOf<Int>().also { l -> l.addAll(st.timerRecent.split(",").mapNotNull { it.toIntOrNull() }) }

    val running get() = end > 0L
    val paused get() = !running && left > 0L
    val idle get() = !running && !paused

    fun remaining(now: Long) = if (running) max(0L, end - now) else left

    private fun save() { st.timerTotal = total; st.timerEnd = end; st.timerLeft = left }

    fun start() {
        val t = ((h * 3600L) + m * 60L + s) * 1000L
        if (t <= 0L) return
        st.timerH = h; st.timerM = m; st.timerS = s
        val secs = (t / 1000L).toInt()
        recent.remove(secs); recent.add(0, secs); while (recent.size > 5) recent.removeAt(recent.size - 1)
        st.timerRecent = recent.joinToString(",")
        total = t; left = 0L; end = System.currentTimeMillis() + t
        Sched.setTimer(ctx, end); save()
    }
    fun pause() {
        left = max(1L, end - System.currentTimeMillis()); end = 0L
        Sched.cancelTimer(ctx); save()
    }
    fun resume() {
        end = System.currentTimeMillis() + left; left = 0L
        Sched.setTimer(ctx, end); save()
    }
    fun cancel() {
        end = 0L; left = 0L; Sched.cancelTimer(ctx); save()
    }
    /** Таймер дошёл до нуля, пока приложение открыто: звонит уведомление, здесь просто сбрасываем состояние. */
    fun finished() { end = 0L; left = 0L; save() }
    fun reload() { end = st.timerEnd; left = st.timerLeft; total = st.timerTotal }
}

@Composable
fun TimerPage(backdrop: Backdrop, tm: TimerState, bottomPad: Dp) {
    val pal = LocalPal.current
    val mode = if (tm.idle) 0 else 1
    AnimatedContent(
        mode,
        transitionSpec = { (fadeIn(tween(280)) + scaleIn(tween(320), .92f)) togetherWith (fadeOut(tween(180)) + scaleOut(tween(220), .96f)) },
        label = "timerMode"
    ) { m ->
        Column(Modifier.fillMaxSize().padding(bottom = bottomPad), horizontalAlignment = Alignment.CenterHorizontally) {
            if (m == 0) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Wheel(24, tm.h, Modifier.weight(1f), rowH = 56.dp, fontSize = 56.sp, highlight = false, fade = .6f) { tm.h = it }
                    Text(":", color = pal.fg, fontSize = 44.sp, fontWeight = FontWeight.Medium)
                    Wheel(60, tm.m, Modifier.weight(1f), rowH = 56.dp, fontSize = 56.sp, highlight = false, fade = .6f) { tm.m = it }
                    Text(":", color = pal.fg, fontSize = 44.sp, fontWeight = FontWeight.Medium)
                    Wheel(60, tm.s, Modifier.weight(1f), rowH = 56.dp, fontSize = 56.sp, highlight = false, fade = .6f) { tm.s = it }
                }
                Spacer(Modifier.height(12.dp))
                val chips = if (tm.recent.isEmpty()) listOf(60, 300, 600, 900, 1800) else tm.recent.toList()
                val cur = tm.h * 3600 + tm.m * 60 + tm.s
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    chips.chunked(3).forEach { rowChips ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            rowChips.forEach { secs ->
                                val sel = secs == cur
                                Box(
                                    Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp))
                                        .background(if (sel) lerp(pal.card, pal.fg, .12f) else pal.card)
                                        .clickable(remember { MutableInteractionSource() }, null) {
                                            tm.h = secs / 3600; tm.m = (secs / 60) % 60; tm.s = secs % 60
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(p2(secs / 3600) + ":" + p2((secs / 60) % 60) + ":" + p2(secs % 60), style = TNUM,
                                        color = if (sel) pal.fg else pal.sub, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                                }
                            }
                            repeat(3 - rowChips.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                PillBtn(backdrop, icon = Icons.Filled.PlayArrow, modifier = Modifier.graphicsLayer { alpha = if (cur > 0) 1f else .4f }, enabled = cur > 0) { tm.start() }
                Spacer(Modifier.height(24.dp))
            } else {
                var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
                LaunchedEffect(tm.running) {
                    while (tm.running) {
                        withFrameNanos { }
                        now = System.currentTimeMillis()
                        if (now >= tm.end) { tm.finished(); break }
                    }
                }
                val rem = tm.remaining(now)
                val frac = if (tm.total > 0) (rem.toFloat() / tm.total).coerceIn(0f, 1f) else 0f
                Spacer(Modifier.height(16.dp))
                Box(Modifier.size(280.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = 10.dp.toPx()
                        val inset = w / 2f
                        drawArc(pal.fg.copy(alpha = .10f), 0f, 360f, false, Offset(inset, inset), Size(size.width - w, size.height - w), style = Stroke(w))
                        drawArc(pal.accent, -90f, 360f * frac, false, Offset(inset, inset), Size(size.width - w, size.height - w), style = Stroke(w, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val secs = (rem + 999) / 1000
                        val hh = secs / 3600; val mm = (secs / 60) % 60; val ss = secs % 60
                        Text(if (hh > 0) "$hh:${p2(mm.toInt())}:${p2(ss.toInt())}" else "${p2(mm.toInt())}:${p2(ss.toInt())}",
                            style = TNUM, color = pal.fg, fontSize = if (hh > 0) 52.sp else 64.sp, fontWeight = FontWeight.Thin, maxLines = 1)
                        if (tm.running) {
                            val c = java.util.Calendar.getInstance().apply { timeInMillis = tm.end }
                            val (tt, ap) = timeStr(c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), LocalH24.current)
                            Text(tr("Сигнал в ", "Rings at ") + tt + (if (ap.isNotEmpty()) " $ap" else ""), color = pal.sub, fontSize = 15.sp)
                        } else Text(tr("Пауза", "Paused"), color = pal.sub, fontSize = 15.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    RoundBtn(backdrop, tr("Отмена", "Cancel")) { tm.cancel() }
                    if (tm.running) RoundBtn(backdrop, tr("Пауза", "Pause"), tint = pal.accent) { tm.pause() }
                    else RoundBtn(backdrop, tr("Далее", "Resume"), tint = Color(0xFF34C759)) { tm.resume() }
                }
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun WheelWithLabel(count: Int, value: Int, label: String, modifier: Modifier, onChange: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Wheel(count, value, Modifier.width(56.dp), onChange = onChange)
        Text(label, color = pal.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 2.dp))
    }
}
