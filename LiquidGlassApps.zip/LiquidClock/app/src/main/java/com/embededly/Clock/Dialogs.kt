package com.embededly.Clock

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop

/** Окно будильника: барабаны часов и минут, подпись, дни недели. alarm == null — создание нового. */
@Composable
fun AlarmEditor(
    backdrop: Backdrop, alarm: Alarm?, onSave: (hour: Int, minute: Int, days: Int, label: String) -> Unit,
    onDelete: () -> Unit, onDismiss: () -> Unit,
) {
    val pal = LocalPal.current
    val now = java.util.Calendar.getInstance()
    var h by remember { mutableIntStateOf(alarm?.hour ?: now.get(java.util.Calendar.HOUR_OF_DAY)) }
    var m by remember { mutableIntStateOf(alarm?.minute ?: now.get(java.util.Calendar.MINUTE)) }
    var days by remember { mutableIntStateOf(alarm?.days ?: 0) }
    var label by remember { mutableStateOf(alarm?.label ?: "") }
    DropWindow(backdrop, onDismiss) { close ->
        Text(if (alarm == null) tr("Новый будильник", "New alarm") else tr("Будильник", "Alarm"), color = pal.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Wheel(24, h, Modifier.width(84.dp), rowH = 38.dp) { h = it }
            Text(":", color = pal.fg, fontSize = 28.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 6.dp))
            Wheel(60, m, Modifier.width(84.dp), rowH = 38.dp) { m = it }
        }
        GlassField(label, tr("Подпись", "Label")) { label = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            DAY_SHORT.forEachIndexed { i, d ->
                val on = ((days shr i) and 1) == 1
                Box(
                    Modifier.size(38.dp).clip(CircleShape)
                        .background(if (on) pal.accent else pal.fg.copy(alpha = .10f))
                        .clickable(remember { MutableInteractionSource() }, null) { days = days xor (1 shl i) },
                    contentAlignment = Alignment.Center
                ) { Text(d, color = if (on) Color.White else pal.fg, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1) }
            }
        }
        Text(daysText(days), color = pal.sub, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(tr("Отмена", "Cancel"), Modifier.weight(1f), primary = false) { close() }
            GlassButton(tr("Готово", "Save"), Modifier.weight(1f)) { onSave(h, m, days, label.trim()); close() }
        }
        if (alarm != null) {
            Text(
                tr("Удалить будильник", "Delete alarm"), color = Color(0xFFFF3B30), fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .clickable(remember { MutableInteractionSource() }, null) { onDelete(); close() }.padding(vertical = 8.dp)
            )
        }
    }
}

/** Окно выбора города для мировых часов. Уже добавленные не показываются. */
@Composable
fun AddCityDialog(backdrop: Backdrop, existing: List<String>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    DropWindow(backdrop, onDismiss) { close ->
        Text(tr("Выберите город", "Choose a city"), color = pal.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
            CITIES.filter { it.id !in existing }.forEach { c ->
                Text(
                    c.name, color = pal.fg, fontSize = 17.sp,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .clickable(remember { MutableInteractionSource() }, null) { onPick(c.id); close() }
                        .padding(horizontal = 12.dp, vertical = 13.dp)
                )
            }
        }
        GlassButton(tr("Отмена", "Cancel"), Modifier.fillMaxWidth().padding(top = 2.dp), primary = false) { close() }
    }
}

/** Поле ввода в стиле стекла (вместо Material TextField). */
@Composable
fun GlassField(value: String, hint: String, onChange: (String) -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.fg.copy(alpha = .08f))
            .border(1.dp, Color.White.copy(alpha = rimAlpha() * .6f), RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 13.dp)
    ) {
        if (value.isEmpty()) Text(hint, color = pal.sub, fontSize = 17.sp)
        BasicTextField(
            value, { if (it.length <= 40) onChange(it) }, Modifier.fillMaxWidth(), singleLine = true,
            textStyle = TextStyle(color = pal.fg, fontSize = 17.sp), cursorBrush = SolidColor(pal.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
        )
    }
}
