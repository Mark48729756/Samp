package com.embededly.Clock

import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filter
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Текущее время в мс. smooth = каждый кадр (для плавной секундной стрелки), иначе раз в секунду. */
@Composable
fun rememberNowMs(smooth: Boolean): State<Long> = produceState(System.currentTimeMillis(), smooth) {
    while (true) {
        if (smooth) withFrameNanos { } else delay(1000L - System.currentTimeMillis() % 1000L + 5L)
        value = System.currentTimeMillis()
    }
}

/** Миллисекунды с начала суток в заданном часовом поясе. */
fun dayMs(ms: Long, tz: TimeZone): Long = Math.floorMod(ms + tz.getOffset(ms), 86_400_000L)

val TNUM = TextStyle(fontFeatureSettings = "tnum")

/** Аналоговые часы как в системном приложении: циферблат с цифрами, белые стрелки, синяя секундная. */
@Composable
fun AnalogClock(now: State<Long>, tz: TimeZone, size: Dp, modifier: Modifier = Modifier, seconds: Boolean = true) {
    val pal = LocalPal.current
    val blue = pal.accent
    Canvas(modifier.size(size)) {
        val t = dayMs(now.value, tz)
        val hourDeg = (t % 43_200_000L) / 43_200_000f * 360f
        val minDeg = (t % 3_600_000L) / 3_600_000f * 360f
        val secDeg = (t % 60_000L) / 60_000f * 360f
        val r = this.size.minDimension / 2f
        val c = center
        drawCircle(if (pal.dark) Color(0xFF0C0C0C) else Color.White, r)
        drawCircle(pal.fg.copy(alpha = .14f), r - 1.dp.toPx(), style = Stroke(2.dp.toPx()))
        for (i in 0 until 60) {
            val big = i % 5 == 0
            val a = Math.toRadians(i * 6.0 - 90.0)
            val outer = r * .95f
            val inner = outer - (if (big) r * .075f else r * .035f)
            drawLine(
                pal.fg.copy(alpha = if (big) .95f else .30f),
                Offset(c.x + cos(a).toFloat() * outer, c.y + sin(a).toFloat() * outer),
                Offset(c.x + cos(a).toFloat() * inner, c.y + sin(a).toFloat() * inner),
                strokeWidth = (if (big) r * .022f else r * .010f), cap = StrokeCap.Round
            )
        }
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.fg.toArgb()
            textSize = r * .17f
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        for (n in 1..12) {
            val a = Math.toRadians(n * 30.0 - 90.0)
            val rr = r * .74f
            drawContext.canvas.nativeCanvas.drawText(
                n.toString(), c.x + cos(a).toFloat() * rr, c.y + sin(a).toFloat() * rr + paint.textSize * .35f, paint
            )
        }
        fun hand(deg: Float, len: Float, w: Float, tail: Float, color: Color) = rotate(deg, c) {
            drawLine(color, Offset(c.x, c.y + tail), Offset(c.x, c.y - len), strokeWidth = w, cap = StrokeCap.Round)
        }
        hand(hourDeg, r * .50f, r * .065f, 0f, pal.fg)
        hand(minDeg, r * .80f, r * .05f, 0f, pal.fg)
        if (seconds) {
            hand(secDeg, r * .86f, r * .06f, r * .12f, blue.copy(alpha = .28f))
            hand(secDeg, r * .86f, r * .02f, r * .12f, blue)
        }
        drawCircle(if (seconds) blue else pal.fg, r * .05f, c)
        drawCircle(if (pal.dark) Color(0xFF0C0C0C) else Color.White, r * .026f, c)
    }
}

/**
 * Барабан выбора числа (вместо Material TimePicker): бесконечная прокрутка с притягиванием к центру, лёгкий тик вибрации
 * на каждом числе, соседние числа тают и уменьшаются. Значение сообщается, когда барабан остановился.
 */
@Composable
fun Wheel(
    count: Int, value: Int, modifier: Modifier = Modifier, rowH: Dp = 40.dp,
    fmt: (Int) -> String = { p2(it) }, fontSize: TextUnit = 26.sp, highlight: Boolean = true, fade: Float = .42f,
    onChange: (Int) -> Unit,
) {
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val base = 400 * count
    val st = androidx.compose.foundation.lazy.rememberLazyListState(initialFirstVisibleItemIndex = base + value - 2)
    val fling = rememberSnapFlingBehavior(st, SnapPosition.Center)
    val onNow by rememberUpdatedState(onChange)
    fun centerIdx(): Int {
        val li = st.layoutInfo
        val mid = (li.viewportStartOffset + li.viewportEndOffset) / 2
        return li.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2 - mid) }?.index ?: (base + value)
    }
    LaunchedEffect(value) {
        if (!st.isScrollInProgress && centerIdx() % count != value) st.scrollToItem(base + value - 2)
    }
    LaunchedEffect(Unit) {
        var last = -1
        snapshotFlow { centerIdx() }.collect { if (last != -1 && it != last) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); last = it }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { st.isScrollInProgress }.filter { !it }.collect { onNow(centerIdx() % count) }
    }
    Box(modifier.height(rowH * 5), contentAlignment = Alignment.Center) {
        if (highlight) Box(Modifier.fillMaxWidth().height(rowH).clip(RoundedCornerShape(12.dp)).background(pal.fg.copy(alpha = .08f)))
        LazyColumn(Modifier.fillMaxWidth(), state = st, flingBehavior = fling) {
            items(count = base * 2) { i ->
                Box(
                    Modifier.fillMaxWidth().height(rowH).graphicsLayer {
                        val li = st.layoutInfo
                        val inf = li.visibleItemsInfo.firstOrNull { it.index == i }
                        if (inf != null) {
                            val mid = (li.viewportStartOffset + li.viewportEndOffset) / 2f
                            val d = abs(inf.offset + inf.size / 2f - mid) / size.height
                            alpha = (1f - d * fade).coerceIn(.12f, 1f)
                            val s = (1f - d * .12f).coerceIn(.6f, 1f)
                            scaleX = s; scaleY = s
                        }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Text(fmt(i % count), color = pal.fg, fontSize = fontSize, fontWeight = FontWeight.Medium, style = TNUM.copy(fontSize = fontSize, fontWeight = FontWeight.Medium, color = pal.fg))
                }
            }
        }
    }
}
