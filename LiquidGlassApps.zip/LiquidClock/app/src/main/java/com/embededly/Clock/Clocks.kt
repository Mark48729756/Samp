package com.embededly.Clock

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filter
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Текущее время в мс. smooth = каждый кадр (для плавной секундной стрелки), иначе раз в секунду. */
@Composable
fun rememberNowMs(smooth: Boolean): State<Long> = produceState(System.currentTimeMillis(), smooth) {
    while (true) {
        if (smooth) withFrameNanos { } else delay(1000L - System.currentTimeMillis() % 1000L + 5L)
        value = System.currentTimeMillis()
    }
}

/** Миллисекунды с начала суток в заданном часовом поясе. */
fun dayMs(ms: Long, tz: TimeZone): Long = Math.floorMod(ms + tz.getOffset(ms), 86_400_000L)

val TNUM = TextStyle(fontFeatureSettings = "tnum")

/**
 * Аналоговые часы в стиле иконки приложения: чёрные часовая и минутная стрелки с белой точкой у конца,
 * красная секундная. Время читается в момент отрисовки, поэтому страница не перекомпонуется каждый кадр.
 */
@Composable
fun AnalogClock(now: State<Long>, tz: TimeZone, size: Dp, modifier: Modifier = Modifier, seconds: Boolean = true) {
    val pal = LocalPal.current
    Canvas(modifier.size(size)) {
        val t = dayMs(now.value, tz)
        val hourDeg = (t % 43_200_000L) / 43_200_000f * 360f
        val minDeg = (t % 3_600_000L) / 3_600_000f * 360f
        val secDeg = (t % 60_000L) / 60_000f * 360f
        val r = this.size.minDimension / 2f
        val c = center
        drawCircle(pal.fg.copy(alpha = if (pal.dark) .08f else .05f), r)
        for (i in 0 until 60) {
            val big = i % 5 == 0
            val a = Math.toRadians(i * 6.0 - 90.0)
            val outer = r * .93f
            val inner = outer - (if (big) r * .10f else r * .045f)
            drawLine(
                pal.fg.copy(alpha = if (big) .92f else .32f),
                Offset(c.x + cos(a).toFloat() * outer, c.y + sin(a).toFloat() * outer),
                Offset(c.x + cos(a).toFloat() * inner, c.y + sin(a).toFloat() * inner),
                strokeWidth = (if (big) r * .028f else r * .012f), cap = StrokeCap.Round
            )
        }
        fun hand(deg: Float, len: Float, w: Float, tail: Float, color: Color, dot: Boolean) = rotate(deg, c) {
            drawRoundRect(color, Offset(c.x - w / 2f, c.y - len), Size(w, len + tail), CornerRadius(w / 2f))
            if (dot) drawCircle(Color.White, w * .2f, Offset(c.x, c.y - len + w * .75f))
        }
        hand(hourDeg, r * .50f, r * .085f, r * .06f, pal.fg, true)
        hand(minDeg, r * .74f, r * .065f, r * .06f, pal.fg, true)
        if (seconds) hand(secDeg, r * .80f, r * .022f, r * .14f, SecondRed, false)
        drawCircle(if (seconds) SecondRed else pal.fg, r * .045f, c)
        drawCircle(pal.bg, r * .016f, c)
    }
}

/**
 * Барабан выбора числа (вместо Material TimePicker): бесконечная прокрутка с притягиванием к центру, лёгкий тик вибрации
 * на каждом числе, соседние числа тают и уменьшаются. Значение сообщается, когда барабан остановился.
 */
@Composable
fun Wheel(
    count: Int, value: Int, modifier: Modifier = Modifier, rowH: Dp = 40.dp,
    fmt: (Int) -> String = { p2(it) }, onChange: (Int) -> Unit,
) {
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val base = 400 * count
    val st = androidx.compose.foundation.lazy.rememberLazyListState(initialFirstVisibleItemIndex = base + value - 2)
    val fling = rememberSnapFlingBehavior(st, SnapPosition.Center)
    val onNow by rememberUpdatedState(onChange)
    fun centerIdx(): Int {
        val li = st.layoutInfo
        val mid = (li.viewportStartOffset + li.viewportEndOffset) / 2
        return li.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2 - mid) }?.index ?: (base + value)
    }
    LaunchedEffect(Unit) {
        var last = -1
        snapshotFlow { centerIdx() }.collect { if (last != -1 && it != last) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); last = it }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { st.isScrollInProgress }.filter { !it }.collect { onNow(centerIdx() % count) }
    }
    Box(modifier.height(rowH * 5), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxWidth().height(rowH).clip(RoundedCornerShape(12.dp)).background(pal.fg.copy(alpha = .08f)))
        LazyColumn(Modifier.fillMaxWidth(), state = st, flingBehavior = fling) {
            items(count = base * 2) { i ->
                Box(
                    Modifier.fillMaxWidth().height(rowH).graphicsLayer {
                        val li = st.layoutInfo
                        val inf = li.visibleItemsInfo.firstOrNull { it.index == i }
                        if (inf != null) {
                            val mid = (li.viewportStartOffset + li.viewportEndOffset) / 2f
                            val d = abs(inf.offset + inf.size / 2f - mid) / size.height
                            alpha = (1f - d * .42f).coerceIn(.12f, 1f)
                            val s = (1f - d * .12f).coerceIn(.6f, 1f)
                            scaleX = s; scaleY = s
                        }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Text(fmt(i % count), color = pal.fg, fontSize = 26.sp, fontWeight = FontWeight.Medium, style = TNUM.copy(fontSize = 26.sp, fontWeight = FontWeight.Medium, color = pal.fg))
                }
            }
        }
    }
}
