package com.embededly.Gallery

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

@Suppress("UNCHECKED_CAST")
class Pref<T : Any>(private val sp: SharedPreferences, private val key: String, val def: T) {
    var value by mutableStateOf(read()); private set

    private fun read(): T {
        val d: Any = def
        return when (d) {
            is Boolean -> sp.getBoolean(key, d)
            is Int -> sp.getInt(key, d)
            is Float -> sp.getFloat(key, d)
            is String -> sp.getString(key, d) ?: d
            is Set<*> -> sp.getStringSet(key, d as Set<String>) ?: d
            else -> d
        } as T
    }

    fun set(v: T) {
        value = v
        val e = sp.edit()
        when (v) {
            is Boolean -> e.putBoolean(key, v)
            is Int -> e.putInt(key, v)
            is Float -> e.putFloat(key, v)
            is String -> e.putString(key, v)
            is Set<*> -> e.putStringSet(key, v as Set<String>)
        }
        e.apply()
    }

    fun reset() = set(def)
}

val ACCENTS = listOf(
    Color(0xFFFF8A1F), Color(0xFF0A84FF), Color(0xFF30D158),
    Color(0xFFFF375F), Color(0xFFFF453A), Color(0xFFBF5AF2),
)

/** Постоянное значение (не настраивается и не хранится). */
class Fixed<T>(val value: T)

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("gallery_prefs", Context.MODE_PRIVATE)
    private val all = ArrayList<Pref<*>>()
    private fun <T : Any> p(key: String, def: T) = Pref(sp, key, def).also { all += it }

    // --- Внешний вид ---
    val theme = p("theme", "system")            // dark | light | system
    val amoled = p("amoled", true)
    val accent = p("accent", 0)
    val anim = p("anim", true)
    val haptics = p("haptics", true)

    // --- Liquid Glass ---
    val glass = p("glass", true)
    val vibrancy = Fixed(true)
    val dockBlur = Fixed(8f)
    val dockRefH = Fixed(10f)
    val dockRefA = Fixed(16f)
    val lensRefH = Fixed(9f)
    val lensRefA = Fixed(14f)
    val lensBlur = Fixed(0f)
    val dockOpacity = Fixed(.5f)
    val lensTint = Fixed(.10f)
    val lensGrow = Fixed(.30f)
    val stiffness = Fixed(420f)
    val damping = Fixed(.62f)
    val dockHeight = Fixed(64)
    val dockBottom = Fixed(16)
    val dockLabels = p("dockLabels", true)
    val searchButton = p("searchButton", true)
    val autoHideDock = p("autoHideDock", false)

    // --- Сетка ---
    val photoCols = p("photoCols", 3)
    val albumCols = p("albumCols", 3)
    val gap = p("gap", 2)
    val albumRadius = p("albumRadius", 24)
    val thumbFit = p("thumbFit", false)
    val showDuration = p("showDuration", true)
    val showHeader = p("showHeader", true)
    val showAlbumCount = p("showAlbumCount", true)
    val groupByDate = p("groupByDate", true)

    // --- Контент ---
    val showPhotos = p("showPhotos", true)
    val showVideos = p("showVideos", true)
    val sortKey = p("sortKey", "date_added")  // date_added | date_modified | _display_name | _size
    val sortDesc = p("sortDesc", true)
    val albumSort = p("albumSort", "recent")  // recent | count | name
    val hidden = p("hidden", emptySet<String>())

    // --- Просмотр ---
    val viewerBg = p("viewerBg", "black")     // black | theme
    val viewerClose = p("viewerClose", true)
    val viewerCounter = p("viewerCounter", true)
    val viewerFill = p("viewerFill", false)
    val slideshowSec = p("slideshowSec", 3)

    fun resetAll() = all.forEach { it.reset() }
}
