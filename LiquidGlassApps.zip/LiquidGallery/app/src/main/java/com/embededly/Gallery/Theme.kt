package com.embededly.Gallery

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class Pal(
    val bg: Color, val fg: Color, val sub: Color,
    val glass: Color, val accent: Color, val dark: Boolean,
)

val LocalPal = staticCompositionLocalOf<Pal> { error("no Pal") }
val LocalPrefs = staticCompositionLocalOf<Prefs> { error("no Prefs") }
