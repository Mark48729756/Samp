package com.embededly.Gallery

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage

private class CardData(val title: String, val cover: Uri?, val count: Int, val icon: ImageVector, val onClick: () -> Unit)

private val STD_NAMES = setOf("pictures", "download", "downloads", "dcim", "movies", "documents", "recordings")

@Composable
fun AlbumsScreen(
    all: List<Media>, albums: List<Album>, trashCount: Int,
    onOpen: (Album) -> Unit, onList: (String, List<Album>) -> Unit, onTrash: () -> Unit,
) {
    val pal = LocalPal.current
    val prefs = LocalPrefs.current
    val cols = prefs.albumCols.value

    val favs = remember(all) { all.filter { it.fav } }
    val videos = remember(all) { all.filter { it.isVideo } }
    val camera = albums.firstOrNull { it.name.equals("Camera", true) }
    val shots = albums.firstOrNull { it.name.startsWith("Screenshot", true) }
    val gallery = albums.filter { it !== camera && it !== shots && it.name.lowercase() in STD_NAMES }
    val other = albums.filter { it !== camera && it !== shots && it.name.lowercase() !in STD_NAMES }

    val cards = buildList {
        val allAlbum = Album(ALL_ID, t(R.string.s_all_items), all)
        add(CardData(allAlbum.name, all.firstOrNull()?.uri, all.size, Icons.Outlined.PhotoLibrary) { onOpen(allAlbum) })
        camera?.let { c ->
            val a = Album(c.id, t(R.string.s_camera), c.items)
            add(CardData(a.name, c.items.first().uri, c.items.size, Icons.Outlined.PhotoCamera) { onOpen(a) })
        }
        shots?.let { c ->
            val a = Album(c.id, t(R.string.s_screenshots), c.items)
            add(CardData(a.name, c.items.first().uri, c.items.size, Icons.Outlined.CropFree) { onOpen(a) })
        }
        if (videos.isNotEmpty()) {
            val a = Album(VIDEO_ID, t(R.string.s_video), videos)
            add(CardData(a.name, videos.first().uri, videos.size, Icons.Outlined.Videocam) { onOpen(a) })
        }
        if (android.os.Build.VERSION.SDK_INT >= 30 && favs.isNotEmpty()) {
            val a = Album(FAV_ID, t(R.string.s_favorites), favs)
            add(CardData(a.name, favs.first().uri, favs.size, Icons.Outlined.Favorite) { onOpen(a) })
        }
        if (android.os.Build.VERSION.SDK_INT >= 30 && trashCount > 0)
            add(CardData(t(R.string.s_trash), null, trashCount, Icons.Outlined.Delete, onTrash))
    }
    val tiles: List<Album?> = gallery + (if (other.isNotEmpty()) listOf<Album?>(null) else emptyList())

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 140.dp)) {
        item { Spacer(Modifier.statusBarsPadding().height(56.dp)) }
        item { SectionTitle(t(R.string.s_common)) { cards.firstOrNull()?.onClick?.invoke() } }
        items(cards.chunked(2)) { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { CommonCard(it, Modifier.weight(1f)) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (tiles.isNotEmpty()) {
            item { SectionTitle(t(R.string.s_gallery)) { onList(t(R.string.s_gallery), albums) } }
            items(tiles.chunked(cols)) { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { a ->
                        if (a != null) AlbumTile(a, Modifier.weight(1f), onOpen)
                        else OtherTile(other, Modifier.weight(1f)) { onList(t(R.string.s_other_albums), other) }
                    }
                    repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 6.dp, top = 22.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = pal.fg, fontSize = 28.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = pal.sub, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun CommonCard(c: CardData, modifier: Modifier) {
    val pal = LocalPal.current
    val card = if (pal.dark) pal.fg.copy(alpha = .08f) else Color.White
    Row(
        modifier.then(if (pal.dark) Modifier else Modifier.shadow(3.dp, RoundedCornerShape(24.dp), clip = false, ambientColor = Color(0x22000000), spotColor = Color(0x22000000)))
            .clip(RoundedCornerShape(24.dp)).background(card).clickable(onClick = c.onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(pal.fg.copy(alpha = .08f)), contentAlignment = Alignment.Center) {
            if (c.cover != null) AsyncImage(c.cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(c.icon, null, tint = pal.sub)
        }
        Column(Modifier.padding(start = 12.dp).weight(1f)) {
            Text(c.title, color = pal.fg, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(c.icon, null, tint = pal.sub, modifier = Modifier.size(16.dp))
                Text("${c.count}", color = pal.sub, fontSize = 15.sp, modifier = Modifier.padding(start = 6.dp))
            }
        }
    }
}

@Composable
private fun AlbumTile(a: Album, modifier: Modifier, onOpen: (Album) -> Unit) {
    val pal = LocalPal.current
    val prefs = LocalPrefs.current
    Column(modifier.clickable { onOpen(a) }) {
        AsyncImage(a.items.first().uri, null,
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(prefs.albumRadius.value.dp)),
            contentScale = ContentScale.Crop)
        Text(a.name, color = pal.fg, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 4.dp, top = 8.dp))
        if (prefs.showAlbumCount.value)
            Text("${a.items.size}", color = pal.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp))
    }
}

@Composable
private fun OtherTile(other: List<Album>, modifier: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    val prefs = LocalPrefs.current
    val covers = other.take(4).map { it.items.first().uri }
    Column(modifier.clickable(onClick = onClick)) {
        Column(Modifier.fillMaxWidth().aspectRatio(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            for (r in 0..1) Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (c in 0..1) {
                    val u = covers.getOrNull(r * 2 + c)
                    Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(14.dp)).background(pal.fg.copy(alpha = .06f))) {
                        if (u != null) AsyncImage(u, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                }
            }
        }
        Text(t(R.string.s_other_albums), color = pal.fg, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 4.dp, top = 8.dp))
        if (prefs.showAlbumCount.value)
            Text("${other.size}", color = pal.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 4.dp))
    }
}

@Composable
fun AlbumListScreen(title: String, albums: List<Album>, onOpen: (Album) -> Unit, onBack: () -> Unit) {
    val pal = LocalPal.current
    val cols = LocalPrefs.current.albumCols.value
    Column(Modifier.fillMaxSize().background(pal.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = pal.fg) }
            Text(title, color = pal.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyVerticalGrid(GridCells.Fixed(cols), Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(albums, key = { it.id }) { a -> AlbumTile(a, Modifier, onOpen) }
        }
    }
}
