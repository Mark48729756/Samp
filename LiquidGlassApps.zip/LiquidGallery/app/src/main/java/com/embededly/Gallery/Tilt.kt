package com.embededly.Gallery

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.max

/**
 * Наклон телефона для бликов на стекле. Берётся из гироскопа (game rotation vector, он сам сращивает гироскоп с акселерометром),
 * если его нет — из акселерометра. Значения -1..1 считаются относительно того, как телефон держат сейчас
 * (медленно «забываем» текущее положение), поэтому блик оживает именно от наклона, а не от позы.
 */
object Tilt {
    val xy = mutableStateOf(Offset.Zero)
    private var sm: SensorManager? = null
    private var base = Offset.Zero
    private var hasBase = false
    private var out = Offset.Zero
    private val rot = FloatArray(9)

    private val listener = object : SensorEventListener {
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        override fun onSensorChanged(e: SensorEvent) {
            val x: Float
            val y: Float
            if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                x = e.values[0] / 9.81f; y = e.values[1] / 9.81f
            } else {
                val v = if (e.values.size > 4) e.values.copyOf(4) else e.values
                SensorManager.getRotationMatrixFromVector(rot, v)
                x = rot[6]; y = rot[7] // куда в координатах телефона смотрит «вверх» мира
            }
            if (!hasBase) { base = Offset(x, y); hasBase = true }
            base = Offset(base.x + (x - base.x) * .012f, base.y + (y - base.y) * .012f)
            val tx = ((x - base.x) * 2.6f).coerceIn(-1f, 1f)
            val ty = ((y - base.y) * 2.6f).coerceIn(-1f, 1f)
            val n = Offset(out.x + (tx - out.x) * .2f, out.y + (ty - out.y) * .2f)
            if (abs(n.x - out.x) + abs(n.y - out.y) > .003f) { out = n; xy.value = n }
        }
    }

    fun start(ctx: Context) {
        stop()
        val m = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val s = m.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: m.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sm = m
        hasBase = false
        m.registerListener(listener, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() { sm?.unregisterListener(listener); sm = null }
}

/**
 * Блик только по окантовке (как на iPhone): никакой заливки поверхности, светится лишь обод, и то частично —
 * два световых пятна на противоположных краях, которые ездят вдоль контура при наклоне; между ними обод почти не виден.
 * Рисуется в отдельном слое (graphicsLayer), поэтому при каждом шаге датчика перерисовывается только он,
 * а не дорогое преломление/размытие под ним.
 */
fun Modifier.tiltRim(shape: Shape, strength: Float = 1f): Modifier = this.graphicsLayer { }.drawBehind {
    val w = size.width
    val h = size.height
    if (w < 2f || h < 2f) return@drawBehind
    val t = Tilt.xy.value
    val outline = shape.createOutline(size, layoutDirection, this)
    val cx = w * (.5f - t.x * .8f)
    val cy = h * (.5f + t.y * .8f)
    drawOutline(
        outline,
        Brush.linearGradient(
            0f to Color.White.copy(alpha = .85f * strength),
            .26f to Color.White.copy(alpha = .0f),
            .74f to Color.White.copy(alpha = .0f),
            1f to Color.White.copy(alpha = .55f * strength),
            start = Offset(cx - w * .55f, cy - h * .55f), end = Offset(cx + w * .55f, cy + h * .55f)),
        style = Stroke(1.4.dp.toPx())
    )
}
