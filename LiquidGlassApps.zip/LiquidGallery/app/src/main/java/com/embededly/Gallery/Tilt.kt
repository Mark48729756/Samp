package com.embededly.Gallery

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.max

/**
 * Наклон телефона для бликов на стекле. Берётся из гироскопа (game rotation vector, он сам сращивает гироскоп с акселерометром),
 * если его нет — из акселерометра. Значения -1..1 считаются относительно того, как телефон держат сейчас
 * (медленно «забываем» текущее положение), поэтому блик оживает именно от наклона, а не от позы.
 */
object Tilt {
    val xy = mutableStateOf(Offset.Zero)
    private var sm: SensorManager? = null
    private var base = Offset.Zero
    private var hasBase = false
    private var out = Offset.Zero
    private val rot = FloatArray(9)

    private val listener = object : SensorEventListener {
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        override fun onSensorChanged(e: SensorEvent) {
            val x: Float
            val y: Float
            if (e.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                x = e.values[0] / 9.81f; y = e.values[1] / 9.81f
            } else {
                val v = if (e.values.size > 4) e.values.copyOf(4) else e.values
                SensorManager.getRotationMatrixFromVector(rot, v)
                x = rot[6]; y = rot[7] // куда в координатах телефона смотрит «вверх» мира
            }
            if (!hasBase) { base = Offset(x, y); hasBase = true }
            base = Offset(base.x + (x - base.x) * .012f, base.y + (y - base.y) * .012f)
            val tx = ((x - base.x) * 2.6f).coerceIn(-1f, 1f)
            val ty = ((y - base.y) * 2.6f).coerceIn(-1f, 1f)
            val n = Offset(out.x + (tx - out.x) * .2f, out.y + (ty - out.y) * .2f)
            if (abs(n.x - out.x) + abs(n.y - out.y) > .003f) { out = n; xy.value = n }
        }
    }

    fun start(ctx: Context) {
        stop()
        return // датчики не нужны, пока блики отключены
        val m = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
        val s = m.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: m.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        sm = m
        hasBase = false
        m.registerListener(listener, s, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() { sm?.unregisterListener(listener); sm = null }
}

/** Блики от наклона отключены: ничего не рисуем. Функция оставлена, чтобы не трогать места вызова. */
@Suppress("UNUSED_PARAMETER")
fun Modifier.tiltRim(shape: Shape, strength: Float = 1f): Modifier = this
