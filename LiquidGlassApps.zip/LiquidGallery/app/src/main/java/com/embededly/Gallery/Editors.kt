package com.embededly.Gallery

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ======================= КРОП ФОТО =======================
private fun resizeRect(corner: Int, r: Rect, dx: Float, dy: Float, b: Rect, ratio: Float?, minSide: Float): Rect {
    val left = corner == 0 || corner == 2; val top = corner == 0 || corner == 1
    val fx = if (left) r.right else r.left; val fy = if (top) r.bottom else r.top
    val mx = ((if (left) r.left else r.right) + dx).coerceIn(b.left, b.right)
    val my = ((if (top) r.top else r.bottom) + dy).coerceIn(b.top, b.bottom)
    val sx = if (left) -1f else 1f; val sy = if (top) -1f else 1f
    var w = ((mx - fx) * sx).coerceAtLeast(minSide); var h = ((my - fy) * sy).coerceAtLeast(minSide)
    if (ratio != null) {
        val maxW = if (sx > 0) b.right - fx else fx - b.left
        val maxH = if (sy > 0) b.bottom - fy else fy - b.top
        w = w.coerceAtMost(maxW); h = w / ratio
        if (h > maxH) { h = maxH; w = h * ratio }
    }
    val ex = fx + sx * w; val ey = fy + sy * h
    return Rect(min(fx, ex), min(fy, ey), max(fx, ex), max(fy, ey))
}

private fun fitRatio(r: Rect, ratio: Float?): Rect {
    if (ratio == null) return r
    var w = r.width; var h = w / ratio
    if (h > r.height) { h = r.height; w = h * ratio }
    val c = r.center
    return Rect(c.x - w / 2, c.y - h / 2, c.x + w / 2, c.y + h / 2)
}

@Composable
fun CropScreen(m: Media, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val scope = rememberCoroutineScope()
    val raw by produceState<Bitmap?>(null, m) {
        value = withContext(Dispatchers.IO) {
            try {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, m.uri)) { dec, info, _ ->
                    val s = max(info.size.width, info.size.height)
                    if (s > 4096) dec.setTargetSampleSize(((s + 4095) / 4096))
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
            } catch (_: Exception) { null }
        }
    }
    var turns by remember { mutableIntStateOf(0) }
    val bmp = remember(raw, turns) {
        raw?.let { r ->
            if (turns % 4 == 0) r
            else Bitmap.createBitmap(r, 0, 0, r.width, r.height, android.graphics.Matrix().apply { postRotate(90f * turns) }, true)
        }
    }
    var ratio by remember { mutableStateOf<Float?>(null) }
    var rect by remember { mutableStateOf(Rect.Zero) }
    var disp by remember { mutableStateOf(Size.Zero) }
    var saving by remember { mutableStateOf(false) }
    val ratios = listOf<Pair<String, Float?>>(t(R.string.s_008) to null, "1:1" to 1f, "4:3" to 4f / 3, "3:4" to 3f / 4,
        "16:9" to 16f / 9, "9:16" to 9f / 16)
    val minPx = with(LocalDensity.current) { 56.dp.toPx() }
    val hit = with(LocalDensity.current) { 40.dp.toPx() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val b = bmp
        if (b == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = pal.accent)
        else BoxWithConstraints(Modifier.fillMaxSize().padding(top = 80.dp, bottom = 150.dp, start = 16.dp, end = 16.dp)) {
            val boxW = constraints.maxWidth.toFloat(); val boxH = constraints.maxHeight.toFloat()
            val sc = min(boxW / b.width, boxH / b.height)
            val iw = b.width * sc; val ih = b.height * sc
            val bounds = Rect(0f, 0f, iw, ih)
            LaunchedEffect(b, iw, ih) { disp = Size(iw, ih); rect = bounds }
            LaunchedEffect(ratio) { if (disp != Size.Zero) rect = fitRatio(rect, ratio) }
            val d = LocalDensity.current
            Box(Modifier.align(Alignment.Center).size(with(d) { iw.toDp() }, with(d) { ih.toDp() })
                .pointerInput(bounds, ratio) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        val p = down.position; val r = rect
                        val corner = listOf(r.topLeft, r.topRight, r.bottomLeft, r.bottomRight).indexOfFirst { (it - p).getDistance() < hit }
                        if (corner < 0 && !r.contains(p)) return@awaitEachGesture
                        drag(down.id) { ch ->
                            val dd = ch.positionChange()
                            rect = if (corner >= 0) resizeRect(corner, rect, dd.x, dd.y, bounds, ratio, minPx)
                            else {
                                val dx = dd.x.coerceIn(bounds.left - rect.left, bounds.right - rect.right)
                                val dy = dd.y.coerceIn(bounds.top - rect.top, bounds.bottom - rect.bottom)
                                rect.translate(dx, dy)
                            }
                            ch.consume()
                        }
                    }
                }
            ) {
                Image(b.asImageBitmap(), null, Modifier.fillMaxSize())
                Canvas(Modifier.fillMaxSize()) {
                    val dim = Color.Black.copy(alpha = .6f)
                    drawRect(dim, Offset.Zero, Size(size.width, rect.top))
                    drawRect(dim, Offset(0f, rect.bottom), Size(size.width, size.height - rect.bottom))
                    drawRect(dim, Offset(0f, rect.top), Size(rect.left, rect.height))
                    drawRect(dim, Offset(rect.right, rect.top), Size(size.width - rect.right, rect.height))
                    drawRect(Color.White, rect.topLeft, rect.size, style = Stroke(2.dp.toPx()))
                    for (i in 1..2) {
                        val x = rect.left + rect.width * i / 3f; val y = rect.top + rect.height * i / 3f
                        drawLine(Color.White.copy(alpha = .35f), Offset(x, rect.top), Offset(x, rect.bottom), 1.dp.toPx())
                        drawLine(Color.White.copy(alpha = .35f), Offset(rect.left, y), Offset(rect.right, y), 1.dp.toPx())
                    }
                    listOf(rect.topLeft, rect.topRight, rect.bottomLeft, rect.bottomRight).forEach {
                        drawCircle(pal.accent, 9.dp.toPx(), it); drawCircle(Color.White, 9.dp.toPx(), it, style = Stroke(2.dp.toPx()))
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClose) { Text(t(R.string.s_009), color = Color.White, fontSize = 16.sp) }
            Spacer(Modifier.weight(1f))
            TextButton({ turns = (turns + 1) % 4 }) { Text(t(R.string.s_010), color = Color.White, fontSize = 16.sp) }
            Spacer(Modifier.weight(1f))
            Button(enabled = bmp != null && !saving, colors = ButtonDefaults.buttonColors(containerColor = pal.accent),
                onClick = {
                    val src = bmp ?: return@Button
                    saving = true
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) {
                            try {
                                val f = src.width / disp.width
                                val l = (rect.left * f).roundToInt().coerceIn(0, src.width - 1)
                                val t = (rect.top * f).roundToInt().coerceIn(0, src.height - 1)
                                val w = (rect.width * f).roundToInt().coerceIn(1, src.width - l)
                                val h = (rect.height * f).roundToInt().coerceIn(1, src.height - t)
                                saveImage(ctx, Bitmap.createBitmap(src, l, t, w, h)) != null
                            } catch (_: Exception) { false }
                        }
                        saving = false
                        Toast.makeText(ctx, if (ok) t(R.string.s_011) else t(R.string.s_012), Toast.LENGTH_SHORT).show()
                        if (ok) onSaved()
                    }
                }) { Text(if (saving) t(R.string.s_013) else t(R.string.s_014)) }
        }
        Row(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 36.dp)
            .horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ratios.forEach { (label, r) ->
                val sel = ratio == r
                Text(label, color = Color.White, fontSize = 14.sp,
                    modifier = Modifier.clip(CircleShape).background(if (sel) pal.accent else Color.White.copy(alpha = .15f))
                        .clickable { ratio = r }.padding(horizontal = 16.dp, vertical = 10.dp))
            }
        }
    }
}

// ======================= ОБРЕЗКА ВИДЕО =======================
private fun ms(v: Float): String {
    val s = (v / 1000f).roundToInt()
    return "%d:%02d".format(s / 60, s % 60)
}

@androidx.annotation.OptIn(UnstableApi::class)
@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrimScreen(m: Media, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val scope = rememberCoroutineScope()
    var dur by remember { mutableFloatStateOf(max(m.durationMs.toFloat(), 1000f)) }
    var range by remember { mutableStateOf(0f..dur) }
    var saving by remember { mutableStateOf(false) }
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() } }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && player.duration > 0 && player.duration.toFloat() != dur) {
                    dur = player.duration.toFloat(); range = 0f..dur
                }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    LaunchedEffect(range) {
        while (true) {
            delay(80)
            if (player.isPlaying && player.currentPosition >= range.endInclusive.toLong()) player.seekTo(range.start.toLong())
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } },
            Modifier.fillMaxSize().padding(top = 80.dp, bottom = 190.dp))
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClose) { Text(t(R.string.s_009), color = Color.White, fontSize = 16.sp) }
            Spacer(Modifier.weight(1f))
            Button(enabled = !saving, colors = ButtonDefaults.buttonColors(containerColor = pal.accent), onClick = {
                if (range.endInclusive - range.start < 500f) {
                    Toast.makeText(ctx, t(R.string.s_015), Toast.LENGTH_SHORT).show(); return@Button
                }
                saving = true; player.pause()
                val out = File(ctx.cacheDir, "trim_${System.currentTimeMillis()}.mp4")
                val clip = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(range.start.toLong()).setEndPositionMs(range.endInclusive.toLong()).build()
                val item = EditedMediaItem.Builder(MediaItem.Builder().setUri(m.uri).setClippingConfiguration(clip).build()).build()
                val t = Transformer.Builder(ctx).addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        scope.launch {
                            val ok = withContext(Dispatchers.IO) { val u = saveVideo(ctx, out); out.delete(); u != null }
                            saving = false
                            Toast.makeText(ctx, if (ok) t(R.string.s_011) else t(R.string.s_012), Toast.LENGTH_SHORT).show()
                            if (ok) onSaved()
                        }
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        saving = false; out.delete()
                        Toast.makeText(ctx, t(R.string.s_016), Toast.LENGTH_SHORT).show()
                    }
                }).build()
                t.start(item, out.absolutePath)
            }) { Text(if (saving) t(R.string.s_013) else t(R.string.s_014)) }
        }
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 20.dp, vertical = 24.dp)) {
            Row {
                Text(ms(range.start), color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(t(R.string.s_length, ms(range.endInclusive - range.start)), color = Color.White.copy(alpha = .7f), fontSize = 14.sp)
                Text(ms(range.endInclusive), color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
            }
            RangeSlider(range, { n ->
                player.seekTo(if (n.start != range.start) n.start.toLong() else n.endInclusive.toLong())
                range = n
            }, valueRange = 0f..dur,
                colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent))
        }
    }
}
