package com.embededly.Gallery

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Media(
    val id: Long, val uri: Uri, val isVideo: Boolean,
    val bucketId: Long, val bucket: String, val durationMs: Long,
    val dateMs: Long = 0L, val fav: Boolean = false,
)

data class Album(val id: Long, val name: String, val items: List<Media>)

private val SORT_COLS = setOf("date_added", "date_modified", "_display_name", "_size")

suspend fun loadMedia(
    ctx: Context, sortKey: String, desc: Boolean, photos: Boolean, videos: Boolean, trashed: Boolean = false,
): List<Media> = withContext(Dispatchers.IO) {
    val out = ArrayList<Media>()
    val types = buildList { if (photos) add(1); if (videos) add(3) }
    if (types.isEmpty() || (trashed && Build.VERSION.SDK_INT < 30)) return@withContext out
    val sdk30 = Build.VERSION.SDK_INT >= 30
    val proj = buildList {
        add("_id"); add("media_type"); add("bucket_id"); add("bucket_display_name")
        add("duration"); add("datetaken"); add("date_added")
        if (sdk30) add("is_favorite")
    }.toTypedArray()
    val col = if (sortKey in SORT_COLS) sortKey else "date_added"
    val args = Bundle().apply {
        putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "media_type IN (${types.joinToString(",")})")
        putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "$col ${if (desc) "DESC" else "ASC"}")
        if (sdk30) putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, if (trashed) MediaStore.MATCH_ONLY else MediaStore.MATCH_EXCLUDE)
    }
    try {
        ctx.contentResolver.query(MediaStore.Files.getContentUri("external"), proj, args, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow("_id")
            val iType = c.getColumnIndexOrThrow("media_type")
            val iB = c.getColumnIndexOrThrow("bucket_id")
            val iBn = c.getColumnIndexOrThrow("bucket_display_name")
            val iD = c.getColumnIndexOrThrow("duration")
            val iT = c.getColumnIndexOrThrow("datetaken")
            val iA = c.getColumnIndexOrThrow("date_added")
            val iF = if (sdk30) c.getColumnIndexOrThrow("is_favorite") else -1
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val video = c.getInt(iType) == 3
                val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val taken = c.getLong(iT)
                out += Media(
                    id, ContentUris.withAppendedId(base, id), video,
                    c.getLong(iB), c.getString(iBn) ?: "—",
                    if (video) c.getLong(iD) else 0L,
                    dateMs = if (taken > 0) taken else c.getLong(iA) * 1000,
                    fav = iF >= 0 && c.getInt(iF) == 1
                )
            }
        }
    } catch (_: Exception) { }
    out
}

fun fmtDur(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

// Виртуальные альбомы
const val FAV_ID = -1L
const val ALL_ID = -2L
const val VIDEO_ID = -3L
