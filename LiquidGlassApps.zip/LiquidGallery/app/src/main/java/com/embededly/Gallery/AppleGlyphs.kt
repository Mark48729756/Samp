package com.embededly.Gallery

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Свои иконки в духе SF Symbols: круглые концы, ровная толщина линий. Рисуются кодом, без SVG/векторных ресурсов. */
enum class Glyph { Photos, Albums, Search, Xmark }

@Composable
fun AppleGlyph(g: Glyph, tint: Color, modifier: Modifier = Modifier, size: Dp = 26.dp, cut: Color = Color.Black) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        fun o(x: Float, y: Float) = Offset(x * s, y * s)
        when (g) {
            Glyph.Search -> {
                val sw = s * .105f
                val r = s * .29f
                val c = o(.43f, .43f)
                drawCircle(tint, r, c, style = Stroke(sw))
                val d = .70710678f
                drawLine(tint, Offset(c.x + r * d, c.y + r * d), o(.87f, .87f), strokeWidth = sw, cap = StrokeCap.Round)
            }
            Glyph.Xmark -> {
                // xmark.circle.fill: полупрозрачный круг и крестик «вырезан»
                drawCircle(tint.copy(alpha = tint.alpha * .38f), s * .5f, o(.5f, .5f))
                val sw = s * .085f
                drawLine(cut, o(.34f, .34f), o(.66f, .66f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(cut, o(.66f, .34f), o(.34f, .66f), strokeWidth = sw, cap = StrokeCap.Round)
            }
            Glyph.Photos -> {
                val sw = s * .075f
                drawRoundRect(tint, o(.12f, .18f), Size(s * .76f, s * .64f), CornerRadius(s * .14f), style = Stroke(sw))
                drawCircle(tint, s * .065f, o(.34f, .39f))
                val p = Path().apply {
                    moveTo(s * .17f, s * .74f); lineTo(s * .38f, s * .53f); lineTo(s * .55f, s * .69f)
                    lineTo(s * .67f, s * .58f); lineTo(s * .84f, s * .74f)
                }
                drawPath(p, tint, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            Glyph.Albums -> {
                val sw = s * .075f
                drawLine(tint, o(.26f, .13f), o(.74f, .13f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, o(.18f, .25f), o(.82f, .25f), strokeWidth = sw, cap = StrokeCap.Round)
                drawRoundRect(tint, o(.11f, .36f), Size(s * .78f, s * .52f), CornerRadius(s * .13f), style = Stroke(sw))
            }
        }
    }
}
