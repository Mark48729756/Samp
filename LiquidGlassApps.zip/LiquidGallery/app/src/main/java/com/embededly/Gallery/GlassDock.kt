package com.embededly.Gallery

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PhotoAlbum
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Стеклянная панель по настройкам; при выключенном «Liquid Glass» — обычная полупрозрачная заливка. */
@Composable
fun Modifier.glassPanel(backdrop: Backdrop, blurDp: Float, refH: Float, refA: Float, surface: Color, shape: Shape = CircleShape, chromatic: Boolean = false): Modifier {
    val prefs = LocalPrefs.current
    if (!prefs.glass.value) return this.background(surface.copy(alpha = (surface.alpha + .35f).coerceAtMost(.95f)), shape)
    val vib = prefs.vibrancy.value
    return this.drawBackdrop(
        backdrop, { shape },
        effects = {
            if (vib) vibrancy()
            if (blurDp > 0f) blur(blurDp.dp.toPx())
            if (refH > 0f) lens(refH.dp.toPx(), refA.dp.toPx(), chromaticAberration = chromatic)
        },
        onDrawSurface = { drawRect(surface) }
    ).tiltRim(shape)
}

@Composable
fun GlassDock(
    backdrop: Backdrop, tab: Int, onTab: (Int) -> Unit,
    searchProgress: Float, onSearchBounds: (Rect) -> Unit, onSearch: () -> Unit, modifier: Modifier = Modifier,
) {
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val dockH = prefs.dockHeight.value.dp
    val seg = (dockH.value * 1.44f).dp
    val segPx = with(LocalDensity.current) { seg.toPx() }
    val scope = rememberCoroutineScope()
    val pos = remember { Animatable(tab.toFloat()) }
    var pressed by remember { mutableStateOf(false) }
    val spec: AnimationSpec<Float> = spring(prefs.damping.value, prefs.stiffness.value)
    // за пальцем капля идёт не жёстко, а на мягкой пружине: чуть запаздывает — отсюда ощущение массы
    val dragSpec: AnimationSpec<Float> = spring(.78f, 560f)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) prefs.lensGrow.value else 0f, spring(.52f, 330f), label = "grow")
    // искажение иконок внутри капли: появляется пока палец на доке, после отпускания быстро пропадает
    // Искажение держится минимум ~170 мс после отпускания, поэтому и у быстрого тапа оно успевает проявиться, а затем плавно гаснет.
    var distortOn by remember { mutableStateOf(false) }
    val distort by animateFloatAsState(if (distortOn) 1f else 0f, if (distortOn) spring(.8f, 700f) else tween(300, easing = FastOutSlowInEasing), label = "distort")
    // «Вес» капли: знаковая скорость (−1..1) сглаживается недозатухающей пружиной. Рывок растягивает каплю по ходу движения,
    // а когда она останавливается — пружина чуть перелетает, и капля желейно «доседает» на место.
    val stretch = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        var lastV = pos.value
        var lastT = System.nanoTime()
        var vSmooth = 0f
        snapshotFlow { pos.value }.collectLatest { v ->
            val now = System.nanoTime()
            val dt = ((now - lastT) / 1e9f).coerceAtLeast(.004f)
            val vel = (v - lastV) / dt // сегментов в секунду
            lastV = v; lastT = now
            vSmooth += (vel - vSmooth) * .5f // сглаживание шума от неровных интервалов между кадрами
            val target = if (abs(vSmooth) < .25f) 0f else (vSmooth / 9f).coerceIn(-1f, 1f)
            stretch.animateTo(target, spring(.5f, 450f))
        }
    }
    val onTabNow by rememberUpdatedState(onTab)
    val hapticOn by rememberUpdatedState(prefs.haptics.value)

    LaunchedEffect(tab) { if (!pressed) pos.animateTo(tab.toFloat(), spec) }
    val dockHPx = with(LocalDensity.current) { dockH.toPx() }
    val openP = (grow / prefs.lensGrow.value).coerceIn(0f, 1f)
    val dropInsetPx = with(LocalDensity.current) { 5.dp.toPx() }
    val bulgePx = with(LocalDensity.current) { 5.dp.toPx() }
    val bulgeXPx = with(LocalDensity.current) { 4.dp.toPx() }
    /** Прямоугольник капли в координатах дока: растёт от своего центра. Один расчёт для layout и для «вырезания» под каплей. */
    fun dropRect(): Rect {
        val w0 = segPx * (1f + grow) - dropInsetPx * 2f
        // в покое капля чуть ниже дока (небольшой зазор сверху и снизу), но выше иконки.
        // При нажатии она растёт и ЧУТЬ-ЧУТЬ выступает за границы дока (как в iOS): ~5dp сверху/снизу и ~4dp по бокам у края.
        val open = (grow / prefs.lensGrow.value).coerceIn(0f, 1f)
        val restH = dockHPx - dropInsetPx * 2f
        val h0 = restH + (dockHPx + 2f * bulgePx - restH) * open
        val bx = bulgeXPx * open
        // растяжение: по ходу движения капля вытягивается, по высоте чуть сплющивается (объём «сохраняется»)
        val s = stretch.value
        val a = abs(s).coerceAtMost(1.3f)
        val w = w0 * (1f + .18f * a)
        val h = h0 * (1f - .06f * a)
        val x0 = (pos.value * segPx - (w0 - segPx) / 2f).coerceIn(-bx, (segPx * 2f - w0 + bx).coerceAtLeast(-bx))
        // ведущий край идёт за пальцем, хвост отстаёт и тянется сзади
        val x = (if (s >= 0f) x0 + w0 - w else x0).coerceIn(-bx, (segPx * 2f - w + bx).coerceAtLeast(-bx))
        val y = (dockHPx - h) / 2f
        return Rect(x, y, x + w, y + h)
    }
    val touchOn = searchProgress < .05f // пока открыт поиск, невидимый док не должен ловить касания

    val dockBackdrop = rememberLayerBackdrop()
    val tabs = listOf(Glyph.Photos to t(R.string.s_017), Glyph.Albums to t(R.string.s_023))
    val idle = pal.fg.copy(alpha = .85f)
    val dockSurface = lerp(pal.glass, Color.Black, .15f).copy(alpha = prefs.dockOpacity.value)

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(seg * 2, dockH)
                .graphicsLayer { alpha = 1f - searchProgress.coerceIn(0f, 1f) }
                .pointerInput(segPx, spec, touchOn) {
                    if (!touchOn) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        pressed = true
                        distortOn = true
                        lift = true
                        if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        var x = down.position.x
                        fun target() = (x / segPx - .5f).coerceIn(0f, 1f)
                        scope.launch { pos.animateTo(target(), spec) }
                        drag(down.id) { ch ->
                            x = ch.position.x
                            scope.launch { pos.animateTo(target(), dragSpec) }
                            ch.consume()
                        }
                        val t = target().roundToInt()
                        pressed = false
                        scope.launch { delay(170); if (!pressed) distortOn = false }
                        scope.launch { pos.animateTo(t.toFloat(), spec) }
                        scope.launch { delay(220); if (!pressed) lift = false }
                        onTabNow(t)
                    }
                }
        ) {
            // 1) основа дока: стеклянная панель + иконки.
            // Внешний слой на экране вырезает дырку под каплей: иначе оригинальные иконки видны сквозь стекло и «двоятся».
            // В dockBackdrop пишутся только иконки (см. ниже), а фон под каплей берётся напрямую из backdrop экрана.
            Box(Modifier.fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    if (!prefs.glass.value) return@drawWithContent // без Liquid Glass капля плоская и ничего не перерисовывает
                    val r = dropRect().deflate(1f)
                    drawRoundRect(Color.Black, r.topLeft, r.size, CornerRadius(minOf(r.width, r.height) / 2f), blendMode = BlendMode.Clear)
                }
            ) {
            // Панель дока рисуется отдельно и в dockBackdrop НЕ попадает: капля должна показывать то, что лежит ЗА доком (фото),
            // а не копию тёмной панели. В dockBackdrop записаны только иконки — их капля увеличивает.
            Box(Modifier.fillMaxSize()
                .glassPanel(backdrop, prefs.dockBlur.value, prefs.dockRefH.value, prefs.dockRefA.value, dockSurface))
            // Видимые иконки дока
            Row(Modifier.fillMaxSize()) {
                tabs.forEachIndexed { i, (icon, label) ->
                    val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                    val col = lerp(idle, pal.accent, k)
                    Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Center, Alignment.CenterHorizontally) {
                        AppleGlyph(icon, col, Modifier, 26.dp)
                        if (prefs.dockLabels.value) Text(label, color = col, fontSize = 10.5.sp)
                    }
                }
            }
            // Невидимая копия иконок для капли: внутри зажатой капли иконка крупнее (в Origin OS ~1.2×).
            // Копия не показывается (alpha 0) и только записывается в dockBackdrop; видимые иконки при этом не растут.
            Row(Modifier.fillMaxSize().alpha(0f).layerBackdrop(dockBackdrop)) {
                tabs.forEachIndexed { i, (icon, label) ->
                    val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                    val col = lerp(idle, pal.accent, k)
                    val sc = 1f + .22f * openP
                    Column(Modifier.weight(1f).fillMaxHeight().graphicsLayer { scaleX = sc; scaleY = sc },
                        Arrangement.Center, Alignment.CenterHorizontally) {
                        AppleGlyph(icon, col, Modifier, 26.dp)
                        if (prefs.dockLabels.value) Text(label, color = col, fontSize = 10.5.sp)
                    }
                }
            }
            }
            // 2) капля: два слоя стекла одной формы — линза над фоном экрана (фото за доком) и поверх неё увеличенные иконки
            val open = (grow / prefs.lensGrow.value).coerceIn(0f, 1f)
            val refH = prefs.lensRefH.value * (1f + open * .15f)
            val refA = prefs.lensRefA.value * (1f + open * .25f)
            // Размер и положение капли меняются через layout (а не graphicsLayer-scale): иначе backdrop
            // считает координаты без учёта масштаба, и преломлённая копия дока уезжает. Капля растёт от своего центра и чуть выступает за док — так и задумано.
            // Контейнер без ограничений (unbounded): капля больше дока, и иначе Compose «подрезал» бы её размер
            // и сдвигал вверх. Здесь капля занимает ровно свой прямоугольник и ставится по нему от верхнего левого угла дока.
            Box(Modifier.fillMaxSize().wrapContentSize(Alignment.TopStart, unbounded = true)) {
            Box(
                Modifier
                    .offset { val r = dropRect(); IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                    .layout { measurable, _ ->
                        val r = dropRect()
                        val w = r.width.roundToInt().coerceAtLeast(1)
                        val h = r.height.roundToInt().coerceAtLeast(1)
                        val pl = measurable.measure(Constraints.fixed(w, h))
                        layout(w, h) { pl.place(0, 0) }
                    }
            ) {
                // в покое капля выглядит как сам док (та же заливка и размытие), при нажатии становится прозрачной линзой над фоном
                Box(Modifier.fillMaxSize().glassPanel(backdrop,
                    prefs.dockBlur.value + (prefs.lensBlur.value - prefs.dockBlur.value) * open, refH, refA,
                    lerp(dockSurface, Color.White.copy(alpha = .06f), open), chromatic = open > .35f))
                if (prefs.glass.value) Box(Modifier.fillMaxSize().drawBackdrop(
                    dockBackdrop, { CircleShape },
                    effects = { val d = distort; if (d > .01f) lens((refH * 1.8f * d).dp.toPx(), (refA * 1.8f * d).dp.toPx()) }
                ))
                Box(Modifier.fillMaxSize().border(1.dp, Color.White.copy(alpha = .12f + .30f * open), CircleShape))
            }
            }
        }
        if (prefs.searchButton.value) {
            // место под кнопку поиска; саму кнопку рисует SearchMorph поверх
            Box(Modifier.size(dockH).onGloballyPositioned { onSearchBounds(it.boundsInRoot()) })
        }
    }
}
