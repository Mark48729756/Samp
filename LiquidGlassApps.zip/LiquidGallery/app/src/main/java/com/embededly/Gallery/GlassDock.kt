package com.embededly.Gallery

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PhotoAlbum
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Стеклянная панель по настройкам; при выключенном «Liquid Glass» — обычная полупрозрачная заливка. */
@Composable
fun Modifier.glassPanel(backdrop: Backdrop, blurDp: Float, refH: Float, refA: Float, surface: Color, shape: Shape = CircleShape): Modifier {
    val prefs = LocalPrefs.current
    if (!prefs.glass.value) return this.background(surface.copy(alpha = (surface.alpha + .35f).coerceAtMost(.95f)), shape)
    val vib = prefs.vibrancy.value
    return this.drawBackdrop(
        backdrop, { shape },
        effects = {
            if (vib) vibrancy()
            if (blurDp > 0f) blur(blurDp.dp.toPx())
            if (refH > 0f) lens(refH.dp.toPx(), refA.dp.toPx())
        },
        onDrawSurface = { drawRect(surface) }
    ).tiltRim(shape)
}

@Composable
fun GlassDock(
    backdrop: Backdrop, tab: Int, onTab: (Int) -> Unit,
    searchProgress: Float, onSearchBounds: (Rect) -> Unit, onSearch: () -> Unit, modifier: Modifier = Modifier,
) {
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val dockH = prefs.dockHeight.value.dp
    val seg = (dockH.value * 1.44f).dp
    val segPx = with(LocalDensity.current) { seg.toPx() }
    val scope = rememberCoroutineScope()
    val pos = remember { Animatable(tab.toFloat()) }
    var pressed by remember { mutableStateOf(false) }
    val spec: AnimationSpec<Float> = spring(prefs.damping.value, prefs.stiffness.value)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) prefs.lensGrow.value else 0f, spring(.52f, 330f), label = "grow")
    // искажение иконок внутри капли: появляется пока палец на доке, после отпускания быстро пропадает
    // Искажение держится минимум ~170 мс после отпускания, поэтому и у быстрого тапа оно успевает проявиться, а затем плавно гаснет.
    var distortOn by remember { mutableStateOf(false) }
    val distort by animateFloatAsState(if (distortOn) 1f else 0f, if (distortOn) spring(.8f, 700f) else tween(300, easing = FastOutSlowInEasing), label = "distort")
    val onTabNow by rememberUpdatedState(onTab)
    val hapticOn by rememberUpdatedState(prefs.haptics.value)

    LaunchedEffect(tab) { if (!pressed) pos.animateTo(tab.toFloat(), spec) }
    val dockHPx = with(LocalDensity.current) { dockH.toPx() }
    val dropInsetPx = with(LocalDensity.current) { 5.dp.toPx() }
    /** Прямоугольник капли в координатах дока: растёт от своего центра. Один расчёт для layout и для «вырезания» под каплей. */
    fun dropRect(): Rect {
        val w = segPx * (1f + grow) - dropInsetPx * 2f
        // в покое капля чуть ниже дока (небольшой зазор сверху и снизу), но выше иконки; ширина не меняется.
        // При нажатии она не выходит за границы дока ни вверх, ни вниз, ни по бокам: остаётся «внутри» него.
        val restH = dockHPx - dropInsetPx * 2f
        val h = (restH + dockHPx * grow * 1.1f).coerceAtMost(dockHPx)
        val x = (pos.value * segPx - (w - segPx) / 2f).coerceIn(0f, (segPx * 2f - w).coerceAtLeast(0f))
        val y = (dockHPx - h) / 2f
        return Rect(x, y, x + w, y + h)
    }
    val touchOn = searchProgress < .05f // пока открыт поиск, невидимый док не должен ловить касания

    val dockBackdrop = rememberLayerBackdrop()
    val tabs = listOf(Glyph.Photos to t(R.string.s_017), Glyph.Albums to t(R.string.s_023))
    val idle = pal.fg.copy(alpha = .85f)
    val dockSurface = lerp(pal.glass, Color.Black, .15f).copy(alpha = prefs.dockOpacity.value)

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(seg * 2, dockH)
                .graphicsLayer { alpha = 1f - searchProgress.coerceIn(0f, 1f) }
                .pointerInput(segPx, spec, touchOn) {
                    if (!touchOn) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        pressed = true
                        distortOn = true
                        lift = true
                        if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        var x = down.position.x
                        fun target() = (x / segPx - .5f).coerceIn(0f, 1f)
                        scope.launch { pos.animateTo(target(), spec) }
                        drag(down.id) { ch ->
                            x = ch.position.x
                            scope.launch { pos.snapTo(target()) }
                            ch.consume()
                        }
                        val t = target().roundToInt()
                        pressed = false
                        scope.launch { delay(170); if (!pressed) distortOn = false }
                        scope.launch { pos.animateTo(t.toFloat(), spec) }
                        scope.launch { delay(220); if (!pressed) lift = false }
                        onTabNow(t)
                    }
                }
        ) {
            // 1) основа дока: стеклянная панель + иконки. Записывается в dockBackdrop,
            //    чтобы капля могла преломлять и увеличивать и сам док, и иконки.
            // Внешний слой на экране вырезает дырку под каплей: иначе оригинальные иконки видны сквозь стекло и «двоятся».
            // Внутренний слой записывает полный док в dockBackdrop, поэтому капля преломляет его целиком.
            Box(Modifier.fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    if (!prefs.glass.value) return@drawWithContent // без Liquid Glass капля плоская и ничего не перерисовывает
                    val r = dropRect().deflate(1f)
                    drawRoundRect(Color.Black, r.topLeft, r.size, CornerRadius(minOf(r.width, r.height) / 2f), blendMode = BlendMode.Clear)
                }
            ) {
            Box(Modifier.fillMaxSize().layerBackdrop(dockBackdrop)) {
                Box(Modifier.fillMaxSize()
                    .glassPanel(backdrop, prefs.dockBlur.value, prefs.dockRefH.value, prefs.dockRefA.value, dockSurface))
                Row(Modifier.fillMaxSize()) {
                    tabs.forEachIndexed { i, (icon, label) ->
                        val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                        val col = lerp(idle, pal.accent, k)
                        Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Center, Alignment.CenterHorizontally) {
                            AppleGlyph(icon, col, Modifier, 26.dp)
                            if (prefs.dockLabels.value) Text(label, color = col, fontSize = 10.5.sp)
                        }
                    }
                }
            }
            }
            // 2) капля: два слоя стекла одной формы — фото под доком и сам док с иконками поверх
            val open = (grow / prefs.lensGrow.value).coerceIn(0f, 1f)
            val refH = prefs.lensRefH.value * (1f + open * .15f)
            val refA = prefs.lensRefA.value * (1f + open * .25f)
            // Размер и положение капли меняются через layout (а не graphicsLayer-scale): иначе backdrop
            // считает координаты без учёта масштаба, и преломлённая копия дока уезжает. Капля растёт от своего центра и чуть выступает за док — так и задумано.
            // Контейнер без ограничений (unbounded): капля больше дока, и иначе Compose «подрезал» бы её размер
            // и сдвигал вверх. Здесь капля занимает ровно свой прямоугольник и ставится по нему от верхнего левого угла дока.
            Box(Modifier.fillMaxSize().wrapContentSize(Alignment.TopStart, unbounded = true)) {
            Box(
                Modifier
                    .offset { val r = dropRect(); IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                    .layout { measurable, _ ->
                        val r = dropRect()
                        val w = r.width.roundToInt().coerceAtLeast(1)
                        val h = r.height.roundToInt().coerceAtLeast(1)
                        val pl = measurable.measure(Constraints.fixed(w, h))
                        layout(w, h) { pl.place(0, 0) }
                    }
            ) {
                Box(Modifier.fillMaxSize().glassPanel(backdrop, prefs.lensBlur.value, refH, refA,
                    Color.White.copy(alpha = .06f)))
                if (prefs.glass.value) Box(Modifier.fillMaxSize().drawBackdrop(
                    dockBackdrop, { CircleShape },
                    effects = { val d = distort; if (d > .01f) lens((refH * 1.8f * d).dp.toPx(), (refA * 1.8f * d).dp.toPx()) }
                ))
                Box(Modifier.fillMaxSize().border(1.dp, Color.White.copy(alpha = .12f + .30f * open), CircleShape))
            }
            }
        }
        if (prefs.searchButton.value) {
            // место под кнопку поиска; саму кнопку рисует SearchMorph поверх
            Box(Modifier.size(dockH).onGloballyPositioned { onSearchBounds(it.boundsInRoot()) })
        }
    }
}
