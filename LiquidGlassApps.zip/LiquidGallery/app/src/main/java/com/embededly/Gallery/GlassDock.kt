package com.embededly.Gallery

import kotlin.math.ceil
import kotlin.math.sqrt
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PhotoAlbum
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Стеклянная панель по настройкам; при выключенном «Liquid Glass» — обычная полупрозрачная заливка. */
@Composable
fun Modifier.glassPanel(backdrop: Backdrop, blurDp: Float, refH: Float, refA: Float, surface: Color, shape: Shape = CircleShape, chromatic: Boolean = false, vibrant: Boolean = true): Modifier {
    val prefs = LocalPrefs.current
    if (!prefs.glass.value) return this.background(surface.copy(alpha = (surface.alpha + .35f).coerceAtMost(.95f)), shape)
    val vib = prefs.vibrancy.value && vibrant // vibrancy осветляет и «засвечивает» фон; для дока и меню нужен обычный блюр
    return this.drawBackdrop(
        backdrop, { shape },
        effects = {
            if (vib) vibrancy()
            if (blurDp > 0f) blur(blurDp.dp.toPx())
            if (refH > 0f) lens(refH.dp.toPx(), refA.dp.toPx(), chromaticAberration = chromatic)
        },
        onDrawSurface = { drawRect(surface) }
    ).tiltRim(shape)
}

@Composable
fun GlassDock(
    backdrop: Backdrop, tab: Int, onTab: (Int) -> Unit,
    searchProgress: Float, onSearchBounds: (Rect) -> Unit, onSearch: () -> Unit, modifier: Modifier = Modifier,
) {
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val dockH = prefs.dockHeight.value.dp
    val seg = (dockH.value * 1.44f).dp
    val segPx = with(LocalDensity.current) { seg.toPx() }
    val scope = rememberCoroutineScope()
    val pos = remember { Animatable(tab.toFloat()) }
    var pressed by remember { mutableStateOf(false) }
    val spec: AnimationSpec<Float> = spring(prefs.damping.value, prefs.stiffness.value)
    // за пальцем капля идёт не жёстко, а на мягкой пружине: чуть запаздывает — отсюда ощущение массы
    val dragSpec: AnimationSpec<Float> = spring(.78f, 560f)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) prefs.lensGrow.value else 0f, spring(.52f, 330f), label = "grow")
    // искажение иконок внутри капли: появляется пока палец на доке, после отпускания быстро пропадает
    // Искажение держится минимум ~170 мс после отпускания, поэтому и у быстрого тапа оно успевает проявиться, а затем плавно гаснет.
    var distortOn by remember { mutableStateOf(false) }
    val distort by animateFloatAsState(if (distortOn) 1f else 0f, if (distortOn) spring(.8f, 700f) else tween(300, easing = FastOutSlowInEasing), label = "distort")
    // «Вес» капли. Скорость считается по кадрам, а пружина растяжения интегрируется вручную в одном цикле по кадрам.
    // (animateTo на каждый кадр здесь нельзя: каждый перезапуск пропускает первый кадр, и значение вообще не двигается.)
    // Рывок растягивает каплю по ходу движения, при остановке она чуть перелетает и желейно оседает.
    val stretchF = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var st = 0f; var sv = 0f; var vs = 0f
        var lastX = pos.value
        var lastNs = 0L
        while (true) {
            if (!pos.isRunning && abs(st) < .003f && abs(sv) < .03f) {
                st = 0f; sv = 0f; vs = 0f; lastNs = 0L
                stretchF.floatValue = 0f
                snapshotFlow { pos.isRunning }.first { it } // спим, пока капля не тронется — в покое кадры не заказываем
                lastX = pos.value
            }
            val ns = withFrameNanos { it }
            if (lastNs == 0L) { lastNs = ns; lastX = pos.value; continue }
            val dt = ((ns - lastNs) / 1e9f).coerceIn(.004f, .033f)
            lastNs = ns
            val x = pos.value
            val vel = (x - lastX) / dt // сегментов в секунду
            lastX = x
            vs += (vel - vs) * .5f // сглаживание шума от неровных интервалов между кадрами
            val target = if (abs(vs) < .25f) 0f else (vs / 9f).coerceIn(-1f, 1f)
            val k = 450f
            val c = 2f * .5f * sqrt(k) // пружина: жёсткость 450, демпфирование .5 — один небольшой «доезд»
            val steps = ceil(dt / .004f).toInt().coerceAtLeast(1)
            val h = dt / steps
            repeat(steps) { sv += (-k * (st - target) - c * sv) * h; st += sv * h }
            stretchF.floatValue = st
        }
    }
    val onTabNow by rememberUpdatedState(onTab)
    val hapticOn by rememberUpdatedState(prefs.haptics.value)

    LaunchedEffect(tab) { if (!pressed) pos.animateTo(tab.toFloat(), spec) }
    val dockHPx = with(LocalDensity.current) { dockH.toPx() }
    val openP = (grow / prefs.lensGrow.value).coerceIn(0f, 1f)
    val dropInsetPx = with(LocalDensity.current) { 5.dp.toPx() }
    val bulgePx = with(LocalDensity.current) { 5.dp.toPx() }
    val bulgeXPx = with(LocalDensity.current) { 4.dp.toPx() }
    /** Прямоугольник капли в координатах дока: растёт от своего центра. Один расчёт для layout и для «вырезания» под каплей. */
    fun dropRect(): Rect {
        val w0 = segPx * (1f + grow) - dropInsetPx * 2f
        // в покое капля чуть ниже дока (небольшой зазор сверху и снизу), но выше иконки.
        // При нажатии она растёт и ЧУТЬ-ЧУТЬ выступает за границы дока (как в iOS): ~5dp сверху/снизу и ~4dp по бокам у края.
        val open = (grow / prefs.lensGrow.value).coerceIn(0f, 1f)
        val restH = dockHPx - dropInsetPx * 2f
        val h0 = restH + (dockHPx + 2f * bulgePx - restH) * open
        val bx = bulgeXPx * open
        // растяжение: по ходу движения капля вытягивается, по высоте чуть сплющивается (объём «сохраняется»)
        val s = stretchF.floatValue
        val a = abs(s).coerceAtMost(1.3f)
        val w = w0 * (1f + .18f * a)
        val h = h0 * (1f - .06f * a)
        val x0 = (pos.value * segPx - (w0 - segPx) / 2f).coerceIn(-bx, (segPx * 2f - w0 + bx).coerceAtLeast(-bx))
        // ведущий край идёт за пальцем, хвост отстаёт и тянется сзади
        val x = (if (s >= 0f) x0 + w0 - w else x0).coerceIn(-bx, (segPx * 2f - w + bx).coerceAtLeast(-bx))
        val y = (dockHPx - h) / 2f
        return Rect(x, y, x + w, y + h)
    }
    val touchOn = searchProgress < .05f // пока открыт поиск, невидимый док не должен ловить касания

    val dockBackdrop = rememberLayerBackdrop()
    val tabs = listOf(Glyph.Photos to t(R.string.s_017), Glyph.Albums to t(R.string.s_023))
    val idle = pal.fg.copy(alpha = .85f)
    val dockSurface = lerp(pal.glass, Color.Black, .15f).copy(alpha = prefs.dockOpacity.value)

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(seg * 2, dockH)
                .graphicsLayer { alpha = 1f - searchProgress.coerceIn(0f, 1f) }
                .pointerInput(segPx, spec, touchOn) {
                    if (!touchOn) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        pressed = true
                        distortOn = true
                        lift = true
                        if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        var x = down.position.x
                        fun target() = (x / segPx - .5f).coerceIn(0f, 1f)
                        scope.launch { pos.animateTo(target(), spec) }
                        drag(down.id) { ch ->
                            x = ch.position.x
                            scope.launch { pos.animateTo(target(), dragSpec) }
                            ch.consume()
                        }
                        val t = target().roundToInt()
                        pressed = false
                        scope.launch { delay(170); if (!pressed) distortOn = false }
                        scope.launch { pos.animateTo(t.toFloat(), spec) }
                        scope.launch { delay(220); if (!pressed) lift = false }
                        onTabNow(t)
                    }
                }
        ) {
            // 1) основа дока: стеклянная панель + иконки.
            // Внешний слой на экране вырезает дырку под каплей: иначе оригинальные иконки видны сквозь стекло и «двоятся».
            // В dockBackdrop пишутся только иконки (см. ниже), а фон под каплей берётся напрямую из backdrop экрана.
            Box(Modifier.fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    if (!prefs.glass.value) return@drawWithContent // без Liquid Glass капля плоская и ничего не перерисовывает
                    val r = dropRect().deflate(1f)
                    val ramp = (openP * 5f).coerceIn(0f, 1f) * distort // в покое ничего не вырезаем: настоящие иконки на месте
                    if (ramp > 0f) drawRoundRect(Color.Black.copy(alpha = ramp), r.topLeft, r.size, CornerRadius(minOf(r.width, r.height) / 2f), blendMode = BlendMode.DstOut)
                }
            ) {
            // Панель дока рисуется отдельно и в dockBackdrop НЕ попадает: капля должна показывать то, что лежит ЗА доком (фото),
            // а не копию тёмной панели. В dockBackdrop записаны только иконки — их капля увеличивает.
            Box(Modifier.fillMaxSize()
                .glassPanel(backdrop, prefs.dockBlur.value, prefs.dockRefH.value, prefs.dockRefA.value, dockSurface, chromatic = true, vibrant = false))
            // Видимые иконки дока
            Row(Modifier.fillMaxSize()) {
                tabs.forEachIndexed { i, (icon, label) ->
                    val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                    val col = lerp(idle, pal.accent, k)
                    Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Center, Alignment.CenterHorizontally) {
                        AppleGlyph(icon, col, Modifier, 26.dp)
                        if (prefs.dockLabels.value) Text(label, color = col, fontSize = 10.5.sp)
                    }
                }
            }
            // Невидимая копия ДОКА для капли (alpha 0 — только записывается в dockBackdrop): полупрозрачная панель + увеличенные иконки.
            // Чем сильнее нажата капля, тем прозрачнее панель в копии: сквозь неё виден фон, но сам док (его кромка, тон, иконки) остаётся виден и преломляется.
            Box(Modifier.fillMaxSize().alpha(0f).layerBackdrop(dockBackdrop)) {
                Box(Modifier.fillMaxSize().glassPanel(backdrop,
                    prefs.dockBlur.value * (1f - openP), prefs.dockRefH.value * (1f - openP), prefs.dockRefA.value * (1f - openP),
                    dockSurface.copy(alpha = dockSurface.alpha * (1f - .5f * openP)), vibrant = false))
                Row(Modifier.fillMaxSize()) {
                    tabs.forEachIndexed { i, (icon, label) ->
                        val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                        val col = lerp(idle, pal.accent, k)
                        val sc = 1f + .22f * openP * k // только активная иконка попадает в линзу
                        Column(Modifier.weight(1f).fillMaxHeight().graphicsLayer { scaleX = sc; scaleY = sc; alpha = k },
                            Arrangement.Center, Alignment.CenterHorizontally) {
                            AppleGlyph(icon, col, Modifier, 26.dp)
                            if (prefs.dockLabels.value) Text(label, color = col, fontSize = 10.5.sp)
                        }
                    }
                }
            }
            }
            // 2) капля: одна линза над фоном экрана и полупрозрачной копией дока
            val open = (grow / prefs.lensGrow.value).coerceIn(0f, 1f)
            val refH = prefs.lensRefH.value * (1f + open * .15f)
            val refA = prefs.lensRefA.value * (1f + open * .25f)
            // Размер и положение капли меняются через layout (а не graphicsLayer-scale): иначе backdrop
            // считает координаты без учёта масштаба, и преломлённая копия дока уезжает. Капля растёт от своего центра и чуть выступает за док — так и задумано.
            // Контейнер без ограничений (unbounded): капля больше дока, и иначе Compose «подрезал» бы её размер
            // и сдвигал вверх. Здесь капля занимает ровно свой прямоугольник и ставится по нему от верхнего левого угла дока.
            Box(Modifier.fillMaxSize().wrapContentSize(Alignment.TopStart, unbounded = true)) {
            Box(
                Modifier
                    .offset { val r = dropRect(); IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                    .layout { measurable, _ ->
                        val r = dropRect()
                        val w = r.width.roundToInt().coerceAtLeast(1)
                        val h = r.height.roundToInt().coerceAtLeast(1)
                        val pl = measurable.measure(Constraints.fixed(w, h))
                        layout(w, h) { pl.place(0, 0) }
                    }
            ) {
                // Одна линза над «фон экрана + копия дока»: фон и док искажаются вместе, как в Origin OS / эталоне библиотеки.
                if (prefs.glass.value) {
                    // в покое — матовая «таблетка» без преломления (ни страница, ни иконки не отражаются); линза и копия дока плавно включаются при нажатии
                    val ramp = (open * 5f).coerceIn(0f, 1f) * distort
                    Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = .08f * (1f - ramp)), CircleShape))
                    if (open > .01f) {
                        val combined = rememberCombinedBackdrop(backdrop, dockBackdrop)
                        Box(Modifier.fillMaxSize().graphicsLayer { alpha = ramp }.drawBackdrop(
                            combined, { CircleShape },
                            effects = { lens(refH.dp.toPx() * ramp, refA.dp.toPx() * ramp, chromaticAberration = open > .35f) },
                            onDrawSurface = { drawRect(Color.White.copy(alpha = .06f * open)) }
                        ).tiltRim(CircleShape))
                    }
                } else {
                    Box(Modifier.fillMaxSize().glassPanel(backdrop, 0f, 0f, 0f, dockSurface))
                }
                Box(Modifier.fillMaxSize().border(1.dp, Color.White.copy(alpha = .12f + .30f * open), CircleShape))
            }
            }
        }
        if (prefs.searchButton.value) {
            // место под кнопку поиска; саму кнопку рисует SearchMorph поверх
            Box(Modifier.size(dockH).onGloballyPositioned { onSearchBounds(it.boundsInRoot()) })
        }
    }
}
