package com.embededly.Gallery

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Переключатель в стиле стекла (вместо Material Switch). */
@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val x by animateFloatAsState(if (checked) 1f else 0f, spring(.7f, 500f), label = "sw")
    Box(
        Modifier.size(52.dp, 32.dp).clip(CircleShape)
            .background(lerp(pal.fg.copy(alpha = .18f), pal.accent, x))
            .clickable(remember { MutableInteractionSource() }, null) { onChange(!checked) }
            .padding(3.dp)
    ) {
        Box(
            Modifier.offset(x = 20.dp * x).size(26.dp).clip(CircleShape).background(Color.White)
                .border(.5.dp, Color.Black.copy(alpha = .12f), CircleShape)
        )
    }
}

/** Ползунок в стиле стекла (вместо Material Slider). */
@Composable
fun GlassSlider(value: Float, range: ClosedFloatingPointRange<Float>, steps: Int = 0, onChange: (Float) -> Unit) {
    val pal = LocalPal.current
    var w by remember { mutableIntStateOf(0) }
    val span = range.endInclusive - range.start
    val frac = ((value - range.start) / span).coerceIn(0f, 1f)
    val onNow by rememberUpdatedState(onChange)
    fun at(x: Float): Float {
        val f = (x / w.coerceAtLeast(1)).coerceIn(0f, 1f)
        return if (steps > 0) range.start + (f * steps).roundToInt() * span / steps else range.start + f * span
    }
    Box(
        Modifier.fillMaxWidth().height(36.dp).padding(horizontal = 13.dp)
            .onSizeChanged { w = it.width }
            .pointerInput(range, steps) { detectTapGestures { onNow(at(it.x)) } }
            .pointerInput(range, steps) { detectHorizontalDragGestures { ch, _ -> ch.consume(); onNow(at(ch.position.x)) } }
    ) {
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth().height(6.dp).clip(CircleShape).background(pal.fg.copy(alpha = .15f)))
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth(frac).height(6.dp).clip(CircleShape).background(pal.accent))
        Box(
            Modifier.align(Alignment.CenterStart)
                .offset { IntOffset((w * frac - 13.dp.toPx()).roundToInt(), 0) }
                .size(26.dp).clip(CircleShape).background(Color.White)
                .border(.5.dp, Color.Black.copy(alpha = .12f), CircleShape)
        )
    }
}

/** Кнопка-«капсула» (вместо Material Button). */
@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, primary: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.height(48.dp).graphicsLayer { alpha = if (enabled) 1f else .4f }
            .clip(CircleShape)
            .background(if (primary) pal.accent else pal.fg.copy(alpha = .12f))
            .border(1.dp, Color.White.copy(alpha = .16f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Color.White else pal.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Точка последнего касания в координатах экрана: окна «вываливаются» из неё как капля. Заполняется в MainActivity. */
val LocalTouch = staticCompositionLocalOf { mutableStateOf(Offset.Unspecified) }

/**
 * Размер меняется через layout, а не graphicsLayer-scale: иначе стекло (backdrop) считает координаты без учёта масштаба
 * и преломление «уезжает». ax/ay — разные пружины по ширине и высоте, из-за чего капля чуть пружинит (squash & stretch).
 * Контент остаётся в натуральном размере по центру, пока стеклянная форма растёт или схлопывается.
 */
private fun Modifier.dropSize(
    ax: () -> Float, ay: () -> Float, vanish: () -> Float = { 0f }, minDp: Float = 40f,
    anchor: Alignment = Alignment.Center,
): Modifier = this.layout { m, c ->
    val pl = m.measure(c)
    val mn = minDp.dp.toPx() * (1f - .85f * vanish()) // в конце шарик ещё и втягивается
    val w = (mn + (pl.width - mn) * ax()).roundToInt().coerceAtLeast(1)
    val h = (mn + (pl.height - mn) * ay()).roundToInt().coerceAtLeast(1)
    layout(w, h) {
        // anchor — угол/точка, из которой капля вытекает и в которую втекает обратно (по умолчанию центр)
        val o = anchor.align(androidx.compose.ui.unit.IntSize(pl.width, pl.height), androidx.compose.ui.unit.IntSize(w, h), layoutDirection)
        pl.place(o.x, o.y)
    }
}

/**
 * Стеклянное меню-капля с эффектом настоящей жидкости. Кнопка, из которой оно вылетает, НЕ исчезает и всегда рисуется поверх.
 * Открытие: капля вытягивается из кнопки узкой «сосулькой», расширяется и отрывается. Закрытие: подтягивается к кнопке,
 * прилипает и втягивается в неё, а кнопка на миг набухает («глотает» каплю).
 * Ставится в Box, положение — через modifier. riseDp / riseXDp — сдвиг свёрнутой капли к кнопке (в dp), minDp — размер шарика.
 * hideBehind оставлен только для совместимости вызовов (больше ничего не делает).
 */
@Composable
fun GlassMenu(
    visible: Boolean, backdrop: Backdrop, onDismiss: () -> Unit, modifier: Modifier = Modifier,
    anchor: Alignment = Alignment.Center, riseDp: Float = 0f, riseXDp: Float = 0f, minDp: Float = 46f,
    hideBehind: Boolean = false, morph: MenuMorph? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val pal = LocalPal.current
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val sep = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val pulse = remember { Animatable(0f) }
    var shown by remember { mutableStateOf(false) }
    SideEffect { morph?.active = visible || shown }
    LaunchedEffect(Unit) { snapshotFlow { ay.value.coerceIn(0f, 1f) }.collect { morph?.p = it } }
    LaunchedEffect(Unit) { snapshotFlow { pulse.value }.collect { morph?.swell = it } }
    LaunchedEffect(visible) {
        if (visible) {
            shown = true
            coroutineScope {
                // капля сначала вытягивается из кнопки вниз/вверх узкой «сосулькой» (всё ещё держится за кнопку),
                // потом расширяется и только в конце отрывается от неё
                launch { ay.animateTo(1f, spring(.55f, 280f)) }
                launch { delay(90); ax.animateTo(1f, spring(.5f, 320f)) }
                launch { delay(120); sep.animateTo(1f, spring(.6f, 240f)) }
                launch { delay(190); fade.animateTo(1f, tween(160)) }
                launch { pulse.animateTo(0f, tween(120)) }
            }
        } else if (shown) {
            coroutineScope {
                launch { fade.animateTo(0f, tween(70)) }
                // сначала капля подтягивается обратно к кнопке и «прилипает» к ней, потом втягивается внутрь
                launch { sep.animateTo(0f, spring(.7f, 360f)) }
                launch { delay(70); ax.animateTo(0f, spring(.6f, 300f)) }
                launch { delay(110); ay.animateTo(0f, spring(.55f, 300f)) }
                launch {
                    snapshotFlow { ay.value }.first { it < .2f }
                    pulse.animateTo(1f, tween(120, easing = FastOutSlowInEasing))
                    pulse.animateTo(0f, spring(.45f, 320f))
                }
            }
            shown = false
        }
    }
    if (visible) BackHandler(onBack = onDismiss)
    if (visible) Box(Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { onDismiss() })
    if (shown) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            modifier
                // у самой кнопки капля прозрачна (прячет ореол по краю), дальше полностью видна
                .graphicsLayer { alpha = (ay.value / .1f).coerceIn(0f, 1f) }
                .offset {
                    IntOffset(
                        ((1f - sep.value) * riseXDp.dp.toPx()).roundToInt(),
                        ((1f - sep.value) * riseDp.dp.toPx()).roundToInt(),
                    )
                }
                .glassPanel(backdrop, 12f, 8f, 14f, pal.glass.copy(alpha = .62f), shape)
                .clip(shape)
                .dropSize({ ax.value }, { ay.value }, { 0f }, minDp = minDp, anchor = anchor)
        ) {
            Column(Modifier.width(220.dp).graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }.padding(vertical = 8.dp), content = content)
        }
    }
}

@Composable
fun GlassMenuItem(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(text, color = pal.fg, fontSize = 16.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp))
}

/**
 * Окно, которое вываливается каплей из точки касания, растёт до своего размера и при закрытии схлопывается обратно.
 * onDismissed вызывается уже после анимации схлопывания.
 */
@Composable
private fun DropWindow(backdrop: Backdrop, onDismissed: () -> Unit, body: @Composable ColumnScope.(close: () -> Unit) -> Unit) {
    val touch = LocalTouch.current
    val origin = remember { touch.value } // где пользователь коснулся последний раз
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val gone = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf(false) }
    val close: () -> Unit = {
        if (!closing) {
            closing = true
            scope.launch {
                launch { fade.animateTo(0f, tween(100)) }
                launch { ax.animateTo(0f, tween(230, easing = FastOutSlowInEasing)) }
                ay.animateTo(0f, tween(250, easing = FastOutSlowInEasing))
                gone.animateTo(1f, tween(130, easing = FastOutSlowInEasing)) // шарик втягивается и тает, а не пропадает рывком
                onDismissed()
            }
        }
    }
    LaunchedEffect(Unit) {
        launch { ax.animateTo(1f, spring(.5f, 300f)) }
        launch { ay.animateTo(1f, spring(.42f, 230f)) }
        launch { delay(80); fade.animateTo(1f, tween(200)) }
    }
    BackHandler(onBack = close)
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize()
                .drawBehind { drawRect(Color.Black.copy(alpha = .45f * ay.value.coerceIn(0f, 1f))) }
                .clickable(remember { MutableInteractionSource() }, null) { close() }
        )
        Layout(
            modifier = Modifier.fillMaxSize(),
            content = {
                Box(Modifier.graphicsLayer { alpha = 1f - gone.value }.glassPanel(backdrop, 16f, 10f, 18f, Color(0xFF1E1E22).copy(alpha = .72f), shape))
                Column(
                    Modifier.graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }
                        .clickable(remember { MutableInteractionSource() }, null) { }
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) { body(close) }
            }
        ) { ms, c ->
            val margin = 28.dp.roundToPx()
            val w = (c.maxWidth - 2 * margin).coerceIn(1, 420.dp.roundToPx())
            val cont = ms[1].measure(Constraints(w, w, 0, (c.maxHeight - 2 * margin).coerceAtLeast(1)))
            val mn = 40.dp.toPx() * (1f - .85f * gone.value)
            val cw = (mn + (cont.width - mn) * ax.value).coerceAtLeast(1f)
            val ch = (mn + (cont.height - mn) * ay.value).coerceAtLeast(1f)
            val fcx = c.maxWidth / 2f
            val fcy = c.maxHeight / 2f
            val ox = if (origin.isSpecified) origin.x else fcx
            val oy = if (origin.isSpecified) origin.y else c.maxHeight * .8f
            val q = ax.value
            val cx = ox + (fcx - ox) * q
            val cy = oy + (fcy - oy) * q
            val glass = ms[0].measure(Constraints.fixed(cw.roundToInt(), ch.roundToInt()))
            layout(c.maxWidth, c.maxHeight) {
                glass.place((cx - cw / 2f).roundToInt(), (cy - ch / 2f).roundToInt())
                cont.place((cx - cont.width / 2f).roundToInt(), (cy - cont.height / 2f).roundToInt())
            }
        }
    }
}

/** Стеклянное диалоговое окно (вместо Material AlertDialog). Ставится в Box на весь экран; onDismiss вызывается после схлопывания. */
@Composable
fun GlassDialog(backdrop: Backdrop, title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    DropWindow(backdrop, onDismiss) { close ->
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        content()
        GlassButton("OK", Modifier.fillMaxWidth().padding(top = 6.dp)) { close() }
    }
}

/** Окно подтверждения (удаление и т.п.): две кнопки, действие запускается сразу, окно схлопывается следом. */
@Composable
fun GlassConfirm(
    backdrop: Backdrop, title: String, text: String, confirm: String, cancel: String,
    onConfirm: () -> Unit, onDismiss: () -> Unit,
) {
    DropWindow(backdrop, onDismiss) { close ->
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(text, color = Color.White.copy(alpha = .7f), fontSize = 15.sp)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(cancel, Modifier.weight(1f), primary = false) { close() }
            GlassButton(confirm, Modifier.weight(1f)) { close(); onConfirm() }
        }
    }
}

/** Связь меню и его кнопки: active — меню открыто или схлопывается, p — прогресс раскрытия, swell — «глоток» кнопки при втягивании капли. */
class MenuMorph {
    var active by androidx.compose.runtime.mutableStateOf(false)
    var p by androidx.compose.runtime.mutableFloatStateOf(0f)
    var swell by androidx.compose.runtime.mutableFloatStateOf(0f)
}

/** Круглая кнопка-«якорь» меню. Не исчезает никогда: при втягивании капли чуть набухает (через layout, чтобы преломление не «уезжало»). */
@Composable
fun MorphAnchor(morph: MenuMorph, modifier: Modifier, glass: @Composable (Modifier) -> Unit, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Box(
        modifier.clickable(remember { MutableInteractionSource() }, null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.fillMaxSize().layout { m, c ->
                val k = 1f + .12f * morph.swell
                val w = (c.maxWidth * k).roundToInt()
                val h = (c.maxHeight * k).roundToInt()
                val pl = m.measure(Constraints.fixed(w, h))
                layout(c.maxWidth, c.maxHeight) { pl.place((c.maxWidth - w) / 2, (c.maxHeight - h) / 2) }
            },
            contentAlignment = Alignment.Center
        ) {
            glass(Modifier.fillMaxSize())
            icon()
        }
    }
}
