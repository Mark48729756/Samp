package com.embededly.Gallery

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Переключатель в стиле стекла (вместо Material Switch). */
@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val x by animateFloatAsState(if (checked) 1f else 0f, spring(.7f, 500f), label = "sw")
    Box(
        Modifier.size(52.dp, 32.dp).clip(CircleShape)
            .background(lerp(pal.fg.copy(alpha = .18f), pal.accent, x))
            .clickable(remember { MutableInteractionSource() }, null) { onChange(!checked) }
            .padding(3.dp)
    ) {
        Box(
            Modifier.offset(x = 20.dp * x).size(26.dp).clip(CircleShape).background(Color.White)
                .border(.5.dp, Color.Black.copy(alpha = .12f), CircleShape)
        )
    }
}

/** Ползунок в стиле стекла (вместо Material Slider). */
@Composable
fun GlassSlider(value: Float, range: ClosedFloatingPointRange<Float>, steps: Int = 0, onChange: (Float) -> Unit) {
    val pal = LocalPal.current
    var w by remember { mutableIntStateOf(0) }
    val span = range.endInclusive - range.start
    val frac = ((value - range.start) / span).coerceIn(0f, 1f)
    val onNow by rememberUpdatedState(onChange)
    fun at(x: Float): Float {
        val f = (x / w.coerceAtLeast(1)).coerceIn(0f, 1f)
        return if (steps > 0) range.start + (f * steps).roundToInt() * span / steps else range.start + f * span
    }
    Box(
        Modifier.fillMaxWidth().height(36.dp).padding(horizontal = 13.dp)
            .onSizeChanged { w = it.width }
            .pointerInput(range, steps) { detectTapGestures { onNow(at(it.x)) } }
            .pointerInput(range, steps) { detectHorizontalDragGestures { ch, _ -> ch.consume(); onNow(at(ch.position.x)) } }
    ) {
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth().height(6.dp).clip(CircleShape).background(pal.fg.copy(alpha = .15f)))
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth(frac).height(6.dp).clip(CircleShape).background(pal.accent))
        Box(
            Modifier.align(Alignment.CenterStart)
                .offset { IntOffset((w * frac - 13.dp.toPx()).roundToInt(), 0) }
                .size(26.dp).clip(CircleShape).background(Color.White)
                .border(.5.dp, Color.Black.copy(alpha = .12f), CircleShape)
        )
    }
}

/** Кнопка-«капсула» (вместо Material Button). */
@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, primary: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.height(48.dp).graphicsLayer { alpha = if (enabled) 1f else .4f }
            .clip(CircleShape)
            .background(if (primary) pal.accent else pal.fg.copy(alpha = .12f))
            .border(1.dp, Color.White.copy(alpha = .16f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Color.White else pal.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Точка последнего касания в координатах экрана: окна «вываливаются» из неё как капля. Заполняется в MainActivity. */
val LocalTouch = staticCompositionLocalOf { mutableStateOf(Offset.Unspecified) }

/**
 * Размер меняется через layout, а не graphicsLayer-scale: иначе стекло (backdrop) считает координаты без учёта масштаба
 * и преломление «уезжает». ax/ay — разные пружины по ширине и высоте, из-за чего капля чуть пружинит (squash & stretch).
 * Контент остаётся в натуральном размере по центру, пока стеклянная форма растёт или схлопывается.
 */
private fun Modifier.dropSize(ax: () -> Float, ay: () -> Float, vanish: () -> Float = { 0f }, minDp: Float = 40f): Modifier = this.layout { m, c ->
    val pl = m.measure(c)
    val mn = minDp.dp.toPx() * (1f - .85f * vanish()) // в конце шарик ещё и втягивается
    val w = (mn + (pl.width - mn) * ax()).roundToInt().coerceAtLeast(1)
    val h = (mn + (pl.height - mn) * ay()).roundToInt().coerceAtLeast(1)
    layout(w, h) { pl.place(((w - pl.width) / 2f).roundToInt(), ((h - pl.height) / 2f).roundToInt()) }
}

/** Стеклянное всплывающее меню: выпадает каплей из угла кнопки и схлопывается обратно. Ставится в Box, положение — через modifier. */
@Composable
fun GlassMenu(
    visible: Boolean, backdrop: Backdrop, onDismiss: () -> Unit, modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val pal = LocalPal.current
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val gone = remember { Animatable(0f) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(visible) {
        if (visible) {
            gone.snapTo(0f)
            shown = true
            coroutineScope {
                launch { ax.animateTo(1f, spring(.5f, 380f)) }
                launch { ay.animateTo(1f, spring(.45f, 300f)) }
                launch { delay(70); fade.animateTo(1f, tween(160)) }
            }
        } else if (shown) {
            coroutineScope {
                launch { fade.animateTo(0f, tween(90)) }
                launch { ax.animateTo(0f, tween(200, easing = FastOutSlowInEasing)) }
                launch { ay.animateTo(0f, tween(220, easing = FastOutSlowInEasing)) }
            }
            gone.animateTo(1f, tween(130, easing = FastOutSlowInEasing)) // шарик втягивается и тает, а не пропадает рывком
            shown = false
        }
    }
    if (visible) BackHandler(onBack = onDismiss)
    if (visible) Box(Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { onDismiss() })
    if (shown) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            modifier
                .graphicsLayer { alpha = 1f - gone.value }
                .glassPanel(backdrop, 12f, 8f, 14f, pal.glass.copy(alpha = .62f), shape)
                .clip(shape)
                .dropSize({ ax.value }, { ay.value }, { gone.value })
        ) {
            Column(Modifier.width(220.dp).graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }.padding(vertical = 8.dp), content = content)
        }
    }
}

@Composable
fun GlassMenuItem(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(text, color = pal.fg, fontSize = 16.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp))
}

/**
 * Окно, которое вываливается каплей из точки касания, растёт до своего размера и при закрытии схлопывается обратно.
 * onDismissed вызывается уже после анимации схлопывания.
 */
@Composable
private fun DropWindow(backdrop: Backdrop, onDismissed: () -> Unit, body: @Composable ColumnScope.(close: () -> Unit) -> Unit) {
    val touch = LocalTouch.current
    val origin = remember { touch.value } // где пользователь коснулся последний раз
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val gone = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf(false) }
    val close: () -> Unit = {
        if (!closing) {
            closing = true
            scope.launch {
                launch { fade.animateTo(0f, tween(100)) }
                launch { ax.animateTo(0f, tween(230, easing = FastOutSlowInEasing)) }
                ay.animateTo(0f, tween(250, easing = FastOutSlowInEasing))
                gone.animateTo(1f, tween(130, easing = FastOutSlowInEasing)) // шарик втягивается и тает, а не пропадает рывком
                onDismissed()
            }
        }
    }
    LaunchedEffect(Unit) {
        launch { ax.animateTo(1f, spring(.5f, 300f)) }
        launch { ay.animateTo(1f, spring(.42f, 230f)) }
        launch { delay(80); fade.animateTo(1f, tween(200)) }
    }
    BackHandler(onBack = close)
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize()
                .drawBehind { drawRect(Color.Black.copy(alpha = .45f * ay.value.coerceIn(0f, 1f))) }
                .clickable(remember { MutableInteractionSource() }, null) { close() }
        )
        Layout(
            modifier = Modifier.fillMaxSize(),
            content = {
                Box(Modifier.graphicsLayer { alpha = 1f - gone.value }.glassPanel(backdrop, 16f, 10f, 18f, Color(0xFF1E1E22).copy(alpha = .72f), shape))
                Column(
                    Modifier.graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }
                        .clickable(remember { MutableInteractionSource() }, null) { }
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) { body(close) }
            }
        ) { ms, c ->
            val margin = 28.dp.roundToPx()
            val w = (c.maxWidth - 2 * margin).coerceIn(1, 420.dp.roundToPx())
            val cont = ms[1].measure(Constraints(w, w, 0, (c.maxHeight - 2 * margin).coerceAtLeast(1)))
            val mn = 40.dp.toPx() * (1f - .85f * gone.value)
            val cw = (mn + (cont.width - mn) * ax.value).coerceAtLeast(1f)
            val ch = (mn + (cont.height - mn) * ay.value).coerceAtLeast(1f)
            val fcx = c.maxWidth / 2f
            val fcy = c.maxHeight / 2f
            val ox = if (origin.isSpecified) origin.x else fcx
            val oy = if (origin.isSpecified) origin.y else c.maxHeight * .8f
            val q = ax.value
            val cx = ox + (fcx - ox) * q
            val cy = oy + (fcy - oy) * q
            val glass = ms[0].measure(Constraints.fixed(cw.roundToInt(), ch.roundToInt()))
            layout(c.maxWidth, c.maxHeight) {
                glass.place((cx - cw / 2f).roundToInt(), (cy - ch / 2f).roundToInt())
                cont.place((cx - cont.width / 2f).roundToInt(), (cy - cont.height / 2f).roundToInt())
            }
        }
    }
}

/** Стеклянное диалоговое окно (вместо Material AlertDialog). Ставится в Box на весь экран; onDismiss вызывается после схлопывания. */
@Composable
fun GlassDialog(backdrop: Backdrop, title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    DropWindow(backdrop, onDismiss) { close ->
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        content()
        GlassButton("OK", Modifier.fillMaxWidth().padding(top = 6.dp)) { close() }
    }
}

/** Окно подтверждения (удаление и т.п.): две кнопки, действие запускается сразу, окно схлопывается следом. */
@Composable
fun GlassConfirm(
    backdrop: Backdrop, title: String, text: String, confirm: String, cancel: String,
    onConfirm: () -> Unit, onDismiss: () -> Unit,
) {
    DropWindow(backdrop, onDismiss) { close ->
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(text, color = Color.White.copy(alpha = .7f), fontSize = 15.sp)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(cancel, Modifier.weight(1f), primary = false) { close() }
            GlassButton(confirm, Modifier.weight(1f)) { close(); onConfirm() }
        }
    }
}
