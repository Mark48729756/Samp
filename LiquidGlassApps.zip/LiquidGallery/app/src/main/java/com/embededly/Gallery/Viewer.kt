package com.embededly.Gallery

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.launch
import kotlin.math.abs

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Viewer(
    items: List<Media>, start: Int, slideshowSec: Int,
    onClose: () -> Unit, onShare: (Media) -> Unit, onEdit: (Media) -> Unit, onDelete: (Media) -> Unit,
    onFav: (Media) -> Unit, onSetAs: (Media) -> Unit,
) {
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val black = prefs.viewerBg.value == "black"
    val fg = if (black) Color.White else pal.fg
    val bg = if (black) Color.Black else pal.bg
    val ps = rememberPagerState(start) { items.size }
    val scope = rememberCoroutineScope()
    val vb = rememberLayerBackdrop()
    var chrome by remember { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    var slide by remember { mutableStateOf(false) }
    val dragY = remember { Animatable(0f) }
    val cur = items.getOrNull(ps.currentPage)
    val ctx = LocalContext.current
    val fade = (1f - abs(dragY.value) / 700f).coerceIn(.2f, 1f)
    val enterT = if (prefs.anim.value) fadeIn() else EnterTransition.None
    val exitT = if (prefs.anim.value) fadeOut() else ExitTransition.None

    LaunchedEffect(slide, ps.currentPage) {
        if (slide) {
            kotlinx.coroutines.delay(slideshowSec * 1000L)
            if (ps.currentPage < items.size - 1) ps.animateScrollToPage(ps.currentPage + 1) else { slide = false; chrome = true }
        }
    }

    Box(Modifier.fillMaxSize().background(bg.copy(alpha = fade))) {
        Box(Modifier.fillMaxSize().layerBackdrop(vb)
            .graphicsLayer { translationY = dragY.value; val s = 1f - abs(dragY.value) / 3000f; scaleX = s; scaleY = s }) {
            HorizontalPager(ps, Modifier.fillMaxSize(), userScrollEnabled = !zoomed, key = { items[it].uri.toString() + it }) { p ->
                ZoomPage(
                    items[p], prefs.viewerFill.value, p == ps.currentPage,
                    onTap = { if (slide) { slide = false; chrome = true } else chrome = !chrome },
                    onZoomed = { zoomed = it },
                    onDrag = { dy -> scope.launch { dragY.snapTo(dragY.value + dy) } },
                    onDragEnd = { if (abs(dragY.value) > 220f) onClose() else scope.launch { dragY.animateTo(0f) } }
                )
            }
        }

        val surface = Color(0xFF1E1E22).copy(alpha = .55f)
        AnimatedVisibility(chrome, Modifier.align(Alignment.TopStart), enter = enterT, exit = exitT) {
            Box(Modifier.statusBarsPadding().padding(12.dp).size(46.dp)
                .glassPanel(vb, 6f, 10f, 20f, surface)
                .clickable(remember { MutableInteractionSource() }, null) { onClose() },
                contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Close, null, tint = Color.White)
            }
        }
        if (prefs.viewerCounter.value && items.size > 1) AnimatedVisibility(chrome, Modifier.align(Alignment.TopCenter), enter = enterT, exit = exitT) {
            Text("${ps.currentPage + 1} / ${items.size}", color = fg, fontSize = 13.sp,
                modifier = Modifier.statusBarsPadding().padding(top = 26.dp))
        }
        AnimatedVisibility(chrome && cur != null, Modifier.align(Alignment.BottomCenter), enter = enterT, exit = exitT) {
            Row(Modifier.navigationBarsPadding().padding(bottom = 20.dp).height(64.dp)
                .glassPanel(vb, 6f, 12f, 24f, surface).padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                if (cur != null) {
                    Act(Icons.Outlined.Share, t(R.string.s_105)) { onShare(cur) }
                    if (android.os.Build.VERSION.SDK_INT >= 30)
                        Act(if (cur.fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, t(R.string.s_106),
                            if (cur.fav) Color(0xFFFF375F) else Color.White) { onFav(cur) }
                    Act(if (cur.isVideo) Icons.Outlined.ContentCut else Icons.Outlined.Crop, t(R.string.s_107)) { onEdit(cur) }
                    Act(Icons.Outlined.Delete, t(R.string.s_108)) { confirmDel = true }
                    Act(Icons.Outlined.MoreVert, t(R.string.s_109)) { more = true }
                }
            }
        }
        if (cur != null) GlassMenu(more, vb, { more = false },
            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 16.dp, bottom = 96.dp)) {
            GlassMenuItem(t(R.string.s_110)) { more = false; info = true }
            GlassMenuItem(t(R.string.s_111)) { more = false; chrome = false; slide = true }
            if (!cur.isVideo) GlassMenuItem(t(R.string.s_112)) { more = false; onSetAs(cur) }
        }
        if (confirmDel && cur != null) GlassConfirm(vb, t(R.string.s_del_title), t(R.string.s_del_text, 1), t(R.string.s_108), t(R.string.s_cancel),
            onConfirm = { onDelete(cur) }, onDismiss = { confirmDel = false })
        if (info && cur != null) {
            val rows = remember(cur) { mediaInfo(ctx, cur) }
            GlassDialog(vb, t(R.string.s_110), { info = false }) {
                if (rows.isEmpty()) Text(t(R.string.s_113), color = Color.White)
                rows.forEach { (k, v) -> Column { Text(k, fontSize = 12.sp, color = Color.White.copy(alpha = .6f)); Text(v, fontSize = 15.sp, color = Color.White) } }
            }
        }
    }
}

@Composable
private fun Act(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Column(Modifier.width(62.dp).fillMaxHeight().clickable(remember { MutableInteractionSource() }, null, onClick = onClick),
        Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, color = Color.White, fontSize = 10.5.sp, maxLines = 1)
    }
}

@Composable
private fun ZoomPage(
    m: Media, fill: Boolean, current: Boolean,
    onTap: () -> Unit, onZoomed: (Boolean) -> Unit, onDrag: (Float) -> Unit, onDragEnd: () -> Unit,
) {
    val ctx = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var playing by remember { mutableStateOf(false) }
    LaunchedEffect(current) { if (!current) { scale = 1f; off = Offset.Zero; playing = false } }
    LaunchedEffect(scale, current) { if (current) onZoomed(scale > 1.01f) }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = size.width * (s - 1f) / 2f; val my = size.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    val gestures = if (playing) Modifier else Modifier
        .pointerInput(m.isVideo) {
            detectTapGestures(
                onTap = { onTap() },
                onDoubleTap = { tap ->
                    if (!m.isVideo) {
                        if (scale > 1.01f) { scale = 1f; off = Offset.Zero }
                        else { scale = 2.5f; off = clamp(Offset((size.width / 2f - tap.x) * 1.5f, (size.height / 2f - tap.y) * 1.5f), 2.5f) }
                    }
                }
            )
        }
        .pointerInput(m.isVideo) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                var tx = 0f; var ty = 0f; var mode = 0 // 0 ?, 1 вертикаль (закрытие), 2 зум/пан, 3 горизонталь (пейджер)
                do {
                    val ev = awaitPointerEvent()
                    val n = ev.changes.count { it.pressed }
                    if (!m.isVideo && (n >= 2 || scale > 1.01f)) {
                        mode = 2
                        val ns = (scale * ev.calculateZoom()).coerceIn(1f, 6f)
                        off = if (ns <= 1.01f) Offset.Zero else clamp(off + ev.calculatePan(), ns)
                        scale = ns
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    } else if (n == 1 && scale <= 1.01f) {
                        val ch = ev.changes.first(); val d = ch.positionChange()
                        tx += d.x; ty += d.y
                        if (mode == 0 && (abs(tx) > viewConfiguration.touchSlop || abs(ty) > viewConfiguration.touchSlop))
                            mode = if (abs(ty) > abs(tx)) 1 else 3
                        if (mode == 1) { onDrag(d.y); ch.consume() }
                    }
                } while (ev.changes.any { it.pressed })
                if (mode == 1) onDragEnd()
                if (scale < 1.05f) { scale = 1f; off = Offset.Zero }
            }
        }

    Box(Modifier.fillMaxSize().onSizeChanged { size = it }.then(gestures), Alignment.Center) {
        if (playing) {
            val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare(); playWhenReady = true } }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, Modifier.fillMaxSize())
        } else {
            AsyncImage(m.uri, null,
                Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
                contentScale = if (fill) ContentScale.Crop else ContentScale.Fit)
            if (m.isVideo) Icon(Icons.Default.PlayCircle, null, tint = Color.White,
                modifier = Modifier.size(76.dp).clickable(remember { MutableInteractionSource() }, null) { playing = true })
        }
    }
}
