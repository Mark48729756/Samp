package com.embededly.Gallery

import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.SeekParameters
import kotlinx.coroutines.delay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil3.compose.AsyncImage
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.launch
import kotlin.math.abs

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Viewer(
    items: List<Media>, start: Int, slideshowSec: Int,
    onClose: () -> Unit, onShare: (Media) -> Unit, onEdit: (Media) -> Unit, onDelete: (Media) -> Unit,
    onFav: (Media) -> Unit, onSetAs: (Media) -> Unit,
) {
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val black = prefs.viewerBg.value == "black"
    val fg = if (black) Color.White else pal.fg
    val bg = if (black) Color.Black else pal.bg
    val ps = rememberPagerState(start) { items.size }
    val scope = rememberCoroutineScope()
    val vb = rememberLayerBackdrop()
    var chrome by remember { mutableStateOf(true) }
    var zoomed by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    val moreMorph = remember { MenuMorph() }
    var vp by remember { mutableStateOf<ExoPlayer?>(null) }          // текущий видеоплеер (если видео запущено)
    var playReq by remember { mutableStateOf<String?>(null) }         // запрос «запустить это видео» с кнопки на панели
    var confirmDel by remember { mutableStateOf(false) }
    var slide by remember { mutableStateOf(false) }
    val dragY = remember { Animatable(0f) }
    val cur = items.getOrNull(ps.currentPage)
    val ctx = LocalContext.current
    val fade = (1f - abs(dragY.value) / 700f).coerceIn(.2f, 1f)
    val enterT = if (prefs.anim.value) fadeIn() else EnterTransition.None
    val exitT = if (prefs.anim.value) fadeOut() else ExitTransition.None

    LaunchedEffect(ps.currentPage) { playReq = null; vp = null }
    LaunchedEffect(slide, ps.currentPage) {
        if (slide) {
            kotlinx.coroutines.delay(slideshowSec * 1000L)
            if (ps.currentPage < items.size - 1) ps.animateScrollToPage(ps.currentPage + 1) else { slide = false; chrome = true }
        }
    }

    var rootSz by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    var rootPos by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var moreBox by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    Box(Modifier.fillMaxSize().background(bg.copy(alpha = fade))
        .onGloballyPositioned { rootSz = it.size; rootPos = it.positionInRoot() }) {
        Box(Modifier.fillMaxSize().layerBackdrop(vb)
            .graphicsLayer { translationY = dragY.value; val s = 1f - abs(dragY.value) / 3000f; scaleX = s; scaleY = s }) {
            HorizontalPager(ps, Modifier.fillMaxSize(), userScrollEnabled = !zoomed, key = { items[it].uri.toString() + it }) { p ->
                ZoomPage(
                    items[p], prefs.viewerFill.value, p == ps.currentPage, playReq,
                    onPlayer = { vp = it }, onPlayerGone = { gone -> if (vp === gone) vp = null },
                    onTap = { if (slide) { slide = false; chrome = true } else chrome = !chrome },
                    onZoomed = { zoomed = it },
                    onDrag = { dy -> scope.launch { dragY.snapTo(dragY.value + dy) } },
                    onDragEnd = { if (abs(dragY.value) > 220f) onClose() else scope.launch { dragY.animateTo(0f) } }
                )
            }
        }

        val surface = Color(0xFF1E1E22).copy(alpha = .55f)
        AnimatedVisibility(chrome, Modifier.align(Alignment.TopStart), enter = enterT, exit = exitT) {
            Box(Modifier.statusBarsPadding().padding(12.dp).size(46.dp)
                .glassPanel(vb, 6f, 10f, 20f, surface)
                .clickable(remember { MutableInteractionSource() }, null) { onClose() },
                contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Close, null, tint = Color.White)
            }
        }
        if (prefs.viewerCounter.value && items.size > 1) AnimatedVisibility(chrome, Modifier.align(Alignment.TopCenter), enter = enterT, exit = exitT) {
            Text("${ps.currentPage + 1} / ${items.size}", color = fg, fontSize = 13.sp,
                modifier = Modifier.statusBarsPadding().padding(top = 26.dp))
        }
        // меню рисуется ПОД доком: капля стартует ровно в центре кнопки «⋮» (спрятана за доком) и вылетает вверх из-за него
        if (cur != null) {
            val mb = moreBox
            val d = LocalDensity.current
            val gap = with(d) { 8.dp.toPx() }
            val ball = 40f
            val endPad = if (mb != null) with(d) { (rootSz.width - (mb.right - rootPos.x)).coerceAtLeast(0f).toDp() } else 16.dp
            val botPad = if (mb != null) with(d) { (rootSz.height - (mb.top - rootPos.y) + gap).coerceAtLeast(0f).toDp() } else 96.dp
            // сдвиг свёрнутой капли от конечного угла меню до центра кнопки (в dp)
            val riseY = if (mb != null) with(d) { ((mb.center.y + ball.dp.toPx() / 2f) - (mb.top - gap)).toDp().value } else 0f
            val riseX = if (mb != null) with(d) { ((mb.center.x + ball.dp.toPx() / 2f) - mb.right).toDp().value } else 0f
            GlassMenu(more, vb, { more = false },
                Modifier.align(Alignment.BottomEnd).padding(end = endPad, bottom = botPad),
                anchor = Alignment.BottomEnd, riseDp = riseY, riseXDp = riseX, minDp = ball, morph = moreMorph) {
                GlassMenuItem(t(R.string.s_110)) { more = false; info = true }
                GlassMenuItem(t(R.string.s_111)) { more = false; chrome = false; slide = true }
                if (!cur.isVideo) GlassMenuItem(t(R.string.s_112)) { more = false; onSetAs(cur) }
            }
        }
        // стеклянный плеер над доком (как в системной галерее): play/pause, нормальная перемотка, звук
        if (cur != null && cur.isVideo) AnimatedVisibility(chrome, Modifier.align(Alignment.BottomCenter), enter = enterT, exit = exitT) {
            VideoBar(vb, vp, cur.durationMs, surface,
                onStart = { playReq = cur.uri.toString() },
                modifier = Modifier.navigationBarsPadding().padding(start = 16.dp, end = 16.dp, bottom = 96.dp))
        }
        AnimatedVisibility(chrome && cur != null, Modifier.align(Alignment.BottomCenter), enter = enterT, exit = exitT) {
            Row(Modifier.navigationBarsPadding().padding(bottom = 20.dp).height(64.dp)
                .glassPanel(vb, 6f, 12f, 24f, surface).padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                if (cur != null) {
                    Act(Icons.Outlined.Share, t(R.string.s_105)) { onShare(cur) }
                    if (android.os.Build.VERSION.SDK_INT >= 30)
                        Act(if (cur.fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, t(R.string.s_106),
                            if (cur.fav) Color(0xFFFF375F) else Color.White) { onFav(cur) }
                    Act(if (cur.isVideo) Icons.Outlined.ContentCut else Icons.Outlined.Crop, t(R.string.s_107)) { onEdit(cur) }
                    Act(Icons.Outlined.Delete, t(R.string.s_108)) { confirmDel = true }
                    Act(Icons.Outlined.MoreVert, t(R.string.s_109), Color.White, Modifier.onGloballyPositioned { moreBox = it.boundsInRoot() }
                        .graphicsLayer { val sc = 1f + .2f * moreMorph.swell; scaleX = sc; scaleY = sc }) { more = !more }
                }
            }
        }
        if (confirmDel && cur != null) GlassConfirm(vb, t(R.string.s_del_title), t(R.string.s_del_text, 1), t(R.string.s_108), t(R.string.s_cancel),
            onConfirm = { onDelete(cur) }, onDismiss = { confirmDel = false })
        if (info && cur != null) {
            val rows = remember(cur) { mediaInfo(ctx, cur) }
            GlassDialog(vb, t(R.string.s_110), { info = false }) {
                if (rows.isEmpty()) Text(t(R.string.s_113), color = Color.White)
                rows.forEach { (k, v) -> Column { Text(k, fontSize = 12.sp, color = Color.White.copy(alpha = .6f)); Text(v, fontSize = 15.sp, color = Color.White) } }
            }
        }
    }
}

@Composable
private fun Act(icon: ImageVector, label: String, tint: Color = Color.White, mod: Modifier = Modifier, onClick: () -> Unit) {
    Column(mod.width(62.dp).fillMaxHeight().clickable(remember { MutableInteractionSource() }, null, onClick = onClick),
        Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, color = Color.White, fontSize = 10.5.sp, maxLines = 1)
    }
}

@Composable
private fun ZoomPage(
    m: Media, fill: Boolean, current: Boolean, playReq: String?,
    onPlayer: (ExoPlayer) -> Unit, onPlayerGone: (ExoPlayer) -> Unit,
    onTap: () -> Unit, onZoomed: (Boolean) -> Unit, onDrag: (Float) -> Unit, onDragEnd: () -> Unit,
) {
    val ctx = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    var playing by remember { mutableStateOf(false) }
    LaunchedEffect(current) { if (!current) { scale = 1f; off = Offset.Zero; playing = false } }
    LaunchedEffect(playReq, current) { if (current && m.isVideo && playReq == m.uri.toString()) playing = true }
    LaunchedEffect(scale, current) { if (current) onZoomed(scale > 1.01f) }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = size.width * (s - 1f) / 2f; val my = size.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    val gestures = if (playing) Modifier else Modifier
        .pointerInput(m.isVideo) {
            detectTapGestures(
                onTap = { onTap() },
                onDoubleTap = { tap ->
                    if (!m.isVideo) {
                        if (scale > 1.01f) { scale = 1f; off = Offset.Zero }
                        else { scale = 2.5f; off = clamp(Offset((size.width / 2f - tap.x) * 1.5f, (size.height / 2f - tap.y) * 1.5f), 2.5f) }
                    }
                }
            )
        }
        .pointerInput(m.isVideo) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                var tx = 0f; var ty = 0f; var mode = 0 // 0 ?, 1 вертикаль (закрытие), 2 зум/пан, 3 горизонталь (пейджер)
                do {
                    val ev = awaitPointerEvent()
                    val n = ev.changes.count { it.pressed }
                    if (!m.isVideo && (n >= 2 || scale > 1.01f)) {
                        mode = 2
                        val ns = (scale * ev.calculateZoom()).coerceIn(1f, 6f)
                        off = if (ns <= 1.01f) Offset.Zero else clamp(off + ev.calculatePan(), ns)
                        scale = ns
                        ev.changes.forEach { if (it.positionChanged()) it.consume() }
                    } else if (n == 1 && scale <= 1.01f) {
                        val ch = ev.changes.first(); val d = ch.positionChange()
                        tx += d.x; ty += d.y
                        if (mode == 0 && (abs(tx) > viewConfiguration.touchSlop || abs(ty) > viewConfiguration.touchSlop))
                            mode = if (abs(ty) > abs(tx)) 1 else 3
                        if (mode == 1) { onDrag(d.y); ch.consume() }
                    }
                } while (ev.changes.any { it.pressed })
                if (mode == 1) onDragEnd()
                if (scale < 1.05f) { scale = 1f; off = Offset.Zero }
            }
        }

    Box(Modifier.fillMaxSize().onSizeChanged { size = it }.then(gestures), Alignment.Center) {
        if (playing) {
            val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare(); playWhenReady = true } }
            DisposableEffect(player) { onPlayer(player); onDispose { onPlayerGone(player); player.release() } }
            // свой стеклянный плеер вместо стандартных контролов Media3, поэтому useController = false
            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = false } }, Modifier.fillMaxSize())
        } else {
            AsyncImage(m.uri, null,
                Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
                contentScale = if (fill) ContentScale.Crop else ContentScale.Fit)
            if (m.isVideo) Icon(Icons.Default.PlayCircle, null, tint = Color.White,
                modifier = Modifier.size(76.dp).clickable(remember { MutableInteractionSource() }, null) { playing = true })
        }
    }
}


/**
 * Стеклянная панель видеоплеера: play/pause, полоса перемотки и кнопка звука.
 * Перемотка нормальная: касание сразу прыгает в нужное место, а при протягивании пальцем кадр меняется вживую
 * (на время протяжки видео ставится на паузу, потом точный seek и продолжение, если играло).
 */
@Composable
private fun VideoBar(
    backdrop: com.kyant.backdrop.Backdrop, player: ExoPlayer?, fallbackMs: Long, surface: Color,
    onStart: () -> Unit, modifier: Modifier = Modifier,
) {
    var playing by remember(player) { mutableStateOf(player?.isPlaying == true) }
    var ended by remember(player) { mutableStateOf(false) }
    var pos by remember(player) { mutableLongStateOf(0L) }
    var dur by remember(player) { mutableLongStateOf(fallbackMs) }
    var muted by remember { mutableStateOf(false) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val durNow by rememberUpdatedState(dur)
    val playerNow by rememberUpdatedState(player)

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(state: Int) { ended = state == Player.STATE_ENDED }
        }
        player?.addListener(l)
        onDispose { player?.removeListener(l) }
    }
    LaunchedEffect(player) {
        while (true) {
            player?.let { p ->
                if (drag == null) pos = p.currentPosition
                val d = p.duration
                if (d > 0) dur = d
            }
            delay(80)
        }
    }
    LaunchedEffect(player, muted) { player?.volume = if (muted) 0f else 1f }

    val frac = drag ?: if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f

    Row(
        modifier.fillMaxWidth().height(52.dp).glassPanel(backdrop, 6f, 12f, 24f, surface).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clickable(remember { MutableInteractionSource() }, null) {
                val p = player
                if (p == null) onStart()
                else if (ended) { p.seekTo(0); p.play() }
                else if (p.isPlaying) p.pause() else p.play()
            },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (playing) androidx.compose.material.icons.Icons.Filled.Pause else androidx.compose.material.icons.Icons.Filled.PlayArrow,
                null, tint = Color.White, modifier = Modifier.size(30.dp)
            )
        }
        Box(
            Modifier.weight(1f).height(40.dp).padding(horizontal = 8.dp)
                .pointerInput(Unit) {
                    detectTapGestures { o ->
                        val p = playerNow ?: return@detectTapGestures
                        val f = (o.x / size.width).coerceIn(0f, 1f)
                        val t = (f * durNow).toLong()
                        p.seekTo(t); pos = t
                    }
                }
                .pointerInput(Unit) {
                    var was = false
                    detectHorizontalDragGestures(
                        onDragStart = { o ->
                            val p = playerNow
                            drag = (o.x / size.width).coerceIn(0f, 1f)
                            if (p != null) { was = p.isPlaying; p.pause(); p.setSeekParameters(SeekParameters.CLOSEST_SYNC) }
                        },
                        onHorizontalDrag = { ch, _ ->
                            val f = (ch.position.x / size.width).coerceIn(0f, 1f)
                            drag = f
                            playerNow?.seekTo((f * durNow).toLong())
                        },
                        onDragEnd = {
                            val p = playerNow
                            val f = drag ?: 0f
                            if (p != null) {
                                p.setSeekParameters(SeekParameters.EXACT)
                                val t = (f * durNow).toLong()
                                p.seekTo(t); pos = t
                                if (was) p.play()
                            }
                            drag = null
                        },
                        onDragCancel = { playerNow?.setSeekParameters(SeekParameters.EXACT); drag = null },
                    )
                }
                .androidx_drawTrack(frac, drag != null)
        )
        Box(
            Modifier.size(40.dp).clickable(remember { MutableInteractionSource() }, null) { muted = !muted },
            contentAlignment = Alignment.Center
        ) {
            Icon(if (muted) Icons.Outlined.VolumeOff else Icons.Outlined.VolumeUp, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
    }
}

/** Дорожка перемотки: тонкая линия, залитая часть и бегунок (при протяжке бегунок крупнее). */
private fun Modifier.androidx_drawTrack(frac: Float, dragging: Boolean): Modifier = this.drawBehind {
    val h = 4.dp.toPx()
    val cy = size.height / 2f
    val r = androidx.compose.ui.geometry.CornerRadius(h / 2f, h / 2f)
    drawRoundRect(Color.White.copy(alpha = .28f), androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(size.width, h), r)
    drawRoundRect(Color.White, androidx.compose.ui.geometry.Offset(0f, cy - h / 2f), androidx.compose.ui.geometry.Size(size.width * frac, h), r)
    drawCircle(Color.White, (if (dragging) 9.dp else 7.dp).toPx(), androidx.compose.ui.geometry.Offset(size.width * frac, cy))
}
