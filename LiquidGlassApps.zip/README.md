# Liquid Glass: Галерея + Калькулятор

Две нативные программы на Kotlin + Jetpack Compose с жидким стеклом (Kyant0/AndroidLiquidGlass):
- `LiquidGallery` — com.embededly.Gallery
- `LiquidCalculator` — com.embededly.Calculator

Блики на стекле наклоняются вместе с телефоном (гироскоп → `Tilt.kt`).

## Сборка (с телефона)
1. Создай репозиторий на github.com и загрузи в него ВСЁ содержимое этой папки (включая `.github`).
2. Actions → «Build APKs» → Run workflow (или дождись автозапуска).
3. Через ~6 минут в Releases появятся `Gallery.apk` и `Calculator.apk`. Оба подписаны одним ключом, обновляются поверх.
