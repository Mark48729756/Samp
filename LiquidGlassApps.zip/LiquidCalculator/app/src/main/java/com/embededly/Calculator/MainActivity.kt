package com.embededly.Calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onResume() { super.onResume(); Tilt.start(this) }
    override fun onPause() { Tilt.stop(); super.onPause() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            val accent = Color(0xFFFF7F1E)
            val pal = if (dark) Pal(
                bg = Color.Black, fg = Color.White, sub = Color(0xFF8E8E93),
                key = Color(0xFF2A2A2C).copy(alpha = .80f), accent = accent, dark = true
            ) else Pal(
                bg = Color(0xFFF2F2F7), fg = Color.Black, sub = Color(0xFF6C6C70),
                key = Color.White.copy(alpha = .78f), accent = accent, dark = false
            )
            CompositionLocalProvider(LocalPal provides pal, androidx.compose.foundation.LocalOverscrollFactory provides null) {
                MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) { CalcApp() }
            }
        }
    }
}
