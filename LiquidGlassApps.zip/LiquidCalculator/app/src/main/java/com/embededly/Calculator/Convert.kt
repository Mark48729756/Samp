package com.embededly.Calculator

/** Единица: переводит значение в базовую единицу категории и обратно. */
class CU(val name: String, val toBase: (Double) -> Double, val fromBase: (Double) -> Double)

class Cat(val name: String, val units: List<CU>)

private fun lin(name: String, f: Double) = CU(name, { it * f }, { it / f })

fun categories(): List<Cat> = listOf(
    Cat(tr("Длина", "Length"), listOf(
        lin(tr("мм", "mm"), .001), lin(tr("см", "cm"), .01), lin(tr("м", "m"), 1.0), lin(tr("км", "km"), 1000.0),
        lin(tr("дюйм", "in"), .0254), lin(tr("фут", "ft"), .3048), lin(tr("ярд", "yd"), .9144), lin(tr("миля", "mi"), 1609.344),
    )),
    Cat(tr("Масса", "Mass"), listOf(
        lin(tr("мг", "mg"), 1e-6), lin(tr("г", "g"), 1e-3), lin(tr("кг", "kg"), 1.0), lin(tr("т", "t"), 1000.0),
        lin(tr("унция", "oz"), 0.028349523125), lin(tr("фунт", "lb"), 0.45359237),
    )),
    Cat(tr("Температура", "Temperature"), listOf(
        CU("°C", { it }, { it }),
        CU("°F", { (it - 32.0) * 5.0 / 9.0 }, { it * 9.0 / 5.0 + 32.0 }),
        CU("K", { it - 273.15 }, { it + 273.15 }),
    )),
    Cat(tr("Площадь", "Area"), listOf(
        lin(tr("мм²", "mm²"), 1e-6), lin(tr("см²", "cm²"), 1e-4), lin(tr("м²", "m²"), 1.0), lin(tr("га", "ha"), 10000.0),
        lin(tr("км²", "km²"), 1e6), lin(tr("фут²", "ft²"), 0.09290304), lin(tr("акр", "ac"), 4046.8564224),
    )),
    Cat(tr("Объём", "Volume"), listOf(
        lin(tr("мл", "ml"), .001), lin(tr("л", "l"), 1.0), lin(tr("м³", "m³"), 1000.0),
        lin(tr("галлон (US)", "gal (US)"), 3.785411784), lin(tr("жидк. унция", "fl oz"), 0.0295735295625), lin(tr("чашка", "cup"), 0.2365882365),
    )),
    Cat(tr("Скорость", "Speed"), listOf(
        lin(tr("м/с", "m/s"), 1.0), lin(tr("км/ч", "km/h"), 1.0 / 3.6), lin(tr("миль/ч", "mph"), 0.44704), lin(tr("узел", "kn"), 1852.0 / 3600.0),
    )),
    Cat(tr("Время", "Time"), listOf(
        lin(tr("с", "s"), 1.0), lin(tr("мин", "min"), 60.0), lin(tr("ч", "h"), 3600.0), lin(tr("сут", "day"), 86400.0),
        lin(tr("нед", "week"), 604800.0), lin(tr("год", "year"), 31557600.0),
    )),
    Cat(tr("Данные", "Data"), listOf(
        lin(tr("бит", "bit"), .125), lin(tr("Б", "B"), 1.0), lin("KB", 1024.0), lin("MB", 1048576.0),
        lin("GB", 1073741824.0), lin("TB", 1099511627776.0),
    )),
)
