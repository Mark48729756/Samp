package com.embededly.Calculator

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class Kind { NUM, OP, EQ, FN }

/** Стеклянная панель: размытие + линза-преломление поверх backdrop. */
fun Modifier.glass(
    backdrop: Backdrop, shape: Shape, surface: Color,
    blurDp: Float = 4f, refH: Float = 8f, refA: Float = 12f, strength: Float = 1f,
): Modifier = this.drawBackdrop(
    backdrop, { shape },
    effects = {
        if (blurDp > 0f) blur(blurDp.dp.toPx())
        if (refH > 0f) lens(refH.dp.toPx(), refA.dp.toPx())
    },
    onDrawSurface = { drawRect(surface) }
).tiltRim(shape, strength)

private const val GROW = .09f

/**
 * Стеклянная клавиша. При касании вырастает от центра («капля») и плавно возвращается; даже у быстрого тапа
 * эффект держится ~170 мс после отпускания. Размер меняется через layout, а не scale, чтобы преломление не «уезжало».
 */
@Composable
fun CalcKey(
    backdrop: Backdrop, kind: Kind, modifier: Modifier = Modifier,
    onLong: (() -> Unit)? = null, onTap: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val tapNow by rememberUpdatedState(onTap)
    val longNow by rememberUpdatedState(onLong)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) GROW else 0f, spring(.52f, 330f), label = "keyGrow")
    val open = (grow / GROW).coerceIn(0f, 1f)
    val shape = RoundedCornerShape(30.dp)
    val surface = when (kind) {
        Kind.EQ -> pal.accent.copy(alpha = .95f)
        Kind.FN -> pal.key.copy(alpha = pal.key.alpha * .8f)
        else -> pal.key
    }
    val edge = (if (pal.dark) .07f else .55f) + .22f * open
    Box(
        modifier.zIndex(if (lift || grow > .002f) 1f else 0f).pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    lift = true
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    tryAwaitRelease()
                    scope.launch { delay(170); lift = false }
                },
                onLongPress = { longNow?.invoke() },
                onTap = { tapNow() },
            )
        }
    ) {
        Box(
            Modifier.fillMaxSize()
                .layout { m, c ->
                    val w = (c.maxWidth * (1f + grow)).roundToInt()
                    val h = (c.maxHeight * (1f + grow * 1.1f)).roundToInt()
                    val pl = m.measure(Constraints.fixed(w, h))
                    layout(c.maxWidth, c.maxHeight) { pl.place((c.maxWidth - w) / 2, (c.maxHeight - h) / 2) }
                }
                .glass(backdrop, shape, surface, 3f, 8f * (1f + open * .2f), 12f * (1f + open * .3f))
                .border(1.dp, Color.White.copy(alpha = edge), shape),
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

class KeyDef(
    val label: String? = null, val icon: ImageVector? = null, val kind: Kind = Kind.NUM,
    val onLong: (() -> Unit)? = null, val onTap: () -> Unit,
)

@Composable
fun Keypad(backdrop: Backdrop, rows: List<List<KeyDef>>, keyH: Dp, gap: Dp = 12.dp, textSp: Int = 34, modifier: Modifier = Modifier) {
    val pal = LocalPal.current
    Column(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(gap)) {
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth().height(keyH), horizontalArrangement = Arrangement.spacedBy(gap)) {
                row.forEach { k ->
                    CalcKey(backdrop, k.kind, Modifier.weight(1f).fillMaxHeight(), k.onLong, k.onTap) {
                        val col = when (k.kind) { Kind.EQ -> Color.White; Kind.OP -> pal.accent; else -> pal.fg }
                        if (k.icon != null) Icon(k.icon, null, tint = col, modifier = Modifier.size((textSp * .9f).dp))
                        else if (k.label != null) {
                            val long = k.label.length > 1
                            Text(
                                k.label, color = col,
                                fontSize = (if (long) textSp * .68f else textSp.toFloat()).sp,
                                fontWeight = if (long) FontWeight.Medium else FontWeight.Light, maxLines = 1,
                            )
                        }
                    }
                }
            }
        }
    }
}
