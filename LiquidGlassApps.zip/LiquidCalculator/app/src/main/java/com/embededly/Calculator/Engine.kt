package com.embededly.Calculator

import java.math.BigDecimal
import java.math.MathContext
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

private val RU_LANGS = setOf("ru", "uk", "be", "kk")

/** Короткий перевод интерфейса без ресурсов: русский для ru/uk/be/kk, иначе английский. */
fun tr(ru: String, en: String): String = if (Locale.getDefault().language in RU_LANGS) ru else en

private val NUM = Regex("[0-9]+(\\.[0-9]*)?(E[+\\-−]?[0-9]+)?")

/** Внутреннее представление → то, что видит пользователь: группы по три цифры, десятичный разделитель локали. */
fun disp(s: String): String {
    val dec = DecimalFormatSymbols.getInstance().decimalSeparator.toString()
    return NUM.replace(s.replace('-', '−')) { m ->
        val t = m.value
        val e = t.indexOf('E')
        val mant = if (e >= 0) t.substring(0, e) else t
        val ex = if (e >= 0) t.substring(e) else ""
        val dot = mant.indexOf('.')
        val ip = if (dot >= 0) mant.substring(0, dot) else mant
        val fp = if (dot >= 0) mant.substring(dot + 1) else null
        val g = ip.reversed().chunked(3).joinToString(" ").reversed()
        g + (if (fp != null) dec + fp else "") + ex
    }
}

object Engine {
    private const val OPS = "+−×÷^"

    /** Число → строка для выражения (точка, минус «−», 12 значащих цифр). */
    fun raw(v: Double): String {
        val x = if (abs(v) < 1e-12) 0.0 else v
        if (x == 0.0) return "0"
        val a = abs(x)
        val bd = BigDecimal(x).round(MathContext(12)).stripTrailingZeros()
        val s = if (a >= 1e15 || a < 1e-9) bd.toString().replace("E+", "E") else bd.toPlainString()
        return s.replace('-', '−')
    }

    /** Считает выражение; null — если оно неполное или некорректное (деление на ноль, ln(−1) и т.п.). */
    fun eval(src: String, deg: Boolean): Double? {
        var s = src
        while (true) {
            var u = s.trimEnd('+', '−', '×', '÷', '^')
            if (u.endsWith("(")) u = u.dropLast(1).trimEnd { it in 'a'..'z' || it == '√' }
            if (u == s) break
            s = u
        }
        if (s.isEmpty()) return null
        val open = s.count { it == '(' } - s.count { it == ')' }
        if (open > 0) s += ")".repeat(open)
        return try {
            val v = P(s, deg).parse()
            if (v.isNaN() || v.isInfinite()) null else v
        } catch (_: Exception) { null }
    }

    private class P(val s: String, val deg: Boolean) {
        var i = 0
        /** Если последний разобранный множитель был «N%», здесь лежит N (нужно для «100+10%» = 110). */
        var pct: Double? = null

        fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        fun fail(): Nothing = throw IllegalStateException("bad expression")

        fun parse(): Double {
            val v = expr()
            if (i != s.length) fail()
            return v
        }

        fun expr(): Double {
            var l = term()
            while (true) {
                val c = peek()
                if (c == '+' || c == '−') {
                    i++
                    val r = term()
                    val pr = pct
                    val rr = if (pr != null) l * pr / 100.0 else r
                    l = if (c == '+') l + rr else l - rr
                } else break
            }
            return l
        }

        fun term(): Double {
            var l = unary()
            var mul = false
            while (true) {
                val c = peek()
                if (c == '×') { i++; l *= unary(); mul = true }
                else if (c == '÷') { i++; l /= unary(); mul = true }
                // неявное умножение: 2π, 3(4+1), 2sin(30)
                else if (c == '(' || c == 'π' || c == '√' || c.isDigit() || c == '.' || c in 'a'..'z') { l *= unary(); mul = true }
                else break
            }
            if (mul) pct = null
            return l
        }

        fun unary(): Double {
            val c = peek()
            if (c == '−') { i++; return -unary() }
            if (c == '+') { i++; return unary() }
            return power()
        }

        fun power(): Double {
            val b = postfix()
            if (peek() == '^') {
                i++
                val e = unary()
                pct = null
                return b.pow(e)
            }
            return b
        }

        fun postfix(): Double {
            var v = primary()
            var rawPct: Double? = null
            while (peek() == '%') { i++; rawPct = v; v /= 100.0 }
            pct = rawPct
            return v
        }

        fun primary(): Double {
            val c = peek()
            when {
                c.isDigit() || c == '.' -> return number()
                c == '(' -> { i++; val v = expr(); if (peek() == ')') i++; return v }
                c == 'π' -> { i++; return Math.PI }
                c == 'e' -> { i++; return Math.E }
                c == '√' -> {
                    i++
                    val v = if (peek() == '(') { i++; val x = expr(); if (peek() == ')') i++; x } else unary()
                    if (v < 0) fail()
                    return sqrt(v)
                }
                c in 'a'..'z' -> {
                    val st = i
                    while (i < s.length && s[i] in 'a'..'z') i++
                    val name = s.substring(st, i)
                    if (peek() != '(') fail()
                    i++
                    val x = expr()
                    if (peek() == ')') i++
                    return fn(name, x)
                }
                else -> fail()
            }
        }

        fun number(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (i + 1 < s.length && s[i] == 'E' && (s[i + 1].isDigit() || s[i + 1] in "+-−")) {
                i++
                if (s[i] in "+-−") i++
                while (i < s.length && s[i].isDigit()) i++
            }
            return s.substring(st, i).replace('−', '-').toDouble()
        }

        fun clean(v: Double) = if (abs(v) < 1e-12) 0.0 else v

        fun fn(n: String, x: Double): Double {
            val a = if (deg) Math.toRadians(x) else x
            return when (n) {
                "sin" -> clean(sin(a))
                "cos" -> clean(cos(a))
                "tan" -> if (deg && (x - 90.0) % 180.0 == 0.0) Double.NaN else clean(tan(a))
                "ln" -> ln(x)
                "log" -> log10(x)
                else -> fail()
            }
        }
    }
}
