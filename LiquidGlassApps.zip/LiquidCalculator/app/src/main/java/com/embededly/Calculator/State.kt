package com.embededly.Calculator

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class Pal(val bg: Color, val fg: Color, val sub: Color, val key: Color, val accent: Color, val dark: Boolean)

val LocalPal = staticCompositionLocalOf<Pal> { error("no Pal") }

/** История и градусы/радианы хранятся в SharedPreferences. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("calc", Context.MODE_PRIVATE)
    var deg: Boolean
        get() = sp.getBoolean("deg", true)
        set(v) { sp.edit().putBoolean("deg", v).apply() }

    fun history(): List<Pair<String, String>> =
        (sp.getString("hist", "") ?: "").split('\n').filter { it.isNotBlank() }.mapNotNull {
            val p = it.split('\u0001'); if (p.size == 2) p[0] to p[1] else null
        }

    fun saveHistory(list: List<Pair<String, String>>) {
        sp.edit().putString("hist", list.take(60).joinToString("\n") { it.first + "\u0001" + it.second }).apply()
    }
}

/** Всё состояние калькулятора. Живёт в корне, поэтому не сбрасывается при переключении вкладок. */
class CalcState(private val store: Store) {
    var expr by mutableStateOf("")
    var sub by mutableStateOf("")          // выражение, которое было до «=»
    var done by mutableStateOf(false)      // только что нажали «=»
    var error by mutableStateOf(false)
    var deg by mutableStateOf(store.deg)
    var sci by mutableStateOf(false)
    val history = mutableStateListOf<Pair<String, String>>().also { it.addAll(store.history()) }

    private fun isOp(c: Char) = c in "+−×÷^"
    private val funcs = listOf("sin(", "cos(", "tan(", "ln(", "log(", "√(")

    private fun lastToken(): String {
        var i = expr.length
        while (i > 0 && (expr[i - 1].isDigit() || expr[i - 1] == '.')) i--
        return expr.substring(i)
    }

    /** Ввод, который начинает новое выражение (цифра, функция, константа) после «=» или ошибки. */
    private fun begin() {
        if (done || error) { expr = ""; sub = ""; done = false; error = false }
    }

    fun digit(d: Char) {
        begin()
        val tk = lastToken()
        if (tk.replace(".", "").length >= 15) return
        if (tk == "0") expr = expr.dropLast(1) + d else expr += d
    }

    fun dot() {
        begin()
        val tk = lastToken()
        if (tk.contains('.')) return
        expr += if (tk.isEmpty()) "0." else "."
    }

    fun op(c: Char) {
        if (error) { expr = ""; error = false }
        if (done) { done = false; sub = "" }
        if (expr.isEmpty()) { expr = if (c == '−') "−" else "0$c"; return }
        val l = expr.last()
        if (l == '(' && c != '−') return
        when {
            c == '−' && (l == '×' || l == '÷' || l == '^' || l == '(') -> expr += c
            isOp(l) -> {
                var e = expr
                while (e.isNotEmpty() && isOp(e.last())) e = e.dropLast(1)
                expr = if (e.isEmpty() || e.last() == '(') (if (c == '−') e + c else e) else e + c
            }
            else -> expr += c
        }
    }

    fun percent() {
        if (error) return
        if (done) { done = false; sub = "" }
        val l = expr.lastOrNull() ?: return
        if (l.isDigit() || l == ')' || l == '%' || l == 'π' || l == 'e') expr += "%"
    }

    fun func(token: String) { begin(); expr += token }
    fun constant(c: Char) { begin(); expr += c }
    fun open() { begin(); expr += "(" }

    fun close() {
        if (done || error) return
        val unclosed = expr.count { it == '(' } - expr.count { it == ')' }
        val l = expr.lastOrNull() ?: return
        if (unclosed > 0 && !isOp(l) && l != '(') expr += ")"
    }

    fun back() {
        if (done || error) { clear(); return }
        val f = funcs.firstOrNull { expr.endsWith(it) }
        expr = if (f != null) expr.dropLast(f.length) else expr.dropLast(1)
    }

    fun clear() { expr = ""; sub = ""; done = false; error = false }

    fun toggleDeg() { deg = !deg; store.deg = deg }

    fun evaluate() {
        if (expr.isEmpty() || done || error) return
        val v = Engine.eval(expr, deg)
        if (v == null) { sub = ""; error = true; done = true; return }
        val r = Engine.raw(v)
        if (r != expr) {
            history.add(0, expr to r)
            if (history.size > 60) history.removeAt(history.lastIndex)
            store.saveHistory(history)
        }
        sub = expr
        expr = r
        done = true
    }

    fun clearHistory() { history.clear(); store.saveHistory(history) }

    fun useResult(r: String) { clear(); expr = r }

    /** Предварительный результат под выражением (не показывается для простого числа и для хвоста из оператора). */
    fun preview(): String? {
        if (done || error || expr.isEmpty()) return null
        val l = expr.last()
        if (isOp(l) || l == '(') return null
        if (Regex("^−?[0-9.]*(E[+\\-−]?[0-9]+)?$").matches(expr)) return null
        val v = Engine.eval(expr, deg) ?: return null
        return Engine.raw(v)
    }
}

/** Состояние конвертера. */
class ConvState {
    var cat by mutableIntStateOf(0)
    var fromIdx by mutableIntStateOf(2)
    var toIdx by mutableIntStateOf(3)
    var text by mutableStateOf("0")

    fun setCategory(i: Int, cats: List<Cat>) {
        cat = i
        val n = cats[i].units.size
        fromIdx = if (n > 3) 2 else 0
        toIdx = if (n > 3) 3 else 1
        text = "0"
    }

    fun digit(d: Char) {
        val digits = text.count { it.isDigit() }
        if (digits >= 15) return
        text = if (text == "0") d.toString() else if (text == "-0") "-$d" else text + d
    }

    fun dot() { if (!text.contains('.')) text += "." }
    fun back() { text = text.dropLast(1).let { if (it.isEmpty() || it == "-") "0" else it } }
    fun clear() { text = "0" }
    fun sign() { text = if (text.startsWith("-")) text.drop(1) else if (text == "0") text else "-$text" }
}
