package com.embededly.Calculator

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Scale
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SquareFoot
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import java.text.DecimalFormatSymbols

@Composable
fun CalcApp() {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val st = remember { CalcState(Store(ctx.applicationContext)) }
    val cs = remember { ConvState() }
    val backdrop = rememberLayerBackdrop()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showHistory by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(pal.bg)) {
        // фон, который «видит» стекло: ровный, без цветных отсветов
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop).background(pal.bg))
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(tab) { if (it == 1 && tab == 1) cs.sel = -1; tab = it; showHistory = false }
            Box(Modifier.weight(1f)) {
                Crossfade(tab, label = "tab") { t ->
                    if (t == 0) CalculatorPage(st, backdrop, showHistory) { showHistory = false }
                    else ConverterPage(cs, backdrop)
                }
            }
        }
        GlassMenu(menuOpen, backdrop, { menuOpen = false },
            Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 61.dp, end = 12.dp),
            anchor = Alignment.TopEnd, riseDp = -51f, riseXDp = -3f, minDp = 40f, hideBehind = true) {
            GlassMenuItem(tr("История", "History")) { menuOpen = false; tab = 0; showHistory = !showHistory }
            GlassMenuItem(tr("Очистить историю", "Clear history")) { menuOpen = false; st.clearHistory() }
            GlassMenuItem(if (st.deg) tr("Радианы", "Radians") else tr("Градусы", "Degrees")) { menuOpen = false; st.toggleDeg() }
        }
        // кнопка «⋮» рисуется ПОСЛЕ меню: у неё свой стеклянный фон, и капля вылетает из-под неё
        MenuButton(backdrop, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 7.dp, end = 12.dp)) { menuOpen = !menuOpen }
    }
}

@Composable
private fun TopBar(tab: Int, onTab: (Int) -> Unit) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Spacer(Modifier.width(12.dp))
        listOf(tr("Калькулятор", "Calculator"), tr("Конвертер", "Converter")).forEachIndexed { i, name ->
            val c by animateColorAsState(if (tab == i) pal.fg else pal.sub, tween(200), label = "tabColor")
            Text(
                name, color = c, fontSize = 21.sp, maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
                    .clickable(remember { MutableInteractionSource() }, null) { onTab(i) }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }
    }
}

/** Круглая стеклянная кнопка «⋮» со своим фоном: меню вылетает из-под неё и втекает обратно под неё. */
@Composable
private fun MenuButton(backdrop: Backdrop, modifier: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.size(46.dp)
            .glass(backdrop, CircleShape, pal.key, 3f, 8f, 12f)
            .border(1.dp, Color.White.copy(alpha = if (pal.dark) .07f else .5f), CircleShape)
            .clip(CircleShape)
            .clickable(remember { MutableInteractionSource() }, null) { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Outlined.MoreVert, null, tint = pal.fg) }
}

/** Одна строка текста, прижатая вправо; если не влезает — прокручивается к концу. */
@Composable
private fun OneLine(text: String, sizeSp: Float, color: Color, weight: FontWeight = FontWeight.Light, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Text(
            text, color = color, fontSize = sizeSp.sp, fontWeight = weight, maxLines = 1, softWrap = false,
            modifier = Modifier.horizontalScroll(rememberScrollState(), reverseScrolling = true)
        )
    }
}

@Composable
private fun Display(st: CalcState, modifier: Modifier) {
    val pal = LocalPal.current
    val main = if (st.error) tr("Ошибка", "Error") else if (st.expr.isEmpty()) "0" else disp(st.expr)
    val target = when {
        main.length <= 6 -> 76f
        main.length <= 9 -> 62f
        main.length <= 12 -> 50f
        main.length <= 16 -> 40f
        else -> 32f
    }
    // при «=» шрифт меняется сразу (текст всё равно заменяется), иначе перерисовка текста на каждом кадре даёт рывки
    val size by animateFloatAsState(target, if (st.done) snap() else tween(200, easing = FastOutSlowInEasing), label = "mainSize")
    val above = if (st.done && !st.error && st.sub.isNotEmpty()) disp(st.sub) + " =" else ""
    val below = st.preview()?.let { "= " + disp(it) } ?: ""
    // Анимация создаётся вместе с новым значением done и сразу стартует с 0 — раньше один кадр показывал конечное состояние,
    // а потом оно сбрасывалось в 0 (отсюда мерцание). Плавная кривая без перелёта вместо пружины с отскоком (отсюда рывки).
    val prog = remember(st.done) { Animatable(if (st.done) 0f else 1f) }
    LaunchedEffect(prog) {
        if (prog.value < 1f) prog.animateTo(1f, tween(380, easing = CubicBezierEasing(.22f, 1f, .36f, 1f)))
    }
    // предпросмотр «= …» не исчезает рывком, а растворяется, пока выражение уезжает вверх
    val lastBelow = remember { arrayOf("") }
    if (below.isNotEmpty()) lastBelow[0] = below
    val belowText = if (below.isNotEmpty()) below else if (st.done && !st.error) lastBelow[0] else ""
    val belowAlpha = if (below.isNotEmpty()) 1f else (1f - prog.value * 3f).coerceIn(0f, 1f)
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        OneLine(above, 24f, pal.sub, FontWeight.Normal, Modifier.height(34.dp).graphicsLayer {
            val p = prog.value
            translationY = (1f - p) * 40.dp.toPx()
            alpha = p
        })
        OneLine(main, size, pal.fg, modifier = Modifier.graphicsLayer {
            val p = prog.value
            translationY = (1f - p) * 22.dp.toPx()
            alpha = (p * 2f).coerceIn(0f, 1f)
            val sc = .94f + .06f * p
            scaleX = sc; scaleY = sc
            transformOrigin = TransformOrigin(1f, .5f)
        })
        OneLine(belowText, 28f, pal.sub, FontWeight.Light, Modifier.height(40.dp).graphicsLayer { alpha = belowAlpha })
    }
}

@Composable
private fun HistoryPanel(st: CalcState, backdrop: Backdrop, onClose: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier.fillMaxSize().padding(16.dp)
            .glass(backdrop, shape, pal.key.copy(alpha = if (pal.dark) .72f else .82f), 10f, 10f, 16f)
            .border(1.dp, Color.White.copy(alpha = if (pal.dark) .08f else .5f), shape)
    ) {
        if (st.history.isEmpty()) {
            Text(tr("История пуста", "History is empty"), color = pal.sub, modifier = Modifier.align(Alignment.Center))
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(st.history.size) { idx ->
                    val (e, r) = st.history[idx]
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { st.useResult(r); onClose() }.padding(8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(disp(e) + " =", color = pal.sub, fontSize = 16.sp, maxLines = 1)
                        Text(disp(r), color = pal.fg, fontSize = 28.sp, fontWeight = FontWeight.Light, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun CalculatorPage(st: CalcState, backdrop: Backdrop, showHistory: Boolean, onCloseHistory: () -> Unit) {
    // любое нажатие на клавишу закрывает историю
    fun act(f: () -> Unit): () -> Unit = { if (showHistory) onCloseHistory(); f() }
    val dec = DecimalFormatSymbols.getInstance().decimalSeparator.toString()
    fun d(c: Char) = KeyDef(c.toString(), onTap = act { st.digit(c) })

    val main = listOf(
        listOf(
            KeyDef("AC", kind = Kind.OP, onTap = act { st.clear() }),
            KeyDef(icon = Icons.AutoMirrored.Outlined.Backspace, kind = Kind.OP, onLong = act { st.clear() }, onTap = act { st.back() }),
            KeyDef("%", kind = Kind.OP, onTap = act { st.percent() }),
            KeyDef("÷", kind = Kind.OP, onTap = act { st.op('÷') }),
        ),
        listOf(d('7'), d('8'), d('9'), KeyDef("×", kind = Kind.OP, onTap = act { st.op('×') })),
        listOf(d('4'), d('5'), d('6'), KeyDef("−", kind = Kind.OP, onTap = act { st.op('−') })),
        listOf(d('1'), d('2'), d('3'), KeyDef("+", kind = Kind.OP, onTap = act { st.op('+') })),
        listOf(
            KeyDef(icon = Icons.Outlined.Functions, kind = Kind.OP, onTap = { st.sci = !st.sci }),
            d('0'),
            KeyDef(dec, onTap = act { st.dot() }),
            KeyDef("=", kind = Kind.EQ, onTap = act { st.evaluate() }),
        ),
    )
    val sci = listOf(
        listOf(
            KeyDef(if (st.deg) "DEG" else "RAD", kind = Kind.FN, onTap = { st.toggleDeg() }),
            KeyDef("sin", kind = Kind.FN, onTap = act { st.func("sin(") }),
            KeyDef("cos", kind = Kind.FN, onTap = act { st.func("cos(") }),
            KeyDef("tan", kind = Kind.FN, onTap = act { st.func("tan(") }),
        ),
        listOf(
            KeyDef("ln", kind = Kind.FN, onTap = act { st.func("ln(") }),
            KeyDef("log", kind = Kind.FN, onTap = act { st.func("log(") }),
            KeyDef("π", kind = Kind.FN, onTap = act { st.constant('π') }),
            KeyDef("e", kind = Kind.FN, onTap = act { st.constant('e') }),
        ),
        listOf(
            KeyDef("√", kind = Kind.FN, onTap = act { st.func("√(") }),
            KeyDef("xʸ", kind = Kind.FN, onTap = act { st.op('^') }),
            KeyDef("(", kind = Kind.FN, onTap = act { st.open() }),
            KeyDef(")", kind = Kind.FN, onTap = act { st.close() }),
        ),
    )

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Display(st, Modifier.align(Alignment.BottomEnd).padding(horizontal = 28.dp, vertical = 8.dp))
            androidx.compose.animation.AnimatedVisibility(
                showHistory,
                enter = fadeIn(tween(200)) + scaleIn(tween(240), initialScale = .94f),
                exit = fadeOut(tween(160)) + scaleOut(tween(200), targetScale = .94f),
            ) { HistoryPanel(st, backdrop, onCloseHistory) }
        }
        AnimatedVisibility(st.sci, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Keypad(backdrop, sci, 46.dp, 8.dp, 22, Modifier.padding(bottom = 12.dp))
        }
        Keypad(backdrop, main, 70.dp, 12.dp, 34, Modifier.padding(bottom = 14.dp))
    }
}

@Composable
private fun ValueCard(backdrop: Backdrop, unitName: String, value: String, active: Boolean, onMenu: (Float) -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(30.dp)
    var top by remember { mutableStateOf(0f) }
    Box(
        Modifier.fillMaxWidth()
            .onGloballyPositioned { top = it.positionInRoot().y }
            .glass(backdrop, shape, pal.key, 3f, 8f, 12f)
            .border(1.dp, if (active) pal.accent.copy(alpha = .75f) else Color.White.copy(alpha = if (pal.dark) .07f else .5f), shape)
            .padding(horizontal = 22.dp, vertical = 14.dp)
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            Row(
                Modifier.align(Alignment.Start).clip(CircleShape)
                    .clickable(remember { MutableInteractionSource() }, null) { onMenu(top) }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(unitName, color = pal.accent, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Icon(Icons.Outlined.ArrowDropDown, null, tint = pal.accent)
            }
            OneLine(value, 44f, pal.fg)
        }
    }
}

private val catIcons: List<ImageVector> = listOf(
    Icons.Outlined.Straighten, Icons.Outlined.Scale, Icons.Outlined.Thermostat, Icons.Outlined.SquareFoot,
    Icons.Outlined.WaterDrop, Icons.Outlined.Speed, Icons.Outlined.Schedule, Icons.Outlined.Storage,
)

@Composable
private fun ConverterPage(cs: ConvState, backdrop: Backdrop) {
    val cats = remember { categories() }
    BackHandler(enabled = cs.sel >= 0) { cs.sel = -1 }
    AnimatedContent(
        cs.sel, label = "convNav",
        transitionSpec = {
            if (targetState >= 0)
                (fadeIn(tween(260)) + scaleIn(tween(320), initialScale = .9f)) togetherWith (fadeOut(tween(160)) + scaleOut(tween(260), targetScale = 1.06f))
            else
                (fadeIn(tween(260)) + scaleIn(tween(320), initialScale = 1.06f)) togetherWith (fadeOut(tween(160)) + scaleOut(tween(260), targetScale = .9f))
        }
    ) { sel ->
        if (sel < 0) ConverterGrid(cs, cats, backdrop) else ConverterDetail(cs, cats, backdrop)
    }
}

/** Сетка категорий: нажал плитку — открылся конвертер, «назад» возвращает сюда. */
@Composable
private fun ConverterGrid(cs: ConvState, cats: List<Cat>, backdrop: Backdrop) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(30.dp)
    LazyVerticalGrid(
        GridCells.Fixed(2), Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        gridItemsIndexed(cats) { i, c ->
            val src = remember { MutableInteractionSource() }
            Column(
                Modifier.fillMaxWidth().height(128.dp)
                    .glass(backdrop, shape, pal.key, 3f, 8f, 12f)
                    .border(1.dp, Color.White.copy(alpha = if (pal.dark) .07f else .5f), shape)
                    .clip(shape)
                    .clickable(src, null) { cs.setCategory(i, cats); cs.sel = i }
                    .padding(18.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Icon(catIcons[i % catIcons.size], null, tint = pal.accent, modifier = Modifier.size(34.dp))
                Text(c.name, color = pal.fg, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
        }
    }
}

@Composable
private fun ConverterDetail(cs: ConvState, cats: List<Cat>, backdrop: Backdrop) {
    val pal = LocalPal.current
    val cat = cats[cs.cat.coerceIn(0, cats.lastIndex)]
    val x = cs.text.toDoubleOrNull() ?: 0.0
    val outText = Engine.raw(cat.units[cs.toIdx].fromBase(cat.units[cs.fromIdx].toBase(x)))
    val dec = DecimalFormatSymbols.getInstance().decimalSeparator.toString()
    fun d(c: Char) = KeyDef(c.toString(), onTap = { cs.digit(c) })

    val rows = listOf(
        listOf(
            KeyDef("AC", kind = Kind.OP, onTap = { cs.clear() }),
            KeyDef(icon = Icons.AutoMirrored.Outlined.Backspace, kind = Kind.OP, onLong = { cs.clear() }, onTap = { cs.back() }),
            KeyDef(icon = Icons.Outlined.SwapHoriz, kind = Kind.OP, onTap = {
                val f = cs.fromIdx; cs.fromIdx = cs.toIdx; cs.toIdx = f
                cs.text = outText.replace('−', '-')
            }),
        ),
        listOf(d('7'), d('8'), d('9')),
        listOf(d('4'), d('5'), d('6')),
        listOf(d('1'), d('2'), d('3')),
        listOf(KeyDef("±", kind = Kind.OP, onTap = { cs.sign() }), d('0'), KeyDef(dec, onTap = { cs.dot() })),
    )

    var menuOpen by remember { mutableStateOf(false) }
    var which by remember { mutableIntStateOf(0) }
    var menuTop by remember { mutableStateOf(0f) }
    var originY by remember { mutableStateOf(0f) }
    var boxH by remember { mutableStateOf(0) }
    val density = LocalDensity.current

    Box(Modifier.fillMaxSize().onGloballyPositioned { originY = it.positionInRoot().y }.onSizeChanged { boxH = it.height }) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                BackButton(backdrop) { cs.sel = -1 }
                Spacer(Modifier.width(14.dp))
                Text(cat.name, color = pal.fg, fontSize = 24.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.Bottom)
            ) {
                ValueCard(backdrop, cat.units[cs.fromIdx].name, disp(cs.text), true) { which = 0; menuTop = it; menuOpen = true }
                ValueCard(backdrop, cat.units[cs.toIdx].name, disp(outText), false) { which = 1; menuTop = it; menuOpen = true }
            }
            Keypad(backdrop, rows, 66.dp, 12.dp, 34, Modifier.padding(bottom = 14.dp))
        }
        val estH = with(density) { (cat.units.size * 46 + 16).dp.toPx() }
        val y = (menuTop - originY).coerceIn(0f, (boxH - estH).coerceAtLeast(0f))
        GlassMenu(menuOpen, backdrop, { menuOpen = false },
            Modifier.align(Alignment.TopStart).padding(start = 32.dp).offset { IntOffset(0, y.roundToInt()) }) {
            cat.units.forEachIndexed { i, u ->
                val cur = if (which == 0) cs.fromIdx else cs.toIdx
                GlassMenuItem(u.name, i == cur) {
                    menuOpen = false
                    if (which == 0) cs.fromIdx = i else cs.toIdx = i
                }
            }
        }
    }
}

/** Круглая стеклянная кнопка «назад»: по ободу бегает блик от наклона телефона. */
@Composable
private fun BackButton(backdrop: Backdrop, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(48.dp)
            .glass(backdrop, CircleShape, pal.key, 3f, 8f, 12f)
            .border(1.dp, Color.White.copy(alpha = if (pal.dark) .07f else .5f), CircleShape)
            .clip(CircleShape)
            .clickable(remember { MutableInteractionSource() }, null) { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, null, tint = pal.fg) }
}
