package com.embededly.Calculator

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import java.text.DecimalFormatSymbols

@Composable
fun CalcApp() {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val st = remember { CalcState(Store(ctx.applicationContext)) }
    val cs = remember { ConvState() }
    val backdrop = rememberLayerBackdrop()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showHistory by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(pal.bg)) {
        // фон, который «видит» стекло: чёрный + мягкие цветные отсветы, чтобы преломление было заметно
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
            Box(Modifier.fillMaxSize().drawBehind {
                drawRect(pal.bg)
                drawRect(Brush.radialGradient(
                    listOf(pal.accent.copy(alpha = if (pal.dark) .22f else .20f), Color.Transparent),
                    center = Offset(size.width * .9f, size.height * .95f), radius = size.width * 1.1f))
                drawRect(Brush.radialGradient(
                    listOf(Color(0xFF3B82F6).copy(alpha = if (pal.dark) .12f else .10f), Color.Transparent),
                    center = Offset(0f, size.height * .55f), radius = size.width * .9f))
            })
        }
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(tab, { tab = it; showHistory = false }, st) { tab = 0; showHistory = !showHistory }
            Box(Modifier.weight(1f)) {
                Crossfade(tab, label = "tab") { t ->
                    if (t == 0) CalculatorPage(st, backdrop, showHistory) { showHistory = false }
                    else ConverterPage(cs, backdrop)
                }
            }
        }
    }
}

@Composable
private fun TopBar(tab: Int, onTab: (Int) -> Unit, st: CalcState, onHistory: () -> Unit) {
    val pal = LocalPal.current
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Spacer(Modifier.width(12.dp))
        listOf(tr("Калькулятор", "Calculator"), tr("Конвертер", "Converter")).forEachIndexed { i, name ->
            val c by animateColorAsState(if (tab == i) pal.fg else pal.sub, tween(200), label = "tabColor")
            Text(
                name, color = c, fontSize = 21.sp, maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
                    .clickable(remember { MutableInteractionSource() }, null) { onTab(i) }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }
        Spacer(Modifier.weight(1f))
        Box {
            IconButton({ menu = true }) { Icon(Icons.Outlined.MoreVert, null, tint = pal.fg) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text(tr("История", "History")) }, onClick = { menu = false; onHistory() })
                DropdownMenuItem(text = { Text(tr("Очистить историю", "Clear history")) }, onClick = { menu = false; st.clearHistory() })
                DropdownMenuItem(
                    text = { Text(if (st.deg) tr("Радианы", "Radians") else tr("Градусы", "Degrees")) },
                    onClick = { menu = false; st.toggleDeg() })
            }
        }
    }
}

/** Одна строка текста, прижатая вправо; если не влезает — прокручивается к концу. */
@Composable
private fun OneLine(text: String, sizeSp: Float, color: Color, weight: FontWeight = FontWeight.Light, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Text(
            text, color = color, fontSize = sizeSp.sp, fontWeight = weight, maxLines = 1, softWrap = false,
            modifier = Modifier.horizontalScroll(rememberScrollState(), reverseScrolling = true)
        )
    }
}

@Composable
private fun Display(st: CalcState, modifier: Modifier) {
    val pal = LocalPal.current
    val main = if (st.error) tr("Ошибка", "Error") else if (st.expr.isEmpty()) "0" else disp(st.expr)
    val target = when {
        main.length <= 6 -> 76f
        main.length <= 9 -> 62f
        main.length <= 12 -> 50f
        main.length <= 16 -> 40f
        else -> 32f
    }
    val size by animateFloatAsState(target, tween(180), label = "mainSize")
    val above = if (st.done && !st.error && st.sub.isNotEmpty()) disp(st.sub) + " =" else ""
    val below = st.preview()?.let { "= " + disp(it) } ?: ""
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        OneLine(above, 24f, pal.sub, FontWeight.Normal, Modifier.height(34.dp))
        OneLine(main, size, pal.fg)
        OneLine(below, 28f, pal.sub, FontWeight.Light, Modifier.height(40.dp))
    }
}

@Composable
private fun HistoryPanel(st: CalcState, backdrop: Backdrop, onClose: () -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier.fillMaxSize().padding(16.dp)
            .glass(backdrop, shape, pal.key.copy(alpha = if (pal.dark) .72f else .82f), 10f, 10f, 16f)
            .border(1.dp, Color.White.copy(alpha = if (pal.dark) .08f else .5f), shape)
    ) {
        if (st.history.isEmpty()) {
            Text(tr("История пуста", "History is empty"), color = pal.sub, modifier = Modifier.align(Alignment.Center))
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(st.history.size) { idx ->
                    val (e, r) = st.history[idx]
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .clickable { st.useResult(r); onClose() }.padding(8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(disp(e) + " =", color = pal.sub, fontSize = 16.sp, maxLines = 1)
                        Text(disp(r), color = pal.fg, fontSize = 28.sp, fontWeight = FontWeight.Light, maxLines = 1)
                    }
                }
            }
        }
    }
}

/** Вынесено в отдельную функцию: внутри Column неявный ColumnScope мешает выбрать обычный AnimatedVisibility. */
@Composable
private fun HistoryOverlay(show: Boolean, st: CalcState, backdrop: Backdrop, onClose: () -> Unit) {
    AnimatedVisibility(
        show,
        enter = fadeIn(tween(200)) + scaleIn(tween(240), initialScale = .94f),
        exit = fadeOut(tween(160)) + scaleOut(tween(200), targetScale = .94f),
    ) { HistoryPanel(st, backdrop, onClose) }
}

@Composable
private fun CalculatorPage(st: CalcState, backdrop: Backdrop, showHistory: Boolean, onCloseHistory: () -> Unit) {
    // любое нажатие на клавишу закрывает историю
    fun act(f: () -> Unit): () -> Unit = { if (showHistory) onCloseHistory(); f() }
    val dec = DecimalFormatSymbols.getInstance().decimalSeparator.toString()
    fun d(c: Char) = KeyDef(c.toString(), onTap = act { st.digit(c) })

    val main = listOf(
        listOf(
            KeyDef("AC", kind = Kind.OP, onTap = act { st.clear() }),
            KeyDef(icon = Icons.AutoMirrored.Outlined.Backspace, kind = Kind.OP, onLong = act { st.clear() }, onTap = act { st.back() }),
            KeyDef("%", kind = Kind.OP, onTap = act { st.percent() }),
            KeyDef("÷", kind = Kind.OP, onTap = act { st.op('÷') }),
        ),
        listOf(d('7'), d('8'), d('9'), KeyDef("×", kind = Kind.OP, onTap = act { st.op('×') })),
        listOf(d('4'), d('5'), d('6'), KeyDef("−", kind = Kind.OP, onTap = act { st.op('−') })),
        listOf(d('1'), d('2'), d('3'), KeyDef("+", kind = Kind.OP, onTap = act { st.op('+') })),
        listOf(
            KeyDef(icon = Icons.Outlined.Functions, kind = Kind.OP, onTap = { st.sci = !st.sci }),
            d('0'),
            KeyDef(dec, onTap = act { st.dot() }),
            KeyDef("=", kind = Kind.EQ, onTap = act { st.evaluate() }),
        ),
    )
    val sci = listOf(
        listOf(
            KeyDef(if (st.deg) "DEG" else "RAD", kind = Kind.FN, onTap = { st.toggleDeg() }),
            KeyDef("sin", kind = Kind.FN, onTap = act { st.func("sin(") }),
            KeyDef("cos", kind = Kind.FN, onTap = act { st.func("cos(") }),
            KeyDef("tan", kind = Kind.FN, onTap = act { st.func("tan(") }),
        ),
        listOf(
            KeyDef("ln", kind = Kind.FN, onTap = act { st.func("ln(") }),
            KeyDef("log", kind = Kind.FN, onTap = act { st.func("log(") }),
            KeyDef("π", kind = Kind.FN, onTap = act { st.constant('π') }),
            KeyDef("e", kind = Kind.FN, onTap = act { st.constant('e') }),
        ),
        listOf(
            KeyDef("√", kind = Kind.FN, onTap = act { st.func("√(") }),
            KeyDef("xʸ", kind = Kind.FN, onTap = act { st.op('^') }),
            KeyDef("(", kind = Kind.FN, onTap = act { st.open() }),
            KeyDef(")", kind = Kind.FN, onTap = act { st.close() }),
        ),
    )

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Display(st, Modifier.align(Alignment.BottomEnd).padding(horizontal = 28.dp, vertical = 8.dp))
            HistoryOverlay(showHistory, st, backdrop, onCloseHistory)
        }
        AnimatedVisibility(st.sci, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Keypad(backdrop, sci, 46.dp, 8.dp, 22, Modifier.padding(bottom = 12.dp))
        }
        Keypad(backdrop, main, 70.dp, 12.dp, 34, Modifier.padding(bottom = 14.dp))
    }
}

@Composable
private fun ValueCard(backdrop: Backdrop, units: List<CU>, idx: Int, value: String, active: Boolean, onUnit: (Int) -> Unit) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(30.dp)
    var menu by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxWidth()
            .glass(backdrop, shape, pal.key, 3f, 8f, 12f)
            .border(1.dp, if (active) pal.accent.copy(alpha = .75f) else Color.White.copy(alpha = if (pal.dark) .07f else .5f), shape)
            .padding(horizontal = 22.dp, vertical = 14.dp)
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            Box(Modifier.align(Alignment.Start)) {
                Row(
                    Modifier.clip(CircleShape).clickable(remember { MutableInteractionSource() }, null) { menu = true }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(units[idx].name, color = pal.accent, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    Icon(Icons.Outlined.ArrowDropDown, null, tint = pal.accent)
                }
                DropdownMenu(menu, { menu = false }) {
                    units.forEachIndexed { i, u -> DropdownMenuItem(text = { Text(u.name) }, onClick = { menu = false; onUnit(i) }) }
                }
            }
            OneLine(value, 44f, pal.fg)
        }
    }
}

@Composable
private fun ConverterPage(cs: ConvState, backdrop: Backdrop) {
    val pal = LocalPal.current
    val cats = remember { categories() }
    val cat = cats[cs.cat]
    val x = cs.text.toDoubleOrNull() ?: 0.0
    val outText = Engine.raw(cat.units[cs.toIdx].fromBase(cat.units[cs.fromIdx].toBase(x)))
    val dec = DecimalFormatSymbols.getInstance().decimalSeparator.toString()
    fun d(c: Char) = KeyDef(c.toString(), onTap = { cs.digit(c) })

    val rows = listOf(
        listOf(
            KeyDef("AC", kind = Kind.OP, onTap = { cs.clear() }),
            KeyDef(icon = Icons.AutoMirrored.Outlined.Backspace, kind = Kind.OP, onLong = { cs.clear() }, onTap = { cs.back() }),
            KeyDef(icon = Icons.Outlined.SwapHoriz, kind = Kind.OP, onTap = {
                val f = cs.fromIdx; cs.fromIdx = cs.toIdx; cs.toIdx = f
                cs.text = outText.replace('−', '-')
            }),
        ),
        listOf(d('7'), d('8'), d('9')),
        listOf(d('4'), d('5'), d('6')),
        listOf(d('1'), d('2'), d('3')),
        listOf(KeyDef("±", kind = Kind.OP, onTap = { cs.sign() }), d('0'), KeyDef(dec, onTap = { cs.dot() })),
    )

    Column(Modifier.fillMaxSize()) {
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(cats) { i, c ->
                val sel = i == cs.cat
                Box(
                    Modifier.clip(CircleShape).background(if (sel) pal.accent else pal.key)
                        .clickable(remember { MutableInteractionSource() }, null) { cs.setCategory(i, cats) }
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                ) { Text(c.name, color = if (sel) Color.White else pal.fg, fontSize = 15.sp, maxLines = 1) }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.Bottom)
        ) {
            ValueCard(backdrop, cat.units, cs.fromIdx, disp(cs.text), true) { cs.fromIdx = it }
            ValueCard(backdrop, cat.units, cs.toIdx, disp(outText), false) { cs.toIdx = it }
        }
        Keypad(backdrop, rows, 66.dp, 12.dp, 34, Modifier.padding(bottom = 14.dp))
    }
}
