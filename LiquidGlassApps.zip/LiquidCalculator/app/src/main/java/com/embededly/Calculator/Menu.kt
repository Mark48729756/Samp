package com.embededly.Calculator

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Размер меняется через layout, а не graphicsLayer-scale: иначе стекло считает координаты без учёта масштаба
 * и преломление «уезжает». ax/ay — разные пружины по ширине и высоте, поэтому капля чуть пружинит.
 */
private fun Modifier.dropSize(
    ax: () -> Float, ay: () -> Float, minDp: Float = 46f, anchor: Alignment = Alignment.Center,
): Modifier = this.layout { m, c ->
    val pl = m.measure(c)
    val mn = minDp.dp.toPx()
    val w = (mn + (pl.width - mn) * ax()).roundToInt().coerceAtLeast(1)
    val h = (mn + (pl.height - mn) * ay()).roundToInt().coerceAtLeast(1)
    layout(w, h) {
        val o = anchor.align(IntSize(pl.width, pl.height), IntSize(w, h), layoutDirection)
        pl.place(o.x, o.y)
    }
}

/** Стеклянное меню: выпадает каплей и схлопывается обратно. Ставится в Box, положение — через modifier. */
@Composable
fun GlassMenu(
    visible: Boolean, backdrop: Backdrop, onDismiss: () -> Unit, modifier: Modifier = Modifier,
    anchor: Alignment = Alignment.Center, riseDp: Float = 0f, riseXDp: Float = 0f, minDp: Float = 46f,
    hideBehind: Boolean = false, morph: MenuMorph? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val pal = LocalPal.current
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val gone = remember { Animatable(0f) }
    var shown by remember { mutableStateOf(false) }
    SideEffect { morph?.active = visible || shown }
    LaunchedEffect(Unit) { snapshotFlow { ay.value.coerceIn(0f, 1f) }.collect { morph?.p = it } }
    LaunchedEffect(visible) {
        if (visible) {
            gone.snapTo(0f)
            shown = true
            coroutineScope {
                launch { ax.animateTo(1f, spring(.5f, 380f)) }
                launch { ay.animateTo(1f, spring(.45f, 300f)) }
                launch { delay(70); fade.animateTo(1f, tween(160)) }
            }
        } else if (shown) {
            coroutineScope {
                launch { fade.animateTo(0f, tween(90)) }
                launch { ax.animateTo(0f, spring(.55f, 380f)) }
                launch { ay.animateTo(0f, spring(.5f, 330f)) }
            }
            if (!hideBehind) gone.animateTo(1f, tween(160, easing = FastOutSlowInEasing))
            shown = false
        }
    }
    if (visible) BackHandler(onBack = onDismiss)
    if (visible) Box(Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { onDismiss() })
    if (shown) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            modifier
                .graphicsLayer { alpha = 1f - gone.value }
                // сдвиг СВЁРНУТОЙ капли к кнопке: стоит до .glass, чтобы смещалось и стекло, и рамка
                .offset {
                    IntOffset(
                        ((1f - ax.value.coerceIn(0f, 1f)) * riseXDp.dp.toPx()).roundToInt(),
                        ((1f - ay.value.coerceIn(0f, 1f)) * riseDp.dp.toPx()).roundToInt(),
                    )
                }
                .glass(backdrop, shape, pal.key.copy(alpha = if (pal.dark) .72f else .8f), 12f, 8f, 14f)
                .border(1.dp, Color.White.copy(alpha = if (pal.dark) .08f else .5f), shape)
                .clip(shape)
                .dropSize({ ax.value }, { ay.value }, minDp = minDp, anchor = anchor)
        ) {
            Column(Modifier.width(220.dp).graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }.padding(vertical = 8.dp), content = content)
        }
    }
}

@Composable
fun GlassMenuItem(text: String, selected: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(
        text, color = if (selected) pal.accent else pal.fg, fontSize = 16.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp)
    )
}

/** Связь меню и его кнопки: пока меню открыто или схлопывается, стекло кнопки отдаёт меню (они совпадают по размеру и форме), p — прогресс раскрытия. */
class MenuMorph {
    var active by mutableStateOf(false)
    var p by mutableFloatStateOf(0f)
}

/** Круглая кнопка-«якорь» меню: своё стекло скрыто, пока его занимает меню; иконка плавно сменяется содержимым меню. */
@Composable
fun MorphAnchor(morph: MenuMorph, modifier: Modifier, glass: @Composable (Modifier) -> Unit, icon: @Composable () -> Unit, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Box(
        modifier.clip(androidx.compose.foundation.shape.CircleShape)
            .clickable(remember { MutableInteractionSource() }, null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        glass(Modifier.fillMaxSize().graphicsLayer { alpha = if (morph.active) 0f else 1f })
        androidx.compose.foundation.layout.Box(Modifier.graphicsLayer { alpha = if (morph.active) (1f - morph.p * 4f).coerceIn(0f, 1f) else 1f }) { icon() }
    }
}

