package com.embededly.Calculator

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.snapshotFlow
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Размер меняется через layout, а не graphicsLayer-scale: иначе стекло считает координаты без учёта масштаба
 * и преломление «уезжает». ax/ay — разные пружины по ширине и высоте, поэтому капля чуть пружинит.
 * minW/minH — размер свёрнутой капли (у выпадающего списка это размер капсулы-селектора, а не кружок).
 */
private fun Modifier.dropSize(
    ax: () -> Float, ay: () -> Float, minW: Float = 46f, minH: Float = 46f, anchor: Alignment = Alignment.Center,
): Modifier = this.layout { m, c ->
    val pl = m.measure(c)
    val mw = minOf(minW.dp.toPx(), pl.width.toFloat())
    val mh = minOf(minH.dp.toPx(), pl.height.toFloat())
    val w = (mw + (pl.width - mw) * ax()).roundToInt().coerceAtLeast(1)
    val h = (mh + (pl.height - mh) * ay()).roundToInt().coerceAtLeast(1)
    layout(w, h) {
        val o = anchor.align(IntSize(pl.width, pl.height), IntSize(w, h), layoutDirection)
        pl.place(o.x, o.y)
    }
}

/**
 * Стеклянное меню-капля. Кнопка/селектор, из которого оно вылетает, НЕ исчезает: капля отрывается от неё (сначала
 * прозрачная, прямо под кнопкой), вырастает в меню, а при закрытии втягивается обратно и «глотается» кнопкой — та на миг
 * набухает. Ставится в Box, положение — через modifier.
 *
 * minDp/minWDp — высота/ширина свёрнутой капли (= размер кнопки), riseDp/riseXDp — сдвиг свёрнутой капли к кнопке.
 */
@Composable
fun GlassMenu(
    visible: Boolean, backdrop: Backdrop, onDismiss: () -> Unit, modifier: Modifier = Modifier,
    anchor: Alignment = Alignment.Center, riseDp: Float = 0f, riseXDp: Float = 0f, minDp: Float = 46f,
    minWDp: Float = minDp, menuWidthDp: Float = 220f, maxHeightDp: Float = 4000f, morph: MenuMorph? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val pal = LocalPal.current
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val sep = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val pulse = remember { Animatable(0f) }
    var shown by remember { mutableStateOf(false) }
    morph?.active = visible || shown
    LaunchedEffect(Unit) { snapshotFlow { ay.value.coerceIn(0f, 1f) }.collect { morph?.p = it } }
    LaunchedEffect(Unit) { snapshotFlow { pulse.value }.collect { morph?.swell = it } }
    LaunchedEffect(visible) {
        if (visible) {
            shown = true
            coroutineScope {
                // капля сначала вытягивается из кнопки вниз/вверх узкой «сосулькой» (всё ещё держится за кнопку),
                // потом расширяется и только в конце отрывается от неё
                launch { ay.animateTo(1f, spring(.55f, 280f)) }
                launch { delay(90); ax.animateTo(1f, spring(.5f, 320f)) }
                launch { delay(120); sep.animateTo(1f, spring(.6f, 240f)) }
                launch { delay(190); fade.animateTo(1f, tween(160)) }
                launch { pulse.animateTo(0f, tween(120)) }
            }
        } else if (shown) {
            coroutineScope {
                launch { fade.animateTo(0f, tween(70)) }
                // сначала капля подтягивается обратно к кнопке и «прилипает» к ней, потом втягивается внутрь
                launch { sep.animateTo(0f, spring(.7f, 360f)) }
                launch { delay(70); ax.animateTo(0f, spring(.6f, 300f)) }
                launch { delay(110); ay.animateTo(0f, spring(.55f, 300f)) }
                launch {
                    snapshotFlow { ay.value }.first { it < .2f }
                    pulse.animateTo(1f, tween(120, easing = FastOutSlowInEasing))
                    pulse.animateTo(0f, spring(.45f, 320f))
                }
            }
            shown = false
        }
    }
    if (visible) BackHandler(onBack = onDismiss)
    if (visible) Box(Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { onDismiss() })
    if (shown) {
        val shape = RoundedCornerShape(26.dp)
        Column(
            modifier
                // у самой кнопки капля прозрачна (прячет ореол по краю), дальше полностью видна
                .graphicsLayer { alpha = (ay.value / .1f).coerceIn(0f, 1f) }
                // сдвиг СВЁРНУТОЙ капли к кнопке: стоит до .glass, чтобы смещалось и стекло, и рамка
                .offset {
                    IntOffset(
                        ((1f - sep.value) * riseXDp.dp.toPx()).roundToInt(),
                        ((1f - sep.value) * riseDp.dp.toPx()).roundToInt(),
                    )
                }
                .glass(backdrop, shape, pal.key.copy(alpha = if (pal.dark) .72f else .8f), 12f, 8f, 14f)
                .border(1.dp, Color.White.copy(alpha = if (pal.dark) .08f else .5f), shape)
                .clip(shape)
                .dropSize({ ax.value }, { ay.value }, minW = minWDp, minH = minDp, anchor = anchor)
        ) {
            Column(
                Modifier.width(menuWidthDp.dp).heightIn(max = maxHeightDp.dp)
                    .graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 8.dp),
                content = content
            )
        }
    }
}

@Composable
fun GlassMenuItem(text: String, selected: Boolean = false, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(
        text, color = if (selected) pal.accent else pal.fg, fontSize = 16.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp)
    )
}

/** Связь меню и его кнопки: active — меню открыто или схлопывается, p — прогресс раскрытия, swell — «глоток» кнопки при втягивании капли. */
class MenuMorph {
    var active by mutableStateOf(false)
    var p by mutableFloatStateOf(0f)
    var swell by mutableFloatStateOf(0f)
}

/** Круглая кнопка-«якорь» меню. Не исчезает никогда: при втягивании капли чуть набухает (через layout, чтобы преломление не «уезжало»). */
@Composable
fun MorphAnchor(morph: MenuMorph, modifier: Modifier, glass: @Composable (Modifier) -> Unit, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Box(
        modifier.clickable(remember { MutableInteractionSource() }, null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.fillMaxSize().layout { m, c ->
                val k = 1f + .12f * morph.swell
                val w = (c.maxWidth * k).roundToInt()
                val h = (c.maxHeight * k).roundToInt()
                val pl = m.measure(Constraints.fixed(w, h))
                layout(c.maxWidth, c.maxHeight) { pl.place((c.maxWidth - w) / 2, (c.maxHeight - h) / 2) }
            },
            contentAlignment = Alignment.Center
        ) {
            glass(Modifier.fillMaxSize())
            icon()
        }
    }
}
