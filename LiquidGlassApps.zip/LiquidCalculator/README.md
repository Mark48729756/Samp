# Калькулятор (com.embededly.Calculator)

Нативный калькулятор + конвертер на Kotlin + Jetpack Compose с liquid glass (Kyant0/AndroidLiquidGlass).
Сборка как у галереи: залей папку в GitHub → Actions → Build APK → Releases → Calculator.apk.
Приложение заявляет категорию APP_CALCULATOR, поэтому подходит для предустановки в ОС.
