package com.embededly.Recorder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput

class MainActivity : ComponentActivity() {
    override fun onResume() { super.onResume(); Tilt.start(this) }
    override fun onPause() { Tilt.stop(); super.onPause() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            val accent = Color(0xFFFF184E) // цвет красной точки с иконки
            val pal = if (dark) Pal(
                bg = Color.Black, fg = Color.White, sub = Color(0xFF8E8E93),
                key = Color(0xFF2A2A2C).copy(alpha = .80f), accent = accent, dark = true
            ) else Pal(
                bg = Color(0xFFF2F2F7), fg = Color.Black, sub = Color(0xFF6C6C70),
                key = Color.White.copy(alpha = .78f), accent = accent, dark = false
            )
            val touch = remember { mutableStateOf(Offset.Unspecified) }
            // Material здесь нет вообще: ни MaterialTheme, ни material3-компонентов
            CompositionLocalProvider(
                LocalPal provides pal, LocalTouch provides touch,
                androidx.compose.foundation.LocalOverscrollFactory provides null
            ) {
                // запоминаем точку касания (ничего не перехватывая): из неё «вываливаются» окна
                Box(Modifier.fillMaxSize().pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val c = awaitPointerEvent(PointerEventPass.Initial).changes.firstOrNull()
                            if (c != null && c.pressed && !c.previousPressed) touch.value = c.position
                        }
                    }
                }) { RecorderApp() }
            }
        }
    }
}
