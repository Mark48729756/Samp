package com.embededly.Recorder

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Свои иконки в духе SF Symbols: круглые концы, ровная толщина линий. Рисуются кодом — ни Material Icons, ни векторных ресурсов. */
enum class Glyph { Dots, Trash, Share, Pencil, Play, Pause, Skip15Back, Skip15Fwd, Wave, Mic, Check, Scissors }

@Composable
fun AppleGlyph(g: Glyph, tint: Color, modifier: Modifier = Modifier, size: Dp = 26.dp) {
    if (g == Glyph.Skip15Back || g == Glyph.Skip15Fwd) {
        Box(modifier.size(size), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(size)) {
                val s = this.size.minDimension
                val sw = s * .075f
                val fwd = g == Glyph.Skip15Fwd
                val r = s * .36f
                val c = Offset(s * .5f, s * .56f)
                // дуга почти в полный круг с разрывом сверху; стрелка на конце по касательной
                // назад (против часовой): от верхнего левого края разрыва до верхнего правого; вперёд (по часовой) — наоборот
                val start = if (fwd) -62f else -118f
                val sweep = if (fwd) 304f else -304f
                drawArc(tint, start, sweep, false, Offset(c.x - r, c.y - r), Size(r * 2, r * 2), style = Stroke(sw, cap = StrokeCap.Round))
                val endDeg = Math.toRadians((start + sweep).toDouble())
                val ex = c.x + r * kotlin.math.cos(endDeg).toFloat()
                val ey = c.y + r * kotlin.math.sin(endDeg).toFloat()
                val dir = if (fwd) 1f else -1f
                val tx = dir * -kotlin.math.sin(endDeg).toFloat()
                val ty = dir * kotlin.math.cos(endDeg).toFloat()
                val len = r * .62f
                val head = Path()
                for (k in listOf(-1f, 1f)) {
                    val ang = Math.toRadians(34.0 * k)
                    val bx = -(tx * kotlin.math.cos(ang) - ty * kotlin.math.sin(ang)).toFloat()
                    val by = -(tx * kotlin.math.sin(ang) + ty * kotlin.math.cos(ang)).toFloat()
                    head.moveTo(ex, ey); head.lineTo(ex + bx * len, ey + by * len)
                }
                drawPath(head, tint, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            GText("15", color = tint, fontSize = (size.value * .30f).sp, fontWeight = FontWeight.SemiBold, modifier = Modifier)
        }
        return
    }
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        fun o(x: Float, y: Float) = Offset(x * s, y * s)
        val sw = s * .08f
        when (g) {
            Glyph.Dots -> {
                for (y in listOf(.2f, .5f, .8f)) drawCircle(tint, s * .065f, o(.5f, y))
            }
            Glyph.Trash -> {
                drawLine(tint, o(.17f, .25f), o(.83f, .25f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, o(.38f, .25f), o(.38f, .15f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, o(.62f, .25f), o(.62f, .15f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, o(.38f, .15f), o(.62f, .15f), strokeWidth = sw, cap = StrokeCap.Round)
                val p = Path().apply {
                    moveTo(s * .25f, s * .25f); lineTo(s * .29f, s * .80f)
                    quadraticTo(s * .295f, s * .88f, s * .37f, s * .88f); lineTo(s * .63f, s * .88f)
                    quadraticTo(s * .705f, s * .88f, s * .71f, s * .80f); lineTo(s * .75f, s * .25f)
                }
                drawPath(p, tint, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawLine(tint, o(.43f, .42f), o(.44f, .72f), strokeWidth = sw * .8f, cap = StrokeCap.Round)
                drawLine(tint, o(.57f, .42f), o(.56f, .72f), strokeWidth = sw * .8f, cap = StrokeCap.Round)
            }
            Glyph.Share -> {
                // square.and.arrow.up
                val p = Path().apply {
                    moveTo(s * .36f, s * .40f); lineTo(s * .30f, s * .40f)
                    quadraticTo(s * .20f, s * .40f, s * .20f, s * .50f); lineTo(s * .20f, s * .80f)
                    quadraticTo(s * .20f, s * .90f, s * .30f, s * .90f); lineTo(s * .70f, s * .90f)
                    quadraticTo(s * .80f, s * .90f, s * .80f, s * .80f); lineTo(s * .80f, s * .50f)
                    quadraticTo(s * .80f, s * .40f, s * .70f, s * .40f); lineTo(s * .64f, s * .40f)
                }
                drawPath(p, tint, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawLine(tint, o(.5f, .10f), o(.5f, .62f), strokeWidth = sw, cap = StrokeCap.Round)
                val a = Path().apply { moveTo(s * .36f, s * .24f); lineTo(s * .5f, s * .10f); lineTo(s * .64f, s * .24f) }
                drawPath(a, tint, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            Glyph.Pencil -> {
                val p = Path().apply {
                    moveTo(s * .20f, s * .80f); lineTo(s * .26f, s * .60f); lineTo(s * .62f, s * .24f)
                    lineTo(s * .76f, s * .38f); lineTo(s * .40f, s * .74f); close()
                }
                drawPath(p, tint, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawLine(tint, o(.55f, .31f), o(.69f, .45f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, o(.18f, .90f), o(.84f, .90f), strokeWidth = sw, cap = StrokeCap.Round)
            }
            Glyph.Play -> {
                val p = Path().apply {
                    moveTo(s * .30f, s * .20f); lineTo(s * .80f, s * .5f); lineTo(s * .30f, s * .80f); close()
                }
                drawPath(p, tint)
                drawPath(p, tint, style = Stroke(s * .12f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            Glyph.Pause -> {
                val w = s * .17f
                drawRoundRect(tint, o(.24f, .18f), Size(w, s * .64f), CornerRadius(w * .4f))
                drawRoundRect(tint, o(.59f, .18f), Size(w, s * .64f), CornerRadius(w * .4f))
            }
            Glyph.Wave -> {
                val w = s * .075f
                val hs = listOf(.20f, .42f, .66f, .90f, .52f, .30f, .16f)
                hs.forEachIndexed { i, h ->
                    val x = s * (.10f + i * .13f)
                    drawLine(tint, Offset(x, s * (.5f - h / 2f)), Offset(x, s * (.5f + h / 2f)), strokeWidth = w, cap = StrokeCap.Round)
                }
            }
            Glyph.Mic -> {
                drawRoundRect(tint, o(.36f, .08f), Size(s * .28f, s * .52f), CornerRadius(s * .14f), style = Stroke(sw))
                drawArc(tint, 0f, 180f, false, o(.22f, .30f), Size(s * .56f, s * .42f), style = Stroke(sw, cap = StrokeCap.Round))
                drawLine(tint, o(.5f, .72f), o(.5f, .90f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, o(.36f, .90f), o(.64f, .90f), strokeWidth = sw, cap = StrokeCap.Round)
            }
            Glyph.Check -> {
                val p = Path().apply { moveTo(s * .20f, s * .54f); lineTo(s * .42f, s * .74f); lineTo(s * .82f, s * .26f) }
                drawPath(p, tint, style = Stroke(sw * 1.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            Glyph.Scissors -> {
                drawCircle(tint, s * .12f, o(.25f, .27f), style = Stroke(sw))
                drawCircle(tint, s * .12f, o(.25f, .73f), style = Stroke(sw))
                drawLine(tint, o(.34f, .34f), o(.88f, .76f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, o(.34f, .66f), o(.88f, .24f), strokeWidth = sw, cap = StrokeCap.Round)
            }
            else -> {}
        }
    }
}
