package com.embededly.Recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.pow
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.audiofx.AudioEffect
import android.media.audiofx.NoiseSuppressor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sign
import kotlin.math.sqrt
import kotlin.math.tanh

/** Записи лежат в общей медиатеке: Recordings/ (Android 12+) или Music/ (Android 10–11). Свои файлы читать/менять можно без разрешений. */
object Library {
    private val coll: Uri get() = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    private const val FOLDER = "Liquid Recorder"
    private val relPath: String get() = (if (Build.VERSION.SDK_INT >= 31) "Recordings/" else "Music/") + FOLDER + "/"

    fun load(ctx: Context, store: Store): List<Clip> {
        val out = ArrayList<Clip>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.SIZE,
        )
        try {
            ctx.contentResolver.query(
                coll, proj, "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?", arrayOf("%$FOLDER%"),
                "${MediaStore.Audio.Media.DATE_ADDED} DESC, ${MediaStore.Audio.Media._ID} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val file = c.getString(1) ?: continue
                    val own = store.dur(id)
                    val dur = if (own >= 0) own else (if (c.isNull(2)) 0L else c.getLong(2))
                    out.add(Clip(id, ContentUris.withAppendedId(coll, id), file.substringBeforeLast('.'), dur, c.getLong(3) * 1000L, c.getLong(4)))
                }
            }
        } catch (_: Exception) { }
        return out
    }

    fun create(ctx: Context, base: String): Pair<Uri, ParcelFileDescriptor>? {
        val v = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "$base.m4a")
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, relPath)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(coll, v) ?: return null
        val pfd = try { ctx.contentResolver.openFileDescriptor(uri, "rw") } catch (_: Exception) { null }
        if (pfd == null) { try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) { }; return null }
        return uri to pfd
    }

    fun publish(ctx: Context, uri: Uri) {
        val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
        try { ctx.contentResolver.update(uri, v, null, null) } catch (_: Exception) { }
    }

    fun rename(ctx: Context, c: Clip, newName: String): Boolean {
        val clean = newName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { return false }
        val v = ContentValues().apply { put(MediaStore.Audio.Media.DISPLAY_NAME, "$clean.m4a") }
        return try { ctx.contentResolver.update(c.uri, v, null, null) > 0 } catch (_: Exception) { false }
    }

    fun delete(ctx: Context, uri: Uri) {
        try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) { }
    }
}

enum class Phase { Idle, Recording, Paused }

/**
 * Движок записи. Живёт в процессе (а не в Activity): запись продолжается при выключенном экране благодаря RecService.
 * Звук идёт AudioRecord → своя обработка (Dsp: фильтр, шумоподавление, усиление голоса) → AAC-кодек → MP4 (M4A).
 */
object Rec {
    var phase by mutableStateOf(Phase.Idle); private set
    var elapsed by mutableLongStateOf(0L); private set
    /** Последние уровни громкости 0..1 для живой волны (новые — справа). */
    var live by mutableStateOf(FloatArray(0)); private set
    /** Увеличивается при каждой сохранённой записи — по нему список перезагружается. */
    var savedTick by mutableLongStateOf(0L); private set
    var lastSavedId by mutableLongStateOf(-1L); private set

    private const val LIVE_N = 52
    private const val SR = 44100
    private const val BLOCK = 256
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ticker: Job? = null
    private var worker: Worker? = null
    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    @Volatile private var level = 0f
    @Volatile private var paused = false
    @Volatile private var stopFlag = false
    @Volatile private var failed = false
    @Volatile private var written = 0L
    private var smooth = 0f
    private val samples = ArrayList<Float>()
    private var samplesCopy: List<Float> = emptyList()

    fun start(ctx: Context, store: Store): Boolean {
        if (phase != Phase.Idle) return true
        Play.stop()
        val app = ctx.applicationContext
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return false
        val ar = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 2, 16384))
        } catch (_: Exception) { return false }
        if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); return false }
        val made = Library.create(app, defaultName())
        if (made == null) { ar.release(); return false }
        val effects = ArrayList<AudioEffect>()
        if (store.ns > 0) {
            try {
                if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(ar.audioSessionId)?.let { it.enabled = true; effects.add(it) }
            } catch (_: Exception) { }
        }
        var codec: MediaCodec? = null
        var mux: MediaMuxer? = null
        try {
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, if (store.hq) 160_000 else 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            mux = MediaMuxer(made.second.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            ar.startRecording()
            if (ar.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("mic busy")
        } catch (_: Exception) {
            try { codec?.release() } catch (_: Exception) { }
            try { mux?.release() } catch (_: Exception) { }
            effects.forEach { try { it.release() } catch (_: Exception) { } }
            try { ar.release() } catch (_: Exception) { }
            try { made.second.close() } catch (_: Exception) { }
            Library.delete(app, made.first)
            return false
        }
        uri = made.first; pfd = made.second
        paused = false; stopFlag = false; failed = false; written = 0L; level = 0f; smooth = 0f
        samples.clear(); live = FloatArray(0); elapsed = 0L
        val w = Worker(ar, codec!!, mux!!, effects, Dsp(store.gain, store.ns))
        worker = w
        phase = Phase.Recording
        w.start()
        try { app.startForegroundService(Intent(app, RecService::class.java)) } catch (_: Exception) { }
        ticker = scope.launch {
            while (true) {
                delay(50)
                if (worker == null) break
                elapsed = written * 1000L / SR
                if (phase == Phase.Recording) {
                    val lv = level
                    level = 0f
                    val target = lv.coerceIn(0f, 1f).pow(.5f)
                    smooth += (target - smooth) * (if (target > smooth) .75f else .35f)
                    samples.add(smooth)
                    val from = (samples.size - LIVE_N).coerceAtLeast(0)
                    live = FloatArray(samples.size - from) { samples[from + it] }
                }
            }
        }
        return true
    }

    fun togglePause() {
        if (worker == null) return
        if (phase == Phase.Recording) { paused = true; phase = Phase.Paused }
        else if (phase == Phase.Paused) { paused = false; phase = Phase.Recording }
    }

    /** Останавливает запись и сохраняет её. Слишком короткая запись удаляется. */
    fun stop(ctx: Context, store: Store) {
        val w = worker ?: return
        val app = ctx.applicationContext
        stopFlag = true
        try { w.join(4000) } catch (_: Exception) { }
        val dur = written * 1000L / SR
        ticker?.cancel(); ticker = null
        val u = uri
        val ok = !failed
        try { pfd?.close() } catch (_: Exception) { }
        reset(app)
        if (u == null) return
        if (!ok || dur < 400) { Library.delete(app, u); return }
        Library.publish(app, u)
        val id = ContentUris.parseId(u)
        store.saveMeta(id, dur, downsample(samplesCopy, 64))
        lastSavedId = id
        savedTick++
    }

    fun discard(ctx: Context) {
        val w = worker ?: return
        val app = ctx.applicationContext
        stopFlag = true
        try { w.join(4000) } catch (_: Exception) { }
        ticker?.cancel(); ticker = null
        try { pfd?.close() } catch (_: Exception) { }
        val u = uri
        reset(app)
        if (u != null) Library.delete(app, u)
    }

    private fun reset(app: Context) {
        samplesCopy = ArrayList(samples)
        worker = null; uri = null; pfd = null
        phase = Phase.Idle; elapsed = 0L; live = FloatArray(0)
        samples.clear()
        try { app.stopService(Intent(app, RecService::class.java)) } catch (_: Exception) { }
    }

    /** Сжимает историю громкости в n столбиков (максимум в каждом окне), 6..100. */
    fun downsample(src: List<Float>, n: Int): IntArray {
        if (src.isEmpty()) return IntArray(n) { 6 }
        return IntArray(n) { i ->
            val a = (i * src.size / n).coerceAtMost(src.size - 1)
            val b = ((i + 1) * src.size / n).coerceIn(a + 1, src.size)
            var m = 0f
            for (k in a until b) if (src[k] > m) m = src[k]
            (m * 100f).toInt().coerceIn(6, 100)
        }
    }

    /** Поток записи: читает микрофон, обрабатывает, кодирует в AAC и пишет в MP4. */
    private class Worker(
        val ar: AudioRecord, val codec: MediaCodec, val mux: MediaMuxer,
        val effects: List<AudioEffect>, val dsp: Dsp,
    ) : Thread("rec-worker") {
        private var track = -1
        private var started = false
        private val info = MediaCodec.BufferInfo()

        override fun run() {
            val buf = ShortArray(1024)
            var total = 0L
            try {
                while (!stopFlag) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n < 0) { failed = true; break }
                    if (n == 0) continue
                    dsp.process(buf, n)
                    if (dsp.peak > level) level = dsp.peak
                    dsp.peak = 0f
                    if (paused) continue
                    val idx = codec.dequeueInputBuffer(20_000)
                    if (idx >= 0) {
                        val ib = codec.getInputBuffer(idx)
                        if (ib != null) {
                            ib.clear()
                            ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(buf, 0, n)
                            codec.queueInputBuffer(idx, 0, n * 2, total * 1_000_000L / SR, 0)
                            total += n
                            written = total
                        }
                    }
                    drain(false)
                }
            } catch (_: Exception) { failed = true }
            try { ar.stop() } catch (_: Exception) { }
            try {
                var idx = codec.dequeueInputBuffer(50_000)
                if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, total * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                drain(true)
            } catch (_: Exception) { failed = true }
            try { codec.stop() } catch (_: Exception) { }
            try { codec.release() } catch (_: Exception) { }
            try { if (started) mux.stop() else failed = true } catch (_: Exception) { failed = true }
            try { mux.release() } catch (_: Exception) { }
            effects.forEach { try { it.release() } catch (_: Exception) { } }
            try { ar.release() } catch (_: Exception) { }
        }

        private fun drain(eos: Boolean) {
            var tries = 0
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (!started) { track = mux.addTrack(codec.outputFormat); mux.start(); started = true }
                    }
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!eos || ++tries > 60) return
                    }
                    i >= 0 -> {
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        val ob = codec.getOutputBuffer(i)
                        if (ob != null && info.size > 0 && started) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            mux.writeSampleData(track, ob, info)
                        }
                        codec.releaseOutputBuffer(i, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }
        }
    }

    /**
     * Обработка голоса, блоками по 256 отсчётов: ВЧ-фильтр (убирает гул и постоянную составляющую) → оценка уровня шума →
     * шумовой гейт с плавным открытием/закрытием → усиление (фиксированное +6/+12/+18 дБ или авто-АРУ) → мягкий лимитер без клиппинга.
     * Шум не усиливается: авто-усиление подстраивается только по речи, а гейт приглушает паузы.
     */
    private class Dsp(private val gainMode: Int, private val nsMode: Int) {
        private val hpA = 0.9873f // ~90 Гц при 44,1 кГц
        private var hpX = 0f
        private var hpY = 0f
        private var floor = 0.004f
        private var gate = 1f
        private var hold = 0
        private var agc = 2f
        private var prevG = 1f
        private val fixed = when (gainMode) { 1 -> 2f; 2 -> 4f; 3 -> 8f; else -> 1f }
        private val tmp = FloatArray(BLOCK)
        @Volatile var peak = 0f

        fun process(b: ShortArray, n: Int) {
            var s = 0
            while (s < n) {
                val len = minOf(BLOCK, n - s)
                var sum = 0f
                for (i in 0 until len) {
                    val x = b[s + i] / 32768f
                    val y = hpA * (hpY + x - hpX)
                    hpX = x; hpY = y
                    tmp[i] = y
                    sum += y * y
                }
                val rms = sqrt(sum / len)
                // уровень шума: быстро падает вслед за тишиной, медленно растёт (и не выше потолка — иначе гейт «съел» бы долгую речь)
                floor += if (rms < floor) (rms - floor) * .1f else (rms - floor) * .0003f
                floor = floor.coerceIn(.0006f, .02f)
                if (nsMode > 0) {
                    val k = if (nsMode == 1) 1.8f else 2.6f
                    val att = if (nsMode == 1) .30f else .08f // макс. ослабление: ~-10 дБ / ~-22 дБ
                    val ratio = (rms / (floor * k)).coerceIn(0f, 1f)
                    val target = att + (1f - att) * ratio * ratio
                    if (target > gate) { gate += (target - gate) * .6f; hold = 10 }
                    else if (hold > 0) hold--
                    else gate += (target - gate) * .05f
                } else gate = 1f
                var gain = fixed
                if (gainMode >= 4) {
                    if (rms > floor * 2.2f) {
                        val want = (.14f / rms).coerceIn(1f, 20f)
                        agc += (want - agc) * (if (want < agc) .15f else .015f)
                    } else agc += (2f - agc) * .002f
                    gain = agc
                }
                val g = gate * gain
                for (i in 0 until len) {
                    val gi = prevG + (g - prevG) * ((i + 1f) / len)
                    var y = tmp[i] * gi
                    val a = abs(y)
                    if (a > .7f) y = sign(y) * (.7f + .3f * tanh((a - .7f) / .3f))
                    b[s + i] = (y * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                    val aa = minOf(abs(y), 1f)
                    if (aa > peak) peak = aa
                }
                prevG = g
                s += len
            }
        }
    }
}

/** Обрезка без перекодирования: берутся готовые AAC-кадры из выбранного отрезка и пишутся в новый файл. */
object Trim {
    fun cut(ctx: Context, src: Clip, startMs: Long, endMs: Long, store: Store): Boolean {
        val app = ctx.applicationContext
        val made = Library.create(app, src.name + tr(" (обрезано)", " (trimmed)")) ?: return false
        val ex = MediaExtractor()
        var ok = false
        try {
            ex.setDataSource(app, src.uri, null)
            var ti = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { ti = i; break }
            }
            if (ti < 0) throw IllegalStateException("no audio")
            ex.selectTrack(ti)
            val mux = MediaMuxer(made.second.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val out = mux.addTrack(ex.getTrackFormat(ti))
            mux.start()
            ex.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocate(1 shl 18)
            val info = MediaCodec.BufferInfo()
            var first = -1L
            var count = 0
            while (true) {
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t > endMs * 1000L) break
                if (first < 0) first = t
                info.set(0, size, t - first, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                mux.writeSampleData(out, buf, info)
                count++
                ex.advance()
            }
            mux.stop(); mux.release()
            ok = count > 0
        } catch (_: Exception) {
            ok = false
        } finally {
            try { ex.release() } catch (_: Exception) { }
            try { made.second.close() } catch (_: Exception) { }
        }
        if (!ok) { Library.delete(app, made.first); return false }
        Library.publish(app, made.first)
        val id = ContentUris.parseId(made.first)
        val old = store.peaks(src.id)
        val dur = (endMs - startMs).coerceAtLeast(0L)
        val peaks = if (old == null || src.durationMs <= 0) IntArray(64) { 30 } else IntArray(64) { i ->
            val t = startMs + dur * i / 64
            old[((t * old.size) / src.durationMs).toInt().coerceIn(0, old.size - 1)]
        }
        store.saveMeta(id, dur, peaks)
        return true
    }
}

/** Плеер: одна запись «выбрана» (раскрыта) — она подготовлена и ждёт; играет не больше одной. */
object Play {
    var id by mutableLongStateOf(-1L); private set
    var playing by mutableStateOf(false); private set
    var pos by mutableLongStateOf(0L); private set
    var dur by mutableLongStateOf(0L); private set
    private var mp: MediaPlayer? = null

    fun select(ctx: Context, c: Clip) {
        if (id == c.id && mp != null) return
        stop()
        val p = MediaPlayer()
        try {
            p.setDataSource(ctx.applicationContext, c.uri)
            p.prepare()
        } catch (_: Exception) { try { p.release() } catch (_: Exception) { }; return }
        p.setOnCompletionListener { playing = false; pos = dur }
        mp = p; id = c.id; dur = p.duration.toLong().coerceAtLeast(c.durationMs); pos = 0L; playing = false
    }

    fun toggle() {
        val p = mp ?: return
        try {
            if (playing) { p.pause(); playing = false }
            else {
                if (pos >= dur - 80) { p.seekTo(0); pos = 0 }
                p.start(); playing = true
            }
        } catch (_: Exception) { playing = false }
    }

    fun seekTo(ms: Long) {
        val p = mp ?: return
        val t = ms.coerceIn(0L, dur)
        try { p.seekTo(t.toInt()) } catch (_: Exception) { }
        pos = t
    }

    fun skip(deltaMs: Long) = seekTo(pos + deltaMs)

    fun tick() {
        val p = mp ?: return
        if (playing) pos = try { p.currentPosition.toLong() } catch (_: Exception) { pos }
    }

    fun stop() {
        try { mp?.release() } catch (_: Exception) { }
        mp = null; id = -1L; playing = false; pos = 0L; dur = 0L
    }
}

/** Foreground-сервис с типом «микрофон»: без него Android прекратит запись, когда экран погаснет. */
class RecService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("rec", getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "rec")
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle(getString(R.string.notif_title))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(7, n)
        } catch (_: Exception) { }
        return START_NOT_STICKY
    }
}
