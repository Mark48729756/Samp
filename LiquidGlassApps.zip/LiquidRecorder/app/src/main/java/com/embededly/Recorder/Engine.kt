package com.embededly.Recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.pow
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.audiofx.AudioEffect
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sign
import kotlin.math.sqrt
import kotlin.math.tanh

/** Записи лежат в общей медиатеке: Recordings/ (Android 12+) или Music/ (Android 10–11). Свои файлы читать/менять можно без разрешений. */
object Library {
    private val coll: Uri get() = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    private const val FOLDER = "Liquid Recorder"
    private val relPath: String get() = (if (Build.VERSION.SDK_INT >= 31) "Recordings/" else "Music/") + FOLDER + "/"

    fun load(ctx: Context, store: Store): List<Clip> {
        val out = ArrayList<Clip>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.SIZE,
        )
        try {
            ctx.contentResolver.query(
                coll, proj, "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?", arrayOf("%$FOLDER%"),
                "${MediaStore.Audio.Media.DATE_ADDED} DESC, ${MediaStore.Audio.Media._ID} DESC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val file = c.getString(1) ?: continue
                    val own = store.dur(id)
                    val dur = if (own >= 0) own else (if (c.isNull(2)) 0L else c.getLong(2))
                    out.add(Clip(id, ContentUris.withAppendedId(coll, id), file.substringBeforeLast('.'), dur, c.getLong(3) * 1000L, c.getLong(4)))
                }
            }
        } catch (_: Exception) { }
        return out
    }

    fun create(ctx: Context, base: String): Pair<Uri, ParcelFileDescriptor>? {
        val v = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "$base.m4a")
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, relPath)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(coll, v) ?: return null
        val pfd = try { ctx.contentResolver.openFileDescriptor(uri, "rw") } catch (_: Exception) { null }
        if (pfd == null) { try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) { }; return null }
        return uri to pfd
    }

    fun publish(ctx: Context, uri: Uri) {
        val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
        try { ctx.contentResolver.update(uri, v, null, null) } catch (_: Exception) { }
    }

    fun rename(ctx: Context, c: Clip, newName: String): Boolean {
        val clean = newName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").ifEmpty { return false }
        val v = ContentValues().apply { put(MediaStore.Audio.Media.DISPLAY_NAME, "$clean.m4a") }
        return try { ctx.contentResolver.update(c.uri, v, null, null) > 0 } catch (_: Exception) { false }
    }

    fun delete(ctx: Context, uri: Uri) {
        try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) { }
    }
}

enum class Phase { Idle, Recording, Paused }

/**
 * Движок записи. Живёт в процессе (а не в Activity): запись продолжается при выключенном экране благодаря RecService.
 * Звук идёт AudioRecord → своё шумоподавление (Dsp) → AAC-кодек → MP4 (M4A).
 */
object Rec {
    var phase by mutableStateOf(Phase.Idle); private set
    var elapsed by mutableLongStateOf(0L); private set
    /** Последние уровни громкости 0..1 для живой волны (новые — справа). */
    var live by mutableStateOf(FloatArray(0)); private set
    /** Увеличивается при каждой сохранённой записи — по нему список перезагружается. */
    var savedTick by mutableLongStateOf(0L); private set
    var lastSavedId by mutableLongStateOf(-1L); private set

    private const val LIVE_N = 52
    private var SR = 44100 // 16000 при шумоподавлении нейросетью DTLN, иначе 44100
    private const val BLOCK = 256
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ticker: Job? = null
    private var worker: Worker? = null
    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    @Volatile private var level = 0f
    @Volatile private var paused = false
    @Volatile private var stopFlag = false
    @Volatile private var failed = false
    @Volatile private var written = 0L
    private var smooth = 0f
    private val samples = ArrayList<Float>()
    private var samplesCopy: List<Float> = emptyList()

    fun start(ctx: Context, store: Store): Boolean {
        if (phase != Phase.Idle) return true
        Play.stop()
        val app = ctx.applicationContext
        val proc: Proc = (if (store.ns > 0) try { Dtln(app, store.ns) } catch (_: Throwable) { null } else null)
            ?: Dsp(store.ns)
        SR = if (proc is Dtln) 16000 else 44100
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) { proc.close(); return false }
        val ar = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf * 2, 16384))
        } catch (_: Exception) { proc.close(); return false }
        if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); proc.close(); return false }
        val made = Library.create(app, defaultName())
        if (made == null) { ar.release(); proc.close(); return false }
        val effects = ArrayList<AudioEffect>()
        var codec: MediaCodec? = null
        var mux: MediaMuxer? = null
        try {
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, if (SR == 16000) (if (store.hq) 64_000 else 40_000) else if (store.hq) 160_000 else 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            mux = MediaMuxer(made.second.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            ar.startRecording()
            if (ar.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("mic busy")
        } catch (_: Exception) {
            try { codec?.release() } catch (_: Exception) { }
            try { mux?.release() } catch (_: Exception) { }
            effects.forEach { try { it.release() } catch (_: Exception) { } }
            try { ar.release() } catch (_: Exception) { }
            try { made.second.close() } catch (_: Exception) { }
            Library.delete(app, made.first)
            proc.close()
            return false
        }
        uri = made.first; pfd = made.second
        paused = false; stopFlag = false; failed = false; written = 0L; level = 0f; smooth = 0f
        samples.clear(); live = FloatArray(0); elapsed = 0L
        val w = Worker(ar, codec!!, mux!!, effects, proc)
        worker = w
        phase = Phase.Recording
        w.start()
        try { app.startForegroundService(Intent(app, RecService::class.java)) } catch (_: Exception) { }
        ticker = scope.launch {
            while (true) {
                delay(50)
                if (worker == null) break
                elapsed = written * 1000L / SR
                if (phase == Phase.Recording) {
                    val lv = level
                    level = 0f
                    val target = lv.coerceIn(0f, 1f).pow(.5f)
                    smooth += (target - smooth) * (if (target > smooth) .5f else .22f) // мягче и вверх, и вниз: соседние столбики не «рубятся»
                    samples.add(smooth)
                    val from = (samples.size - LIVE_N).coerceAtLeast(0)
                    live = FloatArray(samples.size - from) { samples[from + it] }
                }
            }
        }
        return true
    }

    fun togglePause() {
        if (worker == null) return
        if (phase == Phase.Recording) { paused = true; phase = Phase.Paused }
        else if (phase == Phase.Paused) { paused = false; phase = Phase.Recording }
    }

    /** Останавливает запись и сохраняет её. Слишком короткая запись удаляется. */
    fun stop(ctx: Context, store: Store) {
        val w = worker ?: return
        val app = ctx.applicationContext
        stopFlag = true
        try { w.join(4000) } catch (_: Exception) { }
        val dur = written * 1000L / SR
        ticker?.cancel(); ticker = null
        val u = uri
        val ok = !failed
        try { pfd?.close() } catch (_: Exception) { }
        reset(app)
        if (u == null) return
        if (!ok || dur < 400) { Library.delete(app, u); return }
        Library.publish(app, u)
        val id = ContentUris.parseId(u)
        store.saveMeta(id, dur, downsample(samplesCopy, 64))
        lastSavedId = id
        savedTick++
    }

    fun discard(ctx: Context) {
        val w = worker ?: return
        val app = ctx.applicationContext
        stopFlag = true
        try { w.join(4000) } catch (_: Exception) { }
        ticker?.cancel(); ticker = null
        try { pfd?.close() } catch (_: Exception) { }
        val u = uri
        reset(app)
        if (u != null) Library.delete(app, u)
    }

    private fun reset(app: Context) {
        samplesCopy = ArrayList(samples)
        worker = null; uri = null; pfd = null
        phase = Phase.Idle; elapsed = 0L; live = FloatArray(0)
        samples.clear()
        try { app.stopService(Intent(app, RecService::class.java)) } catch (_: Exception) { }
    }

    /** Сжимает историю громкости в n столбиков (максимум в каждом окне), 6..100. */
    fun downsample(src: List<Float>, n: Int): IntArray {
        if (src.isEmpty()) return IntArray(n) { 6 }
        return IntArray(n) { i ->
            val a = (i * src.size / n).coerceAtMost(src.size - 1)
            val b = ((i + 1) * src.size / n).coerceIn(a + 1, src.size)
            var m = 0f
            for (k in a until b) if (src[k] > m) m = src[k]
            (m * 100f).toInt().coerceIn(6, 100)
        }
    }

    /** Поток записи: читает микрофон, обрабатывает, кодирует в AAC и пишет в MP4. */
    private class Worker(
        val ar: AudioRecord, val codec: MediaCodec, val mux: MediaMuxer,
        val effects: List<AudioEffect>, val dsp: Proc,
    ) : Thread("rec-worker") {
        private var track = -1
        private var started = false
        private val info = MediaCodec.BufferInfo()

        override fun run() {
            val buf = ShortArray(1024)
            var total = 0L
            try {
                while (!stopFlag) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n < 0) { failed = true; break }
                    if (n == 0) continue
                    dsp.process(buf, n)
                    if (dsp.peak > level) level = dsp.peak
                    dsp.peak = 0f
                    if (paused) continue
                    val idx = codec.dequeueInputBuffer(20_000)
                    if (idx >= 0) {
                        val ib = codec.getInputBuffer(idx)
                        if (ib != null) {
                            ib.clear()
                            ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(buf, 0, n)
                            codec.queueInputBuffer(idx, 0, n * 2, total * 1_000_000L / SR, 0)
                            total += n
                            written = total
                        }
                    }
                    drain(false)
                }
            } catch (_: Exception) { failed = true }
            try { ar.stop() } catch (_: Exception) { }
            try {
                var idx = codec.dequeueInputBuffer(50_000)
                if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, total * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                drain(true)
            } catch (_: Exception) { failed = true }
            try { codec.stop() } catch (_: Exception) { }
            try { codec.release() } catch (_: Exception) { }
            try { if (started) mux.stop() else failed = true } catch (_: Exception) { failed = true }
            try { mux.release() } catch (_: Exception) { }
            effects.forEach { try { it.release() } catch (_: Exception) { } }
            try { ar.release() } catch (_: Exception) { }
            dsp.close()
        }

        private fun drain(eos: Boolean) {
            var tries = 0
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
                when {
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (!started) { track = mux.addTrack(codec.outputFormat); mux.start(); started = true }
                    }
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        if (!eos || ++tries > 60) return
                    }
                    i >= 0 -> {
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                        val ob = codec.getOutputBuffer(i)
                        if (ob != null && info.size > 0 && started) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            mux.writeSampleData(track, ob, info)
                        }
                        codec.releaseOutputBuffer(i, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }
        }
    }

    /**
     * Шумоподавление (спектральное, Wiener + decision-directed — без «булькающего» шума гейтов).
     * Звук режется на кадры по 512 отсчётов с перекрытием 50% (окно sin), шум оценивается отдельно для каждой частоты
     * (быстро идёт вниз за тишиной, очень медленно вверх), для каждой частоты считается коэффициент пропускания.
     * После очистки идёт небольшое усиление (+3…+12 дБ, только по речи) и мягкий лимитер.
     * nsMode: 0 выкл (звук как есть), 1 слабое (до −12 дБ), 2 сильное (до −24 дБ).
     */
    private class Dsp(private val nsMode: Int) : Proc() {
        private val N = 512
        private val H = 256
        private val B = N / 2 + 1
        private val win = FloatArray(N) { sin(PI * (it + .5) / N).toFloat() }
        private val cosT = FloatArray(N / 2) { cos(2 * PI * it / N).toFloat() }
        private val sinT = FloatArray(N / 2) { sin(2 * PI * it / N).toFloat() }
        private val rev = IntArray(N).also { r -> val bits = 9; for (i in 0 until N) { var x = i; var y = 0; for (k in 0 until bits) { y = (y shl 1) or (x and 1); x = x shr 1 }; r[i] = y } }
        private val re = FloatArray(N)
        private val im = FloatArray(N)
        private val frame = FloatArray(N)
        private val ola = FloatArray(H)
        private val pSm = FloatArray(B)
        private val noise = FloatArray(B)
        private val prevClean = FloatArray(B)
        private val g = FloatArray(B)
        private val gs = FloatArray(B)
        private var frames = 0
        private val gMin = if (nsMode == 1) .25f else .06f
        private val over = if (nsMode == 1) 1.5f else 2.2f
        // HPF ~80 Гц
        private val hpA = 0.9886f
        private var hpX = 0f
        private var hpY = 0f
        // очереди вход/выход
        private val inQ = FloatArray(8192); private var inH = 0; private var inCnt = 0
        private val outQ = FloatArray(8192); private var outH = 0; private var outCnt = 0
        private val hop = FloatArray(H)
        // усиление и лимитер
        private var agc = 1.6f
        private var prevG = 1.6f
        init { outCnt = H } // задержка на один шаг (≈6 мс), чтобы на выходе всегда хватало отсчётов

        private fun fft(inverse: Boolean) {
            if (inverse) for (i in 0 until N) im[i] = -im[i]
            for (i in 0 until N) { val j = rev[i]; if (j > i) { val t = re[i]; re[i] = re[j]; re[j] = t; val u = im[i]; im[i] = im[j]; im[j] = u } }
            var len = 2
            while (len <= N) {
                val half = len / 2; val step = N / len
                var i = 0
                while (i < N) {
                    var k = 0
                    for (j in i until i + half) {
                        val wr = cosT[k]; val wi = -sinT[k]
                        val xr = re[j + half] * wr - im[j + half] * wi
                        val xi = re[j + half] * wi + im[j + half] * wr
                        re[j + half] = re[j] - xr; im[j + half] = im[j] - xi
                        re[j] += xr; im[j] += xi
                        k += step
                    }
                    i += len
                }
                len *= 2
            }
            if (inverse) { val sc = 1f / N; for (i in 0 until N) { re[i] *= sc; im[i] = -im[i] * sc } }
        }

        override fun process(b: ShortArray, n: Int) {
            if (nsMode == 0) {
                for (i in 0 until n) { val a = abs(b[i] / 32768f); if (a > peak) peak = a }
                return
            }
            for (i in 0 until n) {
                val x = b[i] / 32768f
                val y = hpA * (hpY + x - hpX); hpX = x; hpY = y
                inQ[(inH + inCnt) and 8191] = y; inCnt++
            }
            while (inCnt >= H) {
                for (i in 0 until H) hop[i] = inQ[(inH + i) and 8191]
                inH = (inH + H) and 8191; inCnt -= H
                step()
                for (i in 0 until H) outQ[(outH + outCnt + i) and 8191] = hop[i]
                outCnt += H
            }
            for (i in 0 until n) {
                val y = outQ[outH]; outH = (outH + 1) and 8191; outCnt--
                b[i] = (y * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                val a = abs(y); if (a > peak) peak = a
            }
        }

        /** Один шаг: на входе hop (H новых отсчётов), на выходе в нём же H очищенных. */
        private fun step() {
            System.arraycopy(frame, H, frame, 0, H)
            System.arraycopy(hop, 0, frame, H, H)
            for (i in 0 until N) { re[i] = frame[i] * win[i]; im[i] = 0f }
            fft(false)
            val eps = 1e-12f
            var gSum = 0f
            for (k in 0 until B) {
                val pw = re[k] * re[k] + im[k] * im[k]
                if (frames == 0) { pSm[k] = pw; noise[k] = pw }
                pSm[k] += (pw - pSm[k]) * .3f
                if (frames < 10) noise[k] += (pSm[k] - noise[k]) * .3f          // первые ~60 мс считаем тишиной
                else if (pSm[k] < noise[k]) noise[k] += (pSm[k] - noise[k]) * .15f // вниз быстро
                else noise[k] *= 1.0009f                                          // вверх очень медленно (≈0,6 дБ/с)
                val nz = noise[k] * over + eps
                val post = pw / nz
                val prior = .95f * prevClean[k] / nz + .05f * maxOf(post - 1f, 0f)
                g[k] = maxOf(prior / (1f + prior), gMin)
            }
            frames++
            for (k in 0 until B) {
                val l = g[maxOf(k - 1, 0)]; val r = g[minOf(k + 1, B - 1)]
                var v = (l + 2f * g[k] + r) * .25f
                if (k <= 1) v = 0f
                gs[k] = v
                gSum += v
                prevClean[k] = (re[k] * re[k] + im[k] * im[k]) * v * v
            }
            for (k in 0 until B) {
                re[k] *= gs[k]; im[k] *= gs[k]
                if (k in 1 until N / 2) { re[N - k] *= gs[k]; im[N - k] *= gs[k] }
            }
            fft(true)
            var sum = 0f
            for (i in 0 until H) {
                val y = ola[i] + re[i] * win[i]
                ola[i] = re[H + i] * win[H + i]
                hop[i] = y; sum += y * y
            }
            // небольшое усиление по речи
            val rms = sqrt(sum / H)
            val speech = gSum / B > gMin + .3f * (1f - gMin) && rms > .004f
            if (speech) {
                val want = (.1f / rms).coerceIn(1.4f, 4f)
                agc += (want - agc) * (if (want < agc) .2f else .01f)
            } else agc += (1.6f - agc) * .004f
            for (i in 0 until H) {
                val gi = prevG + (agc - prevG) * ((i + 1f) / H)
                var y = hop[i] * gi
                val a = abs(y)
                if (a > .7f) y = sign(y) * (.7f + .3f * tanh((a - .7f) / .3f))
                hop[i] = y
            }
            prevG = agc
        }
    }
}

/** Обрезка без перекодирования: берутся готовые AAC-кадры из выбранного отрезка и пишутся в новый файл. */
object Trim {
    fun cut(ctx: Context, src: Clip, startMs: Long, endMs: Long, store: Store): Boolean {
        val app = ctx.applicationContext
        val made = Library.create(app, src.name + tr(" (обрезано)", " (trimmed)")) ?: return false
        val ex = MediaExtractor()
        var ok = false
        try {
            ex.setDataSource(app, src.uri, null)
            var ti = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { ti = i; break }
            }
            if (ti < 0) throw IllegalStateException("no audio")
            ex.selectTrack(ti)
            val mux = MediaMuxer(made.second.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val out = mux.addTrack(ex.getTrackFormat(ti))
            mux.start()
            ex.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocate(1 shl 18)
            val info = MediaCodec.BufferInfo()
            var first = -1L
            var count = 0
            while (true) {
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t > endMs * 1000L) break
                if (first < 0) first = t
                info.set(0, size, t - first, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                mux.writeSampleData(out, buf, info)
                count++
                ex.advance()
            }
            mux.stop(); mux.release()
            ok = count > 0
        } catch (_: Exception) {
            ok = false
        } finally {
            try { ex.release() } catch (_: Exception) { }
            try { made.second.close() } catch (_: Exception) { }
        }
        if (!ok) { Library.delete(app, made.first); return false }
        Library.publish(app, made.first)
        val id = ContentUris.parseId(made.first)
        val old = store.peaks(src.id)
        val dur = (endMs - startMs).coerceAtLeast(0L)
        val peaks = if (old == null || src.durationMs <= 0) IntArray(64) { 30 } else IntArray(64) { i ->
            val t = startMs + dur * i / 64
            old[((t * old.size) / src.durationMs).toInt().coerceIn(0, old.size - 1)]
        }
        store.saveMeta(id, dur, peaks)
        return true
    }
}

/** Плеер: одна запись «выбрана» (раскрыта) — она подготовлена и ждёт; играет не больше одной. */
object Play {
    var id by mutableLongStateOf(-1L); private set
    var playing by mutableStateOf(false); private set
    var pos by mutableLongStateOf(0L); private set
    var dur by mutableLongStateOf(0L); private set
    private var mp: MediaPlayer? = null

    fun select(ctx: Context, c: Clip) {
        if (id == c.id && mp != null) return
        stop()
        val p = MediaPlayer()
        try {
            p.setDataSource(ctx.applicationContext, c.uri)
            p.prepare()
        } catch (_: Exception) { try { p.release() } catch (_: Exception) { }; return }
        p.setOnCompletionListener { playing = false; pos = dur }
        mp = p; id = c.id; dur = p.duration.toLong().coerceAtLeast(c.durationMs); pos = 0L; playing = false
    }

    fun toggle() {
        val p = mp ?: return
        try {
            if (playing) { p.pause(); playing = false }
            else {
                if (pos >= dur - 80) { p.seekTo(0); pos = 0 }
                p.start(); playing = true
            }
        } catch (_: Exception) { playing = false }
    }

    fun seekTo(ms: Long) {
        val p = mp ?: return
        val t = ms.coerceIn(0L, dur)
        try { p.seekTo(t.toInt()) } catch (_: Exception) { }
        pos = t
    }

    fun skip(deltaMs: Long) = seekTo(pos + deltaMs)

    fun tick() {
        val p = mp ?: return
        if (playing) pos = try { p.currentPosition.toLong() } catch (_: Exception) { pos }
    }

    fun stop() {
        try { mp?.release() } catch (_: Exception) { }
        mp = null; id = -1L; playing = false; pos = 0L; dur = 0L
    }
}

/** Foreground-сервис с типом «микрофон»: без него Android прекратит запись, когда экран погаснет. */
class RecService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("rec", getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "rec")
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle(getString(R.string.notif_title))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(7, n)
        } catch (_: Exception) { }
        return START_NOT_STICKY
    }
}

/** Обработчик звука в потоке записи: меняет буфер на месте, ведёт «пик» для живой волны. */
private abstract class Proc {
    @Volatile var peak = 0f
    abstract fun process(b: ShortArray, n: Int)
    open fun close() {}
}

/** БПФ на 512 точек (комплексное), на месте. */
private class Fft512 {
    private val N = 512
    private val cosT = FloatArray(N / 2) { cos(2 * PI * it / N).toFloat() }
    private val sinT = FloatArray(N / 2) { sin(2 * PI * it / N).toFloat() }
    private val rev = IntArray(N).also { r -> for (i in 0 until N) { var x = i; var y = 0; for (k in 0 until 9) { y = (y shl 1) or (x and 1); x = x shr 1 }; r[i] = y } }
    fun run(re: FloatArray, im: FloatArray, inverse: Boolean) {
        if (inverse) for (i in 0 until N) im[i] = -im[i]
        for (i in 0 until N) { val j = rev[i]; if (j > i) { val t = re[i]; re[i] = re[j]; re[j] = t; val u = im[i]; im[i] = im[j]; im[j] = u } }
        var len = 2
        while (len <= N) {
            val half = len / 2; val step = N / len
            var i = 0
            while (i < N) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]; val wi = -sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr; im[j + half] = im[j] - xi
                    re[j] += xr; im[j] += xi
                    k += step
                }
                i += len
            }
            len *= 2
        }
        if (inverse) { val sc = 1f / N; for (i in 0 until N) { re[i] *= sc; im[i] = -im[i] * sc } }
    }
}

/**
 * Шумоподавление нейросетью DTLN (Dual-signal Transformation LSTM, MIT, Westhausen & Meyer 2020) через TensorFlow Lite.
 * Работает на телефоне, без интернета: 16 кГц, шаг 128 отсчётов (8 мс), на кадр уходит ~1–2 мс.
 * Сеть 1 строит маску по спектру, сеть 2 дочищает сигнал во временной области. Задержка модели 384 отсчёта (24 мс).
 * mode 1 (слабое): 70% очищенного + 30% оригинала, mode 2 (сильное): только очищенный.
 * После сети идёт небольшое усиление речи (до +10 дБ) и мягкий лимитер.
 */
private class Dtln(ctx: Context, private val mode: Int) : Proc() {
    private val H = 128
    private val N = 512
    private val i1: Interpreter
    private val i2: Interpreter
    private val fft = Fft512()
    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val inBuf = FloatArray(N)
    private val outBuf = FloatArray(N)
    private val mag = ByteBuffer.allocateDirect(257 * 4).order(ByteOrder.nativeOrder())
    private val mask = ByteBuffer.allocateDirect(257 * 4).order(ByteOrder.nativeOrder())
    private val blk = ByteBuffer.allocateDirect(N * 4).order(ByteOrder.nativeOrder())
    private val o2 = ByteBuffer.allocateDirect(N * 4).order(ByteOrder.nativeOrder())
    private val st1 = ByteBuffer.allocateDirect(2 * 128 * 2 * 4).order(ByteOrder.nativeOrder())
    private val st1n = ByteBuffer.allocateDirect(2 * 128 * 2 * 4).order(ByteOrder.nativeOrder())
    private val st2 = ByteBuffer.allocateDirect(2 * 128 * 2 * 4).order(ByteOrder.nativeOrder())
    private val st2n = ByteBuffer.allocateDirect(2 * 128 * 2 * 4).order(ByteOrder.nativeOrder())
    private val wet = if (mode == 1) .7f else 1f
    private val inQ = FloatArray(8192); private var inH = 0; private var inCnt = 0
    private val outQ = FloatArray(8192); private var outH = 0; private var outCnt = H
    private val hop = FloatArray(H)
    private var agc = 1.3f
    private var prevG = 1.3f

    init {
        val o = Interpreter.Options().setNumThreads(1)
        i1 = Interpreter(load(ctx, "dtln_1.tflite"), o)
        i2 = Interpreter(load(ctx, "dtln_2.tflite"), Interpreter.Options().setNumThreads(1))
    }

    private fun load(ctx: Context, name: String): ByteBuffer {
        val bytes = ctx.assets.open(name).use { it.readBytes() }
        return ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder()).put(bytes).also { it.rewind() }
    }

    override fun close() {
        try { i1.close() } catch (_: Throwable) { }
        try { i2.close() } catch (_: Throwable) { }
    }

    override fun process(b: ShortArray, n: Int) {
        for (i in 0 until n) { inQ[(inH + inCnt) and 8191] = b[i] / 32768f; inCnt++ }
        while (inCnt >= H) {
            for (i in 0 until H) hop[i] = inQ[(inH + i) and 8191]
            inH = (inH + H) and 8191; inCnt -= H
            step()
            for (i in 0 until H) outQ[(outH + outCnt + i) and 8191] = hop[i]
            outCnt += H
        }
        for (i in 0 until n) {
            val y = outQ[outH]; outH = (outH + 1) and 8191; outCnt--
            b[i] = (y * 32767f).toInt().coerceIn(-32768, 32767).toShort()
            val a = abs(y); if (a > peak) peak = a
        }
    }

    private fun step() {
        System.arraycopy(inBuf, H, inBuf, 0, N - H)
        System.arraycopy(hop, 0, inBuf, N - H, H)
        for (i in 0 until N) { re[i] = inBuf[i]; im[i] = 0f }
        fft.run(re, im, false)
        mag.rewind()
        for (k in 0..256) mag.putFloat(sqrt(re[k] * re[k] + im[k] * im[k]))
        mag.rewind(); st1.rewind(); mask.rewind(); st1n.rewind()
        i1.runForMultipleInputsOutputs(arrayOf<Any>(mag, st1), mapOf<Int, Any>(0 to mask, 1 to st1n))
        st1.rewind(); st1n.rewind(); st1.put(st1n)
        mask.rewind()
        for (k in 0..256) {
            val m = mask.getFloat()
            re[k] *= m; im[k] *= m
            if (k in 1..255) { re[N - k] *= m; im[N - k] *= m }
        }
        fft.run(re, im, true)
        blk.rewind(); for (i in 0 until N) blk.putFloat(re[i])
        blk.rewind(); st2.rewind(); o2.rewind(); st2n.rewind()
        i2.runForMultipleInputsOutputs(arrayOf<Any>(blk, st2), mapOf<Int, Any>(0 to o2, 1 to st2n))
        st2.rewind(); st2n.rewind(); st2.put(st2n)
        o2.rewind()
        System.arraycopy(outBuf, H, outBuf, 0, N - H)
        for (i in N - H until N) outBuf[i] = 0f
        for (i in 0 until N) outBuf[i] += o2.getFloat()
        // первые H отсчётов окна — готовый результат; оригинал для смешивания лежит в тех же позициях inBuf
        var sum = 0f
        for (i in 0 until H) {
            val y = outBuf[i] * wet + inBuf[i] * (1f - wet)
            hop[i] = y; sum += y * y
        }
        val rms = sqrt(sum / H)
        if (rms > .006f) {
            val want = (.1f / rms).coerceIn(1.2f, 3f)
            agc += (want - agc) * (if (want < agc) .2f else .01f)
        } else agc += (1.3f - agc) * .004f
        for (i in 0 until H) {
            val gi = prevG + (agc - prevG) * ((i + 1f) / H)
            var y = hop[i] * gi
            val a = abs(y)
            if (a > .7f) y = sign(y) * (.7f + .3f * tanh((a - .7f) / .3f))
            hop[i] = y
        }
        prevG = agc
    }
}
