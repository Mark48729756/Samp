package com.embededly.Recorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import androidx.compose.foundation.layout.offset
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.gestures.detectDragGestures
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt

private sealed interface Dlg {
    data class Rename(val c: Clip) : Dlg
    data class Delete(val c: Clip) : Dlg
    data object Discard : Dlg
}

private val DANGER = Color(0xFFFF453A)

private fun nsLabel(i: Int) = tr("Шумоподавление: ", "Noise reduction: ") + when (i) {
    0 -> tr("выкл", "off"); 1 -> tr("слабое", "low"); else -> tr("сильное", "high")
}

@Composable
fun RecorderApp() {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val store = remember { Store(ctx) }
    val backdrop = rememberLayerBackdrop()
    val listState = rememberLazyListState()
    var clips by remember { mutableStateOf<List<Clip>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var openId by rememberSaveable { mutableLongStateOf(-1L) }
    var menuOpen by remember { mutableStateOf(false) }
    val menuMorph = remember { MenuMorph() }
    var hq by remember { mutableStateOf(store.hq) }
    var ns by remember { mutableIntStateOf(store.ns) }
    val scope = rememberCoroutineScope()
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    var seen by remember { mutableLongStateOf(Rec.savedTick) }

    fun reload() { clips = Library.load(ctx, store); loaded = true }

    // новая запись сохранена — обновить список, раскрыть её и прокрутить наверх
    LaunchedEffect(Rec.savedTick) {
        reload()
        if (Rec.savedTick != seen) {
            seen = Rec.savedTick
            openId = Rec.lastSavedId
            listState.animateScrollToItem(0)
        }
    }
    // раскрытая запись готовится к проигрыванию; свёрнута/удалена — плеер освобождается
    LaunchedEffect(openId, clips) {
        val c = clips.firstOrNull { it.id == openId }
        if (c != null && Rec.phase == Phase.Idle) Play.select(ctx, c) else Play.stop()
    }
    LaunchedEffect(Rec.phase) { if (Rec.phase != Phase.Idle) openId = -1L }

    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.RECORD_AUDIO)
    }
    fun begin() {
        openId = -1L
        if (!Rec.start(ctx, store)) Toast.makeText(ctx, tr("Не удалось начать запись", "Couldn't start recording"), Toast.LENGTH_SHORT).show()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) begin()
        else Toast.makeText(ctx, tr("Нужен доступ к микрофону", "Microphone access is required"), Toast.LENGTH_SHORT).show()
    }
    fun startRecording() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
        else launcher.launch(perms)
    }
    fun share(c: Clip) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "audio/mp4"; putExtra(Intent.EXTRA_STREAM, c.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { ctx.startActivity(Intent.createChooser(i, null)) } catch (_: Exception) { }
    }

    BackHandler(enabled = openId != -1L) { openId = -1L }

    Box(Modifier.fillMaxSize().background(pal.bg)) {
        // всё, что «видит» стекло: фон, заголовок и список
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop).background(pal.bg)) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                    GText(tr("Диктофон", "Recorder"), color = pal.fg, fontSize = 32.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(
                        Modifier.fillMaxSize(), state = listState,
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 290.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(clips, key = { it.id }) { c ->
                            val peaks = remember(c.id) { store.peaks(c.id) ?: fakePeaks(c.id) }
                            ClipCard(
                                c, peaks, openId == c.id,
                                onToggle = { openId = if (openId == c.id) -1L else c.id },
                                onRename = { dialog = Dlg.Rename(c) },
                                onDelete = { dialog = Dlg.Delete(c) },
                                onShare = { share(c) },
                                onTrim = { a, b ->
                                    scope.launch {
                                        val ok = withContext(Dispatchers.IO) { Trim.cut(ctx, c, a, b, store) }
                                        if (ok) reload()
                                        else Toast.makeText(ctx, tr("Не удалось обрезать", "Couldn't trim"), Toast.LENGTH_SHORT).show()
                                    }
                                },
                            )
                        }
                    }
                    if (loaded && clips.isEmpty() && Rec.phase == Phase.Idle) EmptyState()
                }
            }
        }

        GlassMenu(
            menuOpen, backdrop, { menuOpen = false },
            Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 63.dp, end = 12.dp),
            anchor = Alignment.TopEnd, riseDp = -54f, riseXDp = 0f, minDp = 46f, menuWidthDp = 300f, morph = menuMorph
        ) {
            GlassMenuItem(if (hq) tr("Качество: высокое", "Quality: high") else tr("Качество: стандартное", "Quality: standard")) {
                hq = !hq; store.hq = hq
            }
            GlassMenuItem(nsLabel(ns)) { ns = (ns + 1) % 3; store.ns = ns }
        }
        // кнопка «⋮» рисуется ПОСЛЕ меню: у неё свой стеклянный фон, и капля вылетает из-под неё
        MenuButton(backdrop, menuMorph, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 9.dp, end = 12.dp)) { menuOpen = !menuOpen }

        RecordDock(
            backdrop, onStart = { startRecording() },
            onStop = { Rec.stop(ctx, store) },
            onDiscard = { dialog = Dlg.Discard },
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 14.dp),
        )

        when (val d = dialog) {
            is Dlg.Rename -> GlassPrompt(
                backdrop, tr("Переименовать", "Rename"), d.c.name, "OK", tr("Отмена", "Cancel"),
                onOk = { name -> Library.rename(ctx, d.c, name); reload() }, onDismiss = { dialog = null },
            )
            is Dlg.Delete -> GlassConfirm(
                backdrop, tr("Удалить запись?", "Delete recording?"), d.c.name, tr("Удалить", "Delete"), tr("Отмена", "Cancel"),
                onConfirm = {
                    if (openId == d.c.id) { Play.stop(); openId = -1L }
                    Library.delete(ctx, d.c.uri); store.forget(d.c.id); reload()
                },
                onDismiss = { dialog = null },
            )
            Dlg.Discard -> GlassConfirm(
                backdrop, tr("Удалить запись?", "Discard recording?"),
                tr("Текущая запись будет удалена без сохранения.", "The current recording will be discarded without saving."),
                tr("Удалить", "Discard"), tr("Отмена", "Cancel"),
                onConfirm = { Rec.discard(ctx) }, onDismiss = { dialog = null },
            )
            null -> {}
        }
    }
}

/** Круглая кнопка «⋮»: её стекло отдаётся меню, пока оно открыто — меню вырастает из самой кнопки и пружиной возвращается в неё. */
@Composable
private fun MenuButton(backdrop: Backdrop, morph: MenuMorph, modifier: Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    MorphAnchor(
        morph, modifier.size(46.dp),
        glass = { m ->
            Box(m.glass(backdrop, CircleShape, pal.key, 3f, 8f, 12f).border(1.dp, Color.White.copy(alpha = edgeAlpha(pal)), CircleShape))
        },
        icon = { AppleGlyph(Glyph.Dots, pal.fg, size = 24.dp) },
        onClick = onClick,
    )
}

@Composable
private fun EmptyState() {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxSize().padding(bottom = 160.dp).padding(horizontal = 40.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppleGlyph(Glyph.Wave, pal.sub.copy(alpha = .55f), size = 84.dp)
        Spacer(Modifier.height(18.dp))
        GText(tr("Нет записей", "No recordings"), color = pal.fg, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        GText(
            tr("Нажмите красную кнопку, чтобы начать запись", "Tap the red button to start recording"),
            color = pal.sub, fontSize = 15.sp, textAlign = TextAlign.Center,
        )
    }
}

/** Волна для записей, у которых нет сохранённых пиков (например, добавленных не из приложения). */
private fun fakePeaks(id: Long): IntArray {
    val r = java.util.Random(id)
    var v = 40
    return IntArray(64) { v = (v + r.nextInt(41) - 20).coerceIn(14, 92); v }
}

@Composable
private fun Modifier.tapScale(onHold: (Boolean) -> Unit = {}, onClick: () -> Unit): Modifier {
    var down by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (down) .9f else 1f, spring(.6f, 500f), label = "tap")
    val now by rememberUpdatedState(onClick)
    val haptic = LocalHapticFeedback.current
    return this.graphicsLayer { scaleX = sc; scaleY = sc }.pointerInput(Unit) {
        detectTapGestures(
            onPress = { down = true; onHold(true); tryAwaitRelease(); down = false; onHold(false) },
            onTap = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); now() },
        )
    }
}

@Composable
private fun ClipCard(
    c: Clip, peaks: IntArray, expanded: Boolean,
    onToggle: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit, onShare: () -> Unit, onTrim: (Long, Long) -> Unit,
) {
    val pal = LocalPal.current
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier.fillMaxWidth().animateContentSize(spring(.85f, 380f)).clip(shape).background(pal.key)
            .border(1.dp, Color.White.copy(alpha = edgeAlpha(pal)), shape)
    ) {
        Row(
            Modifier.fillMaxWidth()
                .clickable(remember { MutableInteractionSource() }, null) { onToggle() }
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                GText(c.name, color = pal.fg, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                GText(fmtDate(c.dateMs) + "  ·  " + fmtDur(c.durationMs), color = pal.sub, fontSize = 14.sp, maxLines = 1)
            }
        }
        if (expanded) PlayerPanel(c, peaks, onRename, onDelete, onShare, onTrim)
    }
}

@Composable
private fun PlayerPanel(c: Clip, peaks: IntArray, onRename: () -> Unit, onDelete: () -> Unit, onShare: () -> Unit, onTrim: (Long, Long) -> Unit) {
    val pal = LocalPal.current
    val ready = Play.id == c.id
    val dur = if (ready && Play.dur > 0) Play.dur else c.durationMs
    val pos = if (ready) Play.pos else 0L
    val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f

    var trimming by remember { mutableStateOf(false) }
    var ta by remember { mutableFloatStateOf(0f) }
    var tb by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(Play.playing, Play.id) {
        while (Play.playing && Play.id == c.id) { Play.tick(); delay(33) }
    }

    Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 18.dp)) {
        if (trimming) {
            TrimScrubber(peaks, ta, tb) { a, b -> ta = a; tb = b; if (ready) Play.seekTo((a * dur).toLong()) }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                GText(fmtDur((ta * dur).toLong()), color = pal.sub, fontSize = 13.sp, tnum = true)
                Spacer(Modifier.weight(1f))
                GText(tr("Длина: ", "Length: ") + fmtDur(((tb - ta) * dur).toLong()), color = pal.fg, fontSize = 13.sp, tnum = true)
                Spacer(Modifier.weight(1f))
                GText(fmtDur((tb * dur).toLong()), color = pal.sub, fontSize = 13.sp, tnum = true)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(tr("Отмена", "Cancel"), Modifier.weight(1f), primary = false) { trimming = false }
                GlassButton(tr("Обрезать", "Trim"), Modifier.weight(1f), enabled = (tb - ta) * dur > 500) {
                    trimming = false
                    onTrim((ta * dur).toLong(), (tb * dur).toLong())
                }
            }
            return@Column
        }
        Scrubber(peaks, frac) { f -> if (ready) Play.seekTo((f * dur).toLong()) }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            GText(fmtDur(pos), color = pal.sub, fontSize = 13.sp, tnum = true)
            Spacer(Modifier.weight(1f))
            GText("-" + fmtDur((dur - pos).coerceAtLeast(0)), color = pal.sub, fontSize = 13.sp, tnum = true)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).tapScale { Play.skip(-15_000) }, contentAlignment = Alignment.Center) {
                AppleGlyph(Glyph.Skip15Back, pal.fg, size = 32.dp)
            }
            Spacer(Modifier.width(18.dp))
            Box(
                Modifier.size(68.dp).clip(CircleShape).background(pal.accent).tapScale { Play.toggle() },
                contentAlignment = Alignment.Center,
            ) {
                AppleGlyph(if (Play.playing && ready) Glyph.Pause else Glyph.Play, Color.White, size = 32.dp)
            }
            Spacer(Modifier.width(18.dp))
            Box(Modifier.size(56.dp).tapScale { Play.skip(15_000) }, contentAlignment = Alignment.Center) {
                AppleGlyph(Glyph.Skip15Fwd, pal.fg, size = 32.dp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ActionDot(Glyph.Share, pal.fg, onShare)
            ActionDot(Glyph.Scissors, pal.fg) {
                if (ready && dur > 1000) { if (Play.playing) Play.toggle(); ta = 0f; tb = 1f; trimming = true }
            }
            ActionDot(Glyph.Pencil, pal.fg, onRename)
            ActionDot(Glyph.Trash, DANGER, onDelete)
        }
    }
}

@Composable
private fun ActionDot(g: Glyph, tint: Color, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(pal.fg.copy(alpha = .08f)).tapScale(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { AppleGlyph(g, tint, size = 23.dp) }
}

/** Волна записи с перемоткой: тап и протяжка. Сыгранная часть — цветом акцента. */
@Composable
private fun Scrubber(peaks: IntArray, frac: Float, onSeek: (Float) -> Unit) {
    val pal = LocalPal.current
    val seek by rememberUpdatedState(onSeek)
    Canvas(
        Modifier.fillMaxWidth().height(72.dp)
            .pointerInput(Unit) { detectTapGestures { seek((it.x / size.width).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectHorizontalDragGestures { ch, _ -> ch.consume(); seek((ch.position.x / size.width).coerceIn(0f, 1f)) } }
    ) {
        val n = peaks.size
        val barW = size.width / (n + (n - 1) * .6f)
        val gap = barW * .6f
        val minH = 4.dp.toPx()
        for (i in 0 until n) {
            val x = barW / 2f + i * (barW + gap)
            val h = max(minH, size.height * peaks[i] / 100f)
            val played = (i + .5f) / n <= frac
            drawLine(
                if (played) pal.accent else pal.fg.copy(alpha = .26f),
                Offset(x, (size.height - h) / 2f), Offset(x, (size.height + h) / 2f),
                strokeWidth = barW, cap = StrokeCap.Round,
            )
        }
    }
}

/** Волна с двумя ручками для обрезки: тянем левую или правую (какая ближе к пальцу). */
@Composable
private fun TrimScrubber(peaks: IntArray, a: Float, b: Float, onChange: (Float, Float) -> Unit) {
    val pal = LocalPal.current
    val aNow by rememberUpdatedState(a)
    val bNow by rememberUpdatedState(b)
    val chg by rememberUpdatedState(onChange)
    var which by remember { mutableIntStateOf(0) }
    Canvas(
        Modifier.fillMaxWidth().height(84.dp).pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { pos ->
                    val f = pos.x / size.width
                    which = if (kotlin.math.abs(f - aNow) <= kotlin.math.abs(f - bNow)) 0 else 1
                },
                onDrag = { ch, _ ->
                    ch.consume()
                    val f = (ch.position.x / size.width).coerceIn(0f, 1f)
                    if (which == 0) chg(f.coerceAtMost(bNow - .02f).coerceAtLeast(0f), bNow)
                    else chg(aNow, f.coerceAtLeast(aNow + .02f).coerceAtMost(1f))
                },
            )
        }
    ) {
        val n = peaks.size
        val hp = 10.dp.toPx()
        val w = size.width - hp * 2
        val barW = w / (n + (n - 1) * .6f)
        val gap = barW * .6f
        val minH = 4.dp.toPx()
        val vh = size.height - 12.dp.toPx()
        for (i in 0 until n) {
            val x = hp + barW / 2f + i * (barW + gap)
            val h = max(minH, vh * peaks[i] / 100f)
            val f = (i + .5f) / n
            val inside = f in a..b
            drawLine(
                if (inside) pal.fg.copy(alpha = .85f) else pal.fg.copy(alpha = .2f),
                Offset(x, (size.height - h) / 2f), Offset(x, (size.height + h) / 2f), strokeWidth = barW, cap = StrokeCap.Round,
            )
        }
        for (f in listOf(a, b)) {
            val x = hp + w * f
            drawLine(pal.accent, Offset(x, 2.dp.toPx()), Offset(x, size.height - 2.dp.toPx()), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
        }
    }
}

/**
 * Стеклянная панель записи. В покое — круглая кнопка (красная точка в кольце, как на иконке приложения). При записи вырастает вверх
 * в панель с таймером, живой волной и кнопками «удалить / стоп / пауза». Размер меняется через layout, а не scale — преломление не «уезжает».
 */
@Composable
private fun RecordDock(backdrop: Backdrop, onStart: () -> Unit, onStop: () -> Unit, onDiscard: () -> Unit, modifier: Modifier) {
    val pal = LocalPal.current
    val active = Rec.phase != Phase.Idle
    val p by animateFloatAsState(if (active) 1f else 0f, spring(.66f, 240f), label = "dock")
    val shape = RoundedCornerShape(39.dp)
    val panelH = 252.dp
    val dockBackdrop = rememberLayerBackdrop()
    // капля: появляется под пальцем на кнопке записи и держится ~170 мс после отпускания, чтобы успела проявиться и у быстрого тапа
    var held by remember { mutableStateOf(false) }
    var lift by remember { mutableStateOf(false) }
    LaunchedEffect(held) { if (held) lift = true else { delay(170); lift = false } }
    val grow by animateFloatAsState(if (lift) 1f else 0f, spring(.52f, 330f), label = "drop")
    val dropSize = 78.dp * (1f + .3f * grow)

    // Панель дока. live = настоящая (с касаниями и «дыркой» под каплей), не live = невидимая копия для капли.
    @Composable
    fun Panel(live: Boolean) {
        val hole = if (live) Modifier
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                if (grow > .01f) {
                    // вырезаем место под каплей, иначе оригинальная кнопка видна сквозь стекло и «двоится»
                    val c = Offset(size.width / 2f, size.height - 39.dp.toPx())
                    drawCircle(Color.Black, 78.dp.toPx() * (1f + .3f * grow) / 2f - 1f, c, blendMode = BlendMode.Clear)
                }
            } else Modifier
        Box(
            Modifier
                .then(if (live) Modifier
                    .glass(backdrop, shape, pal.key.copy(alpha = if (pal.dark) .78f else .84f), 10f, 10f, 16f)
                    .border(1.dp, Color.White.copy(alpha = edgeAlpha(pal, p.coerceIn(0f, 1f) * .5f)), shape) else Modifier)
                .clip(shape)
                .then(hole)
                .layout { m, c ->
                    val full = m.measure(Constraints.fixed(c.maxWidth, panelH.roundToPx()))
                    val min = 78.dp.roundToPx()
                    val w = (min + (full.width - min) * p.coerceIn(0f, 1f)).roundToInt().coerceAtMost(c.maxWidth)
                    val h = (min + (full.height - min) * p).roundToInt().coerceAtLeast(min)
                    layout(w, h) { full.place((w - full.width) / 2, h - full.height) }
                }
        ) {
            DockContent(p, pal, live, onStart, onStop, onDiscard) { held = it }
        }
    }

    Box(modifier.fillMaxWidth().padding(horizontal = 16.dp), contentAlignment = Alignment.BottomCenter) {
        Box(Modifier.alpha(0f).layerBackdrop(dockBackdrop)) { Panel(false) }
        Panel(true)
        if (grow > .01f) {
            // одна линза над «фон экрана + копия дока»: через каплю виден и док (панель, кольцо кнопки), и то, что за ним.
            // Размер меняется через modifier size (layout), а не scale — иначе преломление «уезжает».
            val g = grow.coerceIn(0f, 1f)
            val scrim = if (pal.dark) Color.Black else Color.White
            Box(
                Modifier.align(Alignment.BottomCenter).offset(y = dropSize / 2f - 39.dp).size(dropSize)
                    .graphicsLayer { alpha = (grow * 3f).coerceIn(0f, 1f) }
            ) {
                // слой 1: фон экрана под каплей, затемнённый на 40% (в светлой теме осветлённый — тёмные значки должны читаться)
                Box(
                    Modifier.fillMaxSize().drawBackdrop(
                        backdrop, { CircleShape },
                        effects = { blur(2.dp.toPx() * g); lens(10.dp.toPx() * (1f + .15f * g), 16.dp.toPx() * (1f + .25f * g), chromaticAberration = g > .35f) },
                        onDrawSurface = { drawRect(scrim.copy(alpha = .06f + .34f * g)) }
                    )
                )
                // слой 2: сам док (кольцо кнопки, панель) с той же линзой — поверх затемнения
                Box(
                    Modifier.fillMaxSize().drawBackdrop(
                        dockBackdrop, { CircleShape },
                        effects = { lens(10.dp.toPx() * (1f + .15f * g), 16.dp.toPx() * (1f + .25f * g), chromaticAberration = g > .35f) }
                    )
                )
                Box(Modifier.fillMaxSize().border(1.dp, Color.White.copy(alpha = .12f + .30f * g), CircleShape))
            }
        }
    }
}

@Composable
private fun DockContent(
    p: Float, pal: Pal, live: Boolean, onStart: () -> Unit, onStop: () -> Unit, onDiscard: () -> Unit, onHold: (Boolean) -> Unit,
) {
    val pc = p.coerceIn(0f, 1f)
    val recording = Rec.phase == Phase.Recording
    val blink = rememberInfiniteTransition(label = "blink")
    val dotA by blink.animateFloat(1f, .25f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "dot")
    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier.weight(1f).fillMaxWidth().graphicsLayer { alpha = ((pc - .35f) / .65f).coerceIn(0f, 1f) },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(9.dp).graphicsLayer { alpha = if (recording) dotA else 1f }
                            .clip(CircleShape).background(if (recording) pal.accent else pal.sub)
                    )
                    Spacer(Modifier.width(8.dp))
                    GText(
                        if (recording) tr("Идёт запись", "Recording") else tr("Пауза", "Paused"),
                        color = pal.sub, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                    )
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    GText(fmtDur(Rec.elapsed), color = pal.fg, fontSize = 56.sp, fontWeight = FontWeight.Light, tnum = true, maxLines = 1)
                    GText(
                        "," + ((Rec.elapsed % 1000) / 100), color = pal.sub, fontSize = 24.sp, fontWeight = FontWeight.Light,
                        tnum = true, modifier = Modifier.padding(bottom = 10.dp, start = 2.dp),
                    )
                }
                LiveWave(Rec.live, pal.fg)
            }
        }
        Row(Modifier.fillMaxWidth().height(78.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f).graphicsLayer { alpha = pc }, contentAlignment = Alignment.Center) {
                GlassSideButton(Glyph.Trash, DANGER, enabled = live && pc > .8f, onTap = onDiscard)
            }
            Box(
                Modifier.size(78.dp).then(if (live) Modifier.tapScale(onHold) { if (Rec.phase == Phase.Idle) onStart() else onStop() } else Modifier),
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(64.dp).border(3.dp, pal.fg.copy(alpha = .88f), CircleShape))
                Box(
                    Modifier.size(lerp(52.dp, 28.dp, pc))
                        .clip(RoundedCornerShape(lerp(26.dp, 8.dp, pc))).background(pal.accent)
                )
            }
            Box(Modifier.weight(1f).graphicsLayer { alpha = pc }, contentAlignment = Alignment.Center) {
                GlassSideButton(if (recording) Glyph.Pause else Glyph.Mic, pal.fg, enabled = live && pc > .8f, onTap = { Rec.togglePause() })
            }
        }
    }
}

/** Боковая кнопка дока: своё мини-стекло поверх панели (преломляет то же содержимое, что и сама панель). */
@Composable
private fun GlassSideButton(g: Glyph, tint: Color, enabled: Boolean, onTap: () -> Unit) {
    val pal = LocalPal.current
    Box(
        Modifier.size(54.dp).clip(CircleShape).background(pal.fg.copy(alpha = .10f))
            .border(1.dp, Color.White.copy(alpha = edgeAlpha(pal)), CircleShape)
            .then(if (enabled) Modifier.tapScale(onClick = onTap) else Modifier),
        contentAlignment = Alignment.Center,
    ) { AppleGlyph(g, tint, size = 24.dp) }
}

/**
 * Живая волна: новые столбики въезжают справа, старые тают слева. Данные приходят раз в 50 мс, но с неровными интервалами (главный поток),
 * поэтому лента НЕ привязана к моменту их прихода: позиция прокрутки каждый кадр плавно «догоняет» число столбиков по времени кадра.
 * Новый столбик вырастает из центральной линии, пока заезжает в кадр, — ни скачков, ни остановок между обновлениями.
 */
@Composable
private fun LiveWave(live: FloatArray, color: Color) {
    val liveNow by rememberUpdatedState(live)
    var scroll by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val ns = withFrameNanos { it }
            val dt = if (last == 0L) .016f else ((ns - last) / 1e9f).coerceIn(.001f, .05f)
            last = ns
            val target = liveNow.size.toFloat()
            // новая запись началась заново — не едем назад, а сразу встаём в начало
            scroll = if (target < scroll - 1.5f) target else scroll + (target - scroll) * (1f - exp(-dt * 16f))
        }
    }
    Canvas(Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 30.dp)) {
        val data = liveNow
        val pos = scroll
        val n = 52
        val slot = size.width / n
        val bw = slot * .5f
        val minH = 4.dp.toPx()
        val from = (pos.toInt() - n - 1).coerceAtLeast(0)
        // столбик с индексом k стоит на расстоянии (pos - k) слотов от правого края; самый свежий (k = size-1) ещё чуть правее края и заезжает
        for (k in from until data.size) {
            val x = size.width - slot * (pos - k - .5f) - slot
            if (x < -slot || x > size.width + slot) continue
            val enter = ((size.width - x) / slot + .5f).coerceIn(0f, 1f) // 0 за правым краем → 1 внутри кадра
            val h = max(minH, size.height * data[k] * enter)
            val a = ((x / size.width) * 1.15f).coerceIn(0f, 1f) * (.25f + .75f * enter)
            drawLine(
                color.copy(alpha = (.12f + .88f * a).coerceIn(0f, 1f)), Offset(x, (size.height - h) / 2f), Offset(x, (size.height + h) / 2f),
                strokeWidth = bw, cap = StrokeCap.Round,
            )
        }
    }
}
