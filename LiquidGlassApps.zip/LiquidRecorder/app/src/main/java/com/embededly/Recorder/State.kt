package com.embededly.Recorder

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Immutable
data class Pal(val bg: Color, val fg: Color, val sub: Color, val key: Color, val accent: Color, val dark: Boolean)

val LocalPal = staticCompositionLocalOf<Pal> { error("no Pal") }

private val RU_LANGS = setOf("ru", "uk", "be", "kk")
fun tr(ru: String, en: String): String = if (Locale.getDefault().language in RU_LANGS) ru else en

/** Одна запись из медиатеки. */
@Immutable
data class Clip(val id: Long, val uri: Uri, val name: String, val durationMs: Long, val dateMs: Long, val size: Long)

/** Настройки, длительности и «пики» волн хранятся в SharedPreferences. */
class Store(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("rec", Context.MODE_PRIVATE)

    var hq: Boolean
        get() = sp.getBoolean("hq", true)
        set(v) { sp.edit().putBoolean("hq", v).apply() }
    /** Усиление голоса: 0 выкл, 1 +6 дБ, 2 +12 дБ, 3 +18 дБ, 4 авто. */
    var gain: Int
        get() = sp.getInt("gain", 4)
        set(v) { sp.edit().putInt("gain", v).apply() }
    /** Шумоподавление: 0 выкл, 1 слабое, 2 сильное. */
    var ns: Int
        get() = sp.getInt("ns", 1)
        set(v) { sp.edit().putInt("ns", v).apply() }
    var stereo: Boolean
        get() = sp.getBoolean("stereo", false)
        set(v) { sp.edit().putBoolean("stereo", v).apply() }

    fun saveMeta(id: Long, durMs: Long, peaks: IntArray) {
        sp.edit().putLong("d_$id", durMs).putString("p_$id", peaks.joinToString(",")).apply()
    }

    fun dur(id: Long): Long = sp.getLong("d_$id", -1L)

    fun peaks(id: Long): IntArray? =
        sp.getString("p_$id", null)?.split(',')?.mapNotNull { it.toIntOrNull() }?.takeIf { it.isNotEmpty() }?.toIntArray()

    fun forget(id: Long) { sp.edit().remove("d_$id").remove("p_$id").apply() }
}

/** 0:07, 12:34, 1:02:03 */
fun fmtDur(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

/** «Сегодня, 14:32» / «Вчера, 09:10» / «8 ноя, 18:00» */
fun fmtDate(ms: Long): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = ms }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))
    val sameYear = now.get(Calendar.YEAR) == then.get(Calendar.YEAR)
    val dayDiff = now.get(Calendar.DAY_OF_YEAR) - then.get(Calendar.DAY_OF_YEAR)
    return when {
        sameYear && dayDiff == 0 -> tr("Сегодня", "Today") + ", " + time
        sameYear && dayDiff == 1 -> tr("Вчера", "Yesterday") + ", " + time
        else -> SimpleDateFormat(if (sameYear) "d MMM, HH:mm" else "d MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))
    }
}

fun defaultName(): String =
    tr("Запись", "Recording") + " " + SimpleDateFormat("yyyy-MM-dd HH.mm.ss", Locale.getDefault()).format(Date())
