package com.embededly.Recorder

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Текст без Material: тонкая обёртка над BasicText. */
@Composable
fun GText(
    text: String, modifier: Modifier = Modifier, color: Color = LocalPal.current.fg, fontSize: TextUnit = 16.sp,
    fontWeight: FontWeight? = null, maxLines: Int = Int.MAX_VALUE, softWrap: Boolean = true,
    textAlign: TextAlign? = null, letterSpacing: TextUnit = TextUnit.Unspecified, tnum: Boolean = false,
) {
    BasicText(
        text, modifier,
        style = TextStyle(
            color = color, fontSize = fontSize, fontWeight = fontWeight, textAlign = textAlign ?: TextAlign.Unspecified,
            letterSpacing = letterSpacing, fontFeatureSettings = if (tnum) "tnum" else null,
        ),
        overflow = TextOverflow.Ellipsis, softWrap = softWrap, maxLines = maxLines,
    )
}

/** Стеклянная панель: размытие + линза-преломление поверх backdrop. */
fun Modifier.glass(
    backdrop: Backdrop, shape: Shape, surface: Color,
    blurDp: Float = 4f, refH: Float = 8f, refA: Float = 12f, strength: Float = 1f,
): Modifier = this.drawBackdrop(
    backdrop, { shape },
    effects = {
        if (blurDp > 0f) blur(blurDp.dp.toPx())
        if (refH > 0f) lens(refH.dp.toPx(), refA.dp.toPx())
    },
    onDrawSurface = { drawRect(surface) }
).tiltRim(shape, strength)

fun edgeAlpha(pal: Pal, open: Float = 0f) = (if (pal.dark) .07f else .55f) + .22f * open

private const val GROW = .09f

/**
 * Круглая/скруглённая стеклянная кнопка. При касании вырастает от центра («капля») и плавно возвращается; даже у быстрого тапа
 * эффект держится ~170 мс. Размер меняется через layout, а не scale, чтобы преломление не «уезжало».
 */
@Composable
fun GlassPress(
    backdrop: Backdrop, modifier: Modifier = Modifier, shape: Shape = CircleShape, surface: Color = LocalPal.current.key,
    enabled: Boolean = true, onTap: () -> Unit, content: @Composable BoxScope.() -> Unit,
) {
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val tapNow by rememberUpdatedState(onTap)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) GROW else 0f, spring(.52f, 330f), label = "pressGrow")
    val open = (grow / GROW).coerceIn(0f, 1f)
    Box(
        modifier.zIndex(if (lift || grow > .002f) 1f else 0f).graphicsLayer { alpha = if (enabled) 1f else .4f }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures(
                    onPress = {
                        lift = true
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        tryAwaitRelease()
                        scope.launch { delay(170); lift = false }
                    },
                    onTap = { tapNow() },
                )
            }
    ) {
        Box(
            Modifier.fillMaxSize()
                .layout { m, c ->
                    val w = (c.maxWidth * (1f + grow)).roundToInt()
                    val h = (c.maxHeight * (1f + grow * 1.1f)).roundToInt()
                    val pl = m.measure(Constraints.fixed(w, h))
                    layout(c.maxWidth, c.maxHeight) { pl.place((c.maxWidth - w) / 2, (c.maxHeight - h) / 2) }
                }
                .glass(backdrop, shape, surface, 3f, 8f * (1f + open * .2f), 12f * (1f + open * .3f))
                .border(1.dp, Color.White.copy(alpha = edgeAlpha(pal, open)), shape),
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

private fun Modifier.fillMaxSize(): Modifier = this.fillMaxSize()

/** Кнопка-«капсула» (вместо Material Button). */
@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, primary: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.height(48.dp).graphicsLayer { alpha = if (enabled) 1f else .4f }
            .clip(CircleShape)
            .background(if (primary) pal.accent else pal.fg.copy(alpha = .12f))
            .border(1.dp, Color.White.copy(alpha = .16f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        GText(text, color = if (primary) Color.White else pal.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

private fun Modifier.clip(shape: Shape): Modifier = this.then(Modifier.graphicsLayer { clip = true; this.shape = shape })

/** Точка последнего касания в координатах экрана: окна «вываливаются» из неё как капля. Заполняется в MainActivity. */
val LocalTouch = staticCompositionLocalOf { mutableStateOf(Offset.Unspecified) }

/**
 * Окно, которое вываливается каплей из точки касания, растёт до своего размера и при закрытии схлопывается обратно.
 * onDismissed вызывается уже после анимации схлопывания.
 */
@Composable
private fun DropWindow(backdrop: Backdrop, onDismissed: () -> Unit, body: @Composable ColumnScope.(close: () -> Unit) -> Unit) {
    val pal = LocalPal.current
    val touch = LocalTouch.current
    val origin = remember { touch.value }
    val ax = remember { Animatable(0f) }
    val ay = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val gone = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var closing by remember { mutableStateOf(false) }
    val close: () -> Unit = {
        if (!closing) {
            closing = true
            scope.launch {
                launch { fade.animateTo(0f, tween(100)) }
                launch { ax.animateTo(0f, tween(230, easing = FastOutSlowInEasing)) }
                ay.animateTo(0f, tween(250, easing = FastOutSlowInEasing))
                gone.animateTo(1f, tween(130, easing = FastOutSlowInEasing))
                onDismissed()
            }
        }
    }
    LaunchedEffect(Unit) {
        launch { ax.animateTo(1f, spring(.5f, 300f)) }
        launch { ay.animateTo(1f, spring(.42f, 230f)) }
        launch { delay(80); fade.animateTo(1f, tween(200)) }
    }
    BackHandler(onBack = close)
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxSize().imePadding()) {
        Box(
            Modifier.fillMaxSize()
                .drawBehind { drawRect(Color.Black.copy(alpha = .45f * ay.value.coerceIn(0f, 1f))) }
                .clickable(remember { MutableInteractionSource() }, null) { close() }
        )
        Layout(
            modifier = Modifier.fillMaxSize(),
            content = {
                Box(
                    Modifier.graphicsLayer { alpha = 1f - gone.value }
                        .glass(backdrop, shape, pal.key.copy(alpha = if (pal.dark) .78f else .86f), 16f, 10f, 18f)
                        .border(1.dp, Color.White.copy(alpha = edgeAlpha(pal, .5f)), shape)
                )
                Column(
                    Modifier.graphicsLayer { alpha = fade.value.coerceIn(0f, 1f) }
                        .clickable(remember { MutableInteractionSource() }, null) { }
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) { body(close) }
            }
        ) { ms, c ->
            val margin = 28.dp.roundToPx()
            val w = (c.maxWidth - 2 * margin).coerceIn(1, 420.dp.roundToPx())
            val cont = ms[1].measure(Constraints(w, w, 0, (c.maxHeight - 2 * margin).coerceAtLeast(1)))
            val mn = 40.dp.toPx() * (1f - .85f * gone.value)
            val cw = (mn + (cont.width - mn) * ax.value).coerceAtLeast(1f)
            val ch = (mn + (cont.height - mn) * ay.value).coerceAtLeast(1f)
            val fcx = c.maxWidth / 2f
            val fcy = c.maxHeight / 2f
            val ox = if (origin.isSpecified) origin.x else fcx
            val oy = if (origin.isSpecified) origin.y else c.maxHeight * .8f
            val q = ax.value
            val cx = ox + (fcx - ox) * q
            val cy = oy + (fcy - oy) * q
            val glass = ms[0].measure(Constraints.fixed(cw.roundToInt(), ch.roundToInt()))
            layout(c.maxWidth, c.maxHeight) {
                glass.place((cx - cw / 2f).roundToInt(), (cy - ch / 2f).roundToInt())
                cont.place((cx - cont.width / 2f).roundToInt(), (cy - cont.height / 2f).roundToInt())
            }
        }
    }
}

/** Окно подтверждения (удаление и т.п.): действие запускается сразу, окно схлопывается следом. */
@Composable
fun GlassConfirm(
    backdrop: Backdrop, title: String, text: String, confirm: String, cancel: String,
    onConfirm: () -> Unit, onDismiss: () -> Unit,
) {
    val pal = LocalPal.current
    DropWindow(backdrop, onDismiss) { close ->
        GText(title, color = pal.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        GText(text, color = pal.sub, fontSize = 15.sp)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(cancel, Modifier.weight(1f), primary = false) { close() }
            GlassButton(confirm, Modifier.weight(1f)) { close(); onConfirm() }
        }
    }
}

/** Окно ввода названия (переименование). Поле — своё, без Material TextField. */
@Composable
fun GlassPrompt(
    backdrop: Backdrop, title: String, initial: String, ok: String, cancel: String,
    onOk: (String) -> Unit, onDismiss: () -> Unit,
) {
    val pal = LocalPal.current
    DropWindow(backdrop, onDismiss) { close ->
        var tf by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, initial.length))) }
        val focus = remember { FocusRequester() }
        LaunchedEffect(Unit) { delay(260); try { focus.requestFocus() } catch (_: Exception) { } }
        GText(title, color = pal.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.fg.copy(alpha = .08f))
                .border(1.dp, Color.White.copy(alpha = if (pal.dark) .08f else .5f), RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            BasicTextField(
                value = tf, onValueChange = { tf = it },
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
                textStyle = TextStyle(color = pal.fg, fontSize = 17.sp),
                cursorBrush = SolidColor(pal.accent), singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (tf.text.isNotBlank()) { close(); onOk(tf.text) } }),
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(cancel, Modifier.weight(1f), primary = false) { close() }
            GlassButton(ok, Modifier.weight(1f), enabled = tf.text.isNotBlank()) { close(); onOk(tf.text) }
        }
    }
}
