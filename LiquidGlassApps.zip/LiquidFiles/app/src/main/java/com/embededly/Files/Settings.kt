package com.embededly.Files

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import kotlin.reflect.KProperty

const val PREFS = "files"

class IntPref(private val sp: SharedPreferences, private val key: String, def: Int) {
    private val s = mutableIntStateOf(sp.getInt(key, def))
    operator fun getValue(t: Any?, p: KProperty<*>): Int = s.intValue
    operator fun setValue(t: Any?, p: KProperty<*>, v: Int) { s.intValue = v; sp.edit().putInt(key, v).apply() }
}

class BoolPref(private val sp: SharedPreferences, private val key: String, def: Boolean) {
    private val s = mutableStateOf(sp.getBoolean(key, def))
    operator fun getValue(t: Any?, p: KProperty<*>): Boolean = s.value
    operator fun setValue(t: Any?, p: KProperty<*>, v: Boolean) { s.value = v; sp.edit().putBoolean(key, v).apply() }
}

class StrPref(private val sp: SharedPreferences, private val key: String, def: String) {
    private val s = mutableStateOf(sp.getString(key, def) ?: def)
    operator fun getValue(t: Any?, p: KProperty<*>): String = s.value
    operator fun setValue(t: Any?, p: KProperty<*>, v: String) { s.value = v; sp.edit().putString(key, v).apply() }
}

/** Закреплённая вкладка: путь к папке и своё имя (null — имя папки). */
data class Pin(val path: String, val title: String?)

/** Все настройки приложения; каждое поле наблюдаемо из Compose и сразу сохраняется. */
class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var theme by IntPref(sp, "theme", 1)
    var showHidden by BoolPref(sp, "hidden", false)
    var sortBy by IntPref(sp, "sort", 0)
    var sortDesc by BoolPref(sp, "desc", false)
    var foldersFirst by BoolPref(sp, "ff", true)
    var grid by BoolPref(sp, "grid", false)
    var confirmDelete by BoolPref(sp, "confirm", true)
    var useTrash by BoolPref(sp, "trash", true)
    var trashDays by IntPref(sp, "tdays", 30)
    var lang by StrPref(sp, "lang", "system")
    var lastLoc by StrPref(sp, "loc", "")

    val pins = mutableStateListOf<Pin>()

    init {
        runCatching {
            val a = JSONArray(sp.getString("pins", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                pins.add(Pin(o.getString("p"), if (o.has("t")) o.getString("t") else null))
            }
        }
    }

    private fun savePins() {
        val a = JSONArray()
        pins.forEach { a.put(JSONObject().put("p", it.path).also { o -> if (it.title != null) o.put("t", it.title) }) }
        sp.edit().putString("pins", a.toString()).apply()
    }

    fun isPinned(path: String) = pins.any { it.path == path }
    fun pin(path: String) { if (!isPinned(path)) { pins.add(Pin(path, null)); savePins() } }
    fun unpin(path: String) { pins.removeAll { it.path == path }; savePins() }
    fun renamePin(path: String, title: String?) {
        val i = pins.indexOfFirst { it.path == path }
        if (i >= 0) { pins[i] = Pin(path, title?.ifBlank { null }); savePins() }
    }
    fun renamePinPath(old: String, new: String) {
        val i = pins.indexOfFirst { it.path == old }
        if (i >= 0) { pins[i] = Pin(new, pins[i].title); savePins() }
    }
    fun movePin(path: String, delta: Int) {
        val i = pins.indexOfFirst { it.path == path }
        val j = i + delta
        if (i < 0 || j !in pins.indices) return
        val p = pins.removeAt(i)
        pins.add(j, p)
        savePins()
    }

    companion object {
        fun readLang(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lang", "system") ?: "system"
    }
}
