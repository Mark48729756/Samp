package com.embededly.Files

import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

// ───────────────────────── Хранилище ─────────────────────────

@Composable
fun StoragePage(set: Settings, bottomPad: Dp, onOpen: (Loc) -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val quick = rememberQuick(set)
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(Env.vols, key = { it.root }) { v ->
            val (total, free) = remember(v.root) {
                runCatching { StatFs(v.root).let { it.totalBytes to it.availableBytes } }.getOrDefault(0L to 0L)
            }
            val used = (total - free).coerceAtLeast(0L)
            val frac = if (total > 0) used.toFloat() / total else 0f
            Column(
                Modifier.fillMaxWidth().flatShape(RoundedCornerShape(28.dp), pal.card)
                    .clickable(remember { MutableInteractionSource() }, null) { onOpen(Loc.Dir(v.root)) }
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (v.primary) Icons.Filled.Storage else Icons.Filled.SdCard, null, tint = pal.accent, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(v.label, color = pal.fg, fontSize = 22.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(pal.fg.copy(alpha = .12f))) {
                    Box(Modifier.fillMaxWidth(frac.coerceIn(.02f, 1f)).height(10.dp).clip(CircleShape).background(if (frac > .9f) Danger else pal.accent))
                }
                Spacer(Modifier.height(10.dp))
                Text(stringResource(R.string.storage_free_of, fmtSize(ctx, free), fmtSize(ctx, total)), color = pal.sub, fontSize = 15.sp)
            }
        }
        item(key = "qa") {
            Text(stringResource(R.string.quick_access), color = pal.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 8.dp, top = 8.dp))
        }
        val rows = quick.chunked(2)
        items(rows.size, key = { "q$it" }) { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rows[r].forEach { q ->
                    Row(
                        Modifier.weight(1f).height(60.dp).flatShape(RoundedCornerShape(20.dp), pal.card)
                            .clickable(remember { MutableInteractionSource() }, null) { onOpen(q.loc) }.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(q.icon, null, tint = pal.accent, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(q.label, color = pal.fg, fontSize = 16.sp, lineHeight = 19.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (rows[r].size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ───────────────────────── Корзина ─────────────────────────

@Composable
fun TrashPage(entries: List<TrashEntry>, selected: Set<String>, bottomPad: Dp, onToggle: (String) -> Unit) {
    val pal = LocalPal.current
    val locale = LocalConfiguration.current.locales[0]
    val df = remember(locale) { dateFormat(locale) }
    if (entries.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(bottom = bottomPad), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.trash_empty), color = pal.sub, fontSize = 17.sp, textAlign = TextAlign.Center)
        }
        return
    }
    val st = rememberLazyListState()
    val dens = LocalDensity.current
    val topPx = with(dens) { 34.dp.toPx() }
    val botPx = with(dens) { (bottomPad - 6.dp).toPx() }
    val list = remember(entries) { entries.sortedByDescending { it.time } }
    LazyColumn(
        Modifier.fillMaxSize(), st,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        itemsIndexed(list, key = { _, e -> e.id }) { i, e ->
            val first = i == 0
            val last = i == list.lastIndex
            val shape: Shape = RoundedCornerShape(
                topStart = if (first) 24.dp else 6.dp, topEnd = if (first) 24.dp else 6.dp,
                bottomStart = if (last) 24.dp else 6.dp, bottomEnd = if (last) 24.dp else 6.dp
            )
            val item = Trash.asItem(e).let { it.copy(sub = (it.sub ?: "") + "  ·  " + fmtDate(df, e.time)) }
            FileRow(
                item, df, true, e.id in selected, shape, Modifier.edgeFade(st, e.id, topPx, botPx),
                onTap = { onToggle(e.id) }, onLong = { onToggle(e.id) }, onIcon = { onToggle(e.id) }, thumbs = false
            )
        }
    }
}

// ───────────────────────── Настройки ─────────────────────────

@Composable
private fun Section(title: Int, content: @Composable () -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth()) {
        Text(stringResource(title), color = pal.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
        Column(Modifier.fillMaxWidth().flatShape(RoundedCornerShape(24.dp), pal.card).padding(vertical = 4.dp)) { content() }
    }
}

@Composable
private fun SwitchRow(label: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Text(stringResource(label), color = pal.fg, fontSize = 17.sp, lineHeight = 21.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        GlassSwitch(checked, onChange)
    }
}

@Composable
private fun ValueRow(label: Int, value: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Row(
        Modifier.fillMaxWidth().clickable(remember { MutableInteractionSource() }, null, onClick = onClick).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(stringResource(label), color = pal.fg, fontSize = 17.sp, lineHeight = 21.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Text(value, color = pal.sub, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = pal.sub)
    }
}

/** Стеклянный сегментированный переключатель на 2–3 варианта. */
@Composable
private fun SegmentRow(label: Int, options: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(stringResource(label), color = pal.fg, fontSize = 17.sp, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.fg.copy(alpha = .08f)).padding(3.dp)) {
            options.forEachIndexed { i, r ->
                val on = i == selected
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(if (on) pal.accent else Color.Transparent)
                        .clickable(remember { MutableInteractionSource() }, null) { onSelect(i) }.padding(horizontal = 6.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        stringResource(r), color = if (on) Color.White else pal.fg, fontSize = 14.sp, lineHeight = 17.sp,
                        fontWeight = FontWeight.Medium, maxLines = 2, textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsPage(set: Settings, bottomPad: Dp, onSort: () -> Unit, onDays: () -> Unit, onLang: () -> Unit) {
    val sortNames = listOf(R.string.sort_name, R.string.sort_size, R.string.sort_date, R.string.sort_type)
    val ctx = LocalContext.current
    val langName = if (set.lang == "system") stringResource(R.string.lang_system) else Lang.nativeName(set.lang)
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item(key = "look") {
            Section(R.string.s_appearance) {
                SegmentRow(R.string.s_theme, listOf(R.string.theme_system, R.string.theme_dark, R.string.theme_light),
                    when (set.theme) { 1 -> 1; 2 -> 2; else -> 0 }) { set.theme = it }
                ValueRow(R.string.s_language, langName, onLang)
            }
        }
        item(key = "files") {
            Section(R.string.s_files) {
                SwitchRow(R.string.s_hidden, set.showHidden) { set.showHidden = it }
                SegmentRow(R.string.s_view, listOf(R.string.view_list, R.string.view_grid), if (set.grid) 1 else 0) { set.grid = it == 1 }
                ValueRow(R.string.s_sort, stringResource(sortNames[set.sortBy.coerceIn(0, 3)]) + if (set.sortDesc) " ↓" else " ↑", onSort)
                SwitchRow(R.string.s_folders_first, set.foldersFirst) { set.foldersFirst = it }
            }
        }
        item(key = "del") {
            Section(R.string.s_deleting) {
                SwitchRow(R.string.s_confirm, set.confirmDelete) { set.confirmDelete = it }
                SwitchRow(R.string.s_trash_use, set.useTrash) { set.useTrash = it }
                ValueRow(R.string.s_trash_days, stringResource(R.string.days_n, set.trashDays), onDays)
            }
        }
        item(key = "about") {
            val ver = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0" }
            Text(
                stringResource(R.string.app_name) + " · " + stringResource(R.string.about_version, ver), color = LocalPal.current.sub,
                fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ───────────────────────── Нет доступа ─────────────────────────

@Composable
fun PermissionPage(onAllow: () -> Unit) {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.Storage, null, tint = pal.accent, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(18.dp))
        Text(stringResource(R.string.perm_title), color = pal.fg, fontSize = 28.sp, textAlign = TextAlign.Center, lineHeight = 33.sp)
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.perm_text), color = pal.sub, fontSize = 16.sp, lineHeight = 21.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        GlassButton(stringResource(R.string.perm_btn), Modifier.fillMaxWidth(), onClick = onAllow)
    }
}
