package com.embededly.Files

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Внешние действия: открыть, открыть через, поделиться. */
object Act {
    fun uriFor(ctx: Context, it: FItem): Uri? = when (it.src) {
        Src.FS -> FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", File(it.id))
        Src.SAF -> Uri.parse(it.id)
        Src.ZIP -> null
    }

    private fun clip(uris: List<Uri>): ClipData {
        val c = ClipData.newRawUri("", uris.first())
        uris.drop(1).forEach { c.addItem(ClipData.Item(it)) }
        return c
    }

    fun toast(ctx: Context, res: Int) = Toast.makeText(ctx, res, Toast.LENGTH_SHORT).show()

    fun open(ctx: Context, item: FItem, chooser: Boolean) {
        val uri = uriFor(ctx, item) ?: return
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = clip(listOf(uri))
        try {
            ctx.startActivity(if (chooser) Intent.createChooser(i, null) else i)
        } catch (e: Exception) {
            toast(ctx, R.string.err_no_app)
        }
    }

    fun share(ctx: Context, items: List<FItem>) {
        val uris = items.filter { !it.dir }.mapNotNull { uriFor(ctx, it) }
        if (uris.isEmpty()) { toast(ctx, R.string.err_failed); return }
        val i = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).setType(items.first { !it.dir }.mime).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*").putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = clip(uris)
        try { ctx.startActivity(Intent.createChooser(i, null)) } catch (e: Exception) { toast(ctx, R.string.err_failed) }
    }
}
