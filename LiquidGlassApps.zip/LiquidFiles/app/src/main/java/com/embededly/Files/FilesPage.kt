package com.embededly.Files

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TextSnippet
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

fun kindColor(k: Kind): Color = when (k) {
    Kind.FOLDER -> Color(0xFF3478F6)
    Kind.IMAGE -> Color(0xFF34C759)
    Kind.VIDEO -> Color(0xFFAF52DE)
    Kind.AUDIO -> Color(0xFFFF2D55)
    Kind.DOC -> Color(0xFFFF9500)
    Kind.TEXT -> Color(0xFF8E8E93)
    Kind.ARCHIVE -> Color(0xFFFFCC00)
    Kind.APK -> Color(0xFF30D158)
    Kind.OTHER -> Color(0xFF8E8E93)
}

fun kindIcon(k: Kind): ImageVector = when (k) {
    Kind.FOLDER -> Icons.Filled.Folder
    Kind.IMAGE -> Icons.Filled.Image
    Kind.VIDEO -> Icons.Filled.Videocam
    Kind.AUDIO -> Icons.Filled.MusicNote
    Kind.DOC -> Icons.Filled.Description
    Kind.TEXT -> Icons.Filled.TextSnippet
    Kind.ARCHIVE -> Icons.Filled.Archive
    Kind.APK -> Icons.Filled.Android
    Kind.OTHER -> Icons.Filled.Description
}

/** Касание и долгое касание (без Material-индикаторов). */
@Composable
fun Modifier.tapLong(onTap: () -> Unit, onLong: () -> Unit): Modifier {
    val t by rememberUpdatedState(onTap)
    val l by rememberUpdatedState(onLong)
    val haptic = LocalHapticFeedback.current
    return this.pointerInput(Unit) {
        detectTapGestures(onLongPress = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); l() }, onTap = { t() })
    }
}

fun Modifier.flatShape(shape: Shape, color: Color): Modifier = this.clip(shape).background(color)

/** Значок файла: миниатюра (картинка, видео, обложка, иконка APK) или цветной значок типа. */
@Composable
fun FileIcon(item: FItem, modifier: Modifier, px: Int = 160, radius: Dp = 12.dp, thumbs: Boolean = true) {
    val ctx = LocalContext.current
    val tint = kindColor(item.kind)
    val use = thumbs && Thumbs.hasThumb(item)
    var bmp by remember(item.id, item.modified, px) { mutableStateOf(if (use) Thumbs.peek(item, px) else null) }
    if (use && bmp == null) {
        LaunchedEffect(item.id, item.modified, px) { bmp = Thumbs.load(ctx, item, px) }
    }
    Box(modifier.clip(RoundedCornerShape(radius)).background(tint.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), null, Modifier.fillMaxSize(),
                contentScale = if (item.kind == Kind.APK) ContentScale.Fit else ContentScale.Crop
            )
        } else {
            Icon(kindIcon(item.kind), null, tint = tint, modifier = Modifier.fillMaxSize(.52f))
        }
    }
}

@Composable
fun SelectMark(on: Boolean) {
    val pal = LocalPal.current
    Box(
        Modifier.size(26.dp).clip(CircleShape).background(if (on) pal.accent else Color.Transparent)
            .border(1.5.dp, if (on) pal.accent else pal.sub, CircleShape),
        contentAlignment = Alignment.Center
    ) { if (on) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
}

@Composable
fun FileRow(
    item: FItem, df: java.text.DateFormat, selecting: Boolean, selected: Boolean, shape: Shape, modifier: Modifier,
    onTap: () -> Unit, onLong: () -> Unit, onIcon: () -> Unit, thumbs: Boolean = true,
) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val subtitle = remember(item, df) {
        when {
            item.sub != null -> item.sub
            item.dir -> fmtDate(df, item.modified)
            else -> listOf(if (item.size >= 0) fmtSize(ctx, item.size) else "", fmtDate(df, item.modified)).filter { it.isNotEmpty() }.joinToString(" · ")
        }
    }
    Row(
        modifier.fillMaxWidth().flatShape(shape, if (selected) lerp(pal.card, pal.accent, .28f) else pal.card)
            .tapLong(onTap, onLong).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FileIcon(item, Modifier.size(46.dp).tapLong(onIcon, onLong), thumbs = thumbs)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = pal.fg, fontSize = 17.sp, lineHeight = 21.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (!subtitle.isNullOrEmpty()) Text(subtitle, color = pal.sub, fontSize = 13.sp, lineHeight = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        if (selecting) SelectMark(selected)
        else if (item.dir) Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = pal.sub)
    }
}

@Composable
fun FileCell(
    item: FItem, selecting: Boolean, selected: Boolean, modifier: Modifier,
    onTap: () -> Unit, onLong: () -> Unit, onIcon: () -> Unit,
) {
    val pal = LocalPal.current
    Column(
        modifier.flatShape(RoundedCornerShape(20.dp), if (selected) lerp(pal.card, pal.accent, .28f) else pal.card)
            .tapLong(onTap, onLong).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            FileIcon(item, Modifier.fillMaxSize().tapLong(onIcon, onLong), px = 280, radius = 14.dp)
            if (selecting) Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) { SelectMark(selected) }
        }
        Spacer(Modifier.height(6.dp))
        Text(item.name, color = pal.fg, fontSize = 13.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Message(res: Int) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(stringResource(res), color = LocalPal.current.sub, fontSize = 17.sp, textAlign = TextAlign.Center)
    }
}

/** Android/data и Android/obb: честно объясняем ограничение системы и предлагаем выдать доступ через системный выбор папки. */
@Composable
private fun GrantPanel(path: String, onGrant: (String) -> Unit) {
    val pal = LocalPal.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.data_title), color = pal.fg, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(if (Build.VERSION.SDK_INT >= 33) R.string.data_text_new else R.string.data_text_old),
            color = pal.sub, fontSize = 15.sp, lineHeight = 20.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(18.dp))
        GlassButton(stringResource(R.string.data_btn), Modifier.fillMaxWidth()) { onGrant(path) }
    }
}

class Quick(val label: String, val icon: ImageVector, val loc: Loc, val pin: Pin?)

/** Быстрые вкладки: хранилище, загрузки, категории и свои закреплённые папки. */
@Composable
fun rememberQuick(set: Settings): List<Quick> {
    val internal = stringResource(R.string.internal_storage)
    val dl = stringResource(R.string.q_downloads)
    val img = stringResource(R.string.q_images)
    val vid = stringResource(R.string.q_video)
    val mus = stringResource(R.string.q_music)
    val doc = stringResource(R.string.q_docs)
    val arc = stringResource(R.string.q_archives)
    val apk = stringResource(R.string.q_apk)
    val rec = stringResource(R.string.q_recent)
    val base = listOf(
        Quick(internal, Icons.Filled.Storage, Loc.Dir(Env.primaryRoot), null),
        Quick(dl, Icons.Filled.Download, Loc.Dir(downloadsPath()), null),
        Quick(img, Icons.Filled.Image, Loc.Cat(Cat.IMAGES), null),
        Quick(vid, Icons.Filled.Videocam, Loc.Cat(Cat.VIDEO), null),
        Quick(mus, Icons.Filled.MusicNote, Loc.Cat(Cat.MUSIC), null),
        Quick(doc, Icons.Filled.Description, Loc.Cat(Cat.DOCS), null),
        Quick(arc, Icons.Filled.Archive, Loc.Cat(Cat.ARCHIVES), null),
        Quick(apk, Icons.Filled.Android, Loc.Cat(Cat.APK), null),
        Quick(rec, Icons.Filled.History, Loc.Cat(Cat.RECENT), null),
    )
    val pins = set.pins.map { Quick(it.title ?: File(it.path).name.ifEmpty { it.path }, Icons.Filled.PushPin, Loc.Dir(it.path), it) }
    return base + pins
}

@Composable
private fun SearchField(b: Browser) {
    val pal = LocalPal.current
    Row(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(44.dp).clip(CircleShape).background(pal.card).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = pal.sub, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (b.query.isEmpty()) Text(stringResource(R.string.search_hint), color = pal.sub, fontSize = 16.sp, maxLines = 1)
            BasicTextField(
                b.query, { if (it.length <= 80) b.query = it }, Modifier.fillMaxWidth(), singleLine = true,
                textStyle = TextStyle(color = pal.fg, fontSize = 16.sp), cursorBrush = SolidColor(pal.accent)
            )
        }
        if (b.query.isNotEmpty()) {
            Box(
                Modifier.size(28.dp).clip(CircleShape).clickable(remember { MutableInteractionSource() }, null) { b.query = "" },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Close, null, tint = pal.sub, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
fun QuickTabs(b: Browser, onPin: (Pin) -> Unit) {
    val pal = LocalPal.current
    val quick = rememberQuick(b.set)
    val fadePx = with(LocalDensity.current) { 18.dp.toPx() }
    LazyRow(
        Modifier.fillMaxWidth().fadeEdgesH(fadePx),
        contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(quick, key = { it.loc.encode() + (it.pin?.path ?: "") }) { q ->
            val on = b.loc == q.loc
            val fg = if (on) Color.White else pal.fg
            Row(
                Modifier.height(38.dp).clip(CircleShape).background(if (on) pal.accent else pal.card)
                    .tapLong({ b.go(q.loc) }, { q.pin?.let(onPin) }).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(q.icon, null, tint = if (on) Color.White else kindColor(if (q.pin != null) Kind.FOLDER else Kind.OTHER).copy(alpha = if (q.pin != null) 1f else .9f), modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(6.dp))
                Text(q.label, color = fg, fontSize = 15.sp, maxLines = 1, lineHeight = 19.sp)
            }
        }
    }
}

private fun groupShape(first: Boolean, last: Boolean): Shape {
    val big = 24.dp
    val small = 6.dp
    return RoundedCornerShape(
        topStart = if (first) big else small, topEnd = if (first) big else small,
        bottomStart = if (last) big else small, bottomEnd = if (last) big else small
    )
}

@Composable
fun FilesPage(b: Browser, bottomPad: Dp, onContext: (FItem) -> Unit, onPin: (Pin) -> Unit, onGrant: (String) -> Unit) {
    val set = b.set
    val locale = LocalConfiguration.current.locales[0]
    val df = remember(locale) { dateFormat(locale) }
    val shown = remember(b.items, b.results, b.loc, set.sortBy, set.sortDesc, set.foldersFirst, set.showHidden) { b.visible() }
    val selecting = b.selected.isNotEmpty()
    val dens = LocalDensity.current
    val topPx = with(dens) { 34.dp.toPx() }
    val botPx = with(dens) { (bottomPad - 6.dp).toPx() }
    val gp = b.grantPath
    Column(Modifier.fillMaxSize()) {
        SearchField(b)
        Spacer(Modifier.height(8.dp))
        QuickTabs(b, onPin)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                gp != null -> GrantPanel(gp, onGrant)
                b.failed -> Message(R.string.err_read)
                shown.isEmpty() && !b.loading -> Message(if (b.query.isNotBlank()) (if (b.searching) R.string.searching else R.string.empty_search) else R.string.empty_folder)
                set.grid -> {
                    val gst = rememberLazyGridState()
                    LaunchedEffect(b.loc) { gst.scrollToItem(0) }
                    LazyVerticalGrid(
                        GridCells.Adaptive(104.dp), Modifier.fillMaxSize(), gst,
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
                        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(shown, key = { it.id }) { item ->
                            FileCell(
                                item, selecting, item.id in b.selected, Modifier.edgeFadeGrid(gst, item.id, topPx, botPx),
                                onTap = { if (selecting) b.toggle(item.id) else b.open(item) },
                                onLong = { onContext(item) }, onIcon = { b.toggle(item.id) }
                            )
                        }
                    }
                }
                else -> {
                    val st = rememberLazyListState()
                    LaunchedEffect(b.loc) { st.scrollToItem(0) }
                    LazyColumn(
                        Modifier.fillMaxSize(), st,
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = bottomPad),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        itemsIndexed(shown, key = { _, x -> x.id }) { i, item ->
                            FileRow(
                                item, df, selecting, item.id in b.selected, groupShape(i == 0, i == shown.lastIndex),
                                Modifier.edgeFade(st, item.id, topPx, botPx),
                                onTap = { if (selecting) b.toggle(item.id) else b.open(item) },
                                onLong = { onContext(item) }, onIcon = { b.toggle(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}
