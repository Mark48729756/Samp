package com.embededly.Files

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Долгие операции (копирование, перенос, удаление, архивы) живут вне Compose и переживают пересоздание окна. */
object Ops {
    const val OK = 0
    const val CANCELLED = 1
    const val FAILED = 2

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    var active by mutableStateOf(false)
        private set
    var title by mutableIntStateOf(0)
        private set
    var total by mutableIntStateOf(1)
        private set
    var done by mutableIntStateOf(0)
    var current by mutableStateOf("")

    fun run(titleRes: Int, count: Int, onFinish: (Int) -> Unit, block: (Job) -> Unit) {
        if (active) return
        title = titleRes; total = count.coerceAtLeast(1); done = 0; current = ""; active = true
        job = scope.launch(Dispatchers.IO) {
            val me = coroutineContext[Job]!!
            var res = FAILED
            try {
                block(me)
                res = OK
            } catch (e: CancellationException) {
                res = CANCELLED
            } catch (e: Exception) {
                res = FAILED
            } finally {
                withContext(NonCancellable + Dispatchers.Main) {
                    active = false
                    onFinish(res)
                }
            }
        }
    }

    fun cancel() { job?.cancel() }
}
