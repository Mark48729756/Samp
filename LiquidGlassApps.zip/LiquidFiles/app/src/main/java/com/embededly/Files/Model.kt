package com.embededly.Files

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import androidx.compose.runtime.Immutable
import java.text.DateFormat
import java.util.Date
import java.util.Locale

enum class Src { FS, SAF, ZIP }

enum class Kind { FOLDER, IMAGE, VIDEO, AUDIO, DOC, TEXT, ARCHIVE, APK, OTHER }

private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif")
private val VID = setOf("mp4", "mkv", "webm", "3gp", "avi", "mov", "m4v", "flv", "wmv", "mpg", "mpeg")
private val AUD = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "oga", "opus", "amr", "mid", "midi", "wma")
private val DOC = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "rtf", "epub", "fb2", "djvu")
private val TXT = setOf(
    "txt", "log", "md", "json", "xml", "csv", "tsv", "html", "htm", "css", "js", "ts", "kt", "kts", "java", "py", "c", "cpp", "h",
    "cs", "sh", "yml", "yaml", "ini", "conf", "cfg", "properties", "gradle", "sql", "svg", "bat", "lua", "php", "rs", "go", "toml"
)
private val ARC = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "jar", "aar")
private val APKS = setOf("apk", "apks", "xapk", "apkm")
private val ZIPLIKE = setOf("zip", "jar", "apk", "apks", "xapk", "apkm", "aar")

/** Элемент списка: файл, папка, документ SAF или запись внутри архива. id — путь, content-uri или путь записи в zip. */
@Immutable
data class FItem(
    val id: String, val name: String, val dir: Boolean, val size: Long, val modified: Long,
    val src: Src = Src.FS, val sub: String? = null,
) {
    val ext: String get() = if (name.contains('.')) name.substringAfterLast('.').lowercase(Locale.ROOT) else ""
    val kind: Kind
        get() = if (dir) Kind.FOLDER else when (ext) {
            in IMG -> Kind.IMAGE
            in VID -> Kind.VIDEO
            in AUD -> Kind.AUDIO
            in DOC -> Kind.DOC
            in TXT -> Kind.TEXT
            in APKS -> Kind.APK
            in ARC -> Kind.ARCHIVE
            else -> Kind.OTHER
        }
    val hidden: Boolean get() = name.startsWith(".")
    val zipLike: Boolean get() = !dir && src == Src.FS && ext in ZIPLIKE
    val mime: String
        get() = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: if (kind == Kind.TEXT) "text/plain" else "application/octet-stream"
}

fun mimeOfName(name: String): String = FItem("", name, false, 0, 0).mime

/** Где мы сейчас: папка, быстрая вкладка-категория или содержимое архива. Хранится строкой, чтобы переживать пересоздание. */
sealed interface Loc {
    data class Dir(val path: String) : Loc
    data class Cat(val cat: Int) : Loc
    data class Zip(val zip: String, val inner: String) : Loc

    fun encode(): String = when (this) {
        is Dir -> "d:$path"
        is Cat -> "c:$cat"
        is Zip -> "z:$zip|$inner"
    }

    companion object {
        fun decode(s: String, fallback: String): Loc = runCatching {
            when {
                s.startsWith("d:") -> Dir(s.substring(2))
                s.startsWith("c:") -> Cat(s.substring(2).toInt())
                s.startsWith("z:") -> Zip(s.substring(2).substringBefore('|'), s.substringAfter('|'))
                else -> Dir(fallback)
            }
        }.getOrDefault(Dir(fallback))
    }
}

/** Категории быстрых вкладок (номера хранятся в Loc.Cat). */
object Cat {
    const val IMAGES = 0
    const val VIDEO = 1
    const val MUSIC = 2
    const val DOCS = 3
    const val ARCHIVES = 4
    const val APK = 5
    const val RECENT = 6
}

fun fmtSize(ctx: Context, bytes: Long): String = Formatter.formatFileSize(ctx, bytes)

fun dateFormat(locale: Locale): DateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale)

fun fmtDate(df: DateFormat, ms: Long): String = if (ms <= 0L) "" else df.format(Date(ms))

fun fmtDuration(ms: Int): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s / 60) % 60
    val ss = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, ss) else "%d:%02d".format(m, ss)
}

/** Язык приложения: по умолчанию язык системы, свой выбор — необязателен. */
object Lang {
    val TAGS = listOf(
        "ru", "en", "uk", "be", "kk", "uz", "az", "ky", "tg", "tr", "de", "fr", "es", "it", "pt", "nl", "pl", "cs", "ro", "el",
        "sv", "ko", "ja", "zh-CN", "zh-TW", "ar", "he", "hi", "id", "vi", "th", "fa", "ka"
    )

    fun wrap(base: Context, tag: String): Context {
        if (tag == "system") {
            Locale.setDefault(Resources.getSystem().configuration.locales[0])
            return base
        }
        val l = Locale.forLanguageTag(tag)
        Locale.setDefault(l)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(l)
        cfg.setLayoutDirection(l)
        return base.createConfigurationContext(cfg)
    }

    fun nativeName(tag: String): String {
        val l = Locale.forLanguageTag(tag)
        return l.getDisplayName(l).replaceFirstChar { it.titlecase(l) }
    }
}
