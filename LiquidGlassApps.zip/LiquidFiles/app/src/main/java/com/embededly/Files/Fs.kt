package com.embededly.Files

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class Vol(val root: String, val label: String, val primary: Boolean, val uuid: String?)

/** Окружение: тома хранилища и контекст приложения для операций вне Compose. */
object Env {
    lateinit var app: Context
    var vols: List<Vol> = emptyList()

    fun init(ctx: Context) {
        app = ctx.applicationContext
        vols = readVolumes(ctx)
    }

    val primaryRoot: String get() = Environment.getExternalStorageDirectory().path

    fun volOf(path: String): Vol? =
        vols.filter { path == it.root || path.startsWith(it.root + "/") }.maxByOrNull { it.root.length }

    fun isRoot(path: String): Boolean = vols.any { it.root == path }

    private fun readVolumes(ctx: Context): List<Vol> {
        val sm = ctx.getSystemService(StorageManager::class.java)
        val primary = Environment.getExternalStorageDirectory().path
        val out = ArrayList<Vol>()
        out.add(Vol(primary, ctx.getString(R.string.internal_storage), true, null))
        for (d in ctx.getExternalFilesDirs(null)) {
            val p = d?.path ?: continue
            val root = p.substringBefore("/Android/data")
            if (root == p || root == primary || out.any { it.root == root }) continue
            val sv = sm.getStorageVolume(File(root))
            out.add(Vol(root, sv?.getDescription(ctx) ?: File(root).name, false, sv?.uuid))
        }
        return out
    }
}

/** Android 11+ не отдаёт Android/data и Android/obb через обычный File-доступ даже с MANAGE_EXTERNAL_STORAGE. */
fun isRestricted(path: String): Boolean {
    if (Build.VERSION.SDK_INT < 30) return false
    val v = Env.volOf(path) ?: return false
    val rel = path.removePrefix(v.root)
    return rel == "/Android/data" || rel.startsWith("/Android/data/") || rel == "/Android/obb" || rel.startsWith("/Android/obb/")
}

fun safDocId(path: String): String? {
    val v = Env.volOf(path) ?: return null
    val vid = if (v.primary) "primary" else (v.uuid ?: return null)
    return vid + ":" + path.removePrefix(v.root).removePrefix("/")
}

/** Папка из ограниченной зоны, уже выданная через системный выбор папки (SAF), или null. */
fun safGrantFor(path: String): Uri? {
    val docId = safDocId(path) ?: return null
    for (g in Env.app.contentResolver.persistedUriPermissions) {
        if (!g.isReadPermission || !g.isWritePermission) continue
        val tid = runCatching { DocumentsContract.getTreeDocumentId(g.uri) }.getOrNull() ?: continue
        if (docId == tid || docId.startsWith("$tid/")) return DocumentsContract.buildDocumentUriUsingTree(g.uri, docId)
    }
    return null
}

sealed interface Listing {
    class Ok(val items: List<FItem>) : Listing
    class NeedGrant(val path: String) : Listing
    data object Failed : Listing
}

fun listDir(path: String): Listing {
    if (isRestricted(path)) {
        val uri = safGrantFor(path) ?: return Listing.NeedGrant(path)
        return Listing.Ok(listSaf(uri))
    }
    val kids = File(path).listFiles() ?: return Listing.Failed
    return Listing.Ok(kids.map { f -> FItem(f.path, f.name, f.isDirectory, if (f.isDirectory) -1L else f.length(), f.lastModified()) })
}

fun listSaf(doc: Uri): List<FItem> {
    val kids = DocumentsContract.buildChildDocumentsUriUsingTree(doc, DocumentsContract.getDocumentId(doc))
    val out = ArrayList<FItem>()
    val cols = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED)
    Env.app.contentResolver.query(kids, cols, null, null, null)?.use { c ->
        while (c.moveToNext()) {
            val did = c.getString(0)
            val dir = c.getString(2) == Document.MIME_TYPE_DIR
            out.add(
                FItem(
                    DocumentsContract.buildDocumentUriUsingTree(doc, did).toString(), c.getString(1) ?: did, dir,
                    if (dir) -1L else c.getLong(3), c.getLong(4), Src.SAF
                )
            )
        }
    }
    return out
}

fun openZip(path: String): ZipFile = ZipFile(File(path))

/** Содержимое архива на уровне inner («» или «папка/»). */
fun listZip(zip: String, inner: String): List<FItem> {
    val dirs = LinkedHashMap<String, Long>()
    val files = LinkedHashMap<String, FItem>()
    openZip(zip).use { z ->
        val en = z.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            val n = e.name.trimStart('/')
            if (!n.startsWith(inner)) continue
            val rest = n.removePrefix(inner)
            if (rest.isEmpty()) continue
            val first = rest.substringBefore('/')
            if (first.isEmpty()) continue
            if (rest.contains('/')) {
                if (!dirs.containsKey(first)) dirs[first] = e.time
            } else if (!e.isDirectory) {
                files[first] = FItem(inner + first, first, false, e.size, e.time, Src.ZIP)
            } else if (!dirs.containsKey(first)) dirs[first] = e.time
        }
    }
    val out = ArrayList<FItem>()
    dirs.forEach { (n, t) -> out.add(FItem("$inner$n/", n, true, -1L, t, Src.ZIP)) }
    out.addAll(files.values)
    return out
}

fun childrenOf(it: FItem): List<FItem> = when (it.src) {
    Src.FS -> (File(it.id).listFiles() ?: emptyArray()).map { f -> FItem(f.path, f.name, f.isDirectory, if (f.isDirectory) -1L else f.length(), f.lastModified()) }
    Src.SAF -> listSaf(Uri.parse(it.id))
    Src.ZIP -> emptyList()
}

fun dirItemForPath(path: String): FItem? {
    if (isRestricted(path)) {
        val u = safGrantFor(path) ?: return null
        return FItem(u.toString(), File(path).name, true, -1L, 0L, Src.SAF)
    }
    return FItem(path, File(path).name, true, -1L, 0L)
}

fun openIn(it: FItem): InputStream = when (it.src) {
    Src.FS -> FileInputStream(it.id)
    Src.SAF -> Env.app.contentResolver.openInputStream(Uri.parse(it.id)) ?: throw java.io.IOException("open failed")
    Src.ZIP -> throw java.io.IOException("zip")
}

fun mkdir(dest: FItem, name: String): FItem? = when (dest.src) {
    Src.FS -> {
        val f = File(dest.id, name)
        if (f.mkdir()) FItem(f.path, f.name, true, -1L, f.lastModified()) else null
    }
    Src.SAF -> DocumentsContract.createDocument(Env.app.contentResolver, Uri.parse(dest.id), Document.MIME_TYPE_DIR, name)
        ?.let { FItem(it.toString(), name, true, -1L, 0L, Src.SAF) }
    Src.ZIP -> null
}

fun createFile(dest: FItem, name: String): FItem? = when (dest.src) {
    Src.FS -> {
        val f = File(dest.id, name)
        if (f.createNewFile()) FItem(f.path, f.name, false, 0L, f.lastModified()) else null
    }
    Src.SAF -> DocumentsContract.createDocument(Env.app.contentResolver, Uri.parse(dest.id), mimeOfName(name), name)
        ?.let { FItem(it.toString(), name, false, 0L, 0L, Src.SAF) }
    Src.ZIP -> null
}

fun outStream(it: FItem): OutputStream = when (it.src) {
    Src.FS -> FileOutputStream(it.id)
    Src.SAF -> Env.app.contentResolver.openOutputStream(Uri.parse(it.id), "wt") ?: throw java.io.IOException("open failed")
    Src.ZIP -> throw java.io.IOException("zip")
}

fun deleteItem(it: FItem): Boolean = when (it.src) {
    Src.FS -> File(it.id).deleteRecursively()
    Src.SAF -> runCatching { DocumentsContract.deleteDocument(Env.app.contentResolver, Uri.parse(it.id)) }.getOrDefault(false)
    Src.ZIP -> false
}

fun renameItem(it: FItem, newName: String): Boolean = when (it.src) {
    Src.FS -> {
        val f = File(it.id)
        val t = File(f.parentFile, newName)
        !t.exists() && f.renameTo(t)
    }
    Src.SAF -> runCatching { DocumentsContract.renameDocument(Env.app.contentResolver, Uri.parse(it.id), newName) != null }.getOrDefault(false)
    Src.ZIP -> false
}

fun validName(n: String): Boolean = n.isNotBlank() && n != "." && n != ".." && !n.contains('/') && !n.contains('\u0000') && n.length <= 255

/** «имя (1).ext», если такое имя в папке уже занято. */
fun uniqueName(dest: FItem, name: String, dir: Boolean): String {
    val taken = childrenOf(dest).map { it.name }.toHashSet()
    if (name !in taken) return name
    val base = if (!dir && name.contains('.') && !name.startsWith(".")) name.substringBeforeLast('.') else name
    val ext = if (!dir && name.contains('.') && !name.startsWith(".")) "." + name.substringAfterLast('.') else ""
    var i = 1
    while (true) {
        val c = "$base ($i)$ext"
        if (c !in taken) return c
        i++
    }
}

private fun copyStream(i: InputStream, o: OutputStream, job: Job?) {
    val buf = ByteArray(256 * 1024)
    while (true) {
        job?.ensureActive()
        val n = i.read(buf)
        if (n < 0) break
        o.write(buf, 0, n)
    }
}

/** Папка нельзя копировать/переносить саму в себя. */
fun isInside(parent: FItem, child: FItem): Boolean =
    parent.src == Src.FS && child.src == Src.FS && (child.id == parent.id || child.id.startsWith(parent.id + "/"))

/** Копирует item внутрь dest. fresh = dest только что создан (конфликтов имён нет). */
fun copyInto(item: FItem, dest: FItem, job: Job?, fresh: Boolean = false, onFile: (String) -> Unit = {}): FItem? {
    job?.ensureActive()
    val name = if (fresh) item.name else uniqueName(dest, item.name, item.dir)
    if (item.dir) {
        val nd = mkdir(dest, name) ?: return null
        for (c in childrenOf(item)) if (copyInto(c, nd, job, true, onFile) == null) return null
        return nd
    }
    onFile(item.name)
    val out = createFile(dest, name) ?: return null
    openIn(item).use { i -> outStream(out).use { o -> copyStream(i, o, job) } }
    if (item.src == Src.FS && out.src == Src.FS && item.modified > 0) File(out.id).setLastModified(item.modified)
    return out
}

/** Перенос: на одном томе — мгновенное переименование, иначе копирование и удаление источника. */
fun moveInto(item: FItem, dest: FItem, job: Job?, onFile: (String) -> Unit = {}): FItem? {
    if (item.src == Src.FS && dest.src == Src.FS) {
        val name = uniqueName(dest, item.name, item.dir)
        val t = File(dest.id, name)
        if (File(item.id).renameTo(t)) return FItem(t.path, t.name, item.dir, item.size, item.modified)
    }
    val copy = copyInto(item, dest, job, false, onFile) ?: return null
    return if (deleteItem(item)) copy else null
}

private fun addToZip(zos: ZipOutputStream, item: FItem, prefix: String, job: Job?, onFile: (String) -> Unit) {
    job?.ensureActive()
    if (item.dir) {
        val e = ZipEntry(prefix + item.name + "/")
        if (item.modified > 0) e.time = item.modified
        zos.putNextEntry(e); zos.closeEntry()
        for (c in childrenOf(item)) addToZip(zos, c, prefix + item.name + "/", job, onFile)
    } else {
        onFile(item.name)
        val e = ZipEntry(prefix + item.name)
        if (item.modified > 0) e.time = item.modified
        zos.putNextEntry(e)
        openIn(item).use { copyStream(it, zos, job) }
        zos.closeEntry()
    }
}

/** Упаковывает items в новый zip внутри dest. */
fun zipInto(items: List<FItem>, dest: FItem, archiveName: String, job: Job?, onFile: (String) -> Unit): FItem? {
    val out = createFile(dest, uniqueName(dest, archiveName, false)) ?: return null
    try {
        ZipOutputStream(outStream(out).buffered()).use { zos -> items.forEach { addToZip(zos, it, "", job, onFile) } }
    } catch (e: Exception) {
        deleteItem(out)
        throw e
    }
    return out
}

/** Распаковывает записи архива (prefixes — пути записей или папок «a/b/») в папку destDir. Защита от «zip slip». */
fun unzipTo(zip: String, prefixes: List<String>?, destDir: File, job: Job?, onFile: (String) -> Unit) {
    destDir.mkdirs()
    val base = destDir.canonicalPath + File.separator
    openZip(zip).use { z ->
        val en = z.entries()
        while (en.hasMoreElements()) {
            job?.ensureActive()
            val e = en.nextElement()
            val n = e.name.trimStart('/')
            if (n.isEmpty()) continue
            if (prefixes != null && prefixes.none { p -> n == p || (p.endsWith("/") && n.startsWith(p)) }) continue
            val rel = if (prefixes != null) {
                val top = prefixes.first { p -> n == p || (p.endsWith("/") && n.startsWith(p)) }
                val parent = top.trimEnd('/').substringBeforeLast('/', "")
                if (parent.isEmpty()) n else n.removePrefix("$parent/")
            } else n
            val t = File(destDir, rel)
            if (!t.canonicalPath.startsWith(base)) throw java.io.IOException("bad entry")
            if (e.isDirectory) { t.mkdirs(); continue }
            t.parentFile?.mkdirs()
            onFile(t.name)
            z.getInputStream(e).use { i -> FileOutputStream(t).use { o -> copyStream(i, o, job) } }
            if (e.time > 0) t.setLastModified(e.time)
        }
    }
}

fun unzipEntryToCache(zip: String, entry: String, job: Job?): File {
    val dir = File(Env.app.cacheDir, "zipview").apply { mkdirs() }
    val t = File(dir, entry.substringAfterLast('/'))
    openZip(zip).use { z ->
        val e = z.getEntry(entry) ?: throw java.io.IOException("no entry")
        z.getInputStream(e).use { i -> FileOutputStream(t).use { o -> copyStream(i, o, job) } }
    }
    return t
}

/** Итоговый размер и число объектов внутри папки (для «Свойств»). */
fun measure(it: FItem, job: Job? = null): Pair<Long, Int> {
    if (!it.dir) return (if (it.size >= 0) it.size else 0L) to 1
    var size = 0L
    var count = 0
    val stack = ArrayDeque<FItem>()
    stack.add(it)
    while (stack.isNotEmpty()) {
        job?.ensureActive()
        for (c in childrenOf(stack.removeLast())) {
            if (c.dir) stack.add(c) else { size += c.size.coerceAtLeast(0); count++ }
        }
    }
    return size to count
}

/** Обновляет системный индекс медиа: удалённые файлы пропадают из «Картинок», «Видео» и т.д., новые появляются. */
fun scanPaths(paths: List<String>) {
    val all = ArrayList<String>()
    for (p in paths) {
        val f = File(p)
        if (f.isDirectory) {
            var n = 0
            for (x in f.walkTopDown()) { if (x.isFile) { all.add(x.path); if (++n >= 400) break } }
        } else all.add(p)
    }
    if (all.isNotEmpty()) MediaScannerConnection.scanFile(Env.app, all.toTypedArray(), null, null)
}
