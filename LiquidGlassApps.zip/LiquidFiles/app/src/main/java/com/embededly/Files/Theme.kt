package com.embededly.Files

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.LocalOverscrollFactory
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

@Immutable
data class Pal(val bg: Color, val fg: Color, val sub: Color, val glass: Color, val accent: Color, val dark: Boolean, val card: Color)

val LocalPal = staticCompositionLocalOf<Pal> { error("no Pal") }

/** Точка последнего касания: окна «вываливаются» из неё как капля. */
val LocalTouch = staticCompositionLocalOf { mutableStateOf(Offset.Unspecified) }

val Danger = Color(0xFFFF3B30)

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Тема: 0 — как в системе, 1 — тёмная (по умолчанию, чёрный фон), 2 — светлая. */
@Composable
fun FilesTheme(settings: Settings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val accent = Color(0xFF3478F6)
    val pal = if (dark) Pal(
        bg = Color.Black, fg = Color.White, sub = Color(0xFF8E8E93),
        glass = Color(0xFF2A2A2C).copy(alpha = .80f), accent = accent, dark = true, card = Color(0xFF1C1C1E)
    ) else Pal(
        bg = Color(0xFFF2F2F7), fg = Color.Black, sub = Color(0xFF6C6C70),
        glass = Color.White.copy(alpha = .78f), accent = accent, dark = false, card = Color.White
    )
    val view = LocalView.current
    SideEffect {
        val w = view.context.findActivity()?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    val touch = remember { mutableStateOf(Offset.Unspecified) }
    CompositionLocalProvider(LocalPal provides pal, LocalTouch provides touch, LocalOverscrollFactory provides null) {
        Box(Modifier.fillMaxSize().pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val c = awaitPointerEvent(PointerEventPass.Initial).changes.firstOrNull()
                    if (c != null && c.pressed && !c.previousPressed) touch.value = c.position
                }
            }
        }) { content() }
    }
}
