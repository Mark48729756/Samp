package com.embededly.Files

/** Запрос на выбор файла от другого приложения (GET_CONTENT / OPEN_DOCUMENT): что можно выбирать и что сделать с результатом. */
class PickReq(val multiple: Boolean, val mimes: List<String>, val done: (List<FItem>) -> Unit)

object Pick {
    var req: PickReq? = null

    /** Подходит ли файл под запрошенные типы (любой, image и т.п., точный тип). */
    fun accepts(item: FItem): Boolean {
        val r = req ?: return true
        if (item.dir) return false
        val m = item.mime
        return r.mimes.isEmpty() || r.mimes.any { it == "*/*" || it == "*" || it == m || (it.endsWith("/*") && m.startsWith(it.dropLast(1))) }
    }
}
