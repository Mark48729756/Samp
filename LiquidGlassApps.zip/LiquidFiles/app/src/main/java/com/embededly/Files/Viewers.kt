package com.embededly.Files

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

private fun decodeFull(ctx: Context, item: FItem): Bitmap? {
    return runCatching {
        val src = when (item.src) {
            Src.FS -> ImageDecoder.createSource(File(item.id))
            Src.SAF -> ImageDecoder.createSource(ctx.contentResolver, Uri.parse(item.id))
            Src.ZIP -> return null
        }
        ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = maxOf(info.size.width, info.size.height)
            if (m > 3000) dec.setTargetSampleSize(m / 3000 + 1)
        }
    }.getOrNull()
}

@Composable
private fun ZoomImage(item: FItem, onZoom: (Boolean) -> Unit, onTap: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    var bmp by remember(item.id) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(item.id) { mutableStateOf(false) }
    LaunchedEffect(item.id) {
        bmp = withContext(Dispatchers.IO) { decodeFull(ctx, item) }
        failed = bmp == null
    }
    var scale by remember(item.id) { mutableFloatStateOf(1f) }
    var off by remember(item.id) { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(item.id) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) { scale = 1f; off = Offset.Zero } else scale = 2.5f
                        onZoom(scale > 1f)
                    }
                )
            }
            .pointerInput(item.id) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        if (ev.changes.none { it.isConsumed }) {
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            if (ev.changes.size > 1 || scale > 1f) {
                                val ns = (scale * zoom).coerceIn(1f, 6f)
                                val mx = size.width * (ns - 1f) / 2f
                                val my = size.height * (ns - 1f) / 2f
                                off = if (ns <= 1f) Offset.Zero else Offset((off.x + pan.x).coerceIn(-mx, mx), (off.y + pan.y).coerceIn(-my, my))
                                scale = ns
                                onZoom(ns > 1f)
                                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), null,
                Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y },
                contentScale = ContentScale.Fit
            )
        } else if (failed) {
            Text(stringResource(R.string.err_failed), color = pal.sub, fontSize = 16.sp)
        }
    }
}

@Composable
private fun ViewerButton(backdrop: com.kyant.backdrop.Backdrop, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val pal = LocalPal.current
    GlassKey(backdrop, CircleShape, pal.glass, Modifier.size(46.dp), onTap = onClick) { Icon(icon, null, tint = pal.fg) }
}

/** Просмотр картинок: листание, масштаб щипком и двойным касанием. */
@Composable
fun ImageViewer(items: List<FItem>, start: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = start) { items.size }
    val vb = rememberLayerBackdrop()
    var zoomed by remember { mutableStateOf(false) }
    var chrome by remember { mutableStateOf(true) }
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(vb).background(Color.Black)) {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), userScrollEnabled = !zoomed) { p ->
                ZoomImage(items[p], onZoom = { z -> if (pager.currentPage == p) zoomed = z }, onTap = { chrome = !chrome })
            }
        }
        AnimatedVisibility(chrome, Modifier.align(Alignment.TopCenter), enter = fadeIn(), exit = fadeOut()) {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                ViewerButton(vb, Icons.AutoMirrored.Filled.ArrowBack, onClose)
                Text(
                    items[pager.currentPage].name, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                )
                ViewerButton(vb, Icons.Filled.Share) { Act.share(ctx, listOf(items[pager.currentPage])) }
            }
        }
    }
}

/** Встроенный плеер видео и аудио с собственными стеклянными кнопками и ползунком. */
@Composable
fun PlayerViewer(item: FItem, onClose: () -> Unit) {
    val pal = LocalPal.current
    val ctx = LocalContext.current
    val vb = rememberLayerBackdrop()
    var vv by remember { mutableStateOf<VideoView?>(null) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(0) }
    var err by remember { mutableStateOf(false) }
    val uri = remember(item.id) { if (item.src == Src.SAF) Uri.parse(item.id) else Uri.fromFile(File(item.id)) }
    BackHandler(onBack = onClose)
    LaunchedEffect(vv) {
        while (true) {
            vv?.let { pos = it.currentPosition; playing = it.isPlaying }
            delay(250)
        }
    }
    DisposableEffect(Unit) { onDispose { vv?.stopPlayback() } }
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(vb).background(Color.Black), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { c ->
                    VideoView(c).apply {
                        setVideoURI(uri)
                        setOnPreparedListener { mp -> dur = mp.duration; start() }
                        setOnCompletionListener { playing = false; pos = dur }
                        setOnErrorListener { _, _, _ -> err = true; true }
                        vv = this
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            if (item.kind == Kind.AUDIO) Icon(Icons.Filled.MusicNote, null, tint = Color.White.copy(alpha = .35f), modifier = Modifier.size(120.dp))
            if (err) Text(stringResource(R.string.err_failed), color = Color.White, fontSize = 16.sp)
        }
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            ViewerButton(vb, Icons.AutoMirrored.Filled.ArrowBack, onClose)
            Text(item.name, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 12.dp))
            ViewerButton(vb, Icons.Filled.Share) { Act.share(ctx, listOf(item)) }
        }
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ViewerButton(vb, if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow) {
                vv?.let { v ->
                    if (v.isPlaying) { v.pause(); playing = false }
                    else { if (dur > 0 && pos >= dur - 300) v.seekTo(0); v.start(); playing = true }
                }
            }
            Spacer(Modifier.width(12.dp))
            Text(fmtDuration(pos), color = Color.White, fontSize = 13.sp, style = TNUM)
            Box(
                Modifier.weight(1f).height(36.dp).padding(horizontal = 10.dp)
                    .pointerInput(dur) { detectTapGestures { o -> if (dur > 0) { vv?.seekTo((o.x / size.width * dur).toInt().coerceIn(0, dur)) } } }
                    .pointerInput(dur) { detectHorizontalDragGestures { ch, _ -> if (dur > 0) { val t = (ch.position.x / size.width * dur).toInt().coerceIn(0, dur); vv?.seekTo(t); pos = t } } },
                contentAlignment = Alignment.CenterStart
            ) {
                val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
                Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = .25f)))
                Box(Modifier.fillMaxWidth(frac).height(5.dp).clip(CircleShape).background(pal.accent))
            }
            Text(fmtDuration(dur), color = Color.White, fontSize = 13.sp, style = TNUM)
        }
    }
}

/** Простой просмотр текстовых файлов (до ~400 КБ), построчно, чтобы не тормозить на больших файлах. */
@Composable
fun TextViewer(item: FItem, onClose: () -> Unit) {
    val pal = LocalPal.current
    val vb = rememberLayerBackdrop()
    var lines by remember(item.id) { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(item.id) {
        lines = withContext(Dispatchers.IO) {
            runCatching {
                openIn(item).use { s ->
                    val buf = ByteArray(400_000)
                    var n = 0
                    while (n < buf.size) { val r = s.read(buf, n, buf.size - n); if (r < 0) break; n += r }
                    String(buf, 0, n, Charsets.UTF_8).split('\n')
                }
            }.getOrDefault(listOf(""))
        }
    }
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().layerBackdrop(vb).background(pal.bg)) {
        val l = lines
        if (l != null) {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 120.dp, bottom = 40.dp)) {
                itemsIndexed(l) { _, line ->
                    Text(line, color = pal.fg, fontSize = 13.sp, lineHeight = 17.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        ViewerButton(vb, Icons.AutoMirrored.Filled.ArrowBack, onClose)
        Text(item.name, color = pal.fg, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 12.dp))
    }
}
