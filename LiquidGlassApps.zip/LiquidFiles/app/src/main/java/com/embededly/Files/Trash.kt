package com.embededly.Files

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Запись корзины: stored — имя файла в скрытой папке корзины на том же томе, orig — исходный путь. */
data class TrashEntry(val id: String, val orig: String, val name: String, val dir: Boolean, val size: Long, val time: Long, val stored: String)

/**
 * Корзина лежит в скрытой папке .LiquidTrash в корне того же тома, поэтому удаление и восстановление — мгновенное переименование.
 * Список записей хранится в filesDir/trash.json.
 */
object Trash {
    private val index get() = File(Env.app.filesDir, "trash.json")

    @Synchronized
    fun list(): List<TrashEntry> {
        val f = index
        if (!f.exists()) return emptyList()
        return runCatching {
            val a = JSONArray(f.readText())
            List(a.length()) {
                val o = a.getJSONObject(it)
                TrashEntry(o.getString("id"), o.getString("o"), o.getString("n"), o.getBoolean("d"), o.getLong("s"), o.getLong("t"), o.getString("p"))
            }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    private fun save(l: List<TrashEntry>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("o", it.orig).put("n", it.name).put("d", it.dir).put("s", it.size).put("t", it.time).put("p", it.stored)) }
        index.writeText(a.toString())
    }

    private fun dirFor(path: String): File {
        val root = Env.volOf(path)?.root ?: Env.primaryRoot
        val d = File(root, ".LiquidTrash")
        d.mkdirs()
        val nm = File(d, ".nomedia")
        if (!nm.exists()) runCatching { nm.createNewFile() }
        return d
    }

    @Synchronized
    fun moveToTrash(f: File): Boolean {
        val dir = dirFor(f.path)
        val stored = UUID.randomUUID().toString()
        val isDir = f.isDirectory
        val size = if (isDir) -1L else f.length()
        if (!f.renameTo(File(dir, stored))) return false
        save(list() + TrashEntry(stored, f.path, f.name, isDir, size, System.currentTimeMillis(), File(dir, stored).path))
        return true
    }

    @Synchronized
    fun restore(e: TrashEntry): Boolean {
        val src = File(e.stored)
        if (!src.exists()) { save(list().filter { it.id != e.id }); return false }
        val target = File(e.orig)
        val parent = target.parentFile ?: return false
        parent.mkdirs()
        val dest = FItem(parent.path, parent.name, true, -1L, 0L)
        val t = File(parent, uniqueName(dest, target.name, e.dir))
        if (!src.renameTo(t)) return false
        save(list().filter { it.id != e.id })
        scanPaths(listOf(t.path))
        return true
    }

    @Synchronized
    fun deleteForever(e: TrashEntry): Boolean {
        File(e.stored).deleteRecursively()
        save(list().filter { it.id != e.id })
        return true
    }

    @Synchronized
    fun purgeOld(days: Int) {
        val limit = System.currentTimeMillis() - days * 86_400_000L
        list().filter { it.time < limit }.forEach { deleteForever(it) }
    }

    fun asItem(e: TrashEntry) = FItem(e.id, e.name, e.dir, e.size, e.time, Src.FS, File(e.orig).parent)
}
