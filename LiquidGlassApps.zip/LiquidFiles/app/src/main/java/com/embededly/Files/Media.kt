package com.embededly.Files

import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.os.Bundle
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File

/** Быстрые вкладки-категории строятся по индексу MediaStore (мгновенно, без обхода всей памяти). */
object Media {
    private fun like(col: String, exts: List<String>) = exts.joinToString(" OR ", "(", ")") { "$col LIKE '%.$it'" }

    fun query(cat: Int, showHidden: Boolean): List<FItem> {
        val uri = MediaStore.Files.getContentUri("external")
        val where = StringBuilder()
        when (cat) {
            Cat.IMAGES -> where.append("${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}")
            Cat.VIDEO -> where.append("${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO}")
            Cat.MUSIC -> where.append("${MediaStore.Files.FileColumns.MEDIA_TYPE} = ${MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO}")
            Cat.DOCS -> where.append(
                "(${MediaStore.MediaColumns.MIME_TYPE} = 'application/pdf' OR ${MediaStore.MediaColumns.MIME_TYPE} LIKE 'text/%' OR ${MediaStore.MediaColumns.MIME_TYPE} LIKE 'application/vnd.%' " +
                    "OR ${MediaStore.MediaColumns.MIME_TYPE} = 'application/msword' OR ${MediaStore.MediaColumns.MIME_TYPE} = 'application/rtf' OR ${MediaStore.MediaColumns.MIME_TYPE} = 'application/epub+zip') " +
                    "AND ${MediaStore.MediaColumns.MIME_TYPE} != 'application/vnd.android.package-archive'"
            )
            Cat.ARCHIVES -> where.append(like(MediaStore.MediaColumns.DISPLAY_NAME, listOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz")))
            Cat.APK -> where.append(like(MediaStore.MediaColumns.DISPLAY_NAME, listOf("apk", "apks", "xapk", "apkm")))
            else -> where.append("${MediaStore.MediaColumns.MIME_TYPE} IS NOT NULL")
        }
        where.append(" AND ${MediaStore.MediaColumns.DATA} NOT LIKE '%/Android/data/%' AND ${MediaStore.MediaColumns.DATA} NOT LIKE '%/Android/obb/%' AND ${MediaStore.MediaColumns.DATA} NOT LIKE '%/.LiquidTrash/%'")
        if (!showHidden) where.append(" AND ${MediaStore.MediaColumns.DATA} NOT LIKE '%/.%'")
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, where.toString())
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")
            putInt(ContentResolver.QUERY_ARG_LIMIT, if (cat == Cat.RECENT) 200 else 20000)
        }
        val out = ArrayList<FItem>()
        val cols = arrayOf(MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED)
        Env.app.contentResolver.query(uri, cols, args, null)?.use { cur ->
            while (cur.moveToNext()) {
                val p = cur.getString(0) ?: continue
                val n = cur.getString(1) ?: File(p).name
                out.add(FItem(p, n, false, cur.getLong(2), cur.getLong(3) * 1000L, Src.FS, File(p).parent))
            }
        }
        return out
    }
}

/** Миниатюры файлов: изображения, видео, обложки аудио и иконки APK. Кэш в памяти, не больше трёх загрузок одновременно. */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val gate = Semaphore(3)

    fun hasThumb(it: FItem): Boolean = it.src == Src.FS && !it.dir && (it.kind == Kind.IMAGE || it.kind == Kind.VIDEO || it.kind == Kind.AUDIO || it.kind == Kind.APK)

    private fun key(it: FItem, px: Int) = it.id + "|" + it.modified + "|" + px

    fun peek(it: FItem, px: Int): Bitmap? = cache.get(key(it, px))

    suspend fun load(ctx: Context, item: FItem, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        gate.withPermit {
            val k = key(item, px)
            cache.get(k) ?: run {
                val f = File(item.id)
                val b = runCatching {
                    when (item.kind) {
                        Kind.IMAGE -> ThumbnailUtils.createImageThumbnail(f, Size(px, px), null)
                        Kind.VIDEO -> ThumbnailUtils.createVideoThumbnail(f, Size(px, px), null)
                        Kind.AUDIO -> ThumbnailUtils.createAudioThumbnail(f, Size(px, px), null)
                        Kind.APK -> {
                            val pm = ctx.packageManager
                            val info = pm.getPackageArchiveInfo(item.id, PackageManager.GET_ACTIVITIES)
                            val ai = info?.applicationInfo
                            if (ai != null) {
                                ai.sourceDir = item.id
                                ai.publicSourceDir = item.id
                                ai.loadIcon(pm).toBitmap(px, px)
                            } else null
                        }
                        else -> null
                    }
                }.getOrNull()
                if (b != null) cache.put(k, b)
                b
            }
        }
    }
}
