package com.embededly.Files

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) {
        // язык системы подхватывается сам; свой выбор из настроек накладываем здесь
        super.attachBaseContext(Lang.wrap(newBase, Settings.readLang(newBase)))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Env.init(this)
        val set = Settings(this)
        // нас вызвали как «выбор файла» из другого приложения
        val a = intent?.action
        Pick.req = if (a == Intent.ACTION_GET_CONTENT || a == Intent.ACTION_OPEN_DOCUMENT || a == Intent.ACTION_PICK) {
            val mimes = intent.getStringArrayExtra(Intent.EXTRA_MIME_TYPES)?.toList() ?: listOfNotNull(intent.type)
            PickReq(intent.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false), mimes) { items ->
                val uris = items.mapNotNull { Act.uriFor(this, it) }
                if (uris.isNotEmpty()) {
                    val clip = android.content.ClipData.newRawUri("", uris[0])
                    uris.drop(1).forEach { clip.addItem(android.content.ClipData.Item(it)) }
                    setResult(RESULT_OK, Intent().setData(uris[0]).setClipData(clip)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
                    finish()
                }
            }
        } else null
        setContent { FilesTheme(set) { FilesApp(set) } }
    }

    override fun onDestroy() { Pick.req = null; super.onDestroy() }

    override fun onResume() {
        super.onResume()
        Bus.version++
    }
}
