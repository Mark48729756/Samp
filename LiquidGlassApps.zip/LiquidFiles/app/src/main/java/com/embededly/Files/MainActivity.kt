package com.embededly.Files

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) {
        // язык системы подхватывается сам; свой выбор из настроек накладываем здесь
        super.attachBaseContext(Lang.wrap(newBase, Settings.readLang(newBase)))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Env.init(this)
        val set = Settings(this)
        setContent { FilesTheme(set) { FilesApp(set) } }
    }

    override fun onResume() {
        super.onResume()
        Bus.version++
    }
}
