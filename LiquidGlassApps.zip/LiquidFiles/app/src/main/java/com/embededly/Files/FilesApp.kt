package com.embededly.Files

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** Счётчик возвращений в приложение: после выдачи доступа в системных настройках экран сам обновляется. */
object Bus {
    var version by mutableIntStateOf(0)
}

fun hasAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
        ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

private sealed interface Dlg {
    data object NewFolder : Dlg
    data object NewFile : Dlg
    data class Rename(val item: FItem) : Dlg
    data class Ctx(val item: FItem) : Dlg
    data class Props(val items: List<FItem>) : Dlg
    data class Delete(val items: List<FItem>, val permanent: Boolean) : Dlg
    data class Zip(val items: List<FItem>) : Dlg
    data object Sort : Dlg
    data class PinMenu(val pin: Pin) : Dlg
    data class PinRename(val pin: Pin) : Dlg
    data object EmptyTrash : Dlg
    data class TrashDelete(val entries: List<TrashEntry>) : Dlg
    data object TrashDays : Dlg
    data object Language : Dlg
}

private fun catLabel(c: Int): Int = when (c) {
    Cat.IMAGES -> R.string.q_images
    Cat.VIDEO -> R.string.q_video
    Cat.MUSIC -> R.string.q_music
    Cat.DOCS -> R.string.q_docs
    Cat.ARCHIVES -> R.string.q_archives
    Cat.APK -> R.string.q_apk
    else -> R.string.q_recent
}

@Composable
private fun locTitle(l: Loc): String = when (l) {
    is Loc.Dir -> Env.volOf(l.path)?.takeIf { it.root == l.path }?.label ?: File(l.path).name.ifEmpty { "/" }
    is Loc.Cat -> stringResource(catLabel(l.cat))
    is Loc.Zip -> if (l.inner.isEmpty()) File(l.zip).name else l.inner.trimEnd('/').substringAfterLast('/')
}

private fun locSub(l: Loc): String? = when (l) {
    is Loc.Dir -> l.path
    is Loc.Zip -> l.zip + "!/" + l.inner
    is Loc.Cat -> null
}

@Composable
fun GlassIconButton(backdrop: Backdrop, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val pal = LocalPal.current
    GlassKey(backdrop, CircleShape, pal.glass, modifier.size(46.dp), onTap = onClick) { Icon(icon, null, tint = pal.fg) }
}

@Composable
fun FilesApp(set: Settings) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val backdrop = rememberLayerBackdrop()
    val scope = rememberCoroutineScope()
    val b = remember { Browser(ctx, set, scope) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val access = remember(Bus.version) { hasAccess(ctx) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var plusOpen by remember { mutableStateOf(false) }
    var moreOpen by remember { mutableStateOf(false) }
    val plusMorph = remember { MenuMorph() }
    val moreMorph = remember { MenuMorph() }
    var trashVer by remember { mutableIntStateOf(0) }
    var entries by remember { mutableStateOf<List<TrashEntry>>(emptyList()) }
    var trashSel by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showOps by remember { mutableStateOf(false) }

    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomPad = 64.dp + 10.dp + navBottom + 18.dp
    val barBottom = navBottom + 10.dp + 64.dp + 12.dp

    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { Bus.version++ }
    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            b.refresh++
        }
    }

    LaunchedEffect(b.loc, b.refresh, access) { if (access) b.load() }
    LaunchedEffect(b.query, b.loc, b.refresh, access) { if (access) b.search() }
    LaunchedEffect(access, tab, trashVer) {
        if (access) {
            entries = withContext(Dispatchers.IO) { Trash.list() }
            trashSel = trashSel.filter { id -> entries.any { it.id == id } }.toSet()
        }
    }
    LaunchedEffect(access) { if (access) withContext(Dispatchers.IO) { Trash.purgeOld(set.trashDays) } }
    LaunchedEffect(Ops.active) {
        if (Ops.active) { delay(400); showOps = Ops.active } else showOps = false
    }

    val selCount = if (tab == 2) trashSel.size else if (tab == 0) b.selected.size else 0
    val selecting = selCount > 0
    val inZip = b.loc is Loc.Zip

    fun selItems(): List<FItem> = b.visible().filter { it.id in b.selected }

    fun askDelete(items: List<FItem>) {
        val permanent = !set.useTrash || items.any { it.src != Src.FS }
        if (set.confirmDelete) dlg = Dlg.Delete(items, permanent) else b.delete(items, permanent)
    }

    fun restoreSel() {
        val sel = entries.filter { it.id in trashSel }
        Ops.run(R.string.op_restoring, sel.size, { res ->
            trashSel = emptySet(); trashVer++; b.refresh++
            if (res == Ops.FAILED) Act.toast(ctx, R.string.err_failed)
        }) { _ ->
            sel.forEachIndexed { i, e ->
                Ops.done = i; Ops.current = e.name
                if (!Trash.restore(e)) throw IOException("restore")
            }
        }
    }

    fun deleteTrash(list: List<TrashEntry>) {
        Ops.run(R.string.op_deleting, list.size, { _ -> trashSel = emptySet(); trashVer++ }) { _ ->
            list.forEachIndexed { i, e -> Ops.done = i; Ops.current = e.name; Trash.deleteForever(e) }
        }
    }

    fun requestGrant(path: String) {
        val id = safDocId(path)
        val initial = if (id != null) DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", id) else null
        runCatching { treePicker.launch(initial) }
    }

    fun ctxActions(item: FItem): List<ActionRow> {
        val l = b.loc
        val list = ArrayList<ActionRow>()
        fun add(icon: ImageVector, res: Int, danger: Boolean = false, f: () -> Unit) { list.add(ActionRow(icon, ctx.getString(res), danger, f)) }
        if (l is Loc.Zip) {
            add(Icons.AutoMirrored.Filled.OpenInNew, R.string.act_open) { b.open(item) }
            add(Icons.Filled.Unarchive, R.string.act_unzip_sel) { b.unzipEntries(listOf(item)) }
            add(Icons.Filled.Info, R.string.act_props) { dlg = Dlg.Props(listOf(item)) }
            return list
        }
        add(Icons.Filled.CheckCircle, R.string.select) { b.toggle(item.id) }
        if (!item.dir) {
            add(Icons.AutoMirrored.Filled.OpenInNew, R.string.act_open_with) { Act.open(ctx, item, true) }
            add(Icons.Filled.Share, R.string.act_share) { Act.share(ctx, listOf(item)) }
        }
        if (item.zipLike) {
            add(Icons.Filled.FolderZip, R.string.act_browse) { b.go(Loc.Zip(item.id, "")) }
            add(Icons.Filled.Unarchive, R.string.act_unzip) { b.unzipHere(item) }
        }
        if (item.dir && item.src == Src.FS) {
            val pinned = set.isPinned(item.id)
            add(Icons.Filled.PushPin, if (pinned) R.string.act_unpin else R.string.act_pin) { if (pinned) set.unpin(item.id) else set.pin(item.id) }
        }
        if (b.query.isNotEmpty() || l is Loc.Cat) add(Icons.Filled.FolderOpen, R.string.act_show_folder) { b.showInFolder(item) }
        add(Icons.Filled.ContentCopy, R.string.act_copy) { b.copyToClip(listOf(item), false) }
        add(Icons.Filled.ContentCut, R.string.act_move) { b.copyToClip(listOf(item), true) }
        add(Icons.Filled.DriveFileRenameOutline, R.string.act_rename) { dlg = Dlg.Rename(item) }
        if (l is Loc.Dir) add(Icons.Filled.Compress, R.string.act_zip) { dlg = Dlg.Zip(listOf(item)) }
        add(Icons.Filled.Delete, R.string.act_delete, true) { askDelete(listOf(item)) }
        if (item.src == Src.FS && set.useTrash) add(Icons.Filled.DeleteForever, R.string.act_delete_forever, true) { dlg = Dlg.Delete(listOf(item), true) }
        add(Icons.Filled.Info, R.string.act_props) { dlg = Dlg.Props(listOf(item)) }
        return list
    }

    BackHandler(enabled = access && (selecting || tab != 0 || b.query.isNotEmpty() || parentOf(b.loc) != null)) {
        when {
            tab == 2 && trashSel.isNotEmpty() -> trashSel = emptySet()
            tab == 0 && b.selected.isNotEmpty() -> b.selected = emptySet()
            tab != 0 -> tab = 0
            b.query.isNotEmpty() -> b.query = ""
            else -> b.up()
        }
    }

    val tabTitles = listOf(R.string.tab_files, R.string.tab_storage, R.string.tab_trash, R.string.tab_settings)
    val title = if (selecting) stringResource(R.string.selected_n, selCount) else when (tab) {
        0 -> locTitle(b.loc)
        else -> stringResource(tabTitles[tab])
    }

    Box(Modifier.fillMaxSize().background(pal.bg)) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop).background(pal.bg)) {
            if (!access) {
                PermissionPage {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val i = Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
                        try { ctx.startActivity(i) } catch (e: Exception) {
                            runCatching { ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                        }
                    } else legacyPerm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
                }
            } else {
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    Spacer(Modifier.height(56.dp))
                    Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp)) {
                        Box(Modifier.height(60.dp), contentAlignment = Alignment.CenterStart) {
                            Crossfade(title, animationSpec = tween(220), label = "title") {
                                Text(it, color = pal.fg, fontSize = 40.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        val sub = if (tab == 0 && !selecting) locSub(b.loc) else null
                        Text(sub ?: " ", color = pal.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.height(20.dp))
                    }
                    Box(Modifier.weight(1f)) {
                        AnimatedContent(
                            tab,
                            transitionSpec = {
                                val dir = if (targetState > initialState) 1 else -1
                                (slideInHorizontally(tween(340)) { it / 5 * dir } + fadeIn(tween(260))) togetherWith
                                    (slideOutHorizontally(tween(260)) { -it / 5 * dir } + fadeOut(tween(160)))
                            },
                            label = "tab"
                        ) { t ->
                            when (t) {
                                0 -> FilesPage(b, bottomPad, { dlg = Dlg.Ctx(it) }, { dlg = Dlg.PinMenu(it) }, { requestGrant(it) })
                                1 -> StoragePage(set, bottomPad) { tab = 0; b.go(it) }
                                2 -> TrashPage(entries, trashSel, bottomPad) { id -> trashSel = if (id in trashSel) trashSel - id else trashSel + id }
                                else -> SettingsPage(set, bottomPad, { dlg = Dlg.Sort }, { dlg = Dlg.TrashDays }, { dlg = Dlg.Language })
                            }
                        }
                    }
                }
            }
        }

        if (access) {
            GlassDock(
                backdrop, tab,
                listOf(
                    DockTab(Icons.Filled.Folder, stringResource(R.string.tab_files)),
                    DockTab(Icons.Filled.Storage, stringResource(R.string.tab_storage)),
                    DockTab(Icons.Filled.Delete, stringResource(R.string.tab_trash)),
                    DockTab(Icons.Filled.Settings, stringResource(R.string.tab_settings)),
                ),
                { tab = it; plusOpen = false; moreOpen = false; b.selected = emptySet(); trashSel = emptySet() },
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)
            )

            // панель действий над выделенным
            if (tab == 0 && b.selected.isNotEmpty() && Pick.req == null) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = barBottom).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inZip) {
                        GlassButton(stringResource(R.string.act_unzip_sel)) { b.unzipEntries(selItems()) }
                    } else {
                        GlassIconButton(backdrop, Icons.Filled.ContentCopy) { b.copyToClip(selItems(), false) }
                        GlassIconButton(backdrop, Icons.Filled.ContentCut) { b.copyToClip(selItems(), true) }
                        GlassIconButton(backdrop, Icons.Filled.Share) { Act.share(ctx, selItems()) }
                        GlassIconButton(backdrop, Icons.Filled.Delete) { askDelete(selItems()) }
                    }
                }
            }
            val clip = b.clip
            if (tab == 0 && clip != null && b.selected.isEmpty() && b.loc is Loc.Dir && b.grantPath == null) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = barBottom).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassButton(stringResource(if (clip.move) R.string.paste_move_n else R.string.paste_copy_n, clip.items.size)) { b.paste() }
                    GlassIconButton(backdrop, Icons.Filled.Close) { b.clip = null }
                }
            }
            if (tab == 2 && trashSel.isNotEmpty()) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = barBottom).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassButton(stringResource(R.string.act_restore)) { restoreSel() }
                    GlassButton(stringResource(R.string.act_delete_forever), color = Danger) { dlg = Dlg.TrashDelete(entries.filter { it.id in trashSel }) }
                }
            }

            // меню «+» и «⋮» (капля вылетает из-под кнопки)
            GlassMenu(
                plusOpen, backdrop, { plusOpen = false },
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 61.dp, end = 68.dp),
                anchor = Alignment.TopEnd, riseDp = -54f, riseXDp = 0f, minDp = 46f, menuWidthDp = 240f, morph = plusMorph
            ) {
                GlassMenuItem(stringResource(R.string.act_new_folder)) { plusOpen = false; dlg = Dlg.NewFolder }
                GlassMenuItem(stringResource(R.string.act_new_file)) { plusOpen = false; dlg = Dlg.NewFile }
            }
            GlassMenu(
                moreOpen, backdrop, { moreOpen = false },
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 61.dp, end = 12.dp),
                anchor = Alignment.TopEnd, riseDp = -54f, riseXDp = 0f, minDp = 46f, menuWidthDp = 270f, morph = moreMorph
            ) {
                fun close() { moreOpen = false }
                if (tab == 2) {
                    GlassMenuItem(stringResource(R.string.act_empty_trash)) { close(); if (entries.isNotEmpty()) dlg = Dlg.EmptyTrash }
                } else if (tab == 0) {
                    val sel = selItems()
                    val one = sel.singleOrNull()
                    if (sel.isNotEmpty()) {
                        GlassMenuItem(stringResource(R.string.select_none)) { close(); b.selected = emptySet() }
                        GlassMenuItem(stringResource(R.string.select_all)) { close(); b.selected = b.visible().map { it.id }.toSet() }
                        if (!inZip) {
                            if (one != null) {
                                GlassMenuItem(stringResource(R.string.act_rename)) { close(); dlg = Dlg.Rename(one) }
                                if (!one.dir) GlassMenuItem(stringResource(R.string.act_open_with)) { close(); Act.open(ctx, one, true) }
                                if (one.zipLike) {
                                    GlassMenuItem(stringResource(R.string.act_browse)) { close(); b.go(Loc.Zip(one.id, "")) }
                                    GlassMenuItem(stringResource(R.string.act_unzip)) { close(); b.unzipHere(one) }
                                }
                                if (one.dir && one.src == Src.FS) {
                                    val pinned = set.isPinned(one.id)
                                    GlassMenuItem(stringResource(if (pinned) R.string.act_unpin else R.string.act_pin)) { close(); if (pinned) set.unpin(one.id) else set.pin(one.id); b.selected = emptySet() }
                                }
                                if (b.query.isNotEmpty() || b.loc is Loc.Cat) GlassMenuItem(stringResource(R.string.act_show_folder)) { close(); b.showInFolder(one) }
                            }
                            if (b.loc is Loc.Dir) GlassMenuItem(stringResource(R.string.act_zip)) { close(); dlg = Dlg.Zip(sel) }
                            if (sel.all { it.src == Src.FS } && set.useTrash) GlassMenuItem(stringResource(R.string.act_delete_forever)) { close(); dlg = Dlg.Delete(sel, true) }
                        }
                        GlassMenuItem(stringResource(R.string.act_props)) { close(); dlg = Dlg.Props(sel) }
                    } else {
                        GlassMenuItem(stringResource(R.string.select_all)) { close(); b.selected = b.visible().map { it.id }.toSet() }
                        GlassMenuItem(stringResource(R.string.menu_sort)) { close(); dlg = Dlg.Sort }
                        GlassMenuItem(stringResource(if (set.grid) R.string.view_list else R.string.view_grid)) { close(); set.grid = !set.grid }
                        GlassMenuItem(stringResource(if (set.showHidden) R.string.menu_hidden_hide else R.string.menu_hidden_show)) { close(); set.showHidden = !set.showHidden; b.refresh++ }
                        GlassMenuItem(stringResource(R.string.menu_refresh)) { close(); b.refresh++ }
                        val dir = b.loc as? Loc.Dir
                        if (dir != null && b.grantPath == null) {
                            val pinned = set.isPinned(dir.path)
                            GlassMenuItem(stringResource(if (pinned) R.string.act_unpin else R.string.act_pin)) { close(); if (pinned) set.unpin(dir.path) else set.pin(dir.path) }
                        }
                        if (inZip) GlassMenuItem(stringResource(R.string.act_unzip)) { close(); b.unzipAll() }
                    }
                }
            }

            // кнопки рисуются ПОСЛЕ меню: у них свой стеклянный фон, и капля вылетает из-под кнопки
            if (selecting) {
                GlassIconButton(
                    backdrop, Icons.Filled.Close, Modifier.align(Alignment.TopStart).statusBarsPadding().padding(top = 7.dp, start = 12.dp)
                ) { if (tab == 2) trashSel = emptySet() else b.selected = emptySet() }
            } else if (tab == 0 && parentOf(b.loc) != null) {
                GlassIconButton(
                    backdrop, Icons.AutoMirrored.Filled.ArrowBack, Modifier.align(Alignment.TopStart).statusBarsPadding().padding(top = 7.dp, start = 12.dp)
                ) { b.up() }
            }
                if (tab == 0 && !selecting && b.loc is Loc.Dir && b.grantPath == null) {
                    MorphAnchor(
                        plusMorph, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 7.dp, end = 68.dp).size(46.dp),
                        glass = { m -> Box(m.glass(backdrop, CircleShape, pal.glass, 3f, 8f, 12f).border(1.dp, Color.White.copy(alpha = rimAlpha()), CircleShape)) },
                        icon = { Icon(Icons.Outlined.Add, null, tint = pal.fg) }, onClick = { moreOpen = false; plusOpen = !plusOpen }
                    )
                } else if (tab == 0 && selecting) {
                    GlassIconButton(
                        backdrop, Icons.Filled.SelectAll, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 7.dp, end = 68.dp)
                    ) { b.selected = b.visible().filter { Pick.req == null || Pick.accepts(it) }.map { it.id }.toSet() }
                }
                // выбор файлов для другого приложения: кнопка «готово»
                Pick.req?.let { pr ->
                    if (tab == 0 && selecting && pr.multiple) GlassIconButton(
                        backdrop, Icons.Filled.Check, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 7.dp, end = 124.dp)
                    ) { pr.done(selItems().filter { Pick.accepts(it) }) }
                }
                if (tab == 0 || (tab == 2 && !selecting)) {
                    MorphAnchor(
                        moreMorph, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 7.dp, end = 12.dp).size(46.dp),
                        glass = { m -> Box(m.glass(backdrop, CircleShape, pal.glass, 3f, 8f, 12f).border(1.dp, Color.White.copy(alpha = rimAlpha()), CircleShape)) },
                        icon = { Icon(Icons.Outlined.MoreVert, null, tint = pal.fg) }, onClick = { plusOpen = false; moreOpen = !moreOpen }
                    )
                }

            when (val v = b.viewer) {
                is Viewer.Images -> ImageViewer(v.items, v.index) { b.viewer = null }
                is Viewer.Player -> PlayerViewer(v.item) { b.viewer = null }
                is Viewer.Text -> TextViewer(v.item) { b.viewer = null }
                null -> {}
            }

            val strCancel = stringResource(R.string.act_cancel)
            when (val d = dlg) {
                Dlg.NewFolder -> NameDialog(backdrop, stringResource(R.string.act_new_folder), stringResource(R.string.folder_default_name), stringResource(R.string.act_create), false, { b.create(it, true) }, { dlg = null })
                Dlg.NewFile -> NameDialog(backdrop, stringResource(R.string.act_new_file), stringResource(R.string.file_default_name), stringResource(R.string.act_create), true, { b.create(it, false) }, { dlg = null })
                is Dlg.Rename -> NameDialog(backdrop, stringResource(R.string.act_rename), d.item.name, stringResource(R.string.act_rename), true, { b.rename(d.item, it) }, { dlg = null })
                is Dlg.Ctx -> ActionsDialog(backdrop, d.item.name, ctxActions(d.item)) { dlg = null }
                is Dlg.Props -> PropsDialog(backdrop, d.items) { dlg = null }
                is Dlg.Delete -> GlassConfirm(
                    backdrop, stringResource(R.string.del_title),
                    stringResource(if (d.permanent) R.string.del_forever_text else R.string.del_trash_text, d.items.size),
                    stringResource(R.string.act_delete), strCancel, danger = true,
                    onConfirm = { b.delete(d.items, d.permanent) }, onDismiss = { dlg = null }
                )
                is Dlg.Zip -> NameDialog(
                    backdrop, stringResource(R.string.zip_title),
                    if (d.items.size == 1) d.items[0].name.substringBeforeLast('.', d.items[0].name) else stringResource(R.string.zip_default_name),
                    stringResource(R.string.act_create), false, { b.zip(d.items, it) }, { dlg = null }
                )
                Dlg.Sort -> SortDialog(backdrop, set) { dlg = null }
                is Dlg.PinMenu -> {
                    val p = d.pin
                    ActionsDialog(
                        backdrop, p.title ?: File(p.path).name,
                        listOf(
                            ActionRow(Icons.Filled.DriveFileRenameOutline, stringResource(R.string.act_rename)) { dlg = Dlg.PinRename(p) },
                            ActionRow(Icons.Filled.PushPin, stringResource(R.string.pin_earlier)) { set.movePin(p.path, if (isRtl(ctx)) 1 else -1) },
                            ActionRow(Icons.Filled.PushPin, stringResource(R.string.pin_later)) { set.movePin(p.path, if (isRtl(ctx)) -1 else 1) },
                            ActionRow(Icons.Filled.Close, stringResource(R.string.act_unpin), true) { set.unpin(p.path) },
                        )
                    ) { dlg = null }
                }
                is Dlg.PinRename -> NameDialog(
                    backdrop, stringResource(R.string.pin_name_title), d.pin.title ?: File(d.pin.path).name, stringResource(R.string.act_ok), false,
                    { set.renamePin(d.pin.path, it) }, { dlg = null }
                )
                Dlg.EmptyTrash -> GlassConfirm(
                    backdrop, stringResource(R.string.act_empty_trash), stringResource(R.string.trash_empty_confirm),
                    stringResource(R.string.act_empty_trash), strCancel, danger = true,
                    onConfirm = { deleteTrash(entries) }, onDismiss = { dlg = null }
                )
                is Dlg.TrashDelete -> GlassConfirm(
                    backdrop, stringResource(R.string.del_title), stringResource(R.string.del_forever_text, d.entries.size),
                    stringResource(R.string.act_delete_forever), strCancel, danger = true,
                    onConfirm = { deleteTrash(d.entries) }, onDismiss = { dlg = null }
                )
                Dlg.TrashDays -> WheelDialog(
                    backdrop, stringResource(R.string.trash_days_title), 90, (set.trashDays - 1).coerceIn(0, 89),
                    { (it + 1).toString() }, { set.trashDays = it + 1 }, { dlg = null }
                )
                Dlg.Language -> ChoiceDialog(
                    backdrop, stringResource(R.string.s_language),
                    listOf(stringResource(R.string.lang_system)) + Lang.TAGS.map { Lang.nativeName(it) },
                    if (set.lang == "system") 0 else 1 + Lang.TAGS.indexOf(set.lang).coerceAtLeast(0),
                    { i ->
                        val tag = if (i == 0) "system" else Lang.TAGS[i - 1]
                        if (tag != set.lang) { set.lang = tag; ctx.findActivity()?.recreate() }
                    },
                    { dlg = null }
                )
                null -> {}
            }

            if (showOps && Ops.active) ProgressDialog(backdrop) { showOps = false }
        }
    }
}

private fun isRtl(ctx: Context): Boolean = ctx.resources.configuration.layoutDirection == android.view.View.LAYOUT_DIRECTION_RTL
