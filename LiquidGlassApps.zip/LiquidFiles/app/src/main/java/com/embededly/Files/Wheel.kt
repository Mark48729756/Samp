package com.embededly.Files

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.filter
import kotlin.math.abs

val TNUM = TextStyle(fontFeatureSettings = "tnum")

/**
 * Барабан выбора числа: бесконечная прокрутка с притягиванием к центру, тик вибрации на каждом числе,
 * соседние числа тают и размываются к краям. Значение сообщается, когда барабан остановился.
 */
@Composable
fun Wheel(
    count: Int, value: Int, modifier: Modifier = Modifier, rowH: Dp = 40.dp,
    fmt: (Int) -> String = { it.toString() }, fontSize: TextUnit = 26.sp, highlight: Boolean = true, fade: Float = .42f,
    onChange: (Int) -> Unit,
) {
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val base = 400 * count
    val st = rememberLazyListState(initialFirstVisibleItemIndex = base + value - 2)
    val fling = rememberSnapFlingBehavior(st, SnapPosition.Center)
    val onNow by rememberUpdatedState(onChange)
    fun centerIdx(): Int {
        val li = st.layoutInfo
        val mid = (li.viewportStartOffset + li.viewportEndOffset) / 2
        return li.visibleItemsInfo.minByOrNull { abs(it.offset + it.size / 2 - mid) }?.index ?: (base + value)
    }
    LaunchedEffect(value) {
        if (!st.isScrollInProgress && centerIdx() % count != value) st.scrollToItem(base + value - 2)
    }
    LaunchedEffect(Unit) {
        var last = -1
        snapshotFlow { centerIdx() }.collect { if (last != -1 && it != last) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); last = it }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { st.isScrollInProgress }.filter { !it }.collect { onNow(centerIdx() % count) }
    }
    Box(modifier.height(rowH * 5), contentAlignment = Alignment.Center) {
        if (highlight) Box(Modifier.fillMaxWidth().height(rowH).clip(RoundedCornerShape(12.dp)).background(pal.fg.copy(alpha = .08f)))
        LazyColumn(Modifier.fillMaxWidth(), state = st, flingBehavior = fling) {
            items(count = base * 2) { i ->
                Box(
                    Modifier.fillMaxWidth().height(rowH).graphicsLayer {
                        val li = st.layoutInfo
                        val inf = li.visibleItemsInfo.firstOrNull { it.index == i }
                        if (inf != null) {
                            val mid = (li.viewportStartOffset + li.viewportEndOffset) / 2f
                            val d = abs(inf.offset + inf.size / 2f - mid) / size.height
                            alpha = (1f - d * fade).coerceIn(.10f, 1f)
                            val s = (1f - d * .10f).coerceIn(.6f, 1f)
                            scaleX = s; scaleY = s
                            if (Build.VERSION.SDK_INT >= 31) {
                                val bl = ((d - .45f).coerceAtLeast(0f) * 5.5f * density).coerceAtMost(14f * density)
                                renderEffect = if (bl > .6f) BlurEffect(bl, bl, TileMode.Decal) else null
                            }
                        }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        fmt(i % count), color = pal.fg, softWrap = false, overflow = TextOverflow.Visible,
                        style = TNUM.copy(fontSize = fontSize, lineHeight = fontSize * 1.12f, fontWeight = FontWeight.Medium, color = pal.fg)
                    )
                }
            }
        }
    }
}

private fun edgeProximity(center: Float, vs: Float, ve: Float, topPx: Float, botPx: Float): Float {
    val pt = ((vs + topPx - center) / topPx).coerceIn(0f, 1f)
    val pb = ((center - (ve - botPx)) / botPx).coerceIn(0f, 1f)
    return maxOf(pt, pb)
}

private fun androidx.compose.ui.graphics.GraphicsLayerScope.applyEdge(p: Float) {
    alpha = 1f - .8f * p
    val s = 1f - .04f * p
    scaleX = s; scaleY = s
    if (Build.VERSION.SDK_INT >= 31) {
        val bl = p * 9f * density
        renderEffect = if (bl > .6f) BlurEffect(bl, bl, TileMode.Decal) else null
    }
}

/** Строка списка плавно тает и размывается у верхнего и нижнего края (как барабан). bottomPx — зона под доком. */
fun Modifier.edgeFade(st: LazyListState, key: Any, topPx: Float, bottomPx: Float): Modifier = this.graphicsLayer {
    val li = st.layoutInfo
    val inf = li.visibleItemsInfo.firstOrNull { it.key == key } ?: return@graphicsLayer
    val c = inf.offset + inf.size / 2f
    applyEdge(edgeProximity(c, li.viewportStartOffset.toFloat(), li.viewportEndOffset.toFloat(), topPx, bottomPx))
}

fun Modifier.edgeFadeGrid(st: LazyGridState, key: Any, topPx: Float, bottomPx: Float): Modifier = this.graphicsLayer {
    val li = st.layoutInfo
    val inf = li.visibleItemsInfo.firstOrNull { it.key == key } ?: return@graphicsLayer
    val c = inf.offset.y + inf.size.height / 2f
    applyEdge(edgeProximity(c, li.viewportStartOffset.toFloat(), li.viewportEndOffset.toFloat(), topPx, bottomPx))
}

/** Горизонтальное затухание по краям (полоса быстрых вкладок). */
fun Modifier.fadeEdgesH(widthPx: Float): Modifier = this
    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    .drawWithContent {
        drawContent()
        val w = size.width
        val f = (widthPx / w).coerceIn(0f, .45f)
        drawRect(
            Brush.horizontalGradient(0f to Color.Transparent, f to Color.Black, 1f - f to Color.Black, 1f to Color.Transparent),
            blendMode = BlendMode.DstIn
        )
    }
