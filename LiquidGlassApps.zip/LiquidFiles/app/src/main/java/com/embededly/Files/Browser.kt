package com.embededly.Files

import android.content.Context
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

class Clip(val items: List<FItem>, val move: Boolean)

sealed interface Viewer {
    class Images(val items: List<FItem>, val index: Int) : Viewer
    class Player(val item: FItem) : Viewer
    class Text(val item: FItem) : Viewer
}

fun parentOf(l: Loc): Loc? = when (l) {
    is Loc.Dir -> if (Env.isRoot(l.path) || l.path == "/") null else File(l.path).parent?.let { Loc.Dir(it) }
    is Loc.Cat -> Loc.Dir(Env.primaryRoot)
    is Loc.Zip -> if (l.inner.isEmpty()) File(l.zip).parent?.let { Loc.Dir(it) }
    else Loc.Zip(l.zip, l.inner.trimEnd('/').substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" })
}

fun downloadsPath(): String = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path

fun sortItems(list: List<FItem>, by: Int, desc: Boolean, foldersFirst: Boolean): List<FItem> {
    val cmp: Comparator<FItem> = when (by) {
        1 -> compareBy<FItem> { it.size }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        2 -> compareBy<FItem> { it.modified }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        3 -> compareBy<FItem> { it.ext }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        else -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
    }
    val c = if (desc) cmp.reversed() else cmp
    return if (foldersFirst) list.sortedWith(compareBy<FItem> { !it.dir }.then(c)) else list.sortedWith(c)
}

/** Состояние окна проводника: где мы, что показано, что выделено и что лежит в буфере. */
class Browser(val ctx: Context, val set: Settings, private val scope: CoroutineScope) {
    var loc by mutableStateOf(Loc.decode(set.lastLoc, Env.primaryRoot))
        private set
    var items by mutableStateOf<List<FItem>>(emptyList())
    var loading by mutableStateOf(false)
    var grantPath by mutableStateOf<String?>(null)
    var failed by mutableStateOf(false)
    var query by mutableStateOf("")
    var results by mutableStateOf<List<FItem>?>(null)
    var searching by mutableStateOf(false)
    var selected by mutableStateOf<Set<String>>(emptySet())
    var clip by mutableStateOf<Clip?>(null)
    var viewer by mutableStateOf<Viewer?>(null)
    var refresh by mutableIntStateOf(0)

    fun go(l: Loc) {
        selected = emptySet(); query = ""; results = null
        loc = l
        set.lastLoc = l.encode()
    }

    fun up(): Boolean {
        val p = parentOf(loc) ?: return false
        go(p)
        return true
    }

    val dirPath: String? get() = (loc as? Loc.Dir)?.path

    fun pathOf(it: FItem): String = if (it.src == Src.FS) it.id else (dirPath ?: "") + "/" + it.name

    suspend fun load() {
        val l = loc
        loading = true; failed = false; grantPath = null
        val r = withContext(Dispatchers.IO) {
            runCatching {
                when (l) {
                    is Loc.Dir -> listDir(l.path)
                    is Loc.Cat -> Listing.Ok(Media.query(l.cat, set.showHidden))
                    is Loc.Zip -> Listing.Ok(listZip(l.zip, l.inner))
                }
            }.getOrElse { Listing.Failed }
        }
        when (r) {
            is Listing.Ok -> items = r.items
            is Listing.NeedGrant -> { items = emptyList(); grantPath = r.path }
            Listing.Failed -> { items = emptyList(); failed = true }
        }
        loading = false
    }

    suspend fun search() {
        val q = query.trim()
        if (q.isEmpty()) { results = null; searching = false; return }
        delay(250)
        val l = loc
        searching = true
        results = emptyList()
        withContext(Dispatchers.IO) {
            val acc = ArrayList<FItem>()
            if (l is Loc.Dir && !isRestricted(l.path)) {
                val stack = ArrayDeque<File>()
                stack.add(File(l.path))
                var pub = 0
                while (stack.isNotEmpty() && acc.size < 1000) {
                    ensureActive()
                    val d = stack.removeLast()
                    val kids = d.listFiles() ?: continue
                    for (f in kids) {
                        if (!set.showHidden && f.name.startsWith(".")) continue
                        val dir = f.isDirectory
                        if (f.name.contains(q, ignoreCase = true)) {
                            acc.add(FItem(f.path, f.name, dir, if (dir) -1L else f.length(), f.lastModified(), Src.FS, f.parent))
                        }
                        if (dir && !isRestricted(f.path)) stack.add(f)
                    }
                    if (acc.size - pub >= 20) { pub = acc.size; results = acc.toList() }
                }
            } else {
                acc.addAll(items.filter { it.name.contains(q, ignoreCase = true) })
            }
            results = acc.toList()
        }
        searching = false
    }

    fun visible(): List<FItem> {
        val base = results ?: items
        val l = loc
        val list = if (set.showHidden) base else base.filter { !it.hidden }
        return if (l is Loc.Cat) list.sortedByDescending { it.modified } else sortItems(list, set.sortBy, set.sortDesc, set.foldersFirst)
    }

    fun toggle(id: String) { selected = if (id in selected) selected - id else selected + id }

    private fun after(res: Int, paths: List<String> = emptyList()) {
        if (res == Ops.FAILED) Act.toast(ctx, R.string.err_failed)
        refresh++
        if (paths.isNotEmpty()) scope.launch(Dispatchers.IO) { scanPaths(paths) }
    }

    fun copyToClip(list: List<FItem>, move: Boolean) { clip = Clip(list, move); selected = emptySet() }

    fun paste() {
        val c = clip ?: return
        val path = dirPath ?: return
        val dest = dirItemForPath(path) ?: return
        val scanList = ArrayList<String>()
        Ops.run(if (c.move) R.string.op_moving else R.string.op_copying, c.items.size, { res ->
            if (res == Ops.OK && c.move) clip = null
            after(res, scanList + c.items.filter { it.src == Src.FS }.map { it.id } + path)
        }) { job ->
            c.items.forEachIndexed { i, it ->
                Ops.done = i; Ops.current = it.name
                if (it.dir && isInside(it, dest)) throw IOException("into itself")
                if (c.move && it.src == Src.FS && dest.src == Src.FS && File(it.id).parent == dest.id) return@forEachIndexed
                val r = if (c.move) moveInto(it, dest, job) { n -> Ops.current = n } else copyInto(it, dest, job) { n -> Ops.current = n }
                if (r == null) throw IOException("failed")
            }
        }
    }

    fun delete(list: List<FItem>, permanent: Boolean) {
        selected = emptySet()
        Ops.run(R.string.op_deleting, list.size, { res -> after(res, list.filter { it.src == Src.FS }.map { it.id }) }) { _ ->
            list.forEachIndexed { i, it ->
                Ops.done = i; Ops.current = it.name
                val ok = if (!permanent && it.src == Src.FS) Trash.moveToTrash(File(it.id)) else deleteItem(it)
                if (!ok) throw IOException("failed")
            }
        }
    }

    fun zip(list: List<FItem>, name: String) {
        val path = dirPath ?: return
        val dest = dirItemForPath(path) ?: return
        selected = emptySet()
        Ops.run(R.string.op_zipping, 1, { res -> after(res, listOf(path)) }) { job ->
            val n = if (name.endsWith(".zip", true)) name else "$name.zip"
            if (zipInto(list, dest, n, job) { Ops.current = it } == null) throw IOException("failed")
        }
    }

    fun unzipHere(zipItem: FItem) {
        val parent = File(zipItem.id).parentFile ?: return
        selected = emptySet()
        Ops.run(R.string.op_unzipping, 1, { res -> after(res, listOf(parent.path)) }) { job ->
            val d = FItem(parent.path, parent.name, true, -1L, 0L)
            val out = File(parent, uniqueName(d, zipItem.name.substringBeforeLast('.'), true))
            unzipTo(zipItem.id, null, out, job) { Ops.current = it }
        }
    }

    fun unzipEntries(entries: List<FItem>) {
        val z = loc as? Loc.Zip ?: return
        val parent = File(z.zip).parentFile ?: return
        selected = emptySet()
        Ops.run(R.string.op_unzipping, 1, { res -> after(res, listOf(parent.path)) }) { job ->
            val d = FItem(parent.path, parent.name, true, -1L, 0L)
            val out = File(parent, uniqueName(d, File(z.zip).name.substringBeforeLast('.'), true))
            unzipTo(z.zip, entries.map { it.id }, out, job) { Ops.current = it }
        }
    }

    fun unzipAll() {
        val z = loc as? Loc.Zip ?: return
        unzipHere(FItem(z.zip, File(z.zip).name, false, 0L, 0L))
    }

    fun create(name: String, folder: Boolean) {
        val path = dirPath ?: return
        scope.launch(Dispatchers.IO) {
            val dest = dirItemForPath(path)
            val ok = dest != null && (if (folder) mkdir(dest, name) else createFile(dest, name)) != null
            withContext(Dispatchers.Main) { after(if (ok) Ops.OK else Ops.FAILED, listOf(path)) }
        }
    }

    fun rename(item: FItem, name: String) {
        scope.launch(Dispatchers.IO) {
            val ok = renameItem(item, name)
            withContext(Dispatchers.Main) {
                if (ok && item.src == Src.FS) {
                    val p = File(item.id).parent
                    if (p != null && set.isPinned(item.id)) set.renamePinPath(item.id, File(p, name).path)
                }
                results = null; query = ""
                after(if (ok) Ops.OK else Ops.FAILED, listOf(item.id, (File(item.id).parent ?: "") + "/" + name))
            }
        }
    }

    /** Открыть элемент: папка — зайти, архив — просмотреть, картинка/видео/текст — встроенный просмотр, остальное — внешнее приложение. */
    fun open(item: FItem) {
        val l = loc
        when {
            item.dir && item.src == Src.ZIP && l is Loc.Zip -> go(Loc.Zip(l.zip, item.id))
            item.dir -> go(Loc.Dir(pathOf(item)))
            item.src == Src.ZIP && l is Loc.Zip -> {
                var cached: FItem? = null
                Ops.run(R.string.op_unzipping, 1, { res ->
                    cached?.let { if (res == Ops.OK) open(it) }
                    if (res == Ops.FAILED) Act.toast(ctx, R.string.err_failed)
                }) { job ->
                    val f = unzipEntryToCache(l.zip, item.id, job)
                    cached = FItem(f.path, f.name, false, f.length(), f.lastModified())
                }
            }
            item.src == Src.FS && (item.ext == "zip" || item.ext == "jar") -> go(Loc.Zip(item.id, ""))
            item.kind == Kind.IMAGE -> {
                val imgs = visible().filter { it.kind == Kind.IMAGE && it.src == item.src }
                viewer = Viewer.Images(imgs, imgs.indexOfFirst { it.id == item.id }.coerceAtLeast(0))
            }
            item.kind == Kind.VIDEO || item.kind == Kind.AUDIO -> viewer = Viewer.Player(item)
            item.kind == Kind.TEXT && item.size in 0..2_000_000 -> viewer = Viewer.Text(item)
            else -> Act.open(ctx, item, false)
        }
    }

    fun showInFolder(item: FItem) {
        val p = File(item.id).parent ?: return
        go(Loc.Dir(p))
        selected = setOf(item.id)
    }
}
