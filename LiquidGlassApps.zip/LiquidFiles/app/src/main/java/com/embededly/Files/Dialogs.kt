package com.embededly.Files

import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** Поле ввода в стиле стекла (вместо Material TextField). */
@Composable
fun GlassField(value: TextFieldValue, hint: String, onChange: (TextFieldValue) -> Unit, onDone: () -> Unit = {}) {
    val pal = LocalPal.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(280); runCatching { fr.requestFocus() } }
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.fg.copy(alpha = .08f))
            .border(1.dp, Color.White.copy(alpha = rimAlpha() * .6f), RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 13.dp)
    ) {
        if (value.text.isEmpty()) Text(hint, color = pal.sub, fontSize = 17.sp)
        BasicTextField(
            value, { if (it.text.length <= 255) onChange(it) }, Modifier.fillMaxWidth().focusRequester(fr), singleLine = true,
            textStyle = TextStyle(color = pal.fg, fontSize = 17.sp), cursorBrush = SolidColor(pal.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { onDone() }),
        )
    }
}

@Composable
fun DialogTitle(text: String) {
    Text(text, color = LocalPal.current.fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, lineHeight = 25.sp)
}

/** Ввод имени: новая папка, новый файл, переименование, архив, вкладка. selectBase — выделить имя без расширения. */
@Composable
fun NameDialog(
    backdrop: Backdrop, title: String, initial: String, confirm: String, selectBase: Boolean = false,
    onOk: (String) -> Unit, onDismiss: () -> Unit,
) {
    val end = if (selectBase && initial.contains('.') && !initial.startsWith(".")) initial.lastIndexOf('.') else initial.length
    var tf by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, end))) }
    val ok = validName(tf.text.trim())
    DropWindow(backdrop, onDismiss) { close ->
        DialogTitle(title)
        GlassField(tf, "", { tf = it }) { if (ok) { onOk(tf.text.trim()); close() } }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(stringResource(R.string.act_cancel), Modifier.weight(1f), primary = false) { close() }
            GlassButton(confirm, Modifier.weight(1f), enabled = ok) { onOk(tf.text.trim()); close() }
        }
    }
}

/** Выбор из списка: сортировка, язык и т.п. */
@Composable
fun ChoiceDialog(backdrop: Backdrop, title: String, options: List<String>, selected: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    DropWindow(backdrop, onDismiss) { close ->
        DialogTitle(title)
        Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
            options.forEachIndexed { i, o ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .clickable(remember { MutableInteractionSource() }, null) { onPick(i); close() }
                        .padding(horizontal = 12.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(o, color = if (i == selected) pal.accent else pal.fg, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    if (i == selected) Icon(Icons.Filled.Check, null, tint = pal.accent, modifier = Modifier.size(20.dp))
                }
            }
        }
        GlassButton(stringResource(R.string.act_cancel), Modifier.fillMaxWidth().padding(top = 2.dp), primary = false) { close() }
    }
}

class ActionRow(val icon: ImageVector, val label: String, val danger: Boolean = false, val onClick: () -> Unit)

/** Контекстное меню-капля: вылетает из точки долгого нажатия. */
@Composable
fun ActionsDialog(backdrop: Backdrop, title: String, actions: List<ActionRow>, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    DropWindow(backdrop, onDismiss) { close ->
        Text(title, color = pal.fg, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 22.sp)
        Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
            actions.forEach { a ->
                val col = if (a.danger) Danger else pal.fg
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .clickable(remember { MutableInteractionSource() }, null) { close(); a.onClick() }
                        .padding(horizontal = 10.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(a.icon, null, tint = col, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(a.label, color = col, fontSize = 17.sp, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun PropLine(label: String, value: String) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, color = pal.sub, fontSize = 13.sp)
        Text(value, color = pal.fg, fontSize = 16.sp, lineHeight = 20.sp)
    }
}

private fun typeRes(k: Kind): Int = when (k) {
    Kind.FOLDER -> R.string.type_folder
    Kind.IMAGE -> R.string.type_image
    Kind.VIDEO -> R.string.type_video
    Kind.AUDIO -> R.string.type_audio
    Kind.DOC -> R.string.type_doc
    Kind.TEXT -> R.string.type_text
    Kind.ARCHIVE -> R.string.type_archive
    Kind.APK -> R.string.type_apk
    Kind.OTHER -> R.string.type_file
}

/** Свойства одного или нескольких объектов; размер папок считается в фоне. */
@Composable
fun PropsDialog(backdrop: Backdrop, items: List<FItem>, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]
    val df = remember(locale) { dateFormat(locale) }
    var rows by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    LaunchedEffect(items) {
        val calc = ctx.getString(R.string.props_calculating)
        fun base(size: String, extra: List<Pair<String, String>>): List<Pair<String, String>> {
            if (items.size > 1) return listOf(
                ctx.getString(R.string.props_items) to items.size.toString(),
                ctx.getString(R.string.props_size) to size
            )
            val it = items[0]
            val list = ArrayList<Pair<String, String>>()
            list.add(ctx.getString(R.string.props_name) to it.name)
            if (it.src == Src.FS) list.add(ctx.getString(R.string.props_path) to (File(it.id).parent ?: ""))
            else if (it.sub != null) list.add(ctx.getString(R.string.props_path) to it.sub)
            val t = ctx.getString(typeRes(it.kind)) + (if (!it.dir && it.ext.isNotEmpty()) " (" + it.ext.uppercase() + ")" else "")
            list.add(ctx.getString(R.string.props_type) to t)
            list.add(ctx.getString(R.string.props_size) to size)
            if (it.modified > 0) list.add(ctx.getString(R.string.props_modified) to fmtDate(df, it.modified))
            if (it.src == Src.FS) {
                val f = File(it.id)
                list.add(ctx.getString(R.string.props_access) to ctx.getString(if (f.canWrite()) R.string.access_rw else R.string.access_ro))
            }
            list.addAll(extra)
            return list
        }
        rows = base(calc, emptyList())
        val result = withContext(Dispatchers.IO) {
            var total = 0L
            var count = 0
            for (i in items) { val (s, c) = measure(i); total += s; count += c }
            val extra = ArrayList<Pair<String, String>>()
            if (items.size == 1 && items[0].src == Src.FS && !items[0].dir) {
                val it = items[0]
                runCatching {
                    if (it.kind == Kind.IMAGE) {
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(it.id, o)
                        if (o.outWidth > 0) extra.add(ctx.getString(R.string.props_dims) to "${o.outWidth} × ${o.outHeight}")
                    } else if (it.kind == Kind.VIDEO || it.kind == Kind.AUDIO) {
                        val r = MediaMetadataRetriever()
                        try {
                            r.setDataSource(it.id)
                            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull()
                            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                            if (w != null && h != null) extra.add(ctx.getString(R.string.props_dims) to "$w × $h")
                            if (d != null) extra.add(ctx.getString(R.string.props_duration) to fmtDuration(d))
                        } finally { r.release() }
                    }
                }
            }
            Triple(total, count, extra)
        }
        val sizeText = fmtSize(ctx, result.first) + (if (items.any { it.dir }) "  ·  " + ctx.getString(R.string.items_n, result.second) else "")
        rows = base(sizeText, result.third)
    }
    DropWindow(backdrop, onDismiss) { close ->
        DialogTitle(stringResource(R.string.act_props))
        Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
            rows.forEach { (l, v) -> PropLine(l, v) }
        }
        GlassButton(stringResource(R.string.act_ok), Modifier.fillMaxWidth().padding(top = 2.dp)) { close() }
    }
}

/** Окно прогресса долгой операции; кнопка «Отмена» останавливает её. */
@Composable
fun ProgressDialog(backdrop: Backdrop, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    DropWindow(backdrop, onDismiss) { close ->
        DialogTitle(if (Ops.title != 0) stringResource(Ops.title) else "")
        Text(Ops.current, color = pal.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        val frac = (Ops.done.toFloat() / Ops.total).coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(pal.fg.copy(alpha = .14f))) {
            Box(Modifier.fillMaxWidth(if (frac < .04f) .04f else frac).height(8.dp).clip(CircleShape).background(pal.accent))
        }
        GlassButton(stringResource(R.string.act_cancel), Modifier.fillMaxWidth().padding(top = 4.dp), primary = false) { Ops.cancel(); close() }
    }
}

/** Выбор числа барабаном (срок хранения корзины). */
@Composable
fun WheelDialog(backdrop: Backdrop, title: String, count: Int, value: Int, fmt: (Int) -> String, onOk: (Int) -> Unit, onDismiss: () -> Unit) {
    var v by remember { mutableIntStateOf(value) }
    DropWindow(backdrop, onDismiss) { close ->
        DialogTitle(title)
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Wheel(count, v, Modifier.width(140.dp), rowH = 44.dp, fmt = fmt, fontSize = 28.sp) { v = it }
        }
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(stringResource(R.string.act_cancel), Modifier.weight(1f), primary = false) { close() }
            GlassButton(stringResource(R.string.act_ok), Modifier.weight(1f)) { onOk(v); close() }
        }
    }
}

/** Сортировка: поле, направление и «папки сверху» применяются сразу. */
@Composable
fun SortDialog(backdrop: Backdrop, set: Settings, onDismiss: () -> Unit) {
    val pal = LocalPal.current
    val names = listOf(R.string.sort_name, R.string.sort_size, R.string.sort_date, R.string.sort_type)
    DropWindow(backdrop, onDismiss) { close ->
        DialogTitle(stringResource(R.string.s_sort))
        names.forEachIndexed { i, r ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .clickable(remember { MutableInteractionSource() }, null) { set.sortBy = i }
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(r), color = if (set.sortBy == i) pal.accent else pal.fg, fontSize = 17.sp, modifier = Modifier.weight(1f))
                if (set.sortBy == i) Icon(Icons.Filled.Check, null, tint = pal.accent, modifier = Modifier.size(20.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.s_desc), color = pal.fg, fontSize = 17.sp, modifier = Modifier.weight(1f))
            GlassSwitch(set.sortDesc) { set.sortDesc = it }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.s_folders_first), color = pal.fg, fontSize = 17.sp, modifier = Modifier.weight(1f))
            GlassSwitch(set.foldersFirst) { set.foldersFirst = it }
        }
        GlassButton(stringResource(R.string.act_ok), Modifier.fillMaxWidth().padding(top = 4.dp)) { close() }
    }
}
