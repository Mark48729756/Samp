package com.embededly.Files

import androidx.compose.ui.graphics.drawscope.clipPath
import kotlin.math.ceil
import kotlin.math.sqrt
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

private val DOCK_H = 64.dp
private val SEG_MIN = 86.dp

class DockTab(val icon: ImageVector, val label: String)
private const val LENS_GROW = .30f

/**
 * Стеклянный док с каплей-линзой, как в Галерее: капля растёт под пальцем, чуть выступает за границы дока,
 * искажает иконки и пружинит между вкладками. Вкладок несколько — капля тянется за пальцем и подхватывает ближайшую.
 */
@Composable
fun GlassDock(backdrop: Backdrop, tab: Int, tabsIn: List<DockTab>, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    // док всегда считаем слева направо; для RTL просто переворачиваем порядок вкладок
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        DockBody(backdrop, if (rtl) tabsIn.size - 1 - tab else tab, if (rtl) tabsIn.reversed() else tabsIn,
            { onTab(if (rtl) tabsIn.size - 1 - it else it) }, modifier)
    }
}

@Composable
private fun DockBody(backdrop: Backdrop, tab: Int, tabs: List<DockTab>, onTab: (Int) -> Unit, modifier: Modifier) {
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val n = tabs.size
    val dens = LocalDensity.current
    // капля должна быть шире самой длинной подписи: ширина сегмента считается по тексту, а если не влезает в экран — подпись уменьшается
    val measurer = rememberTextMeasurer()
    val availPx = with(dens) { (LocalConfiguration.current.screenWidthDp.dp - 24.dp).toPx() }
    val padPx = with(dens) { 14.dp.toPx() }
    val minSegPx = with(dens) { SEG_MIN.toPx() }
    val labels = tabs.map { it.label }
    val labelW = remember(labels, dens.density, dens.fontScale) {
        labels.maxOf { measurer.measure(it, TextStyle(fontSize = 12.sp), maxLines = 1, softWrap = false).size.width }
    }
    val wantSeg = maxOf(minSegPx, labelW + 2 * padPx)
    val segPx = minOf(wantSeg, availPx / n)
    val fitScale = ((segPx - 2 * padPx) / labelW).coerceIn(.62f, 1f)
    val labelSp = 12f * fitScale
    val segDp = with(dens) { segPx.toDp() }
    val dockHPx = with(dens) { DOCK_H.toPx() }
    val dropInsetPx = with(dens) { 3.dp.toPx() }
    val bulgePx = with(dens) { 5.dp.toPx() }
    val bulgeXPx = with(dens) { 4.dp.toPx() }
    val scope = rememberCoroutineScope()
    val pos = remember { Animatable(tab.toFloat()) }
    var pressed by remember { mutableStateOf(false) }
    val spec: AnimationSpec<Float> = spring(.62f, 420f)
    // за пальцем капля идёт на мягкой пружине и чуть запаздывает — отсюда ощущение массы
    val dragSpec: AnimationSpec<Float> = spring(.78f, 560f)
    var lift by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (lift) LENS_GROW else 0f, spring(.52f, 330f), label = "grow")
    // искажение иконок внутри капли держится минимум ~170 мс после отпускания и плавно гаснет
    var distortOn by remember { mutableStateOf(false) }
    val distort by animateFloatAsState(
        if (distortOn) 1f else 0f,
        if (distortOn) spring(.8f, 700f) else tween(300, easing = FastOutSlowInEasing), label = "distort"
    )
    // «Вес» капли. Скорость считается по кадрам, а пружина растяжения интегрируется вручную в одном цикле по кадрам.
    // (animateTo на каждый кадр здесь нельзя: каждый перезапуск пропускает первый кадр, и значение вообще не двигается.)
    // Рывок растягивает каплю по ходу движения, при остановке она чуть перелетает и желейно оседает.
    val stretchF = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var st = 0f; var sv = 0f; var vs = 0f
        var lastX = pos.value
        var lastNs = 0L
        while (true) {
            if (!pos.isRunning && abs(st) < .003f && abs(sv) < .03f) {
                st = 0f; sv = 0f; vs = 0f; lastNs = 0L
                stretchF.floatValue = 0f
                snapshotFlow { pos.isRunning }.first { it } // спим, пока капля не тронется — в покое кадры не заказываем
                lastX = pos.value
            }
            val ns = withFrameNanos { it }
            if (lastNs == 0L) { lastNs = ns; lastX = pos.value; continue }
            val dt = ((ns - lastNs) / 1e9f).coerceIn(.004f, .033f)
            lastNs = ns
            val x = pos.value
            val vel = (x - lastX) / dt // сегментов в секунду
            lastX = x
            vs += (vel - vs) * .5f // сглаживание шума от неровных интервалов между кадрами
            val target = if (abs(vs) < .25f) 0f else (vs / 9f).coerceIn(-1f, 1f)
            val k = 450f
            val c = 2f * .5f * sqrt(k) // пружина: жёсткость 450, демпфирование .5 — один небольшой «доезд»
            val steps = ceil(dt / .004f).toInt().coerceAtLeast(1)
            val h = dt / steps
            repeat(steps) { sv += (-k * (st - target) - c * sv) * h; st += sv * h }
            stretchF.floatValue = st
        }
    }
    val onTabNow by rememberUpdatedState(onTab)

    LaunchedEffect(tab) { if (!pressed) pos.animateTo(tab.toFloat(), spec) }

    /** Прямоугольник капли в координатах дока: растёт от своего центра. */
    fun dropRect(): Rect {
        val w0 = segPx * (1f + grow) - dropInsetPx * 2f
        val open = (grow / LENS_GROW).coerceIn(0f, 1f)
        val restH = dockHPx - dropInsetPx * 2f
        val h0 = restH + (dockHPx + 2f * bulgePx - restH) * open
        val bx = bulgeXPx * open
        // растяжение по ходу движения (объём «сохраняется»): ведущий край идёт за пальцем, хвост отстаёт
        val s = stretchF.floatValue
        val a = abs(s).coerceAtMost(1.3f)
        val w = w0 * (1f + .18f * a)
        val h = h0 * (1f - .06f * a)
        val x0 = (pos.value * segPx - (w0 - segPx) / 2f).coerceIn(-bx, (segPx * n - w0 + bx).coerceAtLeast(-bx))
        val x = (if (s >= 0f) x0 + w0 - w else x0).coerceIn(-bx, (segPx * n - w + bx).coerceAtLeast(-bx))
        val y = (dockHPx - h) / 2f
        return Rect(x, y, x + w, y + h)
    }

    val idle = pal.fg.copy(alpha = .85f)
    val dockSurface = lerp(pal.glass, Color.Black, if (pal.dark) .15f else 0f).copy(alpha = if (pal.dark) .5f else .62f)

    Box(
        modifier.size(segDp * n, DOCK_H)
            .pointerInput(segPx, spec) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    pressed = true; distortOn = true; lift = true
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    var x = down.position.x
                    fun target() = (x / segPx - .5f).coerceIn(0f, (n - 1).toFloat())
                    scope.launch { pos.animateTo(target(), spec) }
                    drag(down.id) { ch ->
                        x = ch.position.x
                        scope.launch { pos.animateTo(target(), dragSpec) }
                        ch.consume()
                    }
                    val t = target().roundToInt()
                    pressed = false
                    scope.launch { delay(170); if (!pressed) distortOn = false }
                    scope.launch { pos.animateTo(t.toFloat(), spec) }
                    scope.launch { delay(220); if (!pressed) lift = false }
                    onTabNow(t)
                }
            }
    ) {
        val open = (grow / LENS_GROW).coerceIn(0f, 1f)
        // В покое капля — просто стеклянная «таблетка»: ничего не преломляет и не вырезает. Линза и копия иконок плавно включаются при нажатии.
        val ramp = (open * 5f).coerceIn(0f, 1f)
        // Ряд иконок: основной (overlay=false) и такой же поверх капли (overlay=true) — там активная иконка чуть крупнее.
        @Composable
        fun IconsRow(overlay: Boolean) {
            Row(Modifier.fillMaxSize()) {
                tabs.forEachIndexed { i, t ->
                val icon = t.icon
                val label = t.label
                    val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                    val col = lerp(idle, pal.fg, k)
                    Column(
                        Modifier.weight(1f).fillMaxHeight().graphicsLayer {
                            // иконка и подпись «выходят» из капли: под ней чуть растут и приподнимаются
                            val sc = 1f + (if (overlay) .22f else .16f) * k * open
                            scaleX = sc; scaleY = sc
                            translationY = -3.dp.toPx() * k * open
                            if (overlay) alpha = ramp
                        },
                        Arrangement.Center, Alignment.CenterHorizontally
                    ) {
                        Icon(icon, null, tint = col, modifier = Modifier.size(25.dp))
                        Text(label, color = col, fontSize = labelSp.sp, lineHeight = (labelSp + 1f).sp, maxLines = 1, softWrap = false, overflow = TextOverflow.Visible, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        // 1) основа дока: стеклянная панель + иконки.
        // Внешний слой вырезает дырку под каплей — иначе оригинальные иконки видны сквозь стекло и «двоятся».
        // В dockBackdrop НЕ рисуется ничего видимого: это невидимая копия дока (alpha 0) только для капли.
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .drawWithContent {
                    drawContent()
                    val r = dropRect().deflate(1f)
                    if (ramp > 0f) drawRoundRect(Color.Black.copy(alpha = ramp), r.topLeft, r.size, CornerRadius(minOf(r.width, r.height) / 2f), blendMode = BlendMode.DstOut)
                }
        ) {
            Box(
                Modifier.fillMaxSize().glass(backdrop, CircleShape, dockSurface, 8f, 10f, 16f)
                    .border(1.dp, Color.White.copy(alpha = rimAlpha()), CircleShape)
            )
            IconsRow(false)
        }
        // 2) капля: одна линза над «фон экрана + копия дока» — фон и док искажаются вместе, иконки видны всегда.
        // Размер и положение — через layout (не scale), иначе backdrop считает координаты без учёта масштаба.
        Box(Modifier.fillMaxSize().wrapContentSize(Alignment.TopStart, unbounded = true)) {
            val refH = 9f * (1f + open * .15f)
            val refA = 14f * (1f + open * .25f)
            Box(
                Modifier
                    .offset { val r = dropRect(); IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                    .layout { measurable, _ ->
                        val r = dropRect()
                        val w = r.width.roundToInt().coerceAtLeast(1)
                        val h = r.height.roundToInt().coerceAtLeast(1)
                        val pl = measurable.measure(Constraints.fixed(w, h))
                        layout(w, h) { pl.place(0, 0) }
                    }
            ) {
                // в покое — просто матовая «таблетка» без преломления: страница и иконки за ней не просвечивают и не отражаются
                Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = .08f * (1f - ramp)), CircleShape))
                // капля: линза над фоном экрана — тот же рецепт, что у панели дока (она отрисовывается нормально); иконки рисуются поверх, отдельно
                if (open > .01f) Box(
                    Modifier.fillMaxSize().graphicsLayer { alpha = ramp }.drawBackdrop(
                        backdrop, { CircleShape },
                        effects = { blur(2.dp.toPx() * open); lens(refH.dp.toPx() * ramp, refA.dp.toPx() * ramp, chromaticAberration = open > .35f) },
                        onDrawSurface = { drawRect(Color.White.copy(alpha = .10f * open)) }
                    )
                )
                Box(Modifier.fillMaxSize().border(1.dp, Color.White.copy(alpha = .12f + .30f * open), CircleShape))
            }
        }
        // иконки поверх капли (только внутри неё): не зависят от слоя-копии и не преломляются
        Box(Modifier.fillMaxSize().drawWithContent {
            if (ramp <= 0f) return@drawWithContent
            val r = dropRect()
            val path = androidx.compose.ui.graphics.Path().apply {
                addRoundRect(androidx.compose.ui.geometry.RoundRect(r, CornerRadius(minOf(r.width, r.height) / 2f)))
            }
            clipPath(path) { this@drawWithContent.drawContent() }
        }) { IconsRow(true) }
    }
}

