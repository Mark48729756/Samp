# LiquidFiles (com.embededly.Files)
Проводник в стиле «жидкое стекло»: Kotlin + Jetpack Compose + Kyant0/AndroidLiquidGlass, minSdk 29, targetSdk 36.

- Полный доступ к файлам (MANAGE_EXTERNAL_STORAGE; на Android 10 — классические разрешения).
- Android/data и Android/obb: на Android 11–12 через системный выбор папки (SAF), на Android 13+ система закрывает эти папки для всех приложений.
- Строки только в ресурсах `values-xx/strings.xml`; язык системы подхватывается сам, выбор в настройках необязателен.
- Keystore: `keystore/files-release.jks`, alias `files`.
